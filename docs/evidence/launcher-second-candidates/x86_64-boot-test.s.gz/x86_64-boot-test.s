	.att_syntax
	.file	"hematite.d1f4d7a3273d84e0-cgu.0"


	# SAFETY: This entire entry shim executes only under the PVH boot contract.
	# It owns linker-reserved BSS, tables and stack. No safe callers enter it.
	# See docs/design/0001-bootstrap.md and its independent review.
	.section	.note.Xen,"a",@note
	.p2align	2, 0x0
	.long	4
	.long	4
	.long	18
	.ascii	"Xen"
	.byte	0
	.p2align	2, 0x0
	.long	start32

	.section	.text.boot,"ax",@progbits
	.code32
	.globl	start32
start32:
	cli
	cld
	movl	%ebx, %esi	# Preserve PVH start-info address.
	movl	$__stack_top, %esp	# No stack use until BSS cleared.
	xorl	%eax, %eax
	movl	$__bss_start, %edi
	movl	$__bss_end, %ecx
	subl	%edi, %ecx
	shrl	$2, %ecx
	rep		stosl	%eax, %es:(%edi)

	xorl	%eax, %eax
	cpuid
	cmpl	$7, %eax
	jb	boot_fail
	movl	$1, %eax
	cpuid
	andl	$117440512, %edx	# FXSR, SSE, SSE2.
	cmpl	$117440512, %edx
	jne	boot_fail
	movl	$7, %eax
	xorl	%ecx, %ecx
	cpuid
	andl	$1048704, %ebx	# SMEP and SMAP.
	cmpl	$1048704, %ebx
	jne	boot_fail
	movl	$2147483648, %eax
	cpuid
	cmpl	$2147483649, %eax
	jb	boot_fail
	movl	$2147483649, %eax
	cpuid
	andl	$537919488, %edx	# Long mode and NX.
	cmpl	$537919488, %edx
	jne	boot_fail

	movl	$pdpt, %eax
	orl	$3, %eax
	movl	%eax, pml4
	movl	$page_directory, %eax
	orl	$3, %eax
	movl	%eax, pdpt
	movl	$page_directory, %edi
	movl	$page_tables, %eax
	orl	$3, %eax
	movl	$8, %ecx	# Eight PTs map 16 MiB in 4 KiB pages.
.Ltmp0:
	movl	%eax, (%edi)
	addl	$4096, %eax
	addl	$8, %edi
	loop	.Ltmp0

	movl	$page_tables, %edi
	xorl	%ecx, %ecx
.Ltmp1:
	movl	%ecx, %eax
	shll	$12, %eax
	testl	%eax, %eax
	je	.Ltmp2	# Null page stays absent.
	cmpl	$__stack_guard, %eax
	je	.Ltmp2
	movl	$2147483648, %edx	# NX high dword by default.
	cmpl	$__text_start, %eax
	jb	.Ltmp3
	cmpl	$__text_end, %eax
	jae	.Ltmp4
	xorl	%edx, %edx	# Text: RX, supervisor, no write.
	orl	$1, %eax
	jmp	.Ltmp5
.Ltmp4:
	cmpl	$__rodata_start, %eax
	jb	.Ltmp3
	cmpl	$__rodata_end, %eax
	jae	.Ltmp3
	orl	$1, %eax	# Rodata: R/NX.
	jmp	.Ltmp5
.Ltmp3:
	orl	$3, %eax	# Other RAM: RW/NX.
	jmp	.Ltmp5
.Ltmp2:
	xorl	%eax, %eax
	xorl	%edx, %edx
.Ltmp5:
	movl	%eax, (%edi)
	movl	%edx, 4(%edi)
	addl	$8, %edi
	incl	%ecx
	cmpl	$4096, %ecx
	jb	.Ltmp1

	lgdtl	gdt_pointer
	movl	$3147296, %eax	# PAE, OSFXSR, OSXMMEXCPT, SMEP, SMAP.
	movl	%eax, %cr4
	movl	$pml4, %eax
	movl	%eax, %cr3
	movl	$3221225600, %ecx
	rdmsr
	orl	$2304, %eax	# LME and NXE.
	wrmsr
	movl	%cr0, %eax
	andl	$4294967283, %eax	# Clear EM/TS.
	orl	$2147549219, %eax	# Paging, WP, PE, MP.
	movl	%eax, %cr0
	.byte	234
	.long	long_mode	# Far jump to 64-bit code selector.
	.short	8

boot_fail:
	movw	$244, %dx
	movl	$17, %eax
	outl	%eax, %dx
.Ltmp6:
	cli
	hlt
	jmp	.Ltmp6

	.code64
long_mode:
	movw	$16, %ax
	movw	%ax, %ds
	movw	%ax, %es
	movw	%ax, %ss
	xorl	%eax, %eax
	movw	%ax, %fs
	movw	%ax, %gs
	leaq	__stack_top(%rip), %rsp
	xorl	%ebp, %ebp
	clac
	fninit
	ldmxcsr	initial_mxcsr(%rip)
	movl	%esi, %edi
	callq	_RNvCsi1ALLKoImom_8hematite9boot_main
	ud2

	.section	.rodata.boot,"a",@progbits
	.p2align	3, 0x0
gdt:
	.quad	0
	.quad	49428545226735615
	.quad	58426948388454399	# Accessed bit pre-set: no CPU write to RO GDT.
gdt_pointer:
	.short	23
	.long	gdt
initial_mxcsr:
	.long	8064

	.section	.bss.tables,"aw",@nobits
	.p2align	12, 0x0
	.globl	pml4
	.globl	pdpt
	.globl	page_directory
	.globl	page_tables
pml4:
	.zero	4096
pdpt:
	.zero	4096
page_directory:
	.zero	4096
page_tables:
	.zero	32768



	.section	.text._RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBE_,"ax",@progbits
	.prefalign	4, .Lfunc_end0, nop
	.type	_RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBE_,@function
_RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBE_:
.Lfunc_begin0:
	.cfi_sections .debug_frame
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$824, %rsp
	.cfi_def_cfa_offset 29552
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	#APP

	movq	%cr0, %r13

	#NO_APP
	#APP

	movq	%cr3, %rsi

	#NO_APP
	#APP

	movq	%cr4, %rax

	#NO_APP
	movq	%rax, 168(%rsp)
	movl	$-1073741696, %ecx
	#APP

	rdmsr

	#NO_APP
	movl	%eax, 144(%rsp)
	movq	$pml4, %rax
	xorq	%rsi, %rax
	movq	pml4(%rip), %rcx
	andq	$-97, %rcx
	movq	$pdpt+3, %rdx
	xorq	%rcx, %rdx
	movq	pdpt(%rip), %rcx
	andq	$-97, %rcx
	movq	$page_directory+3, %rdi
	xorq	%rcx, %rdi
	orq	%rdx, %rdi
	orq	%rax, %rdi
	sete	%dil
	movl	$2, %ecx
	movq	$-8, %rdx
	.p2align	4
.LBB0_1:
	movq	pml4(%rdx,%rcx,8), %rax
	orq	pdpt(%rdx,%rcx,8), %rax
	sete	%al
	andb	%dil, %al
	cmpq	$512, %rcx
	je	.LBB0_3
	movq	pml4(,%rcx,8), %rdi
	orq	pdpt(,%rcx,8), %rdi
	sete	%dil
	andb	%dil, %al
	addq	$2, %rcx
	movl	%eax, %edi
	jmp	.LBB0_1
.LBB0_3:
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	.p2align	4
.LBB0_4:
	movq	page_directory+64(,%rdx,8), %rdi
	movq	page_directory+72(,%rdx,8), %r8
	orq	%rdi, %r8
	movq	page_directory+80(,%rdx,8), %rdi
	orq	page_directory+88(,%rdx,8), %rdi
	movzbl	%al, %eax
	orq	%r8, %rdi
	cmovnel	%ecx, %eax
	addq	$4, %rdx
	cmpq	$504, %rdx
	jne	.LBB0_4
	movq	page_directory(%rip), %r10
	movq	page_directory+8(%rip), %r11
	movq	page_directory+16(%rip), %rbx
	movq	page_directory+24(%rip), %r9
	movq	page_directory+32(%rip), %r8
	movq	page_directory+40(%rip), %rdi
	movq	page_directory+48(%rip), %rdx
	movq	page_directory+56(%rip), %r14
	andq	$-97, %r14
	movq	$page_tables+28675, %rcx
	xorq	%r14, %rcx
	andq	$-97, %r10
	movq	$page_tables+3, %r14
	xorq	%r10, %r14
	andq	$-97, %r11
	movq	$page_tables+4099, %r10
	xorq	%r11, %r10
	orq	%r14, %r10
	andq	$-97, %rbx
	movq	$page_tables+8195, %r11
	xorq	%rbx, %r11
	andq	$-97, %r9
	movq	$page_tables+12291, %rbx
	xorq	%r9, %rbx
	orq	%r11, %rbx
	orq	%r10, %rbx
	andq	$-97, %r8
	movq	$page_tables+16387, %r9
	xorq	%r8, %r9
	andq	$-97, %rdi
	movq	$page_tables+20483, %r8
	xorq	%rdi, %r8
	orq	%r9, %r8
	andq	$-97, %rdx
	movq	$page_tables+24579, %rdi
	xorq	%rdx, %rdi
	orq	%r8, %rdi
	orq	page_tables(%rip), %rcx
	orq	%rbx, %rdi
	movzbl	%al, %ebp
	xorl	%eax, %eax
	orq	%rdi, %rcx
	cmovnel	%eax, %ebp
	movl	$1, %ecx
	movq	$page_tables+8, %rdx
	movl	$4097, %edi
	movq	$__stack_guard, %r8
	movl	$3, %r9d
	movabsq	$-9223372036854775808, %r10
	jmp	.LBB0_8
	.p2align	4
.LBB0_6:
	andq	$-97, %r11
	cmpq	%r14, %r11
	sete	%r11b
	movl	%r12d, %ebp
.LBB0_7:
	movzbl	%bpl, %ebp
	testb	%r11b, %r11b
	cmovel	%eax, %ebp
	addq	$8, %rdx
	addq	$4096, %rdi
	incq	%rcx
	cmpq	$16777217, %rdi
	je	.LBB0_12
.LBB0_8:
	movq	%rdi, %rbx
	subq	%r8, %rbx
	movq	(%rdx), %r11
	cmpq	$1, %rbx
	jne	.LBB0_10
	testq	%r11, %r11
	sete	%r11b
	jmp	.LBB0_7
	.p2align	4
.LBB0_10:
	movl	%ebp, %r12d
	leaq	-1(%rdi), %rbx
	cmpq	$__text_start, %rbx
	setae	%bpl
	cmpq	$__text_end, %rbx
	setb	%r15b
	movq	%rdi, %r14
	testb	%r15b, %bpl
	jne	.LBB0_6
	movq	%rcx, %r15
	shlq	$12, %r15
	xorl	%r14d, %r14d
	cmpq	$__rodata_end, %rbx
	setae	%r14b
	cmpq	$__rodata_start, %rbx
	leaq	1(%r14,%r14), %r14
	cmovbq	%r9, %r14
	orq	%r15, %r14
	orq	%r10, %r14
	jmp	.LBB0_6
.LBB0_12:
	cmpq	$pml4, %rsi
	sete	%cl
	movq	$__stack_guard, %rax
	cmpq	$16777216, %rax
	setb	%dl
	testb	%cl, %dl
	je	.LBB0_14
	shrq	$12, %rax
	cmpq	$0, page_tables(,%rax,8)
	sete	%al
	movl	%eax, 148(%rsp)
	jmp	.LBB0_15
.LBB0_14:
	movl	$0, 148(%rsp)
	movl	$0, %eax
	cmpq	$pml4, %rsi
	jne	.LBB0_16
.LBB0_15:
	cmpq	$0, page_tables(%rip)
	sete	%al
.LBB0_16:
	movl	%eax, 192(%rsp)
	shrl	$16, %r13d
	andb	$1, %r13b
	movq	%r13, 224(%rsp)
	movl	144(%rsp), %r12d
	shrl	$11, %r12d
	andb	$1, %r12b
	movl	%r12d, 144(%rsp)
	movq	168(%rsp), %r12
	movl	%r12d, %eax
	shrl	$20, %eax
	andb	$1, %al
	movl	%eax, 188(%rsp)
	shrl	$21, %r12d
	andb	$1, %r12b
	movq	%r12, 168(%rsp)
	movw	$0, 352(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 280(%rsp)
	movl	$3, %eax
.LBB0_17:
	cmpb	$0, 352(%rsp)
	jne	.LBB0_23
	movb	$120, 277(%rsp,%rax)
	cmpb	$0, 352(%rsp)
	jne	.LBB0_23
	movb	$120, 278(%rsp,%rax)
	cmpb	$0, 352(%rsp)
	jne	.LBB0_23
	movb	$120, 279(%rsp,%rax)
	cmpb	$0, 352(%rsp)
	jne	.LBB0_23
	movb	$120, 280(%rsp,%rax)
	addq	$4, %rax
	cmpq	$67, %rax
	jne	.LBB0_17
	cmpb	$0, 352(%rsp)
	je	.LBB0_1766
.LBB0_23:
	movl	$0, 132(%rsp)
.LBB0_24:
	movl	$96, %eax
	.p2align	4
.LBB0_25:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB0_25
	xorl	%eax, %eax
	.p2align	4
.LBB0_27:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_27
	xorl	%eax, %eax
	.p2align	4
.LBB0_29:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_29
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %r12
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%r12
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r12
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r12
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r12
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	movl	%ebp, 196(%rsp)
	jmp	.LBB0_32
	.p2align	4
.LBB0_31:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB0_229
.LBB0_32:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB0_34
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB0_37
.LBB0_34:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_31
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_31
	incq	%rax
.LBB0_37:
	movl	$4680, %edx
	leaq	4888(%rsp), %rcx
	xorl	%r11d, %r11d
	jmp	.LBB0_39
	.p2align	4
.LBB0_38:
	addq	$2, %r11
	addq	$80, %rdx
	cmpq	$9800, %rdx
	je	.LBB0_229
.LBB0_39:
	cmpb	$2, 233(%rsp,%rdx)
	jne	.LBB0_41
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB0_44
.LBB0_41:
	cmpb	$2, 273(%rsp,%rdx)
	jne	.LBB0_38
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB0_38
	incq	%r11
.LBB0_44:
	movq	%rax, %rdx
	shlq	$5, %rdx
	movl	304(%rsp,%rdx), %esi
	movq	$1, 280(%rsp,%rdx)
	movq	$16, 288(%rsp,%rdx)
	movb	$0, 296(%rsp,%rdx)
	leaq	(%r11,%r11,4), %rdx
	movq	%rax, (%rcx,%rdx,8)
	movl	%esi, 8(%rcx,%rdx,8)
	movq	$1, 16(%rcx,%rdx,8)
	movw	$263, 24(%rcx,%rdx,8)
	movq	$16, 10032(%rsp)
	movl	32(%rcx,%rdx,8), %eax
	movl	%eax, 24(%rsp)
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_45:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_45
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_47:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_47
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_49:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_49
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB0_51:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_51
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_53:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_53
	movq	%r11, 32(%rsp)
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_55:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_55
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_57:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_57
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_59:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_59
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB0_61:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB0_61
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_63:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB0_63
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_65:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB0_65
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_67:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB0_67
	movl	$0, 20(%rsp)
	cmpq	%rax, %r9
	jne	.LBB0_228
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %r12
	jne	.LBB0_230
	cmpq	%rdx, %r11
	jne	.LBB0_230
	cmpq	%rsi, %rbx
	jne	.LBB0_230
	cmpq	%rdi, %r14
	jne	.LBB0_230
	cmpq	%r8, %r15
	jne	.LBB0_230
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_229
	movl	$112, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_76:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB0_76
	movl	$4753, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_78:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r15, %rdx
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r15b
	addq	%rdx, %r15
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB0_78
	movl	$2192, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB0_80:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r12
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r12, %rdx
	xorl	%r12d, %r12d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r12b
	addq	%rdx, %r12
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB0_80
	movl	$120, %eax
	xorl	%r13d, %r13d
	.p2align	4
.LBB0_82:
	xorl	%ecx, %ecx
	cmpl	$0, 184(%rsp,%rax)
	sete	%cl
	cmpl	$1, 216(%rsp,%rax)
	movq	%r13, %rdx
	adcq	%rcx, %rdx
	xorl	%r13d, %r13d
	cmpl	$0, 248(%rsp,%rax)
	sete	%r13b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %r13
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB0_82
	movl	$4760, %eax
	xorl	%ebp, %ebp
	.p2align	4
.LBB0_84:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbp, %rdx
	adcq	%rcx, %rdx
	xorl	%ebp, %ebp
	cmpl	$0, 240(%rsp,%rax)
	sete	%bpl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %rbp
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB0_84
	movl	$2200, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_86:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbx, %rdx
	adcq	%rcx, %rdx
	xorl	%ebx, %ebx
	cmpl	$0, 240(%rsp,%rax)
	sete	%bl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %rbx
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB0_86
	leaq	280(%rsp), %rdi
	movl	$2, %esi
	movq	32(%rsp), %rdx
	movl	24(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	je	.LBB0_227
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_89:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_89
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_91:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_91
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_93:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_93
	movl	$120, %r8d
	movq	10032(%rsp), %rsi
	movq	%rsi, 40(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB0_95:
	xorl	%r9d, %r9d
	cmpl	$0, 184(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 216(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%r8)
	sete	%sil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2168, %r8
	jne	.LBB0_95
	movl	$4760, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_97:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$9880, %r9
	jne	.LBB0_97
	movl	$2200, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_99:
	xorl	%r11d, %r11d
	cmpl	$0, 160(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 200(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 240(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 280(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$4760, %r10
	jne	.LBB0_99
	movl	$0, 20(%rsp)
	cmpq	$16, 40(%rsp)
	jne	.LBB0_228
	cmpq	%r14, %rax
	jne	.LBB0_228
	cmpq	%r15, %rcx
	jne	.LBB0_228
	cmpq	%r12, %rdx
	jne	.LBB0_228
	cmpq	%r13, %rsi
	movq	memcpy@GOTPCREL(%rip), %r12
	jne	.LBB0_230
	cmpq	%rbp, %r8
	jne	.LBB0_230
	cmpq	%rbx, %r9
	jne	.LBB0_230
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_229
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r15
	movq	%r15, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$2, %esi
	movq	%r15, %rdi
	movq	32(%rsp), %rbx
	movq	%rbx, %rdx
	movl	24(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$-1, %al
	je	.LBB0_229
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_229
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_229
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_229
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_229
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_229
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_229
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_229
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_229
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r15
	movq	%r15, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$1, (%rsp)
	leaq	12600(%rsp), %rdi
	movl	$2, %edx
	movl	$2, %r9d
	movq	%r15, %rsi
	movq	%rbx, %rcx
	movl	24(%rsp), %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$0, 12600(%rsp)
	je	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_227
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_227
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_227
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_227
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_227
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_227
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_227
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_227
	movl	$1, (%rsp)
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$1, %edx
	movl	$2, %r9d
	movq	32(%rsp), %rcx
	movl	24(%rsp), %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$1, 12600(%rsp)
	je	.LBB0_227
	movq	12608(%rsp), %r13
	movl	12616(%rsp), %r15d
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	12600(%rsp), %rdi
	movl	$2, %edx
	movq	%r12, %rsi
	movq	%r13, %rcx
	movl	%r15d, %r8d
	movl	$1, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$1, 12600(%rsp)
	jne	.LBB0_227
	cmpb	$4, 12601(%rsp)
	jne	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_227
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_227
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_227
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_227
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_227
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_227
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_227
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_227
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$1, (%rsp)
	leaq	12600(%rsp), %rdi
	movl	$2, %edx
	movl	$1, %r9d
	movq	%r12, %rsi
	movq	%r13, %rcx
	movl	%r15d, %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$0, 12600(%rsp)
	je	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_227
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_227
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_227
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_227
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_227
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_227
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_227
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_227
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$2, %esi
	movq	%r12, %rdi
	movq	%r13, %rdx
	movl	%r15d, %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$-1, %al
	je	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_227
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_227
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_227
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_227
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_227
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_227
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_227
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_227
	movl	$5, (%rsp)
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$1, %edx
	movl	$2, %r9d
	movq	32(%rsp), %rcx
	movl	24(%rsp), %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$1, 12600(%rsp)
	je	.LBB0_227
	movq	12608(%rsp), %rbx
	movl	12616(%rsp), %ebp
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$7, (%rsp)
	leaq	12600(%rsp), %rdi
	movl	$2, %edx
	movl	$1, %r9d
	movq	%r12, %rsi
	movq	%rbx, %rcx
	movl	%ebp, %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$0, 12600(%rsp)
	je	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_227
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_227
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_227
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_227
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_227
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_227
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_227
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_227
	movl	$1, (%rsp)
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$2, %edx
	movl	$1, %r9d
	movl	%ebp, %r8d
	movq	%rbx, %rcx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$1, 12600(%rsp)
	je	.LBB0_227
	movq	12608(%rsp), %r14
	movl	12616(%rsp), %eax
	movl	%eax, 40(%rsp)
	movl	$7, (%rsp)
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$1, %edx
	movl	$1, %r9d
	movq	32(%rsp), %rcx
	movl	24(%rsp), %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$1, 12600(%rsp)
	je	.LBB0_227
	movq	12608(%rsp), %rbx
	movl	12616(%rsp), %ebp
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$1, %esi
	movq	%r12, %rdi
	movq	%rbx, 56(%rsp)
	movq	%rbx, %rdx
	movl	%ebp, 72(%rsp)
	movl	%ebp, %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$4, %al
	jne	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_227
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_227
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_227
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_227
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_227
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_227
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_227
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_227
	movl	$0, (%rsp)
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$1, %edx
	movl	$2, %r9d
	movq	32(%rsp), %rcx
	movl	24(%rsp), %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$1, 12600(%rsp)
	je	.LBB0_227
	movq	12608(%rsp), %r12
	movl	12616(%rsp), %ebx
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rbp
	movq	%rbp, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	12600(%rsp), %rdi
	movl	$2, %edx
	movq	%rbp, %rsi
	movq	%r12, %rcx
	movl	%ebx, %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$0, 12600(%rsp)
	je	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_227
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_227
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_227
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_227
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_227
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_227
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_227
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$1, %edx
	movq	%r14, %rcx
	movl	40(%rsp), %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$1, 12600(%rsp)
	je	.LBB0_227
	movq	12608(%rsp), %rbx
	movl	12616(%rsp), %ebp
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$2, %esi
	movq	%r12, %rdi
	movq	%rbx, %rdx
	movl	%ebp, %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel
	cmpb	$-1, %al
	je	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_227
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_227
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_227
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_227
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_227
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_227
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_227
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_227
	leaq	280(%rsp), %rdi
	movq	%rbx, %rsi
	movl	%ebp, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	orb	%al, %dl
	testb	$1, %dl
	jne	.LBB0_227
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	32(%rsp), %rdx
	movl	24(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$-1, %al
	jne	.LBB0_227
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rbx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	12600(%rsp), %rdi
	movl	$2, %edx
	movq	%rbx, %rsi
	movq	%r13, %rcx
	movl	%r15d, %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$0, 12600(%rsp)
	je	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_227
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_227
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_227
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_227
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_227
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_227
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_227
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_227
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rbx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	12600(%rsp), %rdi
	movl	$1, %edx
	movq	%rbx, %rsi
	movq	56(%rsp), %rcx
	movl	72(%rsp), %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$0, 12600(%rsp)
	je	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_227
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_227
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_227
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_227
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_227
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_227
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_227
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_227
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rbx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	12600(%rsp), %rdi
	movl	$1, %edx
	movq	%rbx, %rsi
	movq	%r14, %rcx
	movl	40(%rsp), %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$0, 12600(%rsp)
	je	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_227
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_227
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_227
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_227
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_227
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_227
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_227
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12600(%rsp)
	jne	.LBB0_227
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12624(%rsp)
	je	.LBB0_1990
.LBB0_227:
	movl	$0, 20(%rsp)
.LBB0_228:
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_230
.LBB0_229:
	movl	$0, 20(%rsp)
.LBB0_230:
	movl	$96, %eax
	.p2align	4
.LBB0_231:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB0_231
	xorl	%eax, %eax
	.p2align	4
.LBB0_233:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_233
	xorl	%eax, %eax
	.p2align	4
.LBB0_235:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_235
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%r12
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r12
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r12
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r12
	movq	$8, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB0_238
	.p2align	4
.LBB0_237:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB0_282
.LBB0_238:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB0_240
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB0_243
.LBB0_240:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_237
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_237
	incq	%rax
.LBB0_243:
	movl	$4680, %edx
	leaq	4888(%rsp), %rcx
	xorl	%edi, %edi
	jmp	.LBB0_245
	.p2align	4
.LBB0_244:
	addq	$2, %rdi
	addq	$80, %rdx
	cmpq	$9800, %rdx
	je	.LBB0_282
.LBB0_245:
	cmpb	$2, 233(%rsp,%rdx)
	jne	.LBB0_247
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB0_250
.LBB0_247:
	cmpb	$2, 273(%rsp,%rdx)
	jne	.LBB0_244
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB0_244
	incq	%rdi
.LBB0_250:
	movq	%rax, %rdx
	shlq	$5, %rdx
	movl	304(%rsp,%rdx), %esi
	movq	$1, 280(%rsp,%rdx)
	movq	$8, 288(%rsp,%rdx)
	movb	$0, 296(%rsp,%rdx)
	movq	%rdi, 32(%rsp)
	leaq	(%rdi,%rdi,4), %rdx
	movq	%rax, (%rcx,%rdx,8)
	movl	%esi, 8(%rcx,%rdx,8)
	movq	$1, 16(%rcx,%rdx,8)
	movw	$263, 24(%rcx,%rdx,8)
	movq	$8, 10032(%rsp)
	movl	32(%rcx,%rdx,8), %eax
	movl	%eax, 40(%rsp)
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_251:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_251
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_253:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_253
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_255:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_255
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB0_257:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_257
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_259:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_259
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_261:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_261
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_263:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%r14d, %r14d
	cmpb	$2, 248(%rsp,%r10)
	setne	%r14b
	addq	%r11, %r14
	addq	%r9, %r14
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%r14, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_263
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_265:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%r11)
	setne	%r14b
	addq	%r14, %r10
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%r11)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r15b
	addq	%r14, %r15
	addq	%r10, %r15
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r15, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_265
	movl	$2192, %r14d
	xorl	%r11d, %r11d
	.p2align	4
.LBB0_267:
	xorl	%r15d, %r15d
	cmpb	$2, 160(%rsp,%r14)
	setne	%r15b
	addq	%r15, %r11
	xorl	%r15d, %r15d
	cmpb	$2, 200(%rsp,%r14)
	setne	%r15b
	xorl	%r12d, %r12d
	cmpb	$2, 240(%rsp,%r14)
	setne	%r12b
	addq	%r15, %r12
	addq	%r11, %r12
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%r14)
	setne	%r11b
	addq	%r12, %r11
	addq	$160, %r14
	cmpq	$4752, %r14
	jne	.LBB0_267
	movl	$120, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_269:
	xorl	%r12d, %r12d
	cmpl	$0, 184(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 216(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	subq	$-128, %r15
	cmpq	$2168, %r15
	jne	.LBB0_269
	movl	$4760, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_271:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$9880, %r12
	jne	.LBB0_271
	movq	%rax, 24(%rsp)
	movl	$2200, %r13d
	xorl	%r12d, %r12d
	.p2align	4
.LBB0_273:
	xorl	%ebp, %ebp
	cmpl	$0, 160(%rsp,%r13)
	sete	%bpl
	cmpl	$1, 200(%rsp,%r13)
	movq	%r12, %rbx
	adcq	%rbp, %rbx
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%r13)
	sete	%r12b
	cmpl	$1, 280(%rsp,%r13)
	adcq	%rbx, %r12
	addq	$160, %r13
	cmpq	$4760, %r13
	jne	.LBB0_273
	xorl	%eax, %eax
	cmpq	24(%rsp), %r9
	jne	.LBB0_297
	cmpq	%rcx, %r10
	jne	.LBB0_297
	cmpq	%rdx, %r11
	jne	.LBB0_297
	cmpq	%rsi, %r14
	jne	.LBB0_297
	cmpq	%rdi, %r15
	jne	.LBB0_297
	cmpq	%r8, %r12
	movq	memcpy@GOTPCREL(%rip), %r12
	jne	.LBB0_298
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_282
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	32(%rsp), %rdx
	movl	40(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB0_282
	movl	$64, %eax
	.p2align	4
.LBB0_284:
	addq	$-4, %rax
	jne	.LBB0_284
	movl	$128, %eax
	.p2align	4
.LBB0_286:
	addq	$-4, %rax
	jne	.LBB0_286
	movl	$64, %eax
	.p2align	4
.LBB0_288:
	addq	$-4, %rax
	jne	.LBB0_288
	movl	$64, %ecx
	movq	10032(%rsp), %rax
	.p2align	4
.LBB0_290:
	addq	$-4, %rcx
	jne	.LBB0_290
	movl	$128, %ecx
	.p2align	4
.LBB0_292:
	addq	$-4, %rcx
	jne	.LBB0_292
	movl	$64, %ecx
	.p2align	4
.LBB0_294:
	addq	$-4, %rcx
	jne	.LBB0_294
	testq	%rax, %rax
	je	.LBB0_296
.LBB0_282:
	xorl	%eax, %eax
.LBB0_298:
	movl	$96, %ecx
	.p2align	4
.LBB0_299:
	movq	$1, 9968(%rsp,%rcx)
	movq	$2, 9960(%rsp,%rcx)
	movq	$0, 9952(%rsp,%rcx)
	movq	$0, 9944(%rsp,%rcx)
	movq	$0, 9976(%rsp,%rcx)
	movq	$0, 9984(%rsp,%rcx)
	movq	$2, 9992(%rsp,%rcx)
	movq	$1, 10000(%rsp,%rcx)
	movq	$0, 10008(%rsp,%rcx)
	movq	$0, 10016(%rsp,%rcx)
	movq	$2, 10024(%rsp,%rcx)
	movq	$1, 10032(%rsp,%rcx)
	movq	$0, 10040(%rsp,%rcx)
	movq	$0, 10048(%rsp,%rcx)
	movq	$2, 10056(%rsp,%rcx)
	movq	$1, 10064(%rsp,%rcx)
	subq	$-128, %rcx
	cmpq	$2144, %rcx
	jne	.LBB0_299
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_301:
	movq	$1, 312(%rsp,%rcx)
	movq	$512, 304(%rsp,%rcx)
	movq	$0, 296(%rsp,%rcx)
	movq	$0, 288(%rsp,%rcx)
	movq	$0, 280(%rsp,%rcx)
	movq	$0, 320(%rsp,%rcx)
	movq	$0, 328(%rsp,%rcx)
	movq	$0, 336(%rsp,%rcx)
	movq	$512, 344(%rsp,%rcx)
	movq	$1, 352(%rsp,%rcx)
	movq	$0, 360(%rsp,%rcx)
	movq	$0, 368(%rsp,%rcx)
	movq	$0, 376(%rsp,%rcx)
	movq	$512, 384(%rsp,%rcx)
	movq	$1, 392(%rsp,%rcx)
	movq	$0, 400(%rsp,%rcx)
	movq	$0, 408(%rsp,%rcx)
	movq	$0, 416(%rsp,%rcx)
	movq	$512, 424(%rsp,%rcx)
	movq	$1, 432(%rsp,%rcx)
	addq	$160, %rcx
	cmpq	$5120, %rcx
	jne	.LBB0_301
	movl	%eax, 24(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB0_303:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_303
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%r12
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r12
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r12
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r12
	movq	$-1, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB0_306
	.p2align	4
.LBB0_305:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB0_362
.LBB0_306:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB0_308
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB0_311
.LBB0_308:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_305
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_305
	incq	%rax
.LBB0_311:
	movl	$4680, %edx
	leaq	4888(%rsp), %rcx
	xorl	%edi, %edi
	jmp	.LBB0_313
	.p2align	4
.LBB0_312:
	addq	$2, %rdi
	addq	$80, %rdx
	cmpq	$9800, %rdx
	je	.LBB0_362
.LBB0_313:
	cmpb	$2, 233(%rsp,%rdx)
	jne	.LBB0_315
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB0_318
.LBB0_315:
	cmpb	$2, 273(%rsp,%rdx)
	jne	.LBB0_312
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB0_312
	incq	%rdi
.LBB0_318:
	movq	%rax, %rdx
	shlq	$5, %rdx
	movl	304(%rsp,%rdx), %esi
	movq	$1, 280(%rsp,%rdx)
	movq	$-1, 288(%rsp,%rdx)
	movb	$0, 296(%rsp,%rdx)
	movq	%rdi, 40(%rsp)
	leaq	(%rdi,%rdi,4), %rdx
	movq	%rax, (%rcx,%rdx,8)
	movl	%esi, 8(%rcx,%rdx,8)
	movq	$1, 16(%rcx,%rdx,8)
	movw	$263, 24(%rcx,%rdx,8)
	movq	$-1, 10032(%rsp)
	movl	32(%rcx,%rdx,8), %eax
	movl	%eax, 56(%rsp)
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_319:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_319
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_321:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_321
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_323:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_323
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB0_325:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_325
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_327:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_327
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_329:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_329
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_331:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%r14d, %r14d
	cmpb	$2, 248(%rsp,%r10)
	setne	%r14b
	addq	%r11, %r14
	addq	%r9, %r14
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%r14, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_331
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_333:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%r11)
	setne	%r14b
	addq	%r14, %r10
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%r11)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r15b
	addq	%r14, %r15
	addq	%r10, %r15
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r15, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_333
	movl	$2192, %r14d
	xorl	%r11d, %r11d
	.p2align	4
.LBB0_335:
	xorl	%r15d, %r15d
	cmpb	$2, 160(%rsp,%r14)
	setne	%r15b
	addq	%r15, %r11
	xorl	%r15d, %r15d
	cmpb	$2, 200(%rsp,%r14)
	setne	%r15b
	xorl	%r12d, %r12d
	cmpb	$2, 240(%rsp,%r14)
	setne	%r12b
	addq	%r15, %r12
	addq	%r11, %r12
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%r14)
	setne	%r11b
	addq	%r12, %r11
	addq	$160, %r14
	cmpq	$4752, %r14
	jne	.LBB0_335
	movl	$120, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_337:
	xorl	%r12d, %r12d
	cmpl	$0, 184(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 216(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	subq	$-128, %r15
	cmpq	$2168, %r15
	jne	.LBB0_337
	movl	$4760, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_339:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$9880, %r12
	jne	.LBB0_339
	movq	%rax, 32(%rsp)
	movl	$2200, %r13d
	xorl	%r12d, %r12d
	.p2align	4
.LBB0_341:
	xorl	%ebp, %ebp
	cmpl	$0, 160(%rsp,%r13)
	sete	%bpl
	cmpl	$1, 200(%rsp,%r13)
	movq	%r12, %rbx
	adcq	%rbp, %rbx
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%r13)
	sete	%r12b
	cmpl	$1, 280(%rsp,%r13)
	adcq	%rbx, %r12
	addq	$160, %r13
	cmpq	$4760, %r13
	jne	.LBB0_341
	xorl	%eax, %eax
	cmpq	32(%rsp), %r9
	jne	.LBB0_377
	cmpq	%rcx, %r10
	jne	.LBB0_377
	cmpq	%rdx, %r11
	jne	.LBB0_377
	cmpq	%rsi, %r14
	jne	.LBB0_377
	cmpq	%rdi, %r15
	jne	.LBB0_377
	cmpq	%r8, %r12
	movq	memcpy@GOTPCREL(%rip), %r12
	jne	.LBB0_378
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_362
	movl	$64, %eax
	.p2align	4
.LBB0_350:
	addq	$-4, %rax
	jne	.LBB0_350
	movl	$128, %eax
	.p2align	4
.LBB0_352:
	addq	$-4, %rax
	jne	.LBB0_352
	movl	$64, %eax
	.p2align	4
.LBB0_354:
	addq	$-4, %rax
	jne	.LBB0_354
	movl	$64, %eax
	.p2align	4
.LBB0_356:
	addq	$-4, %rax
	jne	.LBB0_356
	movl	$128, %eax
	.p2align	4
.LBB0_358:
	addq	$-4, %rax
	jne	.LBB0_358
	movl	$64, %eax
	.p2align	4
.LBB0_360:
	addq	$-4, %rax
	jne	.LBB0_360
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	40(%rsp), %rdx
	movl	56(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB0_362
	movl	$64, %eax
	.p2align	4
.LBB0_364:
	addq	$-4, %rax
	jne	.LBB0_364
	movl	$128, %eax
	.p2align	4
.LBB0_366:
	addq	$-4, %rax
	jne	.LBB0_366
	movl	$64, %eax
	.p2align	4
.LBB0_368:
	addq	$-4, %rax
	jne	.LBB0_368
	movl	$64, %ecx
	movq	10032(%rsp), %rax
	.p2align	4
.LBB0_370:
	addq	$-4, %rcx
	jne	.LBB0_370
	movl	$128, %ecx
	.p2align	4
.LBB0_372:
	addq	$-4, %rcx
	jne	.LBB0_372
	movl	$64, %ecx
	.p2align	4
.LBB0_374:
	addq	$-4, %rcx
	jne	.LBB0_374
	testq	%rax, %rax
	je	.LBB0_376
.LBB0_362:
	xorl	%eax, %eax
.LBB0_378:
	movl	$96, %ecx
	.p2align	4
.LBB0_379:
	movq	$1, 9968(%rsp,%rcx)
	movq	$2, 9960(%rsp,%rcx)
	movq	$0, 9952(%rsp,%rcx)
	movq	$0, 9944(%rsp,%rcx)
	movq	$0, 9976(%rsp,%rcx)
	movq	$0, 9984(%rsp,%rcx)
	movq	$2, 9992(%rsp,%rcx)
	movq	$1, 10000(%rsp,%rcx)
	movq	$0, 10008(%rsp,%rcx)
	movq	$0, 10016(%rsp,%rcx)
	movq	$2, 10024(%rsp,%rcx)
	movq	$1, 10032(%rsp,%rcx)
	movq	$0, 10040(%rsp,%rcx)
	movq	$0, 10048(%rsp,%rcx)
	movq	$2, 10056(%rsp,%rcx)
	movq	$1, 10064(%rsp,%rcx)
	subq	$-128, %rcx
	cmpq	$2144, %rcx
	jne	.LBB0_379
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_381:
	movq	$1, 312(%rsp,%rcx)
	movq	$512, 304(%rsp,%rcx)
	movq	$0, 296(%rsp,%rcx)
	movq	$0, 288(%rsp,%rcx)
	movq	$0, 280(%rsp,%rcx)
	movq	$0, 320(%rsp,%rcx)
	movq	$0, 328(%rsp,%rcx)
	movq	$0, 336(%rsp,%rcx)
	movq	$512, 344(%rsp,%rcx)
	movq	$1, 352(%rsp,%rcx)
	movq	$0, 360(%rsp,%rcx)
	movq	$0, 368(%rsp,%rcx)
	movq	$0, 376(%rsp,%rcx)
	movq	$512, 384(%rsp,%rcx)
	movq	$1, 392(%rsp,%rcx)
	movq	$0, 400(%rsp,%rcx)
	movq	$0, 408(%rsp,%rcx)
	movq	$0, 416(%rsp,%rcx)
	movq	$512, 424(%rsp,%rcx)
	movq	$1, 432(%rsp,%rcx)
	addq	$160, %rcx
	cmpq	$5120, %rcx
	jne	.LBB0_381
	movl	%eax, 32(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB0_383:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_383
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%r12
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r12
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r12
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r12
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	xorl	%ebx, %ebx
.LBB0_385:
	cmpq	$64, %rbx
	je	.LBB0_401
	incq	%rbx
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB0_388
	.p2align	4
.LBB0_387:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB0_438
.LBB0_388:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB0_390
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB0_393
.LBB0_390:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_387
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_387
	incq	%rax
.LBB0_393:
	movl	$4680, %edx
	xorl	%ecx, %ecx
	jmp	.LBB0_395
	.p2align	4
.LBB0_394:
	addq	$2, %rcx
	addq	$80, %rdx
	cmpq	$9800, %rdx
	je	.LBB0_438
.LBB0_395:
	cmpb	$2, 233(%rsp,%rdx)
	jne	.LBB0_397
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB0_400
.LBB0_397:
	cmpb	$2, 273(%rsp,%rdx)
	jne	.LBB0_394
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB0_394
	incq	%rcx
.LBB0_400:
	movq	%rax, %rdx
	shlq	$5, %rdx
	movl	304(%rsp,%rdx), %esi
	movq	$1, 280(%rsp,%rdx)
	movq	$1, 288(%rsp,%rdx)
	movb	$0, 296(%rsp,%rdx)
	leaq	(%rcx,%rcx,4), %rcx
	leaq	280(%rsp), %rdi
	movq	%rax, 4608(%rdi,%rcx,8)
	movl	%esi, 4616(%rdi,%rcx,8)
	movq	$1, 4624(%rdi,%rcx,8)
	movw	$263, 4632(%rdi,%rcx,8)
	movq	%rbx, 10032(%rsp)
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	jne	.LBB0_385
	jmp	.LBB0_438
.LBB0_297:
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_298
.LBB0_377:
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_378
.LBB0_401:
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_402:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_402
	movl	$128, %ecx
	.p2align	4
.LBB0_404:
	addq	$-4, %rcx
	jne	.LBB0_404
	movl	$64, %ecx
	.p2align	4
.LBB0_406:
	addq	$-4, %rcx
	jne	.LBB0_406
	movl	$64, %ecx
	.p2align	4
.LBB0_408:
	addq	$-4, %rcx
	jne	.LBB0_408
	movl	$128, %ecx
	.p2align	4
.LBB0_410:
	addq	$-4, %rcx
	jne	.LBB0_410
	movl	$64, %ecx
	.p2align	4
.LBB0_412:
	addq	$-4, %rcx
	jne	.LBB0_412
	cmpq	$64, %rax
	jne	.LBB0_438
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_415:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_415
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_417:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_417
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_419:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_419
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB0_421:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_421
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_423:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_423
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_425:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_425
	movl	$56, %r9d
	jmp	.LBB0_428
	.p2align	4
.LBB0_427:
	addq	$64, %r9
	cmpq	$2104, %r9
	je	.LBB0_655
.LBB0_428:
	cmpb	$2, 240(%rsp,%r9)
	jne	.LBB0_430
	cmpl	$0, 248(%rsp,%r9)
	jne	.LBB0_432
.LBB0_430:
	cmpb	$2, 272(%rsp,%r9)
	jne	.LBB0_427
	cmpl	$0, 280(%rsp,%r9)
	je	.LBB0_427
.LBB0_432:
	xorl	%r9d, %r9d
	jmp	.LBB0_434
.LBB0_433:
	addq	$80, %r9
	cmpq	$5120, %r9
	je	.LBB0_655
.LBB0_434:
	cmpb	$2, 4913(%rsp,%r9)
	jne	.LBB0_436
	cmpl	$0, 4920(%rsp,%r9)
	jne	.LBB0_438
.LBB0_436:
	cmpb	$2, 4953(%rsp,%r9)
	jne	.LBB0_433
	cmpl	$0, 4960(%rsp,%r9)
	je	.LBB0_433
.LBB0_438:
	xorl	%ebp, %ebp
.LBB0_439:
	movl	$96, %eax
	.p2align	4
.LBB0_440:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB0_440
	xorl	%eax, %eax
	.p2align	4
.LBB0_442:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_442
	xorl	%eax, %eax
	.p2align	4
.LBB0_444:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_444
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%r12
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r12
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r12
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r12
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	movl	%ebp, 40(%rsp)
	jmp	.LBB0_447
	.p2align	4
.LBB0_446:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB0_512
.LBB0_447:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB0_449
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB0_452
.LBB0_449:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_446
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_446
	incq	%rax
.LBB0_452:
	movl	$4680, %ecx
	xorl	%r13d, %r13d
	jmp	.LBB0_454
	.p2align	4
.LBB0_453:
	addq	$2, %r13
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB0_512
.LBB0_454:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB0_456
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB0_459
.LBB0_456:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB0_453
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_453
	incq	%r13
.LBB0_459:
	movq	%rax, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %edx
	movq	$1, 280(%rsp,%rcx)
	movq	$1, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	leaq	(%r13,%r13,4), %rcx
	leaq	280(%rsp), %rsi
	leaq	4608(%rsi,%rcx,8), %r14
	movq	%rax, 4608(%rsi,%rcx,8)
	movl	%edx, 4616(%rsi,%rcx,8)
	movq	$1, 4624(%rsi,%rcx,8)
	movw	$263, 4632(%rsi,%rcx,8)
	movq	$1, 10032(%rsp)
	movl	4640(%rsi,%rcx,8), %eax
	movl	%eax, 56(%rsp)
	movl	$1, %ebp
	leaq	280(%rsp), %rbx
.LBB0_460:
	cmpl	$128, %ebp
	je	.LBB0_475
	cmpb	$2, 25(%r14)
	je	.LBB0_512
	xorl	%eax, %eax
	cmpq	$1, 16(%r14)
	jne	.LBB0_513
	movq	(%r14), %rdi
	cmpq	$63, %rdi
	ja	.LBB0_513
	movl	8(%r14), %ecx
	movq	%rdi, %rdx
	shlq	$5, %rdx
	cmpl	%ecx, 304(%rsp,%rdx)
	jne	.LBB0_512
	addq	%rsp, %rdx
	addq	$280, %rdx
	xorl	%eax, %eax
	cmpb	$0, 16(%rdx)
	jne	.LBB0_513
	movzbl	24(%r14), %edx
	andb	$5, %dl
	cmpb	$5, %dl
	jne	.LBB0_513
	movl	$4680, %esi
	xorl	%edx, %edx
	jmp	.LBB0_469
	.p2align	4
.LBB0_468:
	addq	$2, %rdx
	addq	$80, %rsi
	cmpq	$9800, %rsi
	je	.LBB0_512
.LBB0_469:
	cmpb	$2, 233(%rsp,%rsi)
	jne	.LBB0_471
	cmpl	$0, 240(%rsp,%rsi)
	jne	.LBB0_474
.LBB0_471:
	cmpb	$2, 273(%rsp,%rsi)
	jne	.LBB0_468
	cmpl	$0, 280(%rsp,%rsi)
	je	.LBB0_468
	incq	%rdx
.LBB0_474:
	leaq	(%rdx,%rdx,4), %rdx
	leaq	280(%rsp), %rsi
	movq	%rdi, 4608(%rsi,%rdx,8)
	movl	%ecx, 4616(%rsi,%rdx,8)
	movq	$2, 4624(%rsi,%rdx,8)
	movw	$1, 4632(%rsi,%rdx,8)
	incl	%ebp
	movq	%rbx, %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	jne	.LBB0_460
	jmp	.LBB0_512
.LBB0_475:
	movl	$64, %eax
	.p2align	4
.LBB0_476:
	addq	$-4, %rax
	jne	.LBB0_476
	movl	$4753, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_478:
	xorl	%edx, %edx
	cmpb	$2, 160(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 200(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	addq	$160, %rcx
	cmpq	$9873, %rcx
	jne	.LBB0_478
	movl	$64, %ecx
	.p2align	4
.LBB0_480:
	addq	$-4, %rcx
	jne	.LBB0_480
	movl	$64, %ecx
	.p2align	4
.LBB0_482:
	addq	$-4, %rcx
	jne	.LBB0_482
	movl	$128, %ecx
	.p2align	4
.LBB0_484:
	addq	$-4, %rcx
	jne	.LBB0_484
	movl	$64, %ecx
	.p2align	4
.LBB0_486:
	addq	$-4, %rcx
	jne	.LBB0_486
	cmpq	$128, %rax
	jne	.LBB0_512
	movl	$112, %ecx
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_489:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %r15
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%r15, %rsi
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rcx)
	setne	%r15b
	addq	%rsi, %r15
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_489
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_491:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_491
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_493:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_493
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB0_495:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_495
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_497:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_497
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_499:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_499
	movl	$56, %r9d
	jmp	.LBB0_502
.LBB0_501:
	addq	$64, %r9
	xorl	%eax, %eax
	cmpq	$2104, %r9
	je	.LBB0_513
.LBB0_502:
	cmpb	$2, 240(%rsp,%r9)
	jne	.LBB0_504
	cmpl	$0, 248(%rsp,%r9)
	jne	.LBB0_506
.LBB0_504:
	cmpb	$2, 272(%rsp,%r9)
	jne	.LBB0_501
	cmpl	$0, 280(%rsp,%r9)
	je	.LBB0_501
.LBB0_506:
	movl	$4680, %r9d
	jmp	.LBB0_508
.LBB0_507:
	addq	$80, %r9
	cmpq	$9800, %r9
	je	.LBB0_693
.LBB0_508:
	cmpb	$2, 233(%rsp,%r9)
	jne	.LBB0_510
	cmpl	$0, 240(%rsp,%r9)
	jne	.LBB0_512
.LBB0_510:
	cmpb	$2, 273(%rsp,%r9)
	jne	.LBB0_507
	cmpl	$0, 280(%rsp,%r9)
	je	.LBB0_507
.LBB0_512:
	xorl	%eax, %eax
.LBB0_513:
	movl	$96, %ecx
	.p2align	4
.LBB0_514:
	movq	$1, 9968(%rsp,%rcx)
	movq	$2, 9960(%rsp,%rcx)
	movq	$0, 9952(%rsp,%rcx)
	movq	$0, 9944(%rsp,%rcx)
	movq	$0, 9976(%rsp,%rcx)
	movq	$0, 9984(%rsp,%rcx)
	movq	$2, 9992(%rsp,%rcx)
	movq	$1, 10000(%rsp,%rcx)
	movq	$0, 10008(%rsp,%rcx)
	movq	$0, 10016(%rsp,%rcx)
	movq	$2, 10024(%rsp,%rcx)
	movq	$1, 10032(%rsp,%rcx)
	movq	$0, 10040(%rsp,%rcx)
	movq	$0, 10048(%rsp,%rcx)
	movq	$2, 10056(%rsp,%rcx)
	movq	$1, 10064(%rsp,%rcx)
	subq	$-128, %rcx
	cmpq	$2144, %rcx
	jne	.LBB0_514
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_516:
	movq	$1, 312(%rsp,%rcx)
	movq	$512, 304(%rsp,%rcx)
	movq	$0, 296(%rsp,%rcx)
	movq	$0, 288(%rsp,%rcx)
	movq	$0, 280(%rsp,%rcx)
	movq	$0, 320(%rsp,%rcx)
	movq	$0, 328(%rsp,%rcx)
	movq	$0, 336(%rsp,%rcx)
	movq	$512, 344(%rsp,%rcx)
	movq	$1, 352(%rsp,%rcx)
	movq	$0, 360(%rsp,%rcx)
	movq	$0, 368(%rsp,%rcx)
	movq	$0, 376(%rsp,%rcx)
	movq	$512, 384(%rsp,%rcx)
	movq	$1, 392(%rsp,%rcx)
	movq	$0, 400(%rsp,%rcx)
	movq	$0, 408(%rsp,%rcx)
	movq	$0, 416(%rsp,%rcx)
	movq	$512, 424(%rsp,%rcx)
	movq	$1, 432(%rsp,%rcx)
	addq	$160, %rcx
	cmpq	$5120, %rcx
	jne	.LBB0_516
	movl	%eax, 56(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB0_518:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_518
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%r12
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r12
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r12
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r12
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %eax
	xorl	%r14d, %r14d
	jmp	.LBB0_521
	.p2align	4
.LBB0_520:
	addq	$2, %r14
	addq	$64, %rax
	cmpq	$2104, %rax
	je	.LBB0_580
.LBB0_521:
	cmpb	$2, 240(%rsp,%rax)
	jne	.LBB0_523
	cmpl	$0, 248(%rsp,%rax)
	jne	.LBB0_526
.LBB0_523:
	cmpb	$2, 272(%rsp,%rax)
	jne	.LBB0_520
	cmpl	$0, 280(%rsp,%rax)
	je	.LBB0_520
	incq	%r14
.LBB0_526:
	movl	$4680, %ecx
	xorl	%eax, %eax
	jmp	.LBB0_528
	.p2align	4
.LBB0_527:
	addq	$2, %rax
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB0_580
.LBB0_528:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB0_530
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB0_533
.LBB0_530:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB0_527
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_527
	incq	%rax
.LBB0_533:
	movq	%r14, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %ebp
	movq	$1, 280(%rsp,%rcx)
	movq	$1, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	leaq	(%rax,%rax,4), %rax
	leaq	280(%rsp), %rcx
	movq	%r14, 4608(%rcx,%rax,8)
	movl	%ebp, 4616(%rcx,%rax,8)
	movq	$1, 4624(%rcx,%rax,8)
	movw	$263, 4632(%rcx,%rax,8)
	movq	$1, 10032(%rsp)
	xorl	%r15d, %r15d
	leaq	2328(%rsp), %r13
	leaq	280(%rsp), %rbx
.LBB0_534:
	cmpl	$64, %r15d
	je	.LBB0_546
	movl	$2192, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_536:
	xorl	%edx, %edx
	cmpb	$2, 160(%rsp,%rax)
	setne	%dl
	addq	%rdx, %rcx
	xorl	%edx, %edx
	cmpb	$2, 200(%rsp,%rax)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rcx, %rsi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rax)
	setne	%cl
	addq	%rsi, %rcx
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB0_536
	cmpq	$63, %rcx
	ja	.LBB0_580
	movl	$2120, %ecx
	xorl	%eax, %eax
	jmp	.LBB0_540
	.p2align	4
.LBB0_539:
	addq	$2, %rax
	addq	$80, %rcx
	cmpq	$4680, %rcx
	je	.LBB0_580
.LBB0_540:
	cmpb	$2, 232(%rsp,%rcx)
	jne	.LBB0_542
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB0_545
.LBB0_542:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_539
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_539
	incq	%rax
.LBB0_545:
	leaq	(%rax,%rax,4), %rax
	movq	$1, (%r13,%rax,8)
	movq	%r14, 8(%r13,%rax,8)
	movl	%ebp, 16(%r13,%rax,8)
	movb	$0, 24(%r13,%rax,8)
	incl	%r15d
	movq	%rbx, %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	jne	.LBB0_534
	jmp	.LBB0_580
.LBB0_546:
	movl	$64, %eax
	.p2align	4
.LBB0_547:
	addq	$-4, %rax
	jne	.LBB0_547
	movl	$128, %eax
	.p2align	4
.LBB0_549:
	addq	$-4, %rax
	jne	.LBB0_549
	movl	$2192, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_551:
	xorl	%edx, %edx
	cmpb	$2, 160(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 200(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	addq	$160, %rcx
	cmpq	$4752, %rcx
	jne	.LBB0_551
	movl	$64, %ecx
	.p2align	4
.LBB0_553:
	addq	$-4, %rcx
	jne	.LBB0_553
	movl	$128, %ecx
	.p2align	4
.LBB0_555:
	addq	$-4, %rcx
	jne	.LBB0_555
	movl	$64, %ecx
	.p2align	4
.LBB0_557:
	addq	$-4, %rcx
	jne	.LBB0_557
	cmpq	$64, %rax
	jne	.LBB0_580
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_560:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_560
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_562:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_562
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_564:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_564
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB0_566:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_566
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_568:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_568
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_570:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_570
	movl	$2192, %r9d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_572:
	xorl	%r11d, %r11d
	cmpb	$2, 160(%rsp,%r9)
	setne	%r11b
	addq	%r11, %r10
	xorl	%r11d, %r11d
	cmpb	$2, 200(%rsp,%r9)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 240(%rsp,%r9)
	setne	%bl
	addq	%r11, %rbx
	addq	%r10, %rbx
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r9)
	setne	%r10b
	addq	%rbx, %r10
	addq	$160, %r9
	cmpq	$4752, %r9
	jne	.LBB0_572
	cmpq	$63, %r10
	ja	.LBB0_674
	xorl	%r9d, %r9d
	jmp	.LBB0_576
.LBB0_575:
	addq	$80, %r9
	cmpq	$2560, %r9
	je	.LBB0_674
.LBB0_576:
	cmpb	$2, 2352(%rsp,%r9)
	jne	.LBB0_578
	cmpl	$0, 2360(%rsp,%r9)
	jne	.LBB0_580
.LBB0_578:
	cmpb	$2, 2392(%rsp,%r9)
	jne	.LBB0_575
	cmpl	$0, 2400(%rsp,%r9)
	je	.LBB0_575
.LBB0_580:
	xorl	%ebp, %ebp
.LBB0_581:
	movl	$96, %eax
	.p2align	4
.LBB0_582:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB0_582
	xorl	%eax, %eax
	.p2align	4
.LBB0_584:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_584
	xorl	%eax, %eax
	.p2align	4
.LBB0_586:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_586
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%r12
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r12
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r12
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r12
	movq	$4096, 10008(%rsp)
	movq	$1, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB0_589
	.p2align	4
.LBB0_588:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB0_604
.LBB0_589:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB0_591
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB0_594
.LBB0_591:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_588
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_588
	incq	%rax
.LBB0_594:
	movl	$4680, %ecx
	xorl	%r14d, %r14d
	jmp	.LBB0_596
	.p2align	4
.LBB0_595:
	addq	$2, %r14
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB0_604
.LBB0_596:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB0_598
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB0_601
.LBB0_598:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB0_595
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_595
	incq	%r14
.LBB0_601:
	movq	%rax, %rdx
	shlq	$5, %rdx
	movl	304(%rsp,%rdx), %ecx
	movq	$1, 280(%rsp,%rdx)
	movq	$1, 288(%rsp,%rdx)
	movb	$0, 296(%rsp,%rdx)
	leaq	(%r14,%r14,4), %rdx
	leaq	280(%rsp), %rsi
	movq	%rax, 4608(%rsi,%rdx,8)
	movl	%ecx, 4616(%rsi,%rdx,8)
	movq	$1, 4624(%rsi,%rdx,8)
	movw	$263, 4632(%rsi,%rdx,8)
	movq	$1, 10032(%rsp)
	movl	4640(%rsi,%rdx,8), %r15d
	movl	$2192, %esi
	leaq	2328(%rsp), %rdx
	xorl	%edi, %edi
	.p2align	4
.LBB0_602:
	xorl	%r8d, %r8d
	cmpb	$2, 160(%rsp,%rsi)
	setne	%r8b
	addq	%r8, %rdi
	xorl	%r8d, %r8d
	cmpb	$2, 200(%rsp,%rsi)
	setne	%r8b
	xorl	%r9d, %r9d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r9b
	addq	%r8, %r9
	addq	%rdi, %r9
	xorl	%edi, %edi
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dil
	addq	%r9, %rdi
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_602
	testq	%rdi, %rdi
	je	.LBB0_605
.LBB0_604:
	xorl	%r13d, %r13d
.LBB0_725:
	movl	$96, %eax
	.p2align	4
.LBB0_726:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB0_726
	xorl	%eax, %eax
	.p2align	4
.LBB0_728:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_728
	xorl	%eax, %eax
	.p2align	4
.LBB0_730:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_730
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%r12
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r12
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r12
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r12
	movq	$4096, 10008(%rsp)
	movq	$0, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB0_733
	.p2align	4
.LBB0_732:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB0_779
.LBB0_733:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB0_735
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB0_738
.LBB0_735:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_732
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_732
	incq	%rax
.LBB0_738:
	movl	$4680, %ecx
	xorl	%esi, %esi
	jmp	.LBB0_740
	.p2align	4
.LBB0_739:
	addq	$2, %rsi
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB0_779
.LBB0_740:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB0_742
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB0_745
.LBB0_742:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB0_739
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_739
	incq	%rsi
.LBB0_745:
	movq	%rax, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %edx
	movq	$1, 280(%rsp,%rcx)
	movq	$1, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	movq	%rsi, 96(%rsp)
	leaq	(%rsi,%rsi,4), %rcx
	leaq	280(%rsp), %rsi
	movq	%rax, 4608(%rsi,%rcx,8)
	movl	%edx, 4616(%rsi,%rcx,8)
	movq	$1, 4624(%rsi,%rcx,8)
	movw	$263, 4632(%rsi,%rcx,8)
	movq	$1, 10032(%rsp)
	movl	4640(%rsi,%rcx,8), %eax
	movl	%eax, 80(%rsp)
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_746:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_746
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_748:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_748
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_750:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_750
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB0_752:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_752
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_754:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_754
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_756:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_756
	movl	$64, %r9d
	.p2align	4
.LBB0_758:
	addq	$-4, %r9
	jne	.LBB0_758
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_760:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%r14d, %r14d
	cmpb	$2, 248(%rsp,%r10)
	setne	%r14b
	addq	%r11, %r14
	addq	%r9, %r14
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%r14, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_760
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_762:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%r11)
	setne	%r14b
	addq	%r14, %r10
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%r11)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r15b
	addq	%r14, %r15
	addq	%r10, %r15
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r15, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_762
	movl	%r13d, 88(%rsp)
	movl	$2192, %r14d
	xorl	%r11d, %r11d
	.p2align	4
.LBB0_764:
	xorl	%r15d, %r15d
	cmpb	$2, 160(%rsp,%r14)
	setne	%r15b
	addq	%r15, %r11
	xorl	%r15d, %r15d
	cmpb	$2, 200(%rsp,%r14)
	setne	%r15b
	xorl	%r12d, %r12d
	cmpb	$2, 240(%rsp,%r14)
	setne	%r12b
	addq	%r15, %r12
	addq	%r11, %r12
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%r14)
	setne	%r11b
	addq	%r12, %r11
	addq	$160, %r14
	cmpq	$4752, %r14
	jne	.LBB0_764
	movl	%ebp, 72(%rsp)
	movl	$120, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_766:
	xorl	%r12d, %r12d
	cmpl	$0, 184(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 216(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	subq	$-128, %r15
	cmpq	$2168, %r15
	jne	.LBB0_766
	movl	$4760, %r15d
	xorl	%r13d, %r13d
	.p2align	4
.LBB0_768:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r13, %rbp
	adcq	%r12, %rbp
	xorl	%r13d, %r13d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r13b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%rbp, %r13
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB0_768
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_770:
	xorl	%ebp, %ebp
	cmpl	$0, 160(%rsp,%r12)
	sete	%bpl
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbx
	adcq	%rbp, %rbx
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbx, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB0_770
	xorl	%ebx, %ebx
	cmpq	%rax, %r9
	jne	.LBB0_974
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %r12
	jne	.LBB0_781
	cmpq	%rdx, %r11
	jne	.LBB0_781
	cmpq	%rsi, %r14
	jne	.LBB0_781
	cmpq	%rdi, %r13
	jne	.LBB0_781
	cmpq	%r8, %r15
	jne	.LBB0_781
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_779
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	96(%rsp), %rdx
	movl	80(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	je	.LBB0_780
.LBB0_779:
	xorl	%ebx, %ebx
.LBB0_781:
	movl	$96, %eax
	.p2align	4
.LBB0_782:
	movq	$1, 17648(%rsp,%rax)
	movq	$2, 17640(%rsp,%rax)
	movq	$0, 17632(%rsp,%rax)
	movq	$0, 17624(%rsp,%rax)
	movq	$0, 17656(%rsp,%rax)
	movq	$0, 17664(%rsp,%rax)
	movq	$2, 17672(%rsp,%rax)
	movq	$1, 17680(%rsp,%rax)
	movq	$0, 17688(%rsp,%rax)
	movq	$0, 17696(%rsp,%rax)
	movq	$2, 17704(%rsp,%rax)
	movq	$1, 17712(%rsp,%rax)
	movq	$0, 17720(%rsp,%rax)
	movq	$0, 17728(%rsp,%rax)
	movq	$2, 17736(%rsp,%rax)
	movq	$1, 17744(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB0_782
	xorl	%eax, %eax
	.p2align	4
.LBB0_784:
	movq	$1, 12632(%rsp,%rax)
	movq	$512, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$512, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$512, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$512, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_784
	movl	%ebx, 184(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB0_786:
	movq	$1, 10072(%rsp,%rax)
	movq	$2, 10064(%rsp,%rax)
	movq	$0, 10056(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10080(%rsp,%rax)
	movq	$0, 10088(%rsp,%rax)
	movq	$0, 10096(%rsp,%rax)
	movq	$2, 10104(%rsp,%rax)
	movq	$1, 10112(%rsp,%rax)
	movq	$0, 10120(%rsp,%rax)
	movq	$0, 10128(%rsp,%rax)
	movq	$0, 10136(%rsp,%rax)
	movq	$2, 10144(%rsp,%rax)
	movq	$1, 10152(%rsp,%rax)
	movq	$0, 10160(%rsp,%rax)
	movq	$0, 10168(%rsp,%rax)
	movq	$0, 10176(%rsp,%rax)
	movq	$2, 10184(%rsp,%rax)
	movq	$1, 10192(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_786
	leaq	19768(%rsp), %rbx
	leaq	17720(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%r12
	leaq	24376(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r12
	leaq	21816(%rsp), %rdi
	leaq	10040(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r12
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r12
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$112, %eax
	xorl	%r13d, %r13d
	.p2align	4
.LBB0_788:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r13
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r13, %rdx
	xorl	%r13d, %r13d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r13b
	addq	%rdx, %r13
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB0_788
	movl	$4753, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_790:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r15, %rdx
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r15b
	addq	%rdx, %r15
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB0_790
	movl	$2192, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB0_792:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r12
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r12, %rdx
	xorl	%r12d, %r12d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r12b
	addq	%rdx, %r12
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB0_792
	movl	$120, %eax
	xorl	%ebp, %ebp
	.p2align	4
.LBB0_794:
	xorl	%ecx, %ecx
	cmpl	$0, 184(%rsp,%rax)
	sete	%cl
	cmpl	$1, 216(%rsp,%rax)
	movq	%rbp, %rdx
	adcq	%rcx, %rdx
	xorl	%ebp, %ebp
	cmpl	$0, 248(%rsp,%rax)
	sete	%bpl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %rbp
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB0_794
	movl	$4760, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_796:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%r14, %rdx
	adcq	%rcx, %rdx
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r14b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %r14
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB0_796
	movl	$2200, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_798:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbx, %rdx
	adcq	%rcx, %rdx
	xorl	%ebx, %ebx
	cmpl	$0, 240(%rsp,%rax)
	sete	%bl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %rbx
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB0_798
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB0_801
	.p2align	4
.LBB0_800:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB0_856
.LBB0_801:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB0_803
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB0_806
.LBB0_803:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_800
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_800
	incq	%rax
.LBB0_806:
	movl	$4680, %ecx
	xorl	%edx, %edx
	jmp	.LBB0_808
	.p2align	4
.LBB0_807:
	addq	$2, %rdx
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB0_856
.LBB0_808:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB0_810
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB0_813
.LBB0_810:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB0_807
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_807
	incq	%rdx
.LBB0_813:
	movq	%rax, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %esi
	movq	$1, 280(%rsp,%rcx)
	movq	$8, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	leaq	(%rdx,%rdx,4), %rcx
	leaq	280(%rsp), %rdi
	movq	%rax, 4608(%rdi,%rcx,8)
	movl	%esi, 4616(%rdi,%rcx,8)
	movq	$1, 4624(%rdi,%rcx,8)
	movw	$263, 4632(%rdi,%rcx,8)
	movq	$8, 10032(%rsp)
	movl	4640(%rdi,%rcx,8), %ecx
	movl	$4680, %edi
	xorl	%r8d, %r8d
	jmp	.LBB0_815
	.p2align	4
.LBB0_814:
	addq	$2, %r8
	addq	$80, %rdi
	cmpq	$9800, %rdi
	je	.LBB0_856
.LBB0_815:
	cmpb	$2, 233(%rsp,%rdi)
	jne	.LBB0_817
	cmpl	$0, 240(%rsp,%rdi)
	jne	.LBB0_820
.LBB0_817:
	cmpb	$2, 273(%rsp,%rdi)
	jne	.LBB0_814
	cmpl	$0, 280(%rsp,%rdi)
	je	.LBB0_814
	incq	%r8
.LBB0_820:
	movq	%r8, 24(%rsp)
	leaq	(%r8,%r8,4), %rdi
	leaq	280(%rsp), %r8
	movq	%rax, 4608(%r8,%rdi,8)
	movl	%esi, 4616(%r8,%rdi,8)
	movq	$2, 4624(%r8,%rdi,8)
	movw	$1, 4632(%r8,%rdi,8)
	movl	4640(%r8,%rdi,8), %eax
	movl	%eax, 32(%rsp)
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_856
	movl	$64, %eax
	.p2align	4
.LBB0_823:
	addq	$-4, %rax
	jne	.LBB0_823
	movl	$128, %eax
	.p2align	4
.LBB0_825:
	addq	$-4, %rax
	jne	.LBB0_825
	movl	$64, %eax
	.p2align	4
.LBB0_827:
	addq	$-4, %rax
	jne	.LBB0_827
	movl	$64, %ecx
	movq	10032(%rsp), %rax
	.p2align	4
.LBB0_829:
	addq	$-4, %rcx
	jne	.LBB0_829
	movl	$128, %ecx
	.p2align	4
.LBB0_831:
	addq	$-4, %rcx
	jne	.LBB0_831
	movl	$64, %ecx
	.p2align	4
.LBB0_833:
	addq	$-4, %rcx
	jne	.LBB0_833
	cmpq	$8, %rax
	jne	.LBB0_856
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_836:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_836
	movl	$128, %ecx
	.p2align	4
.LBB0_838:
	addq	$-4, %rcx
	jne	.LBB0_838
	movl	$64, %ecx
	.p2align	4
.LBB0_840:
	addq	$-4, %rcx
	jne	.LBB0_840
	movl	$64, %ecx
	.p2align	4
.LBB0_842:
	addq	$-4, %rcx
	jne	.LBB0_842
	movl	$128, %ecx
	.p2align	4
.LBB0_844:
	addq	$-4, %rcx
	jne	.LBB0_844
	movl	$64, %ecx
	.p2align	4
.LBB0_846:
	addq	$-4, %rcx
	jne	.LBB0_846
	cmpq	$1, %rax
	jne	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	24(%rsp), %rcx
	cmpq	$1, 12608(%rsp)
	jne	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$2, %edx
	movl	32(%rsp), %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$1, 12600(%rsp)
	je	.LBB0_856
	movq	12608(%rsp), %rax
	movq	%rax, 40(%rsp)
	movl	12616(%rsp), %eax
	movl	%eax, 56(%rsp)
	leaq	280(%rsp), %rdi
	movl	$2, %esi
	movq	24(%rsp), %rdx
	movl	32(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$8, 12624(%rsp)
	jne	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12608(%rsp)
	jne	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$1, 12616(%rsp)
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	movq	40(%rsp), %rsi
	movl	56(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	orb	%al, %dl
	testb	$1, %dl
	je	.LBB0_1768
.LBB0_856:
	movl	$0, 16(%rsp)
.LBB0_857:
	movl	$96, %eax
	movq	memcpy@GOTPCREL(%rip), %r12
	.p2align	4
.LBB0_858:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB0_858
	xorl	%eax, %eax
	.p2align	4
.LBB0_860:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_860
	xorl	%eax, %eax
	.p2align	4
.LBB0_862:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_862
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%r12
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %r14
	movl	$5120, %edx
	movq	%r14, %rsi
	callq	*%r12
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r12
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r12
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	xorl	%ebx, %ebx
	xorl	%r9d, %r9d
.LBB0_864:
	cmpl	$64, %ebx
	je	.LBB0_914
	cmpq	10008(%rsp), %r9
	jae	.LBB0_976
	incl	%ebx
	incq	%r9
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB0_868
	.p2align	4
.LBB0_867:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB0_976
.LBB0_868:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB0_870
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB0_873
.LBB0_870:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_867
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_867
	incq	%rax
.LBB0_873:
	movl	$4680, %ecx
	xorl	%r15d, %r15d
	jmp	.LBB0_875
	.p2align	4
.LBB0_874:
	addq	$2, %r15
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB0_976
.LBB0_875:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB0_877
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB0_880
.LBB0_877:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB0_874
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_874
	incq	%r15
.LBB0_880:
	movq	%rax, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %edx
	movq	$1, 280(%rsp,%rcx)
	movq	$1, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	leaq	(%r15,%r15,4), %rcx
	leaq	280(%rsp), %rsi
	movq	%rax, 4608(%rsi,%rcx,8)
	movl	%edx, 4616(%rsi,%rcx,8)
	movq	$1, 4624(%rsi,%rcx,8)
	movw	$263, 4632(%rsi,%rcx,8)
	movq	%r9, 10032(%rsp)
	movl	4640(%rsi,%rcx,8), %ebp
	movl	$1, %esi
	movq	%r14, %rdi
	movq	%r15, %rdx
	movl	%ebp, %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB0_976
	movq	%r15, %rdx
	movl	$112, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_882:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rax)
	setne	%sil
	addq	%rcx, %rsi
	addq	%r14, %rsi
	xorl	%r14d, %r14d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r14b
	addq	%rsi, %r14
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB0_882
	movl	%ebp, %ecx
	movl	$4753, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_884:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rax)
	setne	%sil
	addq	%rsi, %r15
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rax)
	setne	%dil
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rdi, %rsi
	addq	%r15, %rsi
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r15b
	addq	%rsi, %r15
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB0_884
	movl	$2192, %eax
	xorl	%ebp, %ebp
	.p2align	4
.LBB0_886:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rax)
	setne	%sil
	addq	%rsi, %rbp
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rax)
	setne	%dil
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rdi, %rsi
	addq	%rbp, %rsi
	xorl	%ebp, %ebp
	cmpb	$2, 280(%rsp,%rax)
	setne	%bpl
	addq	%rsi, %rbp
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB0_886
	movl	$120, %eax
	movq	10032(%rsp), %rsi
	xorl	%r12d, %r12d
	.p2align	4
.LBB0_888:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rax)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rax)
	movq	%r12, %rdi
	adcq	%r8, %rdi
	xorl	%r12d, %r12d
	cmpl	$0, 248(%rsp,%rax)
	sete	%r12b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdi, %r12
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB0_888
	movq	%rbx, 32(%rsp)
	movl	$4760, %eax
	xorl	%r13d, %r13d
	.p2align	4
.LBB0_890:
	xorl	%r8d, %r8d
	cmpl	$0, 160(%rsp,%rax)
	sete	%r8b
	cmpl	$1, 200(%rsp,%rax)
	movq	%r13, %rdi
	adcq	%r8, %rdi
	xorl	%r13d, %r13d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r13b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdi, %r13
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB0_890
	movq	%rsi, 24(%rsp)
	movl	$2200, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_892:
	xorl	%edi, %edi
	cmpl	$0, 160(%rsp,%rax)
	sete	%dil
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbx, %rsi
	adcq	%rdi, %rsi
	xorl	%ebx, %ebx
	cmpl	$0, 240(%rsp,%rax)
	sete	%bl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %rbx
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB0_892
	movl	$1, %esi
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	je	.LBB0_973
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_895:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_895
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_897:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_897
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_899:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_899
	movl	$120, %r8d
	movq	10032(%rsp), %rsi
	movq	%rsi, 40(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB0_901:
	xorl	%r9d, %r9d
	cmpl	$0, 184(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 216(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%r8)
	sete	%sil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2168, %r8
	jne	.LBB0_901
	movl	$4760, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_903:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$9880, %r9
	jne	.LBB0_903
	movl	$2200, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_905:
	xorl	%r11d, %r11d
	cmpl	$0, 160(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 200(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 240(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 280(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$4760, %r10
	jne	.LBB0_905
	movq	40(%rsp), %rdi
	cmpq	24(%rsp), %rdi
	jne	.LBB0_975
	cmpq	%r14, %rax
	jne	.LBB0_975
	cmpq	%r15, %rcx
	jne	.LBB0_975
	cmpq	%rbp, %rdx
	jne	.LBB0_975
	cmpq	%r12, %rsi
	jne	.LBB0_975
	cmpq	%r13, %r8
	movq	memcpy@GOTPCREL(%rip), %r12
	jne	.LBB0_976
	cmpq	%rbx, %r9
	movl	$0, %r13d
	jne	.LBB0_977
	leaq	280(%rsp), %r14
	movq	%r14, %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movq	24(%rsp), %r9
	testb	%al, %al
	movq	32(%rsp), %rbx
	jne	.LBB0_864
	jmp	.LBB0_976
.LBB0_605:
	movl	$2120, %esi
	xorl	%r13d, %r13d
	jmp	.LBB0_607
	.p2align	4
.LBB0_606:
	addq	$2, %r13
	addq	$80, %rsi
	cmpq	$4680, %rsi
	je	.LBB0_604
.LBB0_607:
	cmpb	$2, 232(%rsp,%rsi)
	jne	.LBB0_609
	cmpl	$0, 240(%rsp,%rsi)
	jne	.LBB0_612
.LBB0_609:
	cmpb	$2, 272(%rsp,%rsi)
	jne	.LBB0_606
	cmpl	$0, 280(%rsp,%rsi)
	je	.LBB0_606
	incq	%r13
.LBB0_612:
	leaq	(,%r13,4), %rsi
	addq	%r13, %rsi
	movq	$1, (%rdx,%rsi,8)
	movq	%rax, 8(%rdx,%rsi,8)
	movl	%ecx, 16(%rdx,%rsi,8)
	movb	$0, 24(%rdx,%rsi,8)
	movl	32(%rdx,%rsi,8), %eax
	movl	%eax, 96(%rsp)
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_613:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_613
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_615:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_615
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_617:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_617
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB0_619:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_619
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_621:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_621
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_623:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_623
	movl	$2192, %r9d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_625:
	xorl	%r11d, %r11d
	cmpb	$2, 160(%rsp,%r9)
	setne	%r11b
	addq	%r11, %r10
	xorl	%r11d, %r11d
	cmpb	$2, 200(%rsp,%r9)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 240(%rsp,%r9)
	setne	%bl
	addq	%r11, %rbx
	addq	%r10, %rbx
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r9)
	setne	%r10b
	addq	%rbx, %r10
	addq	$160, %r9
	cmpq	$4752, %r9
	jne	.LBB0_625
	testq	%r10, %r10
	je	.LBB0_649
.LBB0_627:
	movq	%r14, 88(%rsp)
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_628:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_628
	movl	%r15d, 120(%rsp)
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_630:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_630
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB0_632:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB0_632
	movq	%r13, 80(%rsp)
	movl	%ebp, 72(%rsp)
	movl	$120, %ebx
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_634:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%rbx)
	sete	%r15b
	cmpl	$1, 216(%rsp,%rbx)
	movq	%r14, %r12
	adcq	%r15, %r12
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%rbx)
	sete	%r14b
	cmpl	$1, 280(%rsp,%rbx)
	adcq	%r12, %r14
	subq	$-128, %rbx
	cmpq	$2168, %rbx
	jne	.LBB0_634
	movl	$4760, %r15d
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_636:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%rbx, %r13
	adcq	%r12, %r13
	xorl	%ebx, %ebx
	cmpl	$0, 240(%rsp,%r15)
	sete	%bl
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %rbx
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB0_636
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_638:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB0_638
	xorl	%r13d, %r13d
	cmpq	%rax, %r9
	jne	.LBB0_724
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %r12
	movl	72(%rsp), %ebp
	jne	.LBB0_725
	cmpq	%rdx, %r11
	jne	.LBB0_725
	cmpq	%rsi, %r14
	jne	.LBB0_725
	cmpq	%rdi, %rbx
	jne	.LBB0_725
	cmpq	%r8, %r15
	jne	.LBB0_725
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_604
	leaq	280(%rsp), %rdi
	movq	80(%rsp), %rsi
	movl	96(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	jne	.LBB0_604
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	xorl	%r13d, %r13d
	movl	$1, %edx
	movq	88(%rsp), %rcx
	movl	120(%rsp), %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$0, 12600(%rsp)
	jne	.LBB0_725
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	%eax, %r13d
	jmp	.LBB0_725
.LBB0_649:
	xorl	%r9d, %r9d
	jmp	.LBB0_651
	.p2align	4
.LBB0_650:
	addq	$80, %r9
	cmpq	$2560, %r9
	je	.LBB0_627
.LBB0_651:
	cmpb	$2, 2352(%rsp,%r9)
	jne	.LBB0_653
	cmpl	$0, 2360(%rsp,%r9)
	jne	.LBB0_604
.LBB0_653:
	cmpb	$2, 2392(%rsp,%r9)
	jne	.LBB0_650
	cmpl	$0, 2400(%rsp,%r9)
	je	.LBB0_650
	jmp	.LBB0_604
.LBB0_780:
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	32(%rsp), %ecx
	andb	24(%rsp), %cl
	movl	40(%rsp), %edx
	andb	%cl, %dl
	andb	%al, %dl
	movl	72(%rsp), %eax
	andb	56(%rsp), %al
	movl	88(%rsp), %ebx
	andb	%al, %bl
	andb	%dl, %bl
	jmp	.LBB0_781
.LBB0_914:
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_915:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_915
	movl	$128, %ecx
	.p2align	4
.LBB0_917:
	addq	$-4, %rcx
	jne	.LBB0_917
	movl	$64, %ecx
	.p2align	4
.LBB0_919:
	addq	$-4, %rcx
	jne	.LBB0_919
	movl	$120, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_921:
	xorl	%esi, %esi
	cmpl	$0, 184(%rsp,%rdx)
	sete	%sil
	cmpl	$1, 216(%rsp,%rdx)
	movq	%rcx, %rdi
	adcq	%rsi, %rdi
	xorl	%ecx, %ecx
	cmpl	$0, 248(%rsp,%rdx)
	sete	%cl
	cmpl	$1, 280(%rsp,%rdx)
	adcq	%rdi, %rcx
	subq	$-128, %rdx
	cmpq	$2168, %rdx
	jne	.LBB0_921
	movl	$4760, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_923:
	xorl	%edi, %edi
	cmpl	$0, 160(%rsp,%rsi)
	sete	%dil
	cmpl	$1, 200(%rsp,%rsi)
	movq	%rdx, %r8
	adcq	%rdi, %r8
	xorl	%edx, %edx
	cmpl	$0, 240(%rsp,%rsi)
	sete	%dl
	cmpl	$1, 280(%rsp,%rsi)
	adcq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$9880, %rsi
	jne	.LBB0_923
	movl	$64, %esi
	.p2align	4
.LBB0_925:
	addq	$-4, %rsi
	jne	.LBB0_925
	xorl	%r13d, %r13d
	orq	%r9, %rax
	jne	.LBB0_977
	cmpq	$64, %rcx
	jne	.LBB0_977
	cmpq	$64, %rdx
	jne	.LBB0_977
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_930:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_930
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_932:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_932
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_934:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_934
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB0_936:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_936
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_938:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_938
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_940:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_940
	cmpq	$0, 10008(%rsp)
	je	.LBB0_954
	xorl	%r9d, %r9d
	jmp	.LBB0_944
.LBB0_943:
	addq	$64, %r9
	cmpq	$2048, %r9
	je	.LBB0_954
.LBB0_944:
	cmpb	$2, 296(%rsp,%r9)
	jne	.LBB0_946
	cmpl	$0, 304(%rsp,%r9)
	jne	.LBB0_948
.LBB0_946:
	cmpb	$2, 328(%rsp,%r9)
	jne	.LBB0_943
	cmpl	$0, 336(%rsp,%r9)
	je	.LBB0_943
.LBB0_948:
	xorl	%r9d, %r9d
	jmp	.LBB0_950
.LBB0_949:
	addq	$80, %r9
	cmpq	$5120, %r9
	je	.LBB0_954
.LBB0_950:
	cmpb	$2, 4913(%rsp,%r9)
	jne	.LBB0_952
	cmpl	$0, 4920(%rsp,%r9)
	jne	.LBB0_976
.LBB0_952:
	cmpb	$2, 4953(%rsp,%r9)
	jne	.LBB0_949
	cmpl	$0, 4960(%rsp,%r9)
	je	.LBB0_949
	jmp	.LBB0_976
.LBB0_296:
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	jmp	.LBB0_298
.LBB0_376:
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	jmp	.LBB0_378
.LBB0_655:
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_656:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_656
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_658:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_658
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB0_660:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB0_660
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_662:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB0_662
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_664:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB0_664
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_666:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB0_666
	xorl	%ebp, %ebp
	cmpq	%rax, %r9
	jne	.LBB0_1743
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %r12
	jne	.LBB0_439
	cmpq	%rdx, %r11
	jne	.LBB0_439
	cmpq	%rsi, %rbx
	jne	.LBB0_439
	cmpq	%rdi, %r14
	jne	.LBB0_439
	cmpq	%r8, %r15
	jne	.LBB0_439
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	%eax, %ebp
	jmp	.LBB0_439
.LBB0_954:
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_955:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_955
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_957:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_957
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB0_959:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB0_959
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_961:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB0_961
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_963:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB0_963
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_965:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB0_965
	xorl	%r13d, %r13d
	cmpq	%rax, %r9
	jne	.LBB0_1745
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %r12
	jne	.LBB0_977
	cmpq	%rdx, %r11
	jne	.LBB0_977
	cmpq	%rsi, %rbx
	jne	.LBB0_977
	cmpq	%rdi, %r14
	jne	.LBB0_977
	cmpq	%r8, %r15
	jne	.LBB0_977
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	%eax, %r13d
	jmp	.LBB0_977
.LBB0_674:
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_675:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_675
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_677:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_677
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB0_679:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB0_679
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_681:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB0_681
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_683:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB0_683
	movl	$2200, %r13d
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_685:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r13)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r13)
	movq	%r15, %rbp
	adcq	%r12, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r13)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r13)
	adcq	%rbp, %r15
	addq	$160, %r13
	cmpq	$4760, %r13
	jne	.LBB0_685
	xorl	%ebp, %ebp
	cmpq	%rax, %r9
	jne	.LBB0_1747
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %r12
	jne	.LBB0_581
	cmpq	%rdx, %r11
	jne	.LBB0_581
	cmpq	%rsi, %rbx
	jne	.LBB0_581
	cmpq	%rdi, %r14
	jne	.LBB0_581
	cmpq	%r8, %r15
	jne	.LBB0_581
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	%eax, %ebp
	jmp	.LBB0_581
.LBB0_973:
	xorl	%r13d, %r13d
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_977
.LBB0_974:
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_781
.LBB0_693:
	movl	$112, %r10d
	xorl	%eax, %eax
.LBB0_694:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %rax
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%rax, %rbx
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%r10)
	setne	%al
	addq	%rbx, %rax
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_694
	movl	$4753, %r11d
	xorl	%r10d, %r10d
.LBB0_696:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_696
	movl	$2192, %ebx
	xorl	%r11d, %r11d
.LBB0_698:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r12d, %r12d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r12b
	addq	%r14, %r12
	addq	%r11, %r12
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r12, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB0_698
	movq	%rax, 72(%rsp)
	movl	$120, %r14d
	xorl	%ebx, %ebx
.LBB0_700:
	xorl	%r12d, %r12d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r12b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %rbp
	adcq	%r12, %rbp
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%rbp, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB0_700
	movl	$4760, %r12d
	xorl	%r14d, %r14d
.LBB0_702:
	xorl	%ebp, %ebp
	cmpl	$0, 160(%rsp,%r12)
	sete	%bpl
	cmpl	$1, 200(%rsp,%r12)
	movq	%r14, %rax
	adcq	%rbp, %rax
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rax, %r14
	addq	$160, %r12
	cmpq	$9880, %r12
	jne	.LBB0_702
	movl	$2200, %r12d
	xorl	%ebp, %ebp
.LBB0_704:
	xorl	%eax, %eax
	cmpl	$0, 160(%rsp,%r12)
	sete	%al
	cmpl	$1, 200(%rsp,%r12)
	movq	%rbp, %r9
	adcq	%rax, %r9
	xorl	%ebp, %ebp
	cmpl	$0, 240(%rsp,%r12)
	sete	%bpl
	cmpl	$1, 280(%rsp,%r12)
	adcq	%r9, %rbp
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB0_704
	cmpq	%r15, 72(%rsp)
	jne	.LBB0_1767
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %r12
	jne	.LBB0_512
	cmpq	%rdx, %r11
	movl	$0, %eax
	jne	.LBB0_513
	cmpq	%rsi, %rbx
	jne	.LBB0_513
	cmpq	%rdi, %r14
	jne	.LBB0_513
	cmpq	%r8, %rbp
	jne	.LBB0_513
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_512
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rbx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$1, (%rsp)
	leaq	12600(%rsp), %rdi
	movl	$1, %edx
	movl	$2, %r9d
	movq	%rbx, %rsi
	movq	%r13, %rcx
	movl	56(%rsp), %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$0, 12600(%rsp)
	je	.LBB0_512
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_512
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_512
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_512
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_512
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_512
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_512
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_512
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_723
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	%r13, %rdx
	movl	56(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$-1, %al
	jne	.LBB0_723
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12624(%rsp)
	je	.LBB0_1852
.LBB0_723:
	xorl	%eax, %eax
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_513
.LBB0_975:
	movq	memcpy@GOTPCREL(%rip), %r12
.LBB0_976:
	xorl	%r13d, %r13d
.LBB0_977:
	movl	$96, %eax
	.p2align	4
.LBB0_978:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB0_978
	xorl	%eax, %eax
	.p2align	4
.LBB0_980:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_980
	xorl	%eax, %eax
	.p2align	4
.LBB0_982:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_982
	leaq	19768(%rsp), %r15
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%r15, %rdi
	callq	*%r12
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r12
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r12
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%r15, %rsi
	callq	*%r12
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB0_985
	.p2align	4
.LBB0_984:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB0_1015
.LBB0_985:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB0_987
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB0_990
.LBB0_987:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_984
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_984
	incq	%rax
.LBB0_990:
	movl	$4680, %ecx
	xorl	%r15d, %r15d
	jmp	.LBB0_992
	.p2align	4
.LBB0_991:
	addq	$2, %r15
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB0_1015
.LBB0_992:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB0_994
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB0_997
.LBB0_994:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB0_991
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_991
	incq	%r15
.LBB0_997:
	movq	%rax, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %edx
	movq	$1, 280(%rsp,%rcx)
	movq	$1, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	leaq	(%r15,%r15,4), %rcx
	leaq	280(%rsp), %rsi
	leaq	4608(%rsi,%rcx,8), %r14
	movq	%rax, 4608(%rsi,%rcx,8)
	movl	%edx, 4616(%rsi,%rcx,8)
	movq	$1, 4624(%rsi,%rcx,8)
	movw	$263, 4632(%rsi,%rcx,8)
	movq	$1, 10032(%rsp)
	movl	4640(%rsi,%rcx,8), %eax
	movl	$1, %ebx
	leaq	280(%rsp), %r12
	movl	%eax, 24(%rsp)
.LBB0_998:
	cmpl	$128, %ebx
	je	.LBB0_1584
	cmpl	%eax, 32(%r14)
	jne	.LBB0_1015
	cmpb	$2, 25(%r14)
	je	.LBB0_1015
	xorl	%ebp, %ebp
	cmpq	$1, 16(%r14)
	jne	.LBB0_1016
	movq	(%r14), %rax
	cmpq	$63, %rax
	ja	.LBB0_1016
	movl	8(%r14), %ecx
	movq	%rax, %rdx
	shlq	$5, %rdx
	cmpl	%ecx, 304(%rsp,%rdx)
	jne	.LBB0_1015
	addq	%rsp, %rdx
	addq	$280, %rdx
	xorl	%ebp, %ebp
	cmpb	$0, 16(%rdx)
	jne	.LBB0_1016
	movzbl	24(%r14), %edx
	andb	$5, %dl
	cmpb	$5, %dl
	jne	.LBB0_1016
	incl	%ebx
	movl	$4680, %esi
	xorl	%edx, %edx
	jmp	.LBB0_1008
	.p2align	4
.LBB0_1007:
	addq	$2, %rdx
	addq	$80, %rsi
	cmpq	$9800, %rsi
	je	.LBB0_1015
.LBB0_1008:
	cmpb	$2, 233(%rsp,%rsi)
	jne	.LBB0_1010
	cmpl	$0, 240(%rsp,%rsi)
	jne	.LBB0_1013
.LBB0_1010:
	cmpb	$2, 273(%rsp,%rsi)
	jne	.LBB0_1007
	cmpl	$0, 280(%rsp,%rsi)
	je	.LBB0_1007
	incq	%rdx
.LBB0_1013:
	leaq	(%rdx,%rdx,4), %rsi
	leaq	280(%rsp), %rdi
	movq	%rax, 4608(%rdi,%rsi,8)
	movl	%ecx, 4616(%rdi,%rsi,8)
	movq	$2, 4624(%rdi,%rsi,8)
	movw	$1, 4632(%rdi,%rsi,8)
	movl	4640(%rdi,%rsi,8), %ecx
	movl	$2, %esi
	movq	%r12, %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB0_1015
	movq	%r12, %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	xorl	%ebp, %ebp
	testb	%al, %al
	movl	24(%rsp), %eax
	jne	.LBB0_998
	jmp	.LBB0_1016
.LBB0_1584:
	movl	$64, %eax
	.p2align	4
.LBB0_1585:
	addq	$-4, %rax
	jne	.LBB0_1585
	movl	$128, %eax
	.p2align	4
.LBB0_1587:
	addq	$-4, %rax
	jne	.LBB0_1587
	movl	$64, %eax
	.p2align	4
.LBB0_1589:
	addq	$-4, %rax
	jne	.LBB0_1589
	movl	$64, %eax
	.p2align	4
.LBB0_1591:
	addq	$-4, %rax
	jne	.LBB0_1591
	movl	$4760, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_1593:
	xorl	%edx, %edx
	cmpl	$0, 160(%rsp,%rcx)
	sete	%dl
	cmpl	$1, 200(%rsp,%rcx)
	movq	%rax, %rsi
	adcq	%rdx, %rsi
	xorl	%eax, %eax
	cmpl	$0, 240(%rsp,%rcx)
	sete	%al
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %rax
	addq	$160, %rcx
	cmpq	$9880, %rcx
	jne	.LBB0_1593
	movl	$64, %ecx
	.p2align	4
.LBB0_1595:
	addq	$-4, %rcx
	jne	.LBB0_1595
	cmpq	$127, %rax
	jne	.LBB0_1015
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_1598:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_1598
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_1600:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_1600
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_1602:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_1602
	movl	$120, %edi
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_1604:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rbx, %r9
	adcq	%r8, %r9
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%rdi)
	sete	%bl
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rbx
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_1604
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_1606:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_1606
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_1608:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_1608
	movl	24(%rsp), %esi
	cmpl	%esi, 32(%r14)
	jne	.LBB0_1657
	cmpb	$2, 25(%r14)
	je	.LBB0_1657
	movq	(%r14), %r9
	cmpq	$1, 16(%r14)
	sete	%r10b
	cmpq	$64, %r9
	setb	%r11b
	andb	%r10b, %r11b
	cmpb	$1, %r11b
	jne	.LBB0_1657
	movl	8(%r14), %r10d
	shlq	$5, %r9
	cmpl	%r10d, 304(%rsp,%r9)
	jne	.LBB0_1657
	addq	%rsp, %r9
	addq	$280, %r9
	cmpb	$0, 16(%r9)
	jne	.LBB0_1657
	movzbl	24(%r14), %r9d
	andb	$5, %r9b
	cmpb	$5, %r9b
	jne	.LBB0_1657
	xorl	%r9d, %r9d
	jmp	.LBB0_1653
.LBB0_1652:
	addq	$80, %r9
	cmpq	$5120, %r9
	je	.LBB0_1657
.LBB0_1653:
	cmpb	$2, 4913(%rsp,%r9)
	jne	.LBB0_1655
	cmpl	$0, 4920(%rsp,%r9)
	jne	.LBB0_1015
.LBB0_1655:
	cmpb	$2, 4953(%rsp,%r9)
	jne	.LBB0_1652
	cmpl	$0, 4960(%rsp,%r9)
	je	.LBB0_1652
	jmp	.LBB0_1015
.LBB0_1657:
	movq	%rbx, 32(%rsp)
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_1658:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_1658
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_1660:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_1660
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB0_1662:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r12d, %r12d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r12b
	addq	%r14, %r12
	addq	%r11, %r12
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r12, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB0_1662
	movl	%r13d, 40(%rsp)
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_1664:
	xorl	%r12d, %r12d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r12b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %rbp
	adcq	%r12, %rbp
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%rbp, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB0_1664
	movl	$4760, %r12d
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_1666:
	xorl	%ebp, %ebp
	cmpl	$0, 160(%rsp,%r12)
	sete	%bpl
	cmpl	$1, 200(%rsp,%r12)
	movq	%r14, %r13
	adcq	%rbp, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%r13, %r14
	addq	$160, %r12
	cmpq	$9880, %r12
	jne	.LBB0_1666
	movl	$2200, %ebp
	xorl	%r12d, %r12d
	.p2align	4
.LBB0_1668:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%rbp)
	sete	%r13b
	cmpl	$1, 200(%rsp,%rbp)
	movq	%r12, %rsi
	adcq	%r13, %rsi
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%rbp)
	sete	%r12b
	cmpl	$1, 280(%rsp,%rbp)
	adcq	%rsi, %r12
	addq	$160, %rbp
	cmpq	$4760, %rbp
	jne	.LBB0_1668
	xorl	%ebp, %ebp
	cmpq	%rax, %r9
	jne	.LBB0_1016
	cmpq	%rcx, %r10
	jne	.LBB0_1016
	cmpq	%rdx, %r11
	jne	.LBB0_1016
	cmpq	32(%rsp), %rbx
	jne	.LBB0_1016
	cmpq	%rdi, %r14
	jne	.LBB0_1016
	cmpq	%r8, %r12
	movl	40(%rsp), %ebx
	jne	.LBB0_1016
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_1015
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	%r15, %rdx
	movl	24(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB0_1015
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$128, 12640(%rsp)
	jne	.LBB0_1015
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	andb	%al, %bl
	movl	%ebx, %ebp
	jmp	.LBB0_1016
.LBB0_1015:
	xorl	%ebp, %ebp
.LBB0_1016:
	movl	$96, %eax
	.p2align	4
.LBB0_1017:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB0_1017
	xorl	%eax, %eax
	movq	memcpy@GOTPCREL(%rip), %r12
	.p2align	4
.LBB0_1019:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_1019
	xorl	%eax, %eax
	.p2align	4
.LBB0_1021:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_1021
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%r12
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r12
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r12
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r12
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB0_1024
	.p2align	4
.LBB0_1023:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB0_1091
.LBB0_1024:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB0_1026
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB0_1029
.LBB0_1026:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_1023
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_1023
	incq	%rax
.LBB0_1029:
	movl	$4680, %ecx
	xorl	%esi, %esi
	jmp	.LBB0_1031
	.p2align	4
.LBB0_1030:
	addq	$2, %rsi
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB0_1091
.LBB0_1031:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB0_1033
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB0_1036
.LBB0_1033:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB0_1030
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_1030
	incq	%rsi
.LBB0_1036:
	movq	%rax, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %edx
	movq	$1, 280(%rsp,%rcx)
	movq	$1, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	movq	%rsi, 80(%rsp)
	leaq	(%rsi,%rsi,4), %rcx
	leaq	280(%rsp), %rsi
	leaq	4608(%rsi,%rcx,8), %rbx
	movq	%rax, 4608(%rsi,%rcx,8)
	movl	%edx, 4616(%rsi,%rcx,8)
	movq	$1, 4624(%rsi,%rcx,8)
	movw	$263, 4632(%rsi,%rcx,8)
	movq	$1, 10032(%rsp)
	movl	4640(%rsi,%rcx,8), %r14d
	xorl	%r15d, %r15d
	leaq	2328(%rsp), %r13
	movl	%ebp, 96(%rsp)
	movl	%r14d, 32(%rsp)
	movq	%rbx, 72(%rsp)
.LBB0_1037:
	cmpl	$64, %r15d
	je	.LBB0_1616
	cmpl	%r14d, 32(%rbx)
	jne	.LBB0_1091
	cmpb	$2, 25(%rbx)
	je	.LBB0_1091
	xorl	%edi, %edi
	cmpq	$1, 16(%rbx)
	jne	.LBB0_1092
	movq	(%rbx), %rax
	cmpq	$63, %rax
	ja	.LBB0_1092
	movl	8(%rbx), %ecx
	movq	%rax, %rdx
	shlq	$5, %rdx
	cmpl	%ecx, 304(%rsp,%rdx)
	jne	.LBB0_1091
	addq	%rsp, %rdx
	addq	$280, %rdx
	xorl	%edi, %edi
	cmpb	$0, 16(%rdx)
	jne	.LBB0_1092
	testb	$1, 24(%rbx)
	je	.LBB0_1092
	incl	%r15d
	movl	$2192, %edx
	xorl	%esi, %esi
	.p2align	4
.LBB0_1046:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%dil
	addq	%rdi, %rsi
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rdx)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rsi, %r8
	xorl	%esi, %esi
	cmpb	$2, 280(%rsp,%rdx)
	setne	%sil
	addq	%r8, %rsi
	addq	$160, %rdx
	cmpq	$4752, %rdx
	jne	.LBB0_1046
	cmpq	10016(%rsp), %rsi
	jae	.LBB0_1091
	movl	$2120, %edx
	xorl	%esi, %esi
	jmp	.LBB0_1050
	.p2align	4
.LBB0_1049:
	addq	$2, %rsi
	addq	$80, %rdx
	cmpq	$4680, %rdx
	je	.LBB0_1091
.LBB0_1050:
	cmpb	$2, 232(%rsp,%rdx)
	jne	.LBB0_1052
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB0_1055
.LBB0_1052:
	cmpb	$2, 272(%rsp,%rdx)
	jne	.LBB0_1049
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB0_1049
	incq	%rsi
.LBB0_1055:
	leaq	(%rsi,%rsi,4), %rdx
	movq	$1, (%r13,%rdx,8)
	movq	%rax, 8(%r13,%rdx,8)
	movl	%ecx, 16(%r13,%rdx,8)
	movb	$0, 24(%r13,%rdx,8)
	movl	32(%r13,%rdx,8), %edx
	leaq	280(%rsp), %rdi
	movq	%rsi, %r13
	movl	%edx, 24(%rsp)
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	xorl	%edi, %edi
	testb	$1, %al
	jne	.LBB0_1092
	testb	$1, %dl
	jne	.LBB0_1092
	movl	$112, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_1058:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB0_1058
	movq	%r15, 56(%rsp)
	movl	$4753, %eax
	xorl	%ebp, %ebp
	movq	%r13, %rsi
	.p2align	4
.LBB0_1060:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbp
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%rbp, %rdx
	xorl	%ebp, %ebp
	cmpb	$2, 280(%rsp,%rax)
	setne	%bpl
	addq	%rdx, %rbp
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB0_1060
	movl	$2192, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_1062:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r15, %rdx
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r15b
	addq	%rdx, %r15
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB0_1062
	movl	$120, %eax
	movq	10032(%rsp), %rcx
	movq	%rcx, 40(%rsp)
	xorl	%r13d, %r13d
	.p2align	4
.LBB0_1064:
	xorl	%ecx, %ecx
	cmpl	$0, 184(%rsp,%rax)
	sete	%cl
	cmpl	$1, 216(%rsp,%rax)
	movq	%r13, %rdx
	adcq	%rcx, %rdx
	xorl	%r13d, %r13d
	cmpl	$0, 248(%rsp,%rax)
	sete	%r13b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %r13
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB0_1064
	movl	$4760, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_1066:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbx, %rdx
	adcq	%rcx, %rdx
	xorl	%ebx, %ebx
	cmpl	$0, 240(%rsp,%rax)
	sete	%bl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %rbx
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB0_1066
	movl	$2200, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB0_1068:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%r12, %rdx
	adcq	%rcx, %rdx
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r12b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %r12
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB0_1068
	leaq	280(%rsp), %rdi
	movl	24(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	je	.LBB0_1651
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_1071:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_1071
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_1073:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_1073
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_1075:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_1075
	movl	$120, %r8d
	movq	10032(%rsp), %rsi
	movq	%rsi, 24(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB0_1077:
	xorl	%r9d, %r9d
	cmpl	$0, 184(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 216(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%r8)
	sete	%sil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2168, %r8
	jne	.LBB0_1077
	movl	$4760, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_1079:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$9880, %r9
	jne	.LBB0_1079
	movl	$2200, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_1081:
	xorl	%r11d, %r11d
	cmpl	$0, 160(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 200(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 240(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 280(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$4760, %r10
	jne	.LBB0_1081
	xorl	%edi, %edi
	movq	24(%rsp), %r10
	cmpq	40(%rsp), %r10
	jne	.LBB0_1744
	cmpq	%r14, %rax
	jne	.LBB0_1744
	cmpq	%rbp, %rcx
	jne	.LBB0_1744
	cmpq	%r15, %rdx
	jne	.LBB0_1744
	cmpq	%r13, %rsi
	jne	.LBB0_1744
	cmpq	%rbx, %r8
	jne	.LBB0_1744
	cmpq	%r12, %r9
	movq	memcpy@GOTPCREL(%rip), %r12
	movl	32(%rsp), %r14d
	movq	72(%rsp), %rbx
	movq	56(%rsp), %r15
	leaq	2328(%rsp), %r13
	jne	.LBB0_1092
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	xorl	%edi, %edi
	testb	%al, %al
	jne	.LBB0_1037
	jmp	.LBB0_1092
.LBB0_1616:
	movl	$64, %eax
	.p2align	4
.LBB0_1617:
	addq	$-4, %rax
	jne	.LBB0_1617
	movl	$128, %eax
	.p2align	4
.LBB0_1619:
	addq	$-4, %rax
	jne	.LBB0_1619
	movl	$64, %eax
	.p2align	4
.LBB0_1621:
	addq	$-4, %rax
	jne	.LBB0_1621
	movl	$64, %eax
	.p2align	4
.LBB0_1623:
	addq	$-4, %rax
	jne	.LBB0_1623
	movl	$128, %eax
	.p2align	4
.LBB0_1625:
	addq	$-4, %rax
	jne	.LBB0_1625
	movl	$2200, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_1627:
	xorl	%edx, %edx
	cmpl	$0, 160(%rsp,%rax)
	sete	%dl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rcx, %rsi
	adcq	%rdx, %rsi
	xorl	%ecx, %ecx
	cmpl	$0, 240(%rsp,%rax)
	sete	%cl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %rcx
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB0_1627
	cmpq	$64, %rcx
	jne	.LBB0_1091
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_1630:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_1630
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_1632:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_1632
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_1634:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_1634
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB0_1636:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_1636
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_1638:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_1638
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_1640:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_1640
	cmpl	%r14d, 32(%rbx)
	jne	.LBB0_1684
	cmpb	$2, 25(%rbx)
	je	.LBB0_1684
	movq	(%rbx), %r9
	cmpq	$1, 16(%rbx)
	sete	%r10b
	cmpq	$64, %r9
	setb	%r11b
	andb	%r10b, %r11b
	cmpb	$1, %r11b
	jne	.LBB0_1684
	movl	8(%rbx), %r10d
	shlq	$5, %r9
	cmpl	%r10d, 304(%rsp,%r9)
	jne	.LBB0_1684
	addq	%rsp, %r9
	addq	$280, %r9
	cmpb	$0, 16(%r9)
	jne	.LBB0_1684
	testb	$1, 24(%rbx)
	je	.LBB0_1684
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
.LBB0_1648:
	xorl	%r11d, %r11d
	cmpb	$2, 2352(%rsp,%r9)
	setne	%r11b
	addq	%r11, %r10
	xorl	%r11d, %r11d
	cmpb	$2, 2392(%rsp,%r9)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 2432(%rsp,%r9)
	setne	%bl
	addq	%r11, %rbx
	addq	%r10, %rbx
	xorl	%r10d, %r10d
	cmpb	$2, 2472(%rsp,%r9)
	setne	%r10b
	addq	%rbx, %r10
	addq	$160, %r9
	cmpq	$2560, %r9
	jne	.LBB0_1648
	cmpq	10016(%rsp), %r10
	jae	.LBB0_1684
	xorl	%r9d, %r9d
	jmp	.LBB0_1680
.LBB0_1651:
	xorl	%edi, %edi
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_1092
.LBB0_1744:
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_1092
.LBB0_1679:
	addq	$80, %r9
	cmpq	$2560, %r9
	je	.LBB0_1684
.LBB0_1680:
	cmpb	$2, 2352(%rsp,%r9)
	jne	.LBB0_1682
	cmpl	$0, 2360(%rsp,%r9)
	jne	.LBB0_1091
.LBB0_1682:
	cmpb	$2, 2392(%rsp,%r9)
	jne	.LBB0_1679
	cmpl	$0, 2400(%rsp,%r9)
	je	.LBB0_1679
	jmp	.LBB0_1091
.LBB0_1684:
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_1685:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_1685
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_1687:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_1687
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB0_1689:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB0_1689
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_1691:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB0_1691
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_1693:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB0_1693
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_1695:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB0_1695
	cmpq	%rax, %r9
	jne	.LBB0_1090
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %r12
	jne	.LBB0_1091
	cmpq	%rdx, %r11
	jne	.LBB0_1091
	cmpq	%rsi, %rbx
	jne	.LBB0_1091
	cmpq	%rdi, %r14
	jne	.LBB0_1091
	cmpq	%r8, %r15
	movl	$0, %edi
	movl	96(%rsp), %ebx
	movl	32(%rsp), %ebp
	jne	.LBB0_1092
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_1091
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	80(%rsp), %rdx
	movl	%ebp, %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB0_1091
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12624(%rsp)
	jne	.LBB0_1091
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	andb	%al, %bl
	movl	%ebx, %edi
	jmp	.LBB0_1092
.LBB0_724:
	movq	memcpy@GOTPCREL(%rip), %r12
	movl	72(%rsp), %ebp
	jmp	.LBB0_725
.LBB0_1743:
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_439
.LBB0_1745:
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_977
.LBB0_1090:
	movq	memcpy@GOTPCREL(%rip), %r12
.LBB0_1091:
	xorl	%edi, %edi
.LBB0_1092:
	movl	%edi, 180(%rsp)
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5valid
	movb	%al, 71(%rsp)
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9malformed
	movb	%al, 70(%rsp)
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5valid
	movl	%eax, %r15d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9malformed
	movb	%al, 119(%rsp)
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid
	movl	%eax, %r14d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests9malformed
	movl	%eax, %r13d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests6ranges
	movb	%al, 118(%rsp)
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests10boundaries
	movb	%al, 117(%rsp)
	movq	$0, 19768(%rsp)
	movq	19768(%rsp), %rax
	movq	$0, 160(%rsp)
	movl	$0, %edx
	testq	%rax, %rax
	jne	.LBB0_1098
	movq	19768(%rsp), %rax
	.p2align	4
.LBB0_1094:
	cmpq	$-1, %rax
	je	.LBB0_1097
	leaq	1(%rax), %rcx
	lock		cmpxchgq	%rcx, 19768(%rsp)
	jne	.LBB0_1094
	testq	%rax, %rax
	je	.LBB0_1571
.LBB0_1097:
	xorl	%edx, %edx
.LBB0_1098:
	movq	%rdx, 216(%rsp)
	callq	_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8contractNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBS_
	movb	%al, 116(%rsp)
	callq	_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8lifetimeNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBS_
	movb	%al, 115(%rsp)
	leaq	17720(%rsp), %rsi
	xorl	%r10d, %r10d
	xorl	%r8d, %r8d
.LBB0_1099:
	leaq	1(%r8), %rax
	movq	%rax, 232(%rsp)
	xorl	%r11d, %r11d
	xorl	%edi, %edi
	movq	%r8, 136(%rsp)
	movq	%r10, 240(%rsp)
.LBB0_1100:
	leaq	1(%rdi), %rax
	movq	%rax, 272(%rsp)
	xorl	%ebx, %ebx
	xorl	%r9d, %r9d
	jmp	.LBB0_1102
	.p2align	4
.LBB0_1101:
	incq	%r9
	decq	%rbx
	cmpq	$4, %r9
	je	.LBB0_1416
.LBB0_1102:
	cmpq	%rdi, %r8
	sete	%al
	cmpq	%r9, %r8
	sete	%cl
	orb	%al, %cl
	cmpq	%r9, %rdi
	sete	%al
	orb	%cl, %al
	jne	.LBB0_1101
	xorl	%ebp, %ebp
.LBB0_1104:
	cmpq	$5, %rbp
	movl	$4, %eax
	cmovaeq	%rbp, %rax
	decq	%rbp
	negq	%rax
	.p2align	4
.LBB0_1105:
	leaq	(%rax,%rbp), %rcx
	cmpq	$-1, %rcx
	je	.LBB0_1101
	leaq	(%rbx,%rbp), %rcx
	movq	%rbp, %rdx
	incq	%rbp
	cmpq	$-1, %rcx
	je	.LBB0_1105
	leaq	(%r11,%rdx), %rcx
	cmpq	$-1, %rcx
	je	.LBB0_1105
	leaq	(%r10,%rdx), %rcx
	cmpq	$-1, %rcx
	je	.LBB0_1105
	addq	$2, %rdx
	movq	%rdx, 248(%rsp)
	movl	$96, %eax
	.p2align	4
.LBB0_1110:
	movq	$1, 17648(%rsp,%rax)
	movq	$2, 17640(%rsp,%rax)
	movq	$0, 17632(%rsp,%rax)
	movq	$0, 17624(%rsp,%rax)
	movq	$0, 17656(%rsp,%rax)
	movq	$0, 17664(%rsp,%rax)
	movq	$2, 17672(%rsp,%rax)
	movq	$1, 17680(%rsp,%rax)
	movq	$0, 17688(%rsp,%rax)
	movq	$0, 17696(%rsp,%rax)
	movq	$2, 17704(%rsp,%rax)
	movq	$1, 17712(%rsp,%rax)
	movq	$0, 17720(%rsp,%rax)
	movq	$0, 17728(%rsp,%rax)
	movq	$2, 17736(%rsp,%rax)
	movq	$1, 17744(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB0_1110
	xorl	%eax, %eax
	.p2align	4
.LBB0_1112:
	movq	$1, 12632(%rsp,%rax)
	movq	$512, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$512, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$512, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$512, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_1112
	movq	%rbx, 264(%rsp)
	movq	%r11, 256(%rsp)
	movq	%rdi, 56(%rsp)
	movq	%r9, 88(%rsp)
	movq	%rbp, 152(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB0_1114:
	movq	$1, 10072(%rsp,%rax)
	movq	$2, 10064(%rsp,%rax)
	movq	$0, 10056(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10080(%rsp,%rax)
	movq	$0, 10088(%rsp,%rax)
	movq	$0, 10096(%rsp,%rax)
	movq	$2, 10104(%rsp,%rax)
	movq	$1, 10112(%rsp,%rax)
	movq	$0, 10120(%rsp,%rax)
	movq	$0, 10128(%rsp,%rax)
	movq	$0, 10136(%rsp,%rax)
	movq	$2, 10144(%rsp,%rax)
	movq	$1, 10152(%rsp,%rax)
	movq	$0, 10160(%rsp,%rax)
	movq	$0, 10168(%rsp,%rax)
	movq	$0, 10176(%rsp,%rax)
	movq	$2, 10184(%rsp,%rax)
	movq	$1, 10192(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_1114
	movl	$2048, %edx
	leaq	19768(%rsp), %rbx
	movq	%rbx, %rdi
	callq	*%r12
	movl	$5120, %edx
	leaq	24376(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	callq	*%r12
	movl	$2560, %edx
	leaq	21816(%rsp), %rdi
	leaq	10040(%rsp), %rsi
	callq	*%r12
	movl	$9728, %edx
	leaq	280(%rsp), %rdi
	movq	%rbx, %rsi
	callq	*%r12
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	movq	88(%rsp), %r9
	jmp	.LBB0_1117
	.p2align	4
.LBB0_1116:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB0_1708
.LBB0_1117:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB0_1119
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB0_1122
.LBB0_1119:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB0_1116
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_1116
	incq	%rax
.LBB0_1122:
	movl	$4680, %ecx
	xorl	%r10d, %r10d
	jmp	.LBB0_1124
	.p2align	4
.LBB0_1123:
	addq	$2, %r10
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB0_1708
.LBB0_1124:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB0_1126
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB0_1129
.LBB0_1126:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB0_1123
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB0_1123
	incq	%r10
.LBB0_1129:
	movq	%rax, %rdx
	shlq	$5, %rdx
	movl	304(%rsp,%rdx), %ecx
	movq	$1, 280(%rsp,%rdx)
	movq	$8, 288(%rsp,%rdx)
	movb	$0, 296(%rsp,%rdx)
	leaq	(%r10,%r10,4), %rdx
	leaq	280(%rsp), %rsi
	movq	%rax, 4608(%rsi,%rdx,8)
	movl	%ecx, 4616(%rsi,%rdx,8)
	movq	$1, 4624(%rsi,%rdx,8)
	movw	$263, 4632(%rsi,%rdx,8)
	movq	$8, 10032(%rsp)
	movl	4640(%rsi,%rdx,8), %edx
	movl	%edx, 96(%rsp)
	movl	$2192, %edx
	xorl	%esi, %esi
	.p2align	4
.LBB0_1130:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%dil
	addq	%rdi, %rsi
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rdx)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rsi, %r8
	xorl	%esi, %esi
	cmpb	$2, 280(%rsp,%rdx)
	setne	%sil
	addq	%r8, %rsi
	addq	$160, %rdx
	cmpq	$4752, %rdx
	jne	.LBB0_1130
	cmpq	$63, %rsi
	ja	.LBB0_1708
	movl	$2120, %edx
	xorl	%esi, %esi
	movq	%r10, 80(%rsp)
	jmp	.LBB0_1134
	.p2align	4
.LBB0_1133:
	addq	$2, %rsi
	addq	$80, %rdx
	cmpq	$4680, %rdx
	je	.LBB0_1708
.LBB0_1134:
	cmpb	$2, 232(%rsp,%rdx)
	jne	.LBB0_1136
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB0_1139
.LBB0_1136:
	cmpb	$2, 272(%rsp,%rdx)
	jne	.LBB0_1133
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB0_1133
	movb	%r13b, 53(%rsp)
	movb	%r15b, 54(%rsp)
	movb	%r14b, 55(%rsp)
	incq	%rsi
	jmp	.LBB0_1140
.LBB0_1139:
	movb	%r13b, 53(%rsp)
	movb	%r15b, 54(%rsp)
	movb	%r14b, 55(%rsp)
.LBB0_1140:
	movq	%rsi, 208(%rsp)
	leaq	(%rsi,%rsi,4), %rdx
	leaq	2328(%rsp), %rsi
	leaq	(%rsi,%rdx,8), %rdi
	movq	%rdi, 120(%rsp)
	movq	$1, (%rsi,%rdx,8)
	movq	%rax, 8(%rsi,%rdx,8)
	movl	%ecx, 16(%rsi,%rdx,8)
	movb	$0, 24(%rsi,%rdx,8)
	movl	32(%rsi,%rdx,8), %eax
	movl	%eax, 108(%rsp)
	movq	$0, 12600(%rsp)
	movq	$4, 12608(%rsp)
	movq	136(%rsp), %rax
	movq	%rax, 12616(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 12624(%rsp)
	movq	%r9, 12632(%rsp)
	movq	152(%rsp), %rax
	movq	%rax, 12640(%rsp)
	movb	$1, %al
	movl	%eax, 40(%rsp)
	movl	$8, %eax
	movq	%rax, 32(%rsp)
	movq	$0, 200(%rsp)
	movb	$1, %al
	movl	%eax, 24(%rsp)
	xorl	%eax, %eax
.LBB0_1141:
	movq	%rax, 72(%rsp)
	movq	12616(%rsp,%rax,8), %rax
	cmpq	$3, %rax
	ja	.LBB0_1707
	jmpq	*.LJTI0_0(,%rax,8)
.LBB0_1143:
	movl	$112, %ecx
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_1144:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %r14
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%r14, %rsi
	xorl	%r14d, %r14d
	cmpb	$2, 280(%rsp,%rcx)
	setne	%r14b
	addq	%rsi, %r14
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_1144
	movl	$4753, %ecx
	xorl	%ebp, %ebp
	movq	80(%rsp), %rdx
	.p2align	4
.LBB0_1146:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rcx)
	setne	%sil
	addq	%rsi, %rbp
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rcx)
	setne	%dil
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rcx)
	setne	%sil
	addq	%rdi, %rsi
	addq	%rbp, %rsi
	xorl	%ebp, %ebp
	cmpb	$2, 280(%rsp,%rcx)
	setne	%bpl
	addq	%rsi, %rbp
	addq	$160, %rcx
	cmpq	$9873, %rcx
	jne	.LBB0_1146
	movl	$2192, %ecx
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_1148:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rcx)
	setne	%sil
	addq	%rsi, %r15
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rcx)
	setne	%dil
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rcx)
	setne	%sil
	addq	%rdi, %rsi
	addq	%r15, %rsi
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rcx)
	setne	%r15b
	addq	%rsi, %r15
	addq	$160, %rcx
	cmpq	$4752, %rcx
	jne	.LBB0_1148
	movl	$120, %ecx
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_1150:
	xorl	%edi, %edi
	cmpl	$0, 184(%rsp,%rcx)
	sete	%dil
	cmpl	$1, 216(%rsp,%rcx)
	movq	%rbx, %rsi
	adcq	%rdi, %rsi
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%rcx)
	sete	%bl
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %rbx
	subq	$-128, %rcx
	cmpq	$2168, %rcx
	jne	.LBB0_1150
	movl	$4760, %ecx
	xorl	%r12d, %r12d
	.p2align	4
.LBB0_1152:
	xorl	%edi, %edi
	cmpl	$0, 160(%rsp,%rcx)
	sete	%dil
	cmpl	$1, 200(%rsp,%rcx)
	movq	%r12, %rsi
	adcq	%rdi, %rsi
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%rcx)
	sete	%r12b
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %r12
	addq	$160, %rcx
	cmpq	$9880, %rcx
	jne	.LBB0_1152
	movl	$2200, %ecx
	xorl	%r13d, %r13d
	.p2align	4
.LBB0_1154:
	xorl	%edi, %edi
	cmpl	$0, 160(%rsp,%rcx)
	sete	%dil
	cmpl	$1, 200(%rsp,%rcx)
	movq	%r13, %rsi
	adcq	%rdi, %rsi
	xorl	%r13d, %r13d
	cmpl	$0, 240(%rsp,%rcx)
	sete	%r13b
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %r13
	addq	$160, %rcx
	cmpq	$4760, %rcx
	jne	.LBB0_1154
	movl	$1, %esi
	leaq	280(%rsp), %rdi
	testq	%rax, %rax
	je	.LBB0_1231
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	jmp	.LBB0_1232
	.p2align	4
.LBB0_1157:
	testb	$1, 40(%rsp)
	je	.LBB0_1331
	movq	120(%rsp), %rax
	movl	108(%rsp), %ecx
	cmpl	%ecx, 32(%rax)
	jne	.LBB0_1707
	movq	120(%rsp), %rax
	cmpb	$2, 24(%rax)
	je	.LBB0_1707
	movq	120(%rsp), %rax
	movq	8(%rax), %rcx
	cmpq	$63, %rcx
	ja	.LBB0_1707
	movq	120(%rsp), %rax
	movl	16(%rax), %eax
	shlq	$5, %rcx
	cmpl	%eax, 304(%rsp,%rcx)
	jne	.LBB0_1707
	addq	%rsp, %rcx
	addq	$280, %rcx
	cmpb	$2, 16(%rcx)
	je	.LBB0_1707
	movq	120(%rsp), %r8
	movzbl	(%r8), %edx
	movzwl	5(%r8), %esi
	movzbl	7(%r8), %edi
	shll	$16, %edi
	orl	%esi, %edi
	movl	1(%r8), %esi
	shlq	$40, %rdi
	shlq	$8, %rsi
	orq	%rdi, %rsi
	orq	%rdx, %rsi
	cmpq	$1, %rsi
	jne	.LBB0_1707
	movq	120(%rsp), %rdx
	movq	$1, (%rdx)
	movb	$1, 24(%rdx)
	cmpl	%eax, 24(%rcx)
	jne	.LBB0_1707
	movb	$1, %al
	movq	%rax, 200(%rsp)
	cmpb	$2, 16(%rcx)
	movb	$1, %al
	movl	%eax, 40(%rsp)
	jne	.LBB0_1368
	jmp	.LBB0_1707
	.p2align	4
.LBB0_1166:
	leaq	280(%rsp), %rdi
	movq	208(%rsp), %rsi
	movl	108(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	jne	.LBB0_1707
	xorb	200(%rsp), %dl
	testb	$1, %dl
	jne	.LBB0_1707
	movl	$112, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_1169:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB0_1169
	movl	$4753, %eax
	xorl	%ebp, %ebp
	.p2align	4
.LBB0_1171:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbp
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%rbp, %rdx
	xorl	%ebp, %ebp
	cmpb	$2, 280(%rsp,%rax)
	setne	%bpl
	addq	%rdx, %rbp
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB0_1171
	movl	$2192, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_1173:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r15, %rdx
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r15b
	addq	%rdx, %r15
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB0_1173
	movl	$120, %eax
	movq	10032(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	xorl	%ebx, %ebx
	movq	208(%rsp), %rsi
	.p2align	4
.LBB0_1175:
	xorl	%ecx, %ecx
	cmpl	$0, 184(%rsp,%rax)
	sete	%cl
	cmpl	$1, 216(%rsp,%rax)
	movq	%rbx, %rdx
	adcq	%rcx, %rdx
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%rax)
	sete	%bl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %rbx
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB0_1175
	movl	$4760, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB0_1177:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%r12, %rdx
	adcq	%rcx, %rdx
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r12b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %r12
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB0_1177
	movl	$2200, %eax
	xorl	%r13d, %r13d
	.p2align	4
.LBB0_1179:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%r13, %rdx
	adcq	%rcx, %rdx
	xorl	%r13d, %r13d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r13b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %r13
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB0_1179
	leaq	280(%rsp), %rdi
	movl	108(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	je	.LBB0_1707
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_1182:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_1182
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_1184:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_1184
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_1186:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_1186
	movl	$120, %r8d
	movq	10032(%rsp), %rsi
	movq	%rsi, 40(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB0_1188:
	xorl	%r9d, %r9d
	cmpl	$0, 184(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 216(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%r8)
	sete	%sil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2168, %r8
	jne	.LBB0_1188
	movl	$4760, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_1190:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$9880, %r9
	jne	.LBB0_1190
	movl	$2200, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_1192:
	xorl	%r11d, %r11d
	cmpl	$0, 160(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 200(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 240(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 280(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$4760, %r10
	jne	.LBB0_1192
	movq	40(%rsp), %rdi
	cmpq	32(%rsp), %rdi
	jne	.LBB0_1707
	cmpq	%r14, %rax
	jne	.LBB0_1707
	cmpq	%rbp, %rcx
	jne	.LBB0_1707
	cmpq	%r15, %rdx
	jne	.LBB0_1707
	cmpq	%rbx, %rsi
	jne	.LBB0_1707
	cmpq	%r12, %r8
	jne	.LBB0_1707
	cmpq	%r13, %r9
	jne	.LBB0_1707
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_1707
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_1202:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_1202
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_1204:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_1204
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_1206:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_1206
	movl	$120, %edi
	xorl	%esi, %esi
	movq	120(%rsp), %rbx
	.p2align	4
.LBB0_1208:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_1208
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_1210:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_1210
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_1212:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_1212
	movl	108(%rsp), %r9d
	cmpl	%r9d, 32(%rbx)
	jne	.LBB0_1218
	movq	8(%rbx), %r9
	cmpb	$2, 24(%rbx)
	setne	%r10b
	cmpq	$64, %r9
	setb	%r11b
	andb	%r10b, %r11b
	cmpb	$1, %r11b
	jne	.LBB0_1218
	shlq	$5, %r9
	movl	304(%rsp,%r9), %r10d
	cmpl	16(%rbx), %r10d
	jne	.LBB0_1218
	addq	%rsp, %r9
	addq	$280, %r9
	cmpb	$2, 16(%r9)
	je	.LBB0_1218
	movzbl	(%rbx), %r9d
	movzwl	5(%rbx), %r10d
	movzbl	7(%rbx), %r11d
	shll	$16, %r11d
	orl	%r10d, %r11d
	movl	1(%rbx), %r10d
	shlq	$40, %r11
	shlq	$8, %r10
	orq	%r11, %r10
	orq	%r9, %r10
	cmpq	$1, %r10
	je	.LBB0_1706
	.p2align	4
.LBB0_1218:
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_1219:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_1219
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_1221:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_1221
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB0_1223:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB0_1223
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_1225:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB0_1225
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_1227:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB0_1227
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_1229:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB0_1229
	jmp	.LBB0_1360
.LBB0_1231:
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
.LBB0_1232:
	cmpb	$-1, %al
	sete	%al
	xorb	24(%rsp), %al
	testb	$1, %al
	jne	.LBB0_1707
	testb	$1, 24(%rsp)
	jne	.LBB0_1253
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_1235:
	xorl	%edx, %edx
	cmpb	$2, 296(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 328(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 360(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 392(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2048, %rcx
	jne	.LBB0_1235
	xorl	%edx, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_1237:
	xorl	%esi, %esi
	cmpb	$2, 4913(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 4953(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 4993(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 5033(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$5120, %rdx
	jne	.LBB0_1237
	xorl	%esi, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_1239:
	xorl	%edi, %edi
	cmpb	$2, 2352(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 2392(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 2432(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 2472(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$2560, %rsi
	jne	.LBB0_1239
	movq	10032(%rsp), %rsi
	movq	%rsi, 24(%rsp)
	xorl	%r8d, %r8d
	xorl	%esi, %esi
	.p2align	4
.LBB0_1241:
	xorl	%r9d, %r9d
	cmpl	$0, 304(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 336(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 368(%rsp,%r8)
	sete	%sil
	cmpl	$1, 400(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2048, %r8
	jne	.LBB0_1241
	xorl	%r9d, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_1243:
	xorl	%r10d, %r10d
	cmpl	$0, 4920(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 4960(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 5000(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 5040(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$5120, %r9
	jne	.LBB0_1243
	xorl	%r10d, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_1245:
	xorl	%r11d, %r11d
	cmpl	$0, 2360(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 2400(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 2440(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 2480(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$2560, %r10
	jne	.LBB0_1245
	movq	24(%rsp), %rdi
	cmpq	32(%rsp), %rdi
	jne	.LBB0_1707
	cmpq	%r14, %rax
	jne	.LBB0_1707
	cmpq	%rbp, %rcx
	jne	.LBB0_1707
	cmpq	%r15, %rdx
	jne	.LBB0_1707
	cmpq	%rbx, %rsi
	jne	.LBB0_1707
	cmpq	%r12, %r8
	jne	.LBB0_1707
	cmpq	%r13, %r9
	jne	.LBB0_1707
.LBB0_1253:
	movl	$112, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_1254:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB0_1254
	movl	$4753, %eax
	xorl	%ebp, %ebp
	movq	80(%rsp), %rdx
	.p2align	4
.LBB0_1256:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbp
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rcx, %rsi
	addq	%rbp, %rsi
	xorl	%ebp, %ebp
	cmpb	$2, 280(%rsp,%rax)
	setne	%bpl
	addq	%rsi, %rbp
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB0_1256
	movl	$2192, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_1258:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rcx, %rsi
	addq	%r15, %rsi
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r15b
	addq	%rsi, %r15
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB0_1258
	movl	$120, %eax
	movq	10032(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_1260:
	xorl	%ecx, %ecx
	cmpl	$0, 184(%rsp,%rax)
	sete	%cl
	cmpl	$1, 216(%rsp,%rax)
	movq	%rbx, %rsi
	adcq	%rcx, %rsi
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%rax)
	sete	%bl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %rbx
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB0_1260
	movl	$4760, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB0_1262:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%r12, %rsi
	adcq	%rcx, %rsi
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r12b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %r12
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB0_1262
	movl	$2200, %eax
	xorl	%r13d, %r13d
	.p2align	4
.LBB0_1264:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%r13, %rsi
	adcq	%rcx, %rsi
	xorl	%r13d, %r13d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r13b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %r13
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB0_1264
	movl	$1, %esi
	leaq	280(%rsp), %rdi
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$-1, %al
	je	.LBB0_1707
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_1267:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_1267
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_1269:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_1269
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_1271:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_1271
	movl	$120, %r8d
	movq	10032(%rsp), %rsi
	movq	%rsi, 24(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB0_1273:
	xorl	%r9d, %r9d
	cmpl	$0, 184(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 216(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%r8)
	sete	%sil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2168, %r8
	jne	.LBB0_1273
	movl	$4760, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_1275:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$9880, %r9
	jne	.LBB0_1275
	movl	$2200, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_1277:
	xorl	%r11d, %r11d
	cmpl	$0, 160(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 200(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 240(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 280(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$4760, %r10
	jne	.LBB0_1277
	movq	24(%rsp), %rdi
	cmpq	32(%rsp), %rdi
	jne	.LBB0_1707
	cmpq	%r14, %rax
	jne	.LBB0_1707
	cmpq	%rbp, %rcx
	jne	.LBB0_1707
	cmpq	%r15, %rdx
	jne	.LBB0_1707
	cmpq	%rbx, %rsi
	jne	.LBB0_1707
	cmpq	%r12, %r8
	jne	.LBB0_1707
	cmpq	%r13, %r9
	jne	.LBB0_1707
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_1707
	movl	$112, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_1287:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB0_1287
	movl	$4753, %eax
	xorl	%ebp, %ebp
	movq	80(%rsp), %rdx
	.p2align	4
.LBB0_1289:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbp
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rcx, %rsi
	addq	%rbp, %rsi
	xorl	%ebp, %ebp
	cmpb	$2, 280(%rsp,%rax)
	setne	%bpl
	addq	%rsi, %rbp
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB0_1289
	movl	$2192, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_1291:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rcx, %rsi
	addq	%r15, %rsi
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r15b
	addq	%rsi, %r15
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB0_1291
	movl	$120, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_1293:
	xorl	%ecx, %ecx
	cmpl	$0, 184(%rsp,%rax)
	sete	%cl
	cmpl	$1, 216(%rsp,%rax)
	movq	%rbx, %rsi
	adcq	%rcx, %rsi
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%rax)
	sete	%bl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %rbx
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB0_1293
	movl	$4760, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB0_1295:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%r12, %rsi
	adcq	%rcx, %rsi
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r12b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %r12
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB0_1295
	movl	$2200, %eax
	xorl	%r13d, %r13d
	.p2align	4
.LBB0_1297:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%r13, %rsi
	adcq	%rcx, %rsi
	xorl	%r13d, %r13d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r13b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %r13
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB0_1297
	movl	$1, %esi
	leaq	280(%rsp), %rdi
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	je	.LBB0_1707
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_1300:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_1300
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_1302:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_1302
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_1304:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_1304
	movl	$120, %r8d
	movq	10032(%rsp), %rsi
	movq	%rsi, 24(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB0_1306:
	xorl	%r9d, %r9d
	cmpl	$0, 184(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 216(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%r8)
	sete	%sil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2168, %r8
	jne	.LBB0_1306
	movl	$4760, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_1308:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$9880, %r9
	jne	.LBB0_1308
	movl	$2200, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_1310:
	xorl	%r11d, %r11d
	cmpl	$0, 160(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 200(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 240(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 280(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$4760, %r10
	jne	.LBB0_1310
	movq	24(%rsp), %rdi
	cmpq	32(%rsp), %rdi
	jne	.LBB0_1707
	cmpq	%r14, %rax
	jne	.LBB0_1707
	cmpq	%rbp, %rcx
	jne	.LBB0_1707
	cmpq	%r15, %rdx
	jne	.LBB0_1707
	cmpq	%rbx, %rsi
	jne	.LBB0_1707
	cmpq	%r12, %r8
	jne	.LBB0_1707
	cmpq	%r13, %r9
	jne	.LBB0_1707
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_1707
	xorl	%eax, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_1320:
	xorl	%ecx, %ecx
	cmpb	$2, 296(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 328(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 360(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 392(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	subq	$-128, %rax
	cmpq	$2048, %rax
	jne	.LBB0_1320
	xorl	%eax, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_1322:
	xorl	%ecx, %ecx
	cmpb	$2, 4913(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbx
	xorl	%ecx, %ecx
	cmpb	$2, 4953(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 4993(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	xorl	%ebx, %ebx
	cmpb	$2, 5033(%rsp,%rax)
	setne	%bl
	addq	%rdx, %rbx
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_1322
	xorl	%eax, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_1324:
	xorl	%ecx, %ecx
	cmpb	$2, 2352(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 2392(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 2432(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r15, %rdx
	xorl	%r15d, %r15d
	cmpb	$2, 2472(%rsp,%rax)
	setne	%r15b
	addq	%rdx, %r15
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_1324
	movl	$64, %eax
	.p2align	4
.LBB0_1326:
	addq	$-4, %rax
	jne	.LBB0_1326
	movl	$128, %eax
	.p2align	4
.LBB0_1328:
	addq	$-4, %rax
	jne	.LBB0_1328
	movl	$64, %eax
	.p2align	4
.LBB0_1330:
	addq	$-4, %rax
	jne	.LBB0_1330
	jmp	.LBB0_1381
.LBB0_1331:
	movl	$112, %ecx
	xorl	%eax, %eax
	movq	120(%rsp), %rbx
	.p2align	4
.LBB0_1332:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_1332
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB0_1334:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB0_1334
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB0_1336:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_1336
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB0_1338:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB0_1338
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB0_1340:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB0_1340
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_1342:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB0_1342
	movl	108(%rsp), %r9d
	cmpl	%r9d, 32(%rbx)
	jne	.LBB0_1348
	movq	8(%rbx), %r9
	cmpb	$2, 24(%rbx)
	setne	%r10b
	cmpq	$64, %r9
	setb	%r11b
	testb	%r11b, %r10b
	je	.LBB0_1348
	shlq	$5, %r9
	movl	304(%rsp,%r9), %r10d
	cmpl	16(%rbx), %r10d
	jne	.LBB0_1348
	addq	%rsp, %r9
	addq	$280, %r9
	cmpb	$2, 16(%r9)
	je	.LBB0_1348
	movzbl	(%rbx), %r9d
	movzwl	5(%rbx), %r10d
	movzbl	7(%rbx), %r11d
	shll	$16, %r11d
	orl	%r10d, %r11d
	movl	1(%rbx), %r10d
	shlq	$40, %r11
	shlq	$8, %r10
	orq	%r11, %r10
	orq	%r9, %r10
	cmpq	$1, %r10
	je	.LBB0_1706
.LBB0_1348:
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB0_1349:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB0_1349
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB0_1351:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB0_1351
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB0_1353:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB0_1353
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_1355:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB0_1355
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_1357:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB0_1357
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_1359:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB0_1359
.LBB0_1360:
	cmpq	%rax, %r9
	jne	.LBB0_1707
	cmpq	%rcx, %r10
	jne	.LBB0_1707
	cmpq	%rdx, %r11
	jne	.LBB0_1707
	cmpq	%rsi, %rbx
	jne	.LBB0_1707
	cmpq	%rdi, %r14
	jne	.LBB0_1707
	cmpq	%r8, %r15
	jne	.LBB0_1707
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_1707
	movl	$0, 40(%rsp)
.LBB0_1368:
	xorl	%eax, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB0_1369:
	xorl	%ecx, %ecx
	cmpb	$2, 296(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 328(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 360(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 392(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	subq	$-128, %rax
	cmpq	$2048, %rax
	jne	.LBB0_1369
	xorl	%eax, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB0_1371:
	xorl	%ecx, %ecx
	cmpb	$2, 4913(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbx
	xorl	%ecx, %ecx
	cmpb	$2, 4953(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 4993(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	xorl	%ebx, %ebx
	cmpb	$2, 5033(%rsp,%rax)
	setne	%bl
	addq	%rdx, %rbx
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_1371
	xorl	%eax, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB0_1373:
	xorl	%ecx, %ecx
	cmpb	$2, 2352(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 2392(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 2432(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r15, %rdx
	xorl	%r15d, %r15d
	cmpb	$2, 2472(%rsp,%rax)
	setne	%r15b
	addq	%rdx, %r15
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_1373
	movl	$64, %eax
	.p2align	4
.LBB0_1375:
	addq	$-4, %rax
	jne	.LBB0_1375
	movl	$128, %eax
	.p2align	4
.LBB0_1377:
	addq	$-4, %rax
	jne	.LBB0_1377
	movl	$64, %eax
	.p2align	4
.LBB0_1379:
	addq	$-4, %rax
	jne	.LBB0_1379
	movb	$1, %bpl
	testb	$1, 24(%rsp)
	movb	$1, %al
	movl	%eax, 24(%rsp)
	jne	.LBB0_1382
.LBB0_1381:
	movl	$0, 24(%rsp)
	movl	40(%rsp), %eax
	movl	%eax, %ebp
.LBB0_1382:
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_1707
	movzbl	%bpl, %eax
	movl	%eax, %ecx
	andl	$1, %ecx
	cmpq	%rcx, %r14
	jne	.LBB0_1707
	movzbl	24(%rsp), %ecx
	cmpq	%rcx, %rbx
	jne	.LBB0_1707
	movzbl	40(%rsp), %ecx
	cmpq	%rcx, %r15
	jne	.LBB0_1707
	andl	$1, %eax
	shll	$3, %eax
	cmpq	%rax, 32(%rsp)
	jne	.LBB0_1707
	movq	72(%rsp), %rax
	incq	%rax
	cmpq	$4, %rax
	jne	.LBB0_1141
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB0_1389:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB0_1389
	movl	$128, %ecx
	movq	memcpy@GOTPCREL(%rip), %r12
	movq	264(%rsp), %rbx
	.p2align	4
.LBB0_1391:
	addq	$-4, %rcx
	jne	.LBB0_1391
	movl	$64, %ecx
	movzbl	55(%rsp), %r14d
	movzbl	54(%rsp), %r15d
	movzbl	53(%rsp), %r13d
	.p2align	4
.LBB0_1393:
	addq	$-4, %rcx
	jne	.LBB0_1393
	movl	$64, %ecx
	.p2align	4
.LBB0_1395:
	addq	$-4, %rcx
	jne	.LBB0_1395
	movl	$128, %ecx
	.p2align	4
.LBB0_1397:
	addq	$-4, %rcx
	jne	.LBB0_1397
	movl	$64, %ecx
	.p2align	4
.LBB0_1399:
	addq	$-4, %rcx
	jne	.LBB0_1399
	testq	%rax, %rax
	jne	.LBB0_1708
	movl	$64, %eax
	.p2align	4
.LBB0_1402:
	addq	$-4, %rax
	jne	.LBB0_1402
	movl	$128, %eax
	.p2align	4
.LBB0_1404:
	addq	$-4, %rax
	jne	.LBB0_1404
	movl	$64, %eax
	.p2align	4
.LBB0_1406:
	addq	$-4, %rax
	jne	.LBB0_1406
	movl	$64, %eax
	.p2align	4
.LBB0_1408:
	addq	$-4, %rax
	jne	.LBB0_1408
	movl	$128, %eax
	.p2align	4
.LBB0_1410:
	addq	$-4, %rax
	jne	.LBB0_1410
	movl	$64, %eax
	.p2align	4
.LBB0_1412:
	addq	$-4, %rax
	jne	.LBB0_1412
	cmpq	$0, 32(%rsp)
	jne	.LBB0_1708
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movq	88(%rsp), %r9
	testb	%al, %al
	je	.LBB0_1708
	movq	160(%rsp), %rax
	incl	%eax
	movq	%rax, 160(%rsp)
	movq	56(%rsp), %rdi
	movq	136(%rsp), %r8
	leaq	17720(%rsp), %rsi
	movq	240(%rsp), %r10
	movq	256(%rsp), %r11
	movq	248(%rsp), %rbp
	jmp	.LBB0_1104
.LBB0_1416:
	decq	%r11
	movq	272(%rsp), %rdi
	cmpq	$4, %rdi
	jne	.LBB0_1100
	decq	%r10
	movq	232(%rsp), %r8
	cmpq	$4, %r8
	jne	.LBB0_1099
	movzbl	70(%rsp), %r10d
	movzbl	71(%rsp), %r9d
	cmpl	$24, 160(%rsp)
	sete	%sil
.LBB0_1419:
	xorl	%edi, %edi
.LBB0_1420:
	cmpq	$15, %rdi
	jne	.LBB0_1426
	movl	$100000, %ecx
.LBB0_1422:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1431
	pause
	decl	%ecx
	jne	.LBB0_1422
	jmp	.LBB0_1424
.LBB0_1426:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.41(%rdi), %ecx
	movl	$100000, %r8d
.LBB0_1427:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1436
	pause
	decl	%r8d
	jne	.LBB0_1427
	jmp	.LBB0_1429
.LBB0_1431:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_1432:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1437
	pause
	decl	%ecx
	jne	.LBB0_1432
	jmp	.LBB0_1434
.LBB0_1436:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_1438
.LBB0_1437:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_1438:
	incq	%rdi
	cmpq	$16, %rdi
	jne	.LBB0_1420
	movq	$0, 280(%rsp)
	movq	$41, 288(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.0, 296(%rsp)
	movq	$13, 304(%rsp)
	movq	224(%rsp), %rax
	movb	%al, 312(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.1, 320(%rsp)
	movq	$2, 328(%rsp)
	movl	144(%rsp), %eax
	movb	%al, 336(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.2, 344(%rsp)
	movq	$20, 352(%rsp)
	movl	188(%rsp), %eax
	movb	%al, 360(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.3, 368(%rsp)
	movq	$19, 376(%rsp)
	movq	168(%rsp), %rax
	movb	%al, 384(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.4, 392(%rsp)
	movq	$2, 400(%rsp)
	movl	196(%rsp), %eax
	movb	%al, 408(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.5, 416(%rsp)
	movq	$11, 424(%rsp)
	movl	148(%rsp), %eax
	movb	%al, 432(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.6, 440(%rsp)
	movq	$10, 448(%rsp)
	movl	192(%rsp), %eax
	movb	%al, 456(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.7, 464(%rsp)
	movq	$13, 472(%rsp)
	movb	$1, 480(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.8, 488(%rsp)
	movq	$14, 496(%rsp)
	movl	132(%rsp), %eax
	movb	%al, 504(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9, 512(%rsp)
	movq	$13, 520(%rsp)
	movl	20(%rsp), %eax
	movb	%al, 528(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.10, 536(%rsp)
	movq	$10, 544(%rsp)
	movl	184(%rsp), %eax
	movb	%al, 552(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.11, 560(%rsp)
	movq	$12, 568(%rsp)
	movl	16(%rsp), %eax
	movb	%al, 576(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.12, 584(%rsp)
	movq	$14, 592(%rsp)
	movl	180(%rsp), %eax
	movb	%al, 600(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.13, 608(%rsp)
	movq	$17, 616(%rsp)
	movb	%r9b, 624(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.14, 632(%rsp)
	movq	$21, 640(%rsp)
	movb	%r10b, 648(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.15, 656(%rsp)
	movq	$18, 664(%rsp)
	movb	%r15b, 672(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.16, 680(%rsp)
	movq	$22, 688(%rsp)
	movzbl	119(%rsp), %eax
	movb	%al, 696(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.17, 704(%rsp)
	movq	$17, 712(%rsp)
	movb	$1, 720(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.18, 728(%rsp)
	movq	$9, 736(%rsp)
	movb	%r14b, 744(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.19, 752(%rsp)
	movq	$13, 760(%rsp)
	movb	%r13b, 768(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.20, 776(%rsp)
	movq	$12, 784(%rsp)
	movzbl	118(%rsp), %eax
	movb	%al, 792(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.21, 800(%rsp)
	movq	$16, 808(%rsp)
	movzbl	117(%rsp), %eax
	movb	%al, 816(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.22, 824(%rsp)
	movq	$14, 832(%rsp)
	movb	$1, 840(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.23, 848(%rsp)
	movq	$11, 856(%rsp)
	movb	$1, 864(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.24, 872(%rsp)
	movq	$11, 880(%rsp)
	movb	$1, 888(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.25, 896(%rsp)
	movq	$14, 904(%rsp)
	movq	216(%rsp), %rax
	movb	%al, 912(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.26, 920(%rsp)
	movq	$14, 928(%rsp)
	movzbl	116(%rsp), %eax
	movb	%al, 936(%rsp)
	leaq	296(%rsp), %rdi
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.27, 944(%rsp)
	movq	$14, 952(%rsp)
	movzbl	115(%rsp), %eax
	movb	%al, 960(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.28, 968(%rsp)
	movq	$13, 976(%rsp)
	movb	$1, 984(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.29, 992(%rsp)
	movq	$15, 1000(%rsp)
	movb	$1, 1008(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.30, 1016(%rsp)
	movq	$13, 1024(%rsp)
	movb	$1, 1032(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.31, 1040(%rsp)
	movq	$11, 1048(%rsp)
	movb	$1, 1056(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.32, 1064(%rsp)
	movq	$14, 1072(%rsp)
	movb	$1, 1080(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.33, 1088(%rsp)
	movq	$14, 1096(%rsp)
	movb	$1, 1104(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.34, 1112(%rsp)
	movq	$16, 1120(%rsp)
	movb	$1, 1128(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.35, 1136(%rsp)
	movq	$14, 1144(%rsp)
	movb	$1, 1152(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.36, 1160(%rsp)
	movq	$16, 1168(%rsp)
	movb	$1, 1176(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.37, 1184(%rsp)
	movq	$15, 1192(%rsp)
	movb	$1, 1200(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.38, 1208(%rsp)
	movq	$13, 1216(%rsp)
	movb	$1, 1224(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.39, 1232(%rsp)
	movq	$16, 1240(%rsp)
	movb	$1, 1248(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.40, 1256(%rsp)
	movq	$13, 1264(%rsp)
	movb	%sil, 1272(%rsp)
	movb	$1, %cl
	xorl	%r8d, %r8d
.LBB0_1440:
	leaq	(%r8,%r8,2), %rax
	incq	%r8
	movq	%r8, 280(%rsp)
	movzbl	16(%rdi,%rax,8), %r9d
	cmpb	$2, %r9b
	je	.LBB0_1550
	movq	(%rdi,%rax,8), %r10
	movq	8(%rdi,%rax,8), %r11
	movl	$100000, %esi
	testb	$1, %r9b
	je	.LBB0_1444
.LBB0_1442:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1446
	pause
	decl	%esi
	jne	.LBB0_1442
	jmp	.LBB0_1509
.LBB0_1444:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1449
	pause
	decl	%esi
	jne	.LBB0_1444
	jmp	.LBB0_1514
.LBB0_1446:
	movw	$1016, %dx
	movb	$72, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1447:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1452
	pause
	decl	%esi
	jne	.LBB0_1447
	jmp	.LBB0_1509
.LBB0_1449:
	movw	$1016, %dx
	movb	$72, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1450:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1455
	pause
	decl	%esi
	jne	.LBB0_1450
	jmp	.LBB0_1514
.LBB0_1452:
	movw	$1016, %dx
	movb	$77, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1453:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1458
	pause
	decl	%esi
	jne	.LBB0_1453
	jmp	.LBB0_1509
.LBB0_1455:
	movw	$1016, %dx
	movb	$77, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1456:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1461
	pause
	decl	%esi
	jne	.LBB0_1456
	jmp	.LBB0_1514
.LBB0_1458:
	movw	$1016, %dx
	movb	$84, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1459:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1464
	pause
	decl	%esi
	jne	.LBB0_1459
	jmp	.LBB0_1509
.LBB0_1461:
	movw	$1016, %dx
	movb	$84, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1462:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1467
	pause
	decl	%esi
	jne	.LBB0_1462
	jmp	.LBB0_1514
.LBB0_1464:
	movw	$1016, %dx
	movb	$69, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1465:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1470
	pause
	decl	%esi
	jne	.LBB0_1465
	jmp	.LBB0_1509
.LBB0_1467:
	movw	$1016, %dx
	movb	$69, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1468:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1473
	pause
	decl	%esi
	jne	.LBB0_1468
	jmp	.LBB0_1514
.LBB0_1470:
	movw	$1016, %dx
	movb	$83, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1471:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1476
	pause
	decl	%esi
	jne	.LBB0_1471
	jmp	.LBB0_1509
.LBB0_1473:
	movw	$1016, %dx
	movb	$83, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1474:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1479
	pause
	decl	%esi
	jne	.LBB0_1474
	jmp	.LBB0_1514
.LBB0_1476:
	movw	$1016, %dx
	movb	$84, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1477:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1482
	pause
	decl	%esi
	jne	.LBB0_1477
	jmp	.LBB0_1509
.LBB0_1479:
	movw	$1016, %dx
	movb	$84, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1480:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1485
	pause
	decl	%esi
	jne	.LBB0_1480
	jmp	.LBB0_1514
.LBB0_1482:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1483:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1488
	pause
	decl	%esi
	jne	.LBB0_1483
	jmp	.LBB0_1509
.LBB0_1485:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1486:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1491
	pause
	decl	%esi
	jne	.LBB0_1486
	jmp	.LBB0_1514
.LBB0_1488:
	movw	$1016, %dx
	movb	$80, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1489:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1494
	pause
	decl	%esi
	jne	.LBB0_1489
	jmp	.LBB0_1509
.LBB0_1491:
	movw	$1016, %dx
	movb	$70, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1492:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1497
	pause
	decl	%esi
	jne	.LBB0_1492
	jmp	.LBB0_1514
.LBB0_1494:
	movw	$1016, %dx
	movb	$65, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1495:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1500
	pause
	decl	%esi
	jne	.LBB0_1495
	jmp	.LBB0_1509
.LBB0_1497:
	movw	$1016, %dx
	movb	$65, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1498:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1503
	pause
	decl	%esi
	jne	.LBB0_1498
	jmp	.LBB0_1514
.LBB0_1500:
	movw	$1016, %dx
	movb	$83, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1501:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1506
	pause
	decl	%esi
	jne	.LBB0_1501
	jmp	.LBB0_1509
.LBB0_1503:
	movw	$1016, %dx
	movb	$73, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1504:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1511
	pause
	decl	%esi
	jne	.LBB0_1504
	jmp	.LBB0_1514
.LBB0_1506:
	movw	$1016, %dx
	movb	$83, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1507:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1516
	pause
	decl	%esi
	jne	.LBB0_1507
	jmp	.LBB0_1509
.LBB0_1511:
	movw	$1016, %dx
	movb	$76, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1512:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1517
	pause
	decl	%esi
	jne	.LBB0_1512
	jmp	.LBB0_1514
.LBB0_1516:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_1518
.LBB0_1517:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_1518:
	testq	%r11, %r11
	je	.LBB0_1539
	addq	%r10, %r11
.LBB0_1520:
	movzbl	(%r10), %esi
	cmpb	$10, %sil
	jne	.LBB0_1526
	movl	$100000, %esi
.LBB0_1522:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1531
	pause
	decl	%esi
	jne	.LBB0_1522
	jmp	.LBB0_1524
.LBB0_1526:
	movl	$100000, %ebx
.LBB0_1527:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1536
	pause
	decl	%ebx
	jne	.LBB0_1527
	jmp	.LBB0_1529
.LBB0_1531:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1532:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1537
	pause
	decl	%esi
	jne	.LBB0_1532
	jmp	.LBB0_1534
.LBB0_1536:
	movw	$1016, %dx
	movl	%esi, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_1538
.LBB0_1537:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_1538:
	incq	%r10
	cmpq	%r11, %r10
	jne	.LBB0_1520
.LBB0_1539:
	movl	$100000, %esi
.LBB0_1540:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1544
	pause
	decl	%esi
	jne	.LBB0_1540
	jmp	.LBB0_1542
.LBB0_1544:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1545:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1549
	pause
	decl	%esi
	jne	.LBB0_1545
	jmp	.LBB0_1547
.LBB0_1549:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	andb	%r9b, %cl
	cmpq	$41, %r8
	jne	.LBB0_1440
.LBB0_1550:
	xorl	%edi, %edi
.LBB0_1551:
	cmpq	$13, %rdi
	jne	.LBB0_1557
	movl	$100000, %esi
.LBB0_1553:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1562
	pause
	decl	%esi
	jne	.LBB0_1553
	jmp	.LBB0_1555
.LBB0_1557:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.42(%rdi), %esi
	movl	$100000, %r8d
.LBB0_1558:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1567
	pause
	decl	%r8d
	jne	.LBB0_1558
	jmp	.LBB0_1560
.LBB0_1562:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB0_1563:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1568
	pause
	decl	%esi
	jne	.LBB0_1563
	jmp	.LBB0_1565
.LBB0_1567:
	movw	$1016, %dx
	movl	%esi, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_1569
.LBB0_1568:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_1569:
	incq	%rdi
	cmpq	$14, %rdi
	jne	.LBB0_1551
	andb	$1, %cl
	movl	%ecx, %eax
	addq	$29496, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB0_1571:
	.cfi_def_cfa_offset 29552
	movq	19768(%rsp), %rax
	.p2align	4
.LBB0_1572:
	cmpq	$-1, %rax
	je	.LBB0_1097
	leaq	1(%rax), %rcx
	lock		cmpxchgq	%rcx, 19768(%rsp)
	jne	.LBB0_1572
	cmpq	$1, %rax
	jne	.LBB0_1097
	movq	19768(%rsp), %rax
	cmpq	$2, %rax
	jne	.LBB0_1097
	movq	$-2, 280(%rsp)
	movq	280(%rsp), %rax
.LBB0_1577:
	cmpq	$-1, %rax
	je	.LBB0_1097
	leaq	1(%rax), %rcx
	lock		cmpxchgq	%rcx, 280(%rsp)
	jne	.LBB0_1577
	cmpq	$-2, %rax
	jb	.LBB0_1097
	movq	280(%rsp), %rax
	cmpq	$-1, %rax
	jne	.LBB0_1097
	movq	280(%rsp), %rax
.LBB0_1582:
	cmpq	$-1, %rax
	je	.LBB0_1740
	leaq	1(%rax), %rcx
	lock		cmpxchgq	%rcx, 280(%rsp)
	jne	.LBB0_1582
	jmp	.LBB0_1097
.LBB0_1706:
	movq	$1, (%rbx)
	movb	$1, 24(%rbx)
.LBB0_1707:
	movzbl	55(%rsp), %r14d
	movzbl	54(%rsp), %r15d
	movzbl	53(%rsp), %r13d
.LBB0_1708:
	xorl	%esi, %esi
	movq	56(%rsp), %r9
.LBB0_1709:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.49(%rsi), %ecx
	incq	%rsi
	movl	$100000, %edi
	.p2align	4
.LBB0_1710:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1714
	pause
	decl	%edi
	jne	.LBB0_1710
	jmp	.LBB0_1712
	.p2align	4
.LBB0_1714:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	cmpq	$25, %rsi
	jne	.LBB0_1709
	movl	$100000, %ecx
	movw	$1021, %dx
	.p2align	4
.LBB0_1716:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1720
	pause
	decl	%ecx
	jne	.LBB0_1716
.LBB0_1718:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB0_1719:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1719
.LBB0_1712:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB0_1713:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1713
.LBB0_1720:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movq	136(%rsp), %rax
	cmpq	$4, %rax
	jae	.LBB0_1982
	shlq	$4, %rax
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54(%rax), %rsi
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54+8(%rax), %rdi
	addq	%rsi, %rdi
.LBB0_1722:
	movzbl	(%rsi), %ecx
	cmpb	$10, %cl
	jne	.LBB0_1726
	movl	$100000, %ecx
	.p2align	4
.LBB0_1724:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1731
	pause
	decl	%ecx
	jne	.LBB0_1724
	jmp	.LBB0_1963
.LBB0_1726:
	movl	$100000, %r8d
	.p2align	4
.LBB0_1727:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1734
	pause
	decl	%r8d
	jne	.LBB0_1727
	jmp	.LBB0_1729
.LBB0_1731:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_1732:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1735
	pause
	decl	%ecx
	jne	.LBB0_1732
	jmp	.LBB0_1971
.LBB0_1734:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_1736
.LBB0_1735:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_1736:
	incq	%rsi
	cmpq	%rdi, %rsi
	jne	.LBB0_1722
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB0_1738:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1748
	pause
	decl	%ecx
	jne	.LBB0_1738
	jmp	.LBB0_1718
.LBB0_1740:
	movq	280(%rsp), %rax
.LBB0_1741:
	cmpq	$-1, %rax
	je	.LBB0_1746
	leaq	1(%rax), %rcx
	xorl	%edx, %edx
	lock		cmpxchgq	%rcx, 280(%rsp)
	jne	.LBB0_1741
	jmp	.LBB0_1098
.LBB0_1746:
	movq	280(%rsp), %rax
	cmpq	$-1, %rax
	sete	%dl
	jmp	.LBB0_1098
.LBB0_1747:
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_581
.LBB0_1748:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	cmpq	$3, %r9
	ja	.LBB0_1981
	shlq	$4, %r9
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54(%r9), %rsi
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54+8(%r9), %rdi
	addq	%rsi, %rdi
.LBB0_1750:
	movzbl	(%rsi), %ecx
	cmpb	$10, %cl
	jne	.LBB0_1754
	movl	$100000, %ecx
.LBB0_1752:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1757
	pause
	decl	%ecx
	jne	.LBB0_1752
	jmp	.LBB0_1963
.LBB0_1754:
	movl	$100000, %r8d
.LBB0_1755:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1760
	pause
	decl	%r8d
	jne	.LBB0_1755
	jmp	.LBB0_1729
.LBB0_1757:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_1758:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1761
	pause
	decl	%ecx
	jne	.LBB0_1758
	jmp	.LBB0_1971
.LBB0_1760:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_1762
.LBB0_1761:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_1762:
	incq	%rsi
	cmpq	%rdi, %rsi
	jne	.LBB0_1750
	movl	$100000, %ecx
	movzbl	70(%rsp), %r10d
	movzbl	71(%rsp), %r9d
	movw	$1021, %dx
.LBB0_1764:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1824
	pause
	decl	%ecx
	jne	.LBB0_1764
	jmp	.LBB0_1718
.LBB0_1766:
	movq	$0, 344(%rsp)
	movw	$0, 352(%rsp)
	movl	$1886152040, 280(%rsp)
	movb	$1, %al
	movl	%eax, 132(%rsp)
	jmp	.LBB0_24
.LBB0_1767:
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_512
.LBB0_1424:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1425:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1425
.LBB0_1429:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1430:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1430
.LBB0_1768:
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12624(%rsp)
	jne	.LBB0_856
	cmpq	%r13, 12600(%rsp)
	jne	.LBB0_856
	cmpq	%r15, 12608(%rsp)
	jne	.LBB0_856
	cmpq	%r12, 12616(%rsp)
	jne	.LBB0_856
	cmpq	%rbp, 12632(%rsp)
	jne	.LBB0_856
	cmpq	%r14, 12640(%rsp)
	jne	.LBB0_856
	cmpq	%rbx, 12648(%rsp)
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_856
	movl	$96, %eax
.LBB0_1777:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB0_1777
	xorl	%eax, %eax
.LBB0_1779:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB0_1779
	xorl	%eax, %eax
.LBB0_1781:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB0_1781
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	movq	memcpy@GOTPCREL(%rip), %r14
	callq	*%r14
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r14
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r14
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r14
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$112, %eax
	xorl	%r12d, %r12d
.LBB0_1783:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r12
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r12, %rdx
	xorl	%r12d, %r12d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r12b
	addq	%rdx, %r12
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB0_1783
	movl	$4753, %eax
	xorl	%ebp, %ebp
.LBB0_1785:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbp
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%rbp, %rdx
	xorl	%ebp, %ebp
	cmpb	$2, 280(%rsp,%rax)
	setne	%bpl
	addq	%rdx, %rbp
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB0_1785
	movl	$2192, %ecx
	leaq	2328(%rsp), %rax
	xorl	%r15d, %r15d
.LBB0_1787:
	xorl	%edx, %edx
	cmpb	$2, 160(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %r15
	xorl	%edx, %edx
	cmpb	$2, 200(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%r15, %rsi
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rcx)
	setne	%r15b
	addq	%rsi, %r15
	addq	$160, %rcx
	cmpq	$4752, %rcx
	jne	.LBB0_1787
	movl	$120, %ecx
	xorl	%r14d, %r14d
.LBB0_1789:
	xorl	%edx, %edx
	cmpl	$0, 184(%rsp,%rcx)
	sete	%dl
	cmpl	$1, 216(%rsp,%rcx)
	movq	%r14, %rsi
	adcq	%rdx, %rsi
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%rcx)
	sete	%r14b
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %r14
	subq	$-128, %rcx
	cmpq	$2168, %rcx
	jne	.LBB0_1789
	movl	$4760, %ecx
	xorl	%r13d, %r13d
.LBB0_1791:
	xorl	%edx, %edx
	cmpl	$0, 160(%rsp,%rcx)
	sete	%dl
	cmpl	$1, 200(%rsp,%rcx)
	movq	%r13, %rsi
	adcq	%rdx, %rsi
	xorl	%r13d, %r13d
	cmpl	$0, 240(%rsp,%rcx)
	sete	%r13b
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %r13
	addq	$160, %rcx
	cmpq	$9880, %rcx
	jne	.LBB0_1791
	movl	$2200, %ecx
	xorl	%ebx, %ebx
.LBB0_1793:
	xorl	%edx, %edx
	cmpl	$0, 160(%rsp,%rcx)
	sete	%dl
	cmpl	$1, 200(%rsp,%rcx)
	movq	%rbx, %rsi
	adcq	%rdx, %rsi
	xorl	%ebx, %ebx
	cmpl	$0, 240(%rsp,%rcx)
	sete	%bl
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %rbx
	addq	$160, %rcx
	cmpq	$4760, %rcx
	jne	.LBB0_1793
	movl	$56, %edx
	xorl	%ecx, %ecx
	jmp	.LBB0_1796
.LBB0_1795:
	addq	$2, %rcx
	addq	$64, %rdx
	cmpq	$2104, %rdx
	je	.LBB0_856
.LBB0_1796:
	cmpb	$2, 240(%rsp,%rdx)
	jne	.LBB0_1798
	cmpl	$0, 248(%rsp,%rdx)
	jne	.LBB0_1801
.LBB0_1798:
	cmpb	$2, 272(%rsp,%rdx)
	jne	.LBB0_1795
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB0_1795
	incq	%rcx
.LBB0_1801:
	movl	$4680, %edx
	movq	$0, 24(%rsp)
	jmp	.LBB0_1803
.LBB0_1802:
	addq	$2, 24(%rsp)
	addq	$80, %rdx
	cmpq	$9800, %rdx
	je	.LBB0_856
.LBB0_1803:
	cmpb	$2, 233(%rsp,%rdx)
	jne	.LBB0_1805
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB0_1808
.LBB0_1805:
	cmpb	$2, 273(%rsp,%rdx)
	jne	.LBB0_1802
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB0_1802
	incq	24(%rsp)
.LBB0_1808:
	movq	%rcx, %rsi
	shlq	$5, %rsi
	movl	304(%rsp,%rsi), %edx
	movq	$1, 280(%rsp,%rsi)
	movq	$32, 288(%rsp,%rsi)
	movb	$0, 296(%rsp,%rsi)
	movq	24(%rsp), %rsi
	leaq	(%rsi,%rsi,4), %rsi
	leaq	280(%rsp), %rdi
	leaq	4608(%rdi,%rsi,8), %r8
	movq	%rcx, 4608(%rdi,%rsi,8)
	movl	%edx, 4616(%rdi,%rsi,8)
	movq	$1, 4624(%rdi,%rsi,8)
	movw	$263, 4632(%rdi,%rsi,8)
	movq	$32, 10032(%rsp)
	movl	4640(%rdi,%rsi,8), %esi
	movl	%esi, 40(%rsp)
	movl	$4680, %esi
	movq	$0, 32(%rsp)
	jmp	.LBB0_1810
.LBB0_1809:
	addq	$2, 32(%rsp)
	addq	$80, %rsi
	cmpq	$9800, %rsi
	je	.LBB0_856
.LBB0_1810:
	cmpb	$2, 233(%rsp,%rsi)
	jne	.LBB0_1812
	cmpl	$0, 240(%rsp,%rsi)
	jne	.LBB0_1815
.LBB0_1812:
	cmpb	$2, 273(%rsp,%rsi)
	jne	.LBB0_1809
	cmpl	$0, 280(%rsp,%rsi)
	je	.LBB0_1809
	incq	32(%rsp)
.LBB0_1815:
	movq	32(%rsp), %rsi
	leaq	(%rsi,%rsi,4), %r9
	leaq	280(%rsp), %rsi
	movq	%rcx, 4608(%rsi,%r9,8)
	movl	%edx, 4616(%rsi,%r9,8)
	movq	$2, 4624(%rsi,%r9,8)
	movw	$1, 4632(%rsi,%r9,8)
	cmpb	$2, 25(%r8)
	je	.LBB0_856
	movq	(%r8), %rsi
	cmpq	$1, 16(%r8)
	sete	%dil
	cmpq	$64, %rsi
	setb	%r10b
	andb	%dil, %r10b
	cmpb	$1, %r10b
	jne	.LBB0_856
	movl	8(%r8), %edi
	movq	%rsi, %r10
	shlq	$5, %r10
	cmpl	%edi, 304(%rsp,%r10)
	jne	.LBB0_856
	addq	%rsp, %r10
	addq	$280, %r10
	movl	$0, 16(%rsp)
	cmpb	$0, 16(%r10)
	jne	.LBB0_857
	movzbl	24(%r8), %r8d
	andb	$2, %r8b
	je	.LBB0_857
	leaq	280(%rsp), %r8
	movl	4640(%r8,%r9,8), %r8d
	movl	%r8d, 96(%rsp)
	movl	$2192, %r8d
	xorl	%r9d, %r9d
.LBB0_1821:
	xorl	%r10d, %r10d
	cmpb	$2, 160(%rsp,%r8)
	setne	%r10b
	addq	%r10, %r9
	xorl	%r10d, %r10d
	cmpb	$2, 200(%rsp,%r8)
	setne	%r10b
	xorl	%r11d, %r11d
	cmpb	$2, 240(%rsp,%r8)
	setne	%r11b
	addq	%r10, %r11
	addq	%r9, %r11
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r8)
	setne	%r9b
	addq	%r11, %r9
	addq	$160, %r8
	cmpq	$4752, %r8
	jne	.LBB0_1821
	cmpq	$63, %r9
	ja	.LBB0_856
	movl	$2120, %r8d
	movq	$0, 56(%rsp)
	jmp	.LBB0_1843
.LBB0_1434:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1435:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1435
.LBB0_1824:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	cmpq	$3, 88(%rsp)
	ja	.LBB0_1989
	movq	88(%rsp), %rax
	shlq	$4, %rax
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54(%rax), %rsi
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54+8(%rax), %rdi
	addq	%rsi, %rdi
.LBB0_1826:
	movzbl	(%rsi), %ecx
	cmpb	$10, %cl
	jne	.LBB0_1830
	movl	$100000, %ecx
.LBB0_1828:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1833
	pause
	decl	%ecx
	jne	.LBB0_1828
	jmp	.LBB0_1963
.LBB0_1830:
	movl	$100000, %r8d
.LBB0_1831:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1836
	pause
	decl	%r8d
	jne	.LBB0_1831
	jmp	.LBB0_1729
.LBB0_1833:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_1834:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1837
	pause
	decl	%ecx
	jne	.LBB0_1834
	jmp	.LBB0_1971
.LBB0_1836:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_1838
.LBB0_1837:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_1838:
	incq	%rsi
	cmpq	%rdi, %rsi
	jne	.LBB0_1826
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB0_1840:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1957
	pause
	decl	%ecx
	jne	.LBB0_1840
	jmp	.LBB0_1718
.LBB0_1509:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1510:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1510
.LBB0_1514:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1515:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1515
.LBB0_1842:
	addq	$2, 56(%rsp)
	addq	$80, %r8
	movl	$0, 16(%rsp)
	cmpq	$4680, %r8
	je	.LBB0_857
.LBB0_1843:
	cmpb	$2, 232(%rsp,%r8)
	jne	.LBB0_1845
	cmpl	$0, 240(%rsp,%r8)
	jne	.LBB0_1848
.LBB0_1845:
	cmpb	$2, 272(%rsp,%r8)
	jne	.LBB0_1842
	cmpl	$0, 280(%rsp,%r8)
	je	.LBB0_1842
	incq	56(%rsp)
.LBB0_1848:
	movq	56(%rsp), %r8
	leaq	(%r8,%r8,4), %r8
	leaq	(%rax,%r8,8), %r9
	movq	%r9, 80(%rsp)
	movq	$1, (%rax,%r8,8)
	movq	%rsi, 8(%rax,%r8,8)
	movl	%edi, 16(%rax,%r8,8)
	movb	$0, 24(%rax,%r8,8)
	movl	32(%rax,%r8,8), %esi
	movl	%esi, 88(%rsp)
	movl	$2192, %esi
	xorl	%edi, %edi
.LBB0_1849:
	xorl	%r8d, %r8d
	cmpb	$2, 160(%rsp,%rsi)
	setne	%r8b
	addq	%r8, %rdi
	xorl	%r8d, %r8d
	cmpb	$2, 200(%rsp,%rsi)
	setne	%r8b
	xorl	%r9d, %r9d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r9b
	addq	%r8, %r9
	addq	%rdi, %r9
	xorl	%edi, %edi
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dil
	addq	%r9, %rdi
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB0_1849
	cmpq	$63, %rdi
	ja	.LBB0_856
	movl	$2120, %esi
	movq	$0, 72(%rsp)
	jmp	.LBB0_1854
.LBB0_1852:
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB0_513
.LBB0_1853:
	addq	$2, 72(%rsp)
	addq	$80, %rsi
	movl	$0, 16(%rsp)
	cmpq	$4680, %rsi
	je	.LBB0_857
.LBB0_1854:
	cmpb	$2, 232(%rsp,%rsi)
	jne	.LBB0_1856
	cmpl	$0, 240(%rsp,%rsi)
	jne	.LBB0_1859
.LBB0_1856:
	cmpb	$2, 272(%rsp,%rsi)
	jne	.LBB0_1853
	cmpl	$0, 280(%rsp,%rsi)
	je	.LBB0_1853
	incq	72(%rsp)
.LBB0_1859:
	movq	72(%rsp), %rsi
	leaq	(%rsi,%rsi,4), %rsi
	movq	$2, (%rax,%rsi,8)
	movq	%rcx, 8(%rax,%rsi,8)
	movl	%edx, 16(%rax,%rsi,8)
	movb	$0, 24(%rax,%rsi,8)
	movl	32(%rax,%rsi,8), %eax
	movl	%eax, 120(%rsp)
	leaq	280(%rsp), %rdi
	movl	$2, %esi
	movq	32(%rsp), %rdx
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB0_856
	movl	88(%rsp), %eax
	movq	80(%rsp), %rcx
	cmpl	%eax, 32(%rcx)
	jne	.LBB0_856
	movq	80(%rsp), %rcx
	movq	8(%rcx), %rax
	cmpb	$2, 24(%rcx)
	setne	%cl
	cmpq	$64, %rax
	setb	%dl
	andb	%cl, %dl
	cmpb	$1, %dl
	jne	.LBB0_856
	shlq	$5, %rax
	movl	304(%rsp,%rax), %ecx
	movq	80(%rsp), %rdx
	cmpl	16(%rdx), %ecx
	jne	.LBB0_856
	addq	%rsp, %rax
	addq	$280, %rax
	cmpb	$2, 16(%rax)
	je	.LBB0_856
	movq	80(%rsp), %rsi
	movzbl	(%rsi), %eax
	movzwl	5(%rsi), %ecx
	movzbl	7(%rsi), %edx
	shll	$16, %edx
	orl	%ecx, %edx
	movl	1(%rsi), %ecx
	shlq	$40, %rdx
	shlq	$8, %rcx
	orq	%rdx, %rcx
	orq	%rax, %rcx
	cmpq	$1, %rcx
	jne	.LBB0_856
	movq	80(%rsp), %rax
	movq	$1, (%rax)
	movb	$1, 24(%rax)
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	56(%rsp), %rdx
	movl	88(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel
	cmpb	$-1, %al
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	24(%rsp), %rdx
	movl	40(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$-1, %al
	jne	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$32, 12624(%rsp)
	jne	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$1, 12600(%rsp)
	jne	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12608(%rsp)
	jne	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$2, 12616(%rsp)
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_856
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$2, %esi
	leaq	280(%rsp), %rdi
	movq	32(%rsp), %rdx
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	je	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_856
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_856
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_856
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_856
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_856
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_856
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_856
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	12600(%rsp), %rdi
	movl	$1, %edx
	leaq	280(%rsp), %rsi
	movq	24(%rsp), %rcx
	movl	40(%rsp), %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$0, 12600(%rsp)
	je	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_856
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_856
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_856
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_856
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_856
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_856
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_856
	leaq	280(%rsp), %rdi
	movq	56(%rsp), %rsi
	movl	88(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	notb	%al
	andb	%dl, %al
	testb	$1, %al
	je	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$32, 12624(%rsp)
	jne	.LBB0_856
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	280(%rsp), %rdi
	movq	56(%rsp), %rsi
	movl	88(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	je	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_856
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_856
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_856
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_856
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_856
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_856
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_856
	leaq	280(%rsp), %rdi
	movq	72(%rsp), %rsi
	movl	120(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	orb	%al, %dl
	testb	$1, %dl
	jne	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$0, 16(%rsp)
	cmpq	$0, 12624(%rsp)
	jne	.LBB0_857
	cmpq	%r12, 12600(%rsp)
	jne	.LBB0_857
	cmpq	%rbp, 12608(%rsp)
	jne	.LBB0_857
	cmpq	%r15, 12616(%rsp)
	jne	.LBB0_857
	cmpq	%r14, 12632(%rsp)
	jne	.LBB0_857
	cmpq	%r13, 12640(%rsp)
	jne	.LBB0_857
	cmpq	%rbx, 12648(%rsp)
	jne	.LBB0_857
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$2, %esi
	leaq	280(%rsp), %rdi
	movq	72(%rsp), %rdx
	movl	120(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel
	cmpb	$-1, %al
	je	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_856
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_856
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_856
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_856
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_856
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_856
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$32, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6create
	cmpb	$1, 12600(%rsp)
	je	.LBB0_856
	movq	12608(%rsp), %rcx
	movl	12616(%rsp), %r8d
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$1, %edx
	movq	%rcx, 32(%rsp)
	movl	%r8d, 96(%rsp)
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$1, 12600(%rsp)
	je	.LBB0_856
	movq	12608(%rsp), %rax
	movq	%rax, 80(%rsp)
	movl	12616(%rsp), %eax
	movl	%eax, 108(%rsp)
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$1, %esi
	leaq	280(%rsp), %rdi
	movq	24(%rsp), %rdx
	movl	40(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	je	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_856
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_856
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_856
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_856
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_856
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_856
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_856
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	280(%rsp), %rdi
	movq	56(%rsp), %rsi
	movl	88(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	cmpb	$2, %dl
	sete	%cl
	andb	%al, %cl
	cmpb	$1, %cl
	jne	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_856
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_856
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_856
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_856
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_856
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_856
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_856
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	280(%rsp), %rdi
	movq	72(%rsp), %rsi
	movl	120(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	je	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB0_856
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB0_856
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB0_856
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB0_856
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB0_856
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB0_856
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB0_856
	leaq	280(%rsp), %rdi
	movq	80(%rsp), %rsi
	movl	108(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	jne	.LBB0_856
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	32(%rsp), %rdx
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB0_856
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$0, 16(%rsp)
	cmpq	$0, 12624(%rsp)
	jne	.LBB0_857
	cmpq	%r12, 12600(%rsp)
	jne	.LBB0_857
	cmpq	%rbp, 12608(%rsp)
	jne	.LBB0_857
	cmpq	%r15, 12616(%rsp)
	jne	.LBB0_857
	cmpq	%r14, 12632(%rsp)
	jne	.LBB0_857
	cmpq	%r13, 12640(%rsp)
	jne	.LBB0_857
	cmpq	%rbx, 12648(%rsp)
	jne	.LBB0_857
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	%eax, 16(%rsp)
	jmp	.LBB0_857
.LBB0_1555:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1556:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1556
.LBB0_1560:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1561:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1561
.LBB0_1957:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	cmpq	$3, 152(%rsp)
	ja	.LBB0_1991
	movq	152(%rsp), %rax
	shlq	$4, %rax
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54(%rax), %rsi
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54+8(%rax), %rdi
	addq	%rsi, %rdi
.LBB0_1959:
	movzbl	(%rsi), %ecx
	cmpb	$10, %cl
	jne	.LBB0_1965
	movl	$100000, %ecx
.LBB0_1961:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1968
	pause
	decl	%ecx
	jne	.LBB0_1961
	jmp	.LBB0_1963
.LBB0_1965:
	movl	$100000, %r8d
.LBB0_1966:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1973
	pause
	decl	%r8d
	jne	.LBB0_1966
	jmp	.LBB0_1729
.LBB0_1968:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_1969:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1974
	pause
	decl	%ecx
	jne	.LBB0_1969
	jmp	.LBB0_1971
.LBB0_1973:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_1975
.LBB0_1974:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_1975:
	incq	%rsi
	cmpq	%rdi, %rsi
	jne	.LBB0_1959
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB0_1977:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1983
	pause
	decl	%ecx
	jne	.LBB0_1977
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1980:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1980
.LBB0_1729:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB0_1730:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1730
.LBB0_1963:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB0_1964:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1964
.LBB0_1971:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB0_1972:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1972
.LBB0_1565:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1566:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1566
.LBB0_1981:
	movq	%r9, 136(%rsp)
.LBB0_1982:
	movl	$4, %esi
	movq	136(%rsp), %rdi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.LBB0_1983:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB0_1984:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_1988
	pause
	decl	%ecx
	jne	.LBB0_1984
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1987:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1987
.LBB0_1524:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1525:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1525
.LBB0_1529:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1530:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1530
.LBB0_1542:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1543:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1543
.LBB0_1988:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	xorl	%esi, %esi
	jmp	.LBB0_1419
.LBB0_1534:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1535:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1535
.LBB0_1547:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_1548:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_1548
.LBB0_1989:
	movq	88(%rsp), %rax
	movq	%rax, 136(%rsp)
	movl	$4, %esi
	movq	136(%rsp), %rdi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.LBB0_1990:
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	%eax, 20(%rsp)
	jmp	.LBB0_228
.LBB0_1991:
	movq	152(%rsp), %rax
	movq	%rax, 136(%rsp)
	movl	$4, %esi
	movq	136(%rsp), %rdi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.Lfunc_end0:
	.size	_RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBE_, .Lfunc_end0-_RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBE_
	.cfi_endproc
	.section	.rodata._RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBE_,"a",@progbits
	.p2align	3, 0x0
.LJTI0_0:
	.quad	.LBB0_1143
	.quad	.LBB0_1157
	.quad	.LBB0_1166
	.quad	.LBB0_1143

	.section	.text._RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8contractNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBS_,"ax",@progbits
	.prefalign	4, .Lfunc_end1, nop
	.type	_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8contractNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBS_,@function
_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8contractNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBS_:
.Lfunc_begin1:
	.cfi_startproc
	subq	$72, %rsp
	.cfi_def_cfa_offset 80
	movb	$0, 24(%rsp)
	movq	$1, (%rsp)
	movq	$2, 8(%rsp)
	movq	$3, 16(%rsp)
	movb	$0, 40(%rsp)
	movq	$17, 32(%rsp)
	xorl	%ecx, %ecx
	movb	$1, %dl
	xorl	%eax, %eax
	lock		cmpxchgb	%dl, 24(%rsp)
	jne	.LBB1_16
	movq	$29, 8(%rsp)
	xorl	%eax, %eax
	lock		cmpxchgb	%dl, 24(%rsp)
	jne	.LBB1_2
	movb	$0, 24(%rsp)
	jmp	.LBB1_18
.LBB1_2:
	movb	$1, %cl
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 40(%rsp)
	jne	.LBB1_18
	movq	$18, 32(%rsp)
	movq	%rsp, %rdi
	movl	$24, %edx
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.46, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	movb	$0, 40(%rsp)
	testl	%eax, %eax
	jne	.LBB1_18
	movb	$1, %cl
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 24(%rsp)
	movb	$0, 24(%rsp)
	je	.LBB1_18
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 24(%rsp)
	je	.LBB1_9
	movl	$1, %ecx
	movq	$-1, %rdx
	movb	$1, %sil
	.p2align	4
.LBB1_7:
	incq	%rcx
	cmoveq	%rdx, %rcx
	xorl	%eax, %eax
	lock		cmpxchgb	%sil, 24(%rsp)
	jne	.LBB1_7
	cmpq	$1, %rcx
	jne	.LBB1_18
.LBB1_9:
	movq	%rsp, %rdi
	movl	$24, %edx
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.46, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	jne	.LBB1_18
	movq	$41, 16(%rsp)
	movb	$0, 24(%rsp)
	movb	$1, %cl
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 24(%rsp)
	je	.LBB1_14
	movl	$1, %edx
	movq	$-1, %rsi
.LBB1_12:
	incq	%rdx
	cmoveq	%rsi, %rdx
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 24(%rsp)
	jne	.LBB1_12
	cmpq	$1, %rdx
	jne	.LBB1_18
.LBB1_14:
	movq	%rsp, %rdi
	movl	$24, %edx
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.47, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	je	.LBB1_15
.LBB1_18:
	movb	$0, 24(%rsp)
	xorl	%ecx, %ecx
.LBB1_16:
	movl	%ecx, %eax
	addq	$72, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB1_15:
	.cfi_def_cfa_offset 80
	movb	$0, 24(%rsp)
	movq	$53, (%rsp)
	movq	8(%rsp), %rax
	movq	16(%rsp), %rcx
	movq	%rcx, 64(%rsp)
	movq	%rax, 56(%rsp)
	movq	$53, 48(%rsp)
	leaq	48(%rsp), %rdi
	movl	$24, %edx
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.48, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	sete	%cl
	movl	%ecx, %eax
	addq	$72, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8contractNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBS_, .Lfunc_end1-_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8contractNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBS_
	.cfi_endproc

	.section	.text._RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8lifetimeNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBS_,"ax",@progbits
	.prefalign	4, .Lfunc_end2, nop
	.type	_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8lifetimeNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBS_,@function
_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8lifetimeNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBS_:
.Lfunc_begin2:
	.cfi_startproc
	subq	$80, %rsp
	.cfi_def_cfa_offset 88
	movq	$0, (%rsp)
	movb	$0, 24(%rsp)
	movq	%rsp, %rdx
	movq	%rdx, 8(%rsp)
	movq	$17, 16(%rsp)
	xorl	%ecx, %ecx
	movb	$1, %sil
	xorl	%eax, %eax
	lock		cmpxchgb	%sil, 24(%rsp)
	jne	.LBB2_15
	cmpq	$0, (%rsp)
	je	.LBB2_2
.LBB2_18:
	movb	$0, 24(%rsp)
	xorl	%ecx, %ecx
.LBB2_15:
	movl	%ecx, %eax
	addq	$80, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB2_2:
	.cfi_def_cfa_offset 88
	movq	$18, 16(%rsp)
	movb	$0, 24(%rsp)
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	lock		cmpxchgb	%sil, 24(%rsp)
	jne	.LBB2_15
	cmpq	$0, (%rsp)
	jne	.LBB2_18
	movq	$19, 16(%rsp)
	movb	$0, 24(%rsp)
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	lock		cmpxchgb	%sil, 24(%rsp)
	jne	.LBB2_15
	cmpq	$0, (%rsp)
	jne	.LBB2_18
	movq	$20, 16(%rsp)
	movb	$0, 24(%rsp)
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	lock		cmpxchgb	%sil, 24(%rsp)
	jne	.LBB2_15
	cmpq	$0, (%rsp)
	jne	.LBB2_18
	movq	$21, 16(%rsp)
	movb	$0, 24(%rsp)
	movq	$1, (%rsp)
	movb	$0, 48(%rsp)
	movq	%rdx, 32(%rsp)
	movq	$31, 40(%rsp)
	movb	$1, %cl
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 48(%rsp)
	jne	.LBB2_17
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 48(%rsp)
	jne	.LBB2_10
.LBB2_16:
	movb	$0, 48(%rsp)
	jmp	.LBB2_17
.LBB2_10:
	cmpq	$1, (%rsp)
	jne	.LBB2_17
	movq	$43, 40(%rsp)
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 48(%rsp)
	je	.LBB2_16
	cmpq	$1, (%rsp)
	jne	.LBB2_17
	movq	$2, (%rsp)
	movb	$0, 72(%rsp)
	movq	%rdx, 56(%rsp)
	movq	$59, 64(%rsp)
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 72(%rsp)
	jne	.LBB2_17
	movb	$0, 72(%rsp)
	cmpq	$2, (%rsp)
	sete	%cl
	movl	%ecx, %eax
	addq	$80, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB2_17:
	.cfi_def_cfa_offset 88
	xorl	%ecx, %ecx
	movl	%ecx, %eax
	addq	$80, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8lifetimeNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBS_, .Lfunc_end2-_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8lifetimeNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBS_
	.cfi_endproc

	.section	.text._RNvCsi1ALLKoImom_8hematite9boot_main,"ax",@progbits
	.prefalign	4, .Lfunc_end3, nop
	.type	_RNvCsi1ALLKoImom_8hematite9boot_main,@function
_RNvCsi1ALLKoImom_8hematite9boot_main:
.Lfunc_begin3:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	xorl	%esi, %esi
	movw	$1017, %dx
	xorl	%eax, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$1019, %dx
	movb	$-128, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$1016, %dx
	movb	$1, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$1017, %dx
	xorl	%eax, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$1019, %dx
	movb	$3, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$1018, %dx
	movb	$-57, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$1020, %dx
	movb	$3, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB3_1:
	cmpq	$44, %rsi
	jne	.LBB3_2
	movl	$100000, %ecx
	.p2align	4
.LBB3_9:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB3_13
	pause
	decl	%ecx
	jne	.LBB3_9
	jmp	.LBB3_11
	.p2align	4
.LBB3_2:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.57(%rsi), %ecx
	movl	$100000, %edi
	.p2align	4
.LBB3_3:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB3_7
	pause
	decl	%edi
	jne	.LBB3_3
	jmp	.LBB3_5
	.p2align	4
.LBB3_13:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	.p2align	4
.LBB3_14:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB3_18
	pause
	decl	%ecx
	jne	.LBB3_14
	jmp	.LBB3_16
	.p2align	4
.LBB3_7:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rsi
	cmpq	$45, %rsi
	jne	.LBB3_1
	jmp	.LBB3_20
.LBB3_18:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rsi
	cmpq	$45, %rsi
	jne	.LBB3_1
.LBB3_20:
	callq	_RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCsi1ALLKoImom_8hematite4arch12BootPlatformEBE_
	movzbl	%al, %eax
	xorl	$17, %eax
	movw	$244, %dx
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB3_21:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB3_21
.LBB3_5:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB3_6:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB3_6
.LBB3_11:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB3_12:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB3_12
.LBB3_16:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB3_17:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB3_17
.Lfunc_end3:
	.size	_RNvCsi1ALLKoImom_8hematite9boot_main, .Lfunc_end3-_RNvCsi1ALLKoImom_8hematite9boot_main
	.cfi_endproc

	.section	.text.unlikely._RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt,"ax",@progbits
	.prefalign	4, .Lfunc_end4, nop
	.type	_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt,@function
_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt:
.Lfunc_begin4:
	.cfi_startproc
	.file	1 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/panicking.rs"
	.loc	1 80 14 prologue_end
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.loc	1 0 14 is_stmt 0
.Ltmp7:
	.p2align	4
.LBB4_1:
	.loc	1 80 14
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB4_1
.Ltmp8:
.Lfunc_end4:
	.size	_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt, .Lfunc_end4-_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt
	.cfi_endproc

	.section	.text.unlikely._RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail,"ax",@progbits
	.prefalign	4, .Lfunc_end5, nop
	.type	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail,@function
_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail:
.Lfunc_begin5:
	.file	2 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/slice/index.rs"
	.loc	2 39 0 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
.Ltmp9:
	.file	3 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/panic.rs"
	.loc	3 177 9 prologue_end
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt
.Ltmp10:
.Lfunc_end5:
	.size	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail, .Lfunc_end5-_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
	.cfi_endproc

	.section	.text.unlikely._RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check,"ax",@progbits
	.type	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check,@function
_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check:
.Lfunc_begin6:
	.loc	1 266 0
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
.Ltmp11:
	.loc	1 271 5 prologue_end
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt
.Ltmp12:
.Lfunc_end6:
	.size	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check, .Lfunc_end6-_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
	.cfi_endproc

	.section	.text._RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned,"ax",@progbits
	.prefalign	4, .Lfunc_end7, nop
	.type	_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned,@function
_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned:
.Lfunc_begin7:
	.file	4 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/slice/memchr.rs"
	.loc	4 53 0
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	.file	5 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/ptr/mod.rs"
	.loc	5 2380 31 prologue_end
	leaq	7(%rdi), %rcx
	andq	$-8, %rcx
.Ltmp13:
	.loc	4 73 16
	subq	%rdi, %rcx
	jne	.LBB7_1
	.loc	4 0 16 is_stmt 0
	leaq	-16(%rsi), %rax
	xorl	%ecx, %ecx
.LBB7_5:
	movabsq	$-9187201950435737472, %rdx
	movabsq	$3399988123389603631, %r8
	movabsq	$72340172838076672, %r9
	.p2align	4
.LBB7_6:
.Ltmp14:
	.loc	4 87 29 is_stmt 1
	movq	(%rdi,%rcx), %r10
.Ltmp15:
	.loc	4 91 49
	movq	%r10, %r11
	xorq	%r8, %r11
.Ltmp16:
	.loc	4 19 5
	movq	%r9, %rbx
	subq	%r11, %rbx
	orq	%r10, %rbx
	movq	8(%rdi,%rcx), %r10
.Ltmp17:
	.loc	4 92 49
	xorq	%r8, %r10
.Ltmp18:
	.loc	4 19 5
	movq	%r9, %r11
	subq	%r10, %r11
	orq	%r10, %r11
.Ltmp19:
	.loc	4 93 24
	andq	%rdx, %rbx
	andq	%r11, %rbx
	cmpq	%rdx, %rbx
	jne	.LBB7_7
.Ltmp20:
	.loc	4 97 17
	addq	$16, %rcx
	.loc	4 83 19
	cmpq	%rax, %rcx
	jbe	.LBB7_6
	jmp	.LBB7_7
.Ltmp21:
.LBB7_1:
	.loc	4 0 19 is_stmt 0
	xorl	%edx, %edx
	.p2align	4
.LBB7_2:
.Ltmp22:
	.loc	4 42 12 is_stmt 1
	cmpb	$47, (%rdi,%rdx)
	je	.LBB7_15
	.loc	4 46 9
	incq	%rdx
	.loc	4 41 11
	cmpq	%rdx, %rcx
	jne	.LBB7_2
.Ltmp23:
	.loc	4 0 11 is_stmt 0
	leaq	-16(%rsi), %rax
.Ltmp24:
	.loc	4 83 19 is_stmt 1
	cmpq	%rax, %rcx
	jbe	.LBB7_5
.LBB7_7:
.Ltmp25:
	.loc	4 41 11
	subq	%rcx, %rsi
	jne	.LBB7_10
.Ltmp26:
	.loc	4 0 11 is_stmt 0
	xorl	%eax, %eax
	.loc	4 109 2 epilogue_begin is_stmt 1
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB7_10:
	.cfi_def_cfa_offset 16
	.loc	4 0 2 is_stmt 0
	addq	%rcx, %rdi
	xorl	%eax, %eax
	xorl	%edx, %edx
	.p2align	4
.LBB7_11:
.Ltmp27:
	.loc	4 42 12 is_stmt 1
	cmpb	$47, (%rdi,%rdx)
	je	.LBB7_14
	.loc	4 46 9
	incq	%rdx
	.loc	4 41 11
	cmpq	%rdx, %rsi
	jne	.LBB7_11
.Ltmp28:
	.loc	4 109 2 epilogue_begin
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB7_14:
	.cfi_def_cfa_offset 16
.Ltmp29:
	.loc	4 106 60
	addq	%rcx, %rdx
.Ltmp30:
.LBB7_15:
	.loc	4 0 60 is_stmt 0
	movl	$1, %eax
	.loc	4 109 2 epilogue_begin is_stmt 1
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Ltmp31:
.Lfunc_end7:
	.size	_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned, .Lfunc_end7-_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned
	.cfi_endproc
	.file	6 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/ptr/const_ptr.rs"
	.file	7 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/intrinsics/mod.rs"

	.section	.text.unlikely._RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail,"ax",@progbits
	.prefalign	4, .Lfunc_end8, nop
	.type	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail,@function
_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail:
.Lfunc_begin8:
	.file	8 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/slice/mod.rs"
	.loc	8 5588 0
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
.Ltmp32:
	.loc	3 172 21 prologue_end
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt
.Ltmp33:
.Lfunc_end8:
	.size	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail, .Lfunc_end8-_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build,"ax",@progbits
	.prefalign	4, .Lfunc_end9, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build:
.Lfunc_begin9:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$552, %rsp
	.cfi_def_cfa_offset 608
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %rbx
	subq	%rsi, %rbx
	jbe	.LBB9_40
	orl	%esi, %edx
	testl	$4095, %edx
	je	.LBB9_5
	movb	$1, 1(%rdi)
	jmp	.LBB9_3
.LBB9_5:
	cmpq	$16781311, %rbx
	jbe	.LBB9_6
	movb	$2, 1(%rdi)
	jmp	.LBB9_3
.LBB9_6:
	movq	%r8, %r14
	shlq	$4, %r14
	testq	%r8, %r8
	je	.LBB9_13
	leaq	1(%r8), %rax
	xorl	%r10d, %r10d
	movq	%rcx, %r11
	xorl	%r15d, %r15d
.LBB9_10:
	movq	(%r11), %r12
	movq	8(%r11), %r13
	cmpq	%r13, %r12
	jae	.LBB9_11
	cmpq	%rax, %r15
	je	.LBB9_15
	addq	$16, %r11
	incq	%r15
	movq	%r10, %rbp
	movq	%rcx, %rax
	.p2align	4
.LBB9_18:
	testq	%rbp, %rbp
	je	.LBB9_9
	movq	%rax, %rdx
	addq	$16, %rax
	addq	$-16, %rbp
	cmpq	8(%rdx), %r12
	jae	.LBB9_18
	cmpq	%r13, (%rdx)
	jae	.LBB9_18
	jmp	.LBB9_21
.LBB9_9:
	addq	$16, %r10
	leaq	(%rcx,%r14), %rax
	cmpq	%rax, %r11
	leaq	1(%r8), %rax
	jne	.LBB9_10
.LBB9_13:
	movq	608(%rsp), %rax
	movq	%rax, %r15
	shlq	$4, %r15
	testq	%rax, %rax
	je	.LBB9_24
	leaq	(%r9,%r15), %rax
	movq	%r9, %rdx
	.p2align	4
.LBB9_23:
	movq	(%rdx), %r10
	cmpq	8(%rdx), %r10
	jae	.LBB9_40
	addq	$16, %rdx
	cmpq	%rax, %rdx
	jne	.LBB9_23
.LBB9_24:
	movq	%r8, %rbp
	shrq	$12, %rbx
	leaq	16(%rsp), %rax
	movl	$512, %edx
	movq	%rdi, (%rsp)
	movq	%rax, %rdi
	movq	%rsi, %r12
	xorl	%esi, %esi
	movq	%r9, %r13
	movq	%rcx, 8(%rsp)
	callq	*memset@GOTPCREL(%rip)
	movq	8(%rsp), %rax
	movq	(%rsp), %rdi
	movq	%r12, 528(%rsp)
	movq	%rbx, 536(%rsp)
	movq	$0, 544(%rsp)
	testq	%rbx, %rbx
	je	.LBB9_37
	testq	%rbp, %rbp
	je	.LBB9_39
	xorl	%esi, %esi
	jmp	.LBB9_27
.LBB9_21:
	movb	$3, %al
	movb	%al, 1(%rdi)
	jmp	.LBB9_3
.LBB9_41:
	movq	%rcx, %rax
	shrq	$6, %rax
	cmpq	$4095, %rcx
	ja	.LBB9_43
	movl	$1, %r8d
	shlq	%cl, %r8
	orq	%r8, 16(%rsp,%rax,8)
	incq	544(%rsp)
	movq	8(%rsp), %rax
	.p2align	4
.LBB9_36:
	cmpq	%rbx, %rsi
	je	.LBB9_37
.LBB9_27:
	movq	%rsi, %r8
	shlq	$12, %r8
	addq	528(%rsp), %r8
	jb	.LBB9_40
	cmpq	$-4097, %r8
	ja	.LBB9_40
	movq	%rsi, %rcx
	incq	%rsi
	leaq	4096(%r8), %r9
	xorl	%r10d, %r10d
	jmp	.LBB9_30
	.p2align	4
.LBB9_38:
	addq	$16, %r10
	cmpq	%r10, %r14
	je	.LBB9_36
.LBB9_30:
	cmpq	%r8, (%rax,%r10)
	ja	.LBB9_38
	cmpq	8(%rax,%r10), %r9
	ja	.LBB9_38
	movq	%r15, %r10
	movq	%r13, %r11
	.p2align	4
.LBB9_33:
	testq	%r10, %r10
	je	.LBB9_41
	movq	%r11, %rbp
	addq	$16, %r11
	addq	$-16, %r10
	cmpq	8(%rbp), %r8
	jae	.LBB9_33
	cmpq	%r9, (%rbp)
	jae	.LBB9_33
	jmp	.LBB9_36
.LBB9_39:
	xorl	%eax, %eax
	movq	$-4096, %rdx
	subq	%r12, %rdx
	cmovaeq	%rdx, %rax
	addq	$4095, %rax
	shrq	$12, %rax
	decq	%rbx
	cmpq	%rbx, %rax
	jbe	.LBB9_40
.LBB9_37:
	addq	$8, %rdi
	leaq	16(%rsp), %rsi
	movl	$536, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movq	(%rsp), %rdi
	xorl	%eax, %eax
	jmp	.LBB9_4
.LBB9_40:
	movb	$0, 1(%rdi)
.LBB9_3:
	movb	$1, %al
.LBB9_4:
	movb	%al, (%rdi)
	addq	$552, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB9_11:
	.cfi_def_cfa_offset 608
	xorl	%eax, %eax
	movb	%al, 1(%rdi)
	jmp	.LBB9_3
.LBB9_15:
	xorl	%edi, %edi
	movq	%rax, %rsi
	movq	%r8, %rdx
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB9_43:
	movl	$64, %esi
	movq	%rax, %rdi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.Lfunc_end9:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build, .Lfunc_end9-_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit,"ax",@progbits
	.prefalign	4, .Lfunc_end10, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit:
.Lfunc_begin10:
	.cfi_startproc
	movl	9744(%rdi), %edx
	testl	%edx, %edx
	je	.LBB10_3
	movq	9736(%rdi), %rcx
	cmpq	$64, %rcx
	jbe	.LBB10_4
.LBB10_3:
	xorl	%eax, %eax
	retq
.LBB10_4:
	xorl	%esi, %esi
	.p2align	4
.LBB10_5:
	cmpq	$2048, %rsi
	je	.LBB10_13
	movq	%rsi, %rax
	movl	24(%rdi,%rsi), %esi
	cmpl	%edx, %esi
	ja	.LBB10_3
	testl	%esi, %esi
	jne	.LBB10_9
	cmpb	$2, 16(%rdi,%rax)
	jne	.LBB10_3
.LBB10_9:
	movl	56(%rdi,%rax), %r8d
	cmpl	%edx, %r8d
	ja	.LBB10_3
	leaq	64(%rax), %rsi
	testl	%r8d, %r8d
	jne	.LBB10_5
	cmpb	$2, 48(%rdi,%rax)
	je	.LBB10_5
	jmp	.LBB10_3
.LBB10_13:
	xorl	%r8d, %r8d
	.p2align	4
.LBB10_14:
	cmpq	$5120, %r8
	je	.LBB10_25
	movq	%r8, %rsi
	movl	4640(%rdi,%r8), %eax
	cmpl	%edx, %eax
	ja	.LBB10_3
	testl	%eax, %eax
	jne	.LBB10_18
	cmpb	$2, 4633(%rdi,%rsi)
	jne	.LBB10_3
.LBB10_18:
	movl	4680(%rdi,%rsi), %eax
	cmpl	%edx, %eax
	ja	.LBB10_3
	leaq	80(%rsi), %r8
	testl	%eax, %eax
	jne	.LBB10_14
	xorl	%eax, %eax
	cmpb	$2, 4673(%rdi,%rsi)
	je	.LBB10_14
.LBB10_21:
	retq
.LBB10_25:
	xorl	%r8d, %r8d
.LBB10_26:
	cmpq	$2560, %r8
	je	.LBB10_36
	movq	%r8, %rsi
	movl	2080(%rdi,%r8), %eax
	cmpl	%edx, %eax
	ja	.LBB10_3
	testl	%eax, %eax
	jne	.LBB10_30
	cmpb	$2, 2072(%rdi,%rsi)
	jne	.LBB10_3
.LBB10_30:
	movl	2120(%rdi,%rsi), %eax
	cmpl	%edx, %eax
	ja	.LBB10_3
	leaq	80(%rsi), %r8
	testl	%eax, %eax
	jne	.LBB10_26
	xorl	%eax, %eax
	cmpb	$2, 2112(%rdi,%rsi)
	je	.LBB10_26
	jmp	.LBB10_21
.LBB10_36:
	xorl	%eax, %eax
	xorl	%edx, %edx
.LBB10_37:
	xorl	%esi, %esi
	cmpb	$2, 2072(%rdi,%rax)
	setne	%sil
	addq	%rsi, %rdx
	xorl	%esi, %esi
	cmpb	$2, 2112(%rdi,%rax)
	setne	%sil
	xorl	%r8d, %r8d
	cmpb	$2, 2152(%rdi,%rax)
	setne	%r8b
	addq	%rsi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 2192(%rdi,%rax)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB10_37
	cmpq	%rcx, %rdx
	ja	.LBB10_3
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	xorl	%edx, %edx
	xorl	%esi, %esi
	xorl	%ecx, %ecx
	jmp	.LBB10_46
.LBB10_44:
	cmpq	$1, %rax
	ja	.LBB10_98
.LBB10_45:
	addq	$32, %rdx
	incq	%rsi
	cmpq	$2048, %rdx
	je	.LBB10_69
.LBB10_46:
	movzbl	16(%rdi,%rdx), %eax
	cmpb	$2, %al
	je	.LBB10_45
	addq	8(%rdi,%rdx), %rcx
	jb	.LBB10_98
	movl	24(%rdi,%rdx), %r8d
	xorl	%r9d, %r9d
	jmp	.LBB10_50
.LBB10_49:
	addq	$80, %r9
	cmpq	$5120, %r9
	je	.LBB10_57
.LBB10_50:
	cmpb	$2, 4633(%rdi,%r9)
	je	.LBB10_53
	cmpl	%r8d, 4616(%rdi,%r9)
	jne	.LBB10_53
	cmpq	%rsi, 4608(%rdi,%r9)
	je	.LBB10_56
.LBB10_53:
	cmpb	$2, 4673(%rdi,%r9)
	je	.LBB10_49
	cmpl	%r8d, 4656(%rdi,%r9)
	jne	.LBB10_49
	cmpq	%rsi, 4648(%rdi,%r9)
	jne	.LBB10_49
.LBB10_56:
	testb	$1, %al
	je	.LBB10_65
	jmp	.LBB10_98
.LBB10_57:
	xorl	%r9d, %r9d
	jmp	.LBB10_59
.LBB10_58:
	addq	$80, %r9
	xorl	%eax, %eax
	cmpq	$2560, %r9
	je	.LBB10_93
.LBB10_59:
	cmpb	$2, 2072(%rdi,%r9)
	je	.LBB10_62
	cmpl	%r8d, 2064(%rdi,%r9)
	jne	.LBB10_62
	cmpq	%rsi, 2056(%rdi,%r9)
	je	.LBB10_65
.LBB10_62:
	cmpb	$2, 2112(%rdi,%r9)
	je	.LBB10_58
	cmpl	%r8d, 2104(%rdi,%r9)
	jne	.LBB10_58
	cmpq	%rsi, 2096(%rdi,%r9)
	jne	.LBB10_58
.LBB10_65:
	xorl	%r9d, %r9d
	xorl	%eax, %eax
	jmp	.LBB10_67
.LBB10_66:
	cmpl	%r8d, 4616(%rdi,%r9)
	sete	%r11b
	cmpq	%rsi, 4608(%rdi,%r9)
	sete	%bl
	andb	%r11b, %bl
	movzbl	%bl, %r11d
	andl	%r11d, %r10d
	addq	%r10, %rax
	addq	$40, %r9
	cmpq	$5120, %r9
	je	.LBB10_44
.LBB10_67:
	movzbl	4633(%rdi,%r9), %r10d
	cmpq	$2, %r10
	jne	.LBB10_66
	xorl	%r10d, %r10d
	addq	%r10, %rax
	addq	$40, %r9
	cmpq	$5120, %r9
	jne	.LBB10_67
	jmp	.LBB10_44
.LBB10_69:
	xorl	%edx, %edx
	jmp	.LBB10_72
.LBB10_70:
	cmpb	$8, %r8b
	jae	.LBB10_98
.LBB10_71:
	addq	$40, %rdx
	cmpq	$5120, %rdx
	je	.LBB10_80
.LBB10_72:
	movzbl	4633(%rdi,%rdx), %eax
	cmpb	$2, %al
	je	.LBB10_71
	movq	4608(%rdi,%rdx), %rsi
	cmpq	$64, %rsi
	jae	.LBB10_98
	shlq	$5, %rsi
	movl	24(%rdi,%rsi), %r8d
	cmpl	4616(%rdi,%rdx), %r8d
	jne	.LBB10_98
	addq	%rdi, %rsi
	cmpb	$0, 16(%rsi)
	jne	.LBB10_98
	movzbl	4632(%rdi,%rdx), %r8d
	testb	$1, %al
	je	.LBB10_70
	xorl	%eax, %eax
	cmpb	$7, %r8b
	ja	.LBB10_93
	movq	(%rsi), %rsi
	cmpq	%rsi, 4624(%rdi,%rdx)
	je	.LBB10_71
	jmp	.LBB10_93
.LBB10_80:
	xorl	%eax, %eax
	jmp	.LBB10_82
.LBB10_81:
	addq	$40, %rax
	cmpq	$2560, %rax
	je	.LBB10_91
.LBB10_82:
	cmpb	$2, 2072(%rdi,%rax)
	je	.LBB10_81
	movq	2056(%rdi,%rax), %rdx
	cmpq	$64, %rdx
	jae	.LBB10_98
	shlq	$5, %rdx
	movl	24(%rdi,%rdx), %esi
	cmpl	2064(%rdi,%rax), %esi
	jne	.LBB10_98
	addq	%rdi, %rdx
	cmpb	$2, 16(%rdx)
	jne	.LBB10_81
	jmp	.LBB10_98
.LBB10_91:
	cmpq	9752(%rdi), %rcx
	jne	.LBB10_98
	cmpq	9728(%rdi), %rcx
	setbe	%al
.LBB10_93:
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	retq
.LBB10_98:
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	retq
.Lfunc_end10:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit, .Lfunc_end10-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin,"ax",@progbits
	.prefalign	4, .Lfunc_end11, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin:
.Lfunc_begin11:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movb	$1, %al
	movb	$1, %r10b
	cmpq	$127, %rcx
	ja	.LBB11_7
	leaq	(%rcx,%rcx,4), %rcx
	cmpl	%r8d, 4640(%rsi,%rcx,8)
	jne	.LBB11_7
	leaq	(%rsi,%rcx,8), %r11
	addq	$4608, %r11
	cmpb	$2, 25(%r11)
	je	.LBB11_7
	movb	$3, %r10b
	cmpq	%rdx, 16(%r11)
	jne	.LBB11_7
	movq	(%r11), %rcx
	movb	$11, %r10b
	cmpq	$63, %rcx
	ja	.LBB11_7
	movl	8(%r11), %r8d
	movq	%rcx, %rbx
	shlq	$5, %rbx
	cmpl	%r8d, 24(%rsi,%rbx)
	jne	.LBB11_7
	addq	%rsi, %rbx
	cmpb	$0, 16(%rbx)
	je	.LBB11_8
.LBB11_7:
	movb	%r10b, 1(%rdi)
	movb	%al, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB11_8:
	.cfi_def_cfa_offset 24
	movb	$-2, %r10b
	subb	%r9b, %r10b
	orb	24(%r11), %r10b
	cmpb	$-1, %r10b
	je	.LBB11_10
	movb	$4, 1(%rdi)
	movb	%al, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB11_10:
	.cfi_def_cfa_offset 24
	leaq	2048(%rsi), %r9
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
.LBB11_11:
	xorl	%ebx, %ebx
	cmpb	$2, 2072(%rsi,%r10)
	setne	%bl
	addq	%rbx, %r11
	xorl	%ebx, %ebx
	cmpb	$2, 2112(%rsi,%r10)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 2152(%rsi,%r10)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r11, %r14
	xorl	%r11d, %r11d
	cmpb	$2, 2192(%rsi,%r10)
	setne	%r11b
	addq	%r14, %r11
	addq	$160, %r10
	cmpq	$2560, %r10
	jne	.LBB11_11
	cmpq	9736(%rsi), %r11
	jae	.LBB11_23
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	jmp	.LBB11_14
.LBB11_18:
	addq	$2, %r10
	addq	$80, %r11
	cmpq	$2560, %r11
	je	.LBB11_19
.LBB11_14:
	cmpb	$2, 2072(%rsi,%r11)
	jne	.LBB11_16
	cmpl	$0, 2080(%rsi,%r11)
	jne	.LBB11_21
.LBB11_16:
	cmpb	$2, 2112(%rsi,%r11)
	jne	.LBB11_18
	cmpl	$0, 2120(%rsi,%r11)
	je	.LBB11_18
	incq	%r10
.LBB11_21:
	leaq	(%r10,%r10,4), %rax
	movq	%rdx, (%r9,%rax,8)
	movq	%rcx, 8(%r9,%rax,8)
	movl	%r8d, 16(%r9,%rax,8)
	movb	$0, 24(%r9,%rax,8)
	movl	32(%r9,%rax,8), %eax
	movq	%r10, 8(%rdi)
	movl	%eax, 16(%rdi)
	xorl	%eax, %eax
	movb	%al, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB11_23:
	.cfi_def_cfa_offset 24
	movb	$8, 1(%rdi)
	movb	%al, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB11_19:
	.cfi_def_cfa_offset 24
	movb	$9, 1(%rdi)
	movb	%al, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end11:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin, .Lfunc_end11-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant,"ax",@progbits
	.prefalign	4, .Lfunc_end12, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant:
.Lfunc_begin12:
	.cfi_startproc
	movb	$1, %al
	movb	$1, %r10b
	cmpq	$127, %rcx
	ja	.LBB12_7
	leaq	(%rcx,%rcx,4), %rcx
	cmpl	%r8d, 4640(%rsi,%rcx,8)
	jne	.LBB12_7
	leaq	(%rsi,%rcx,8), %r11
	addq	$4608, %r11
	cmpb	$2, 25(%r11)
	je	.LBB12_7
	movb	$3, %r10b
	cmpq	%rdx, 16(%r11)
	jne	.LBB12_7
	movq	(%r11), %rcx
	movb	$11, %r10b
	cmpq	$63, %rcx
	ja	.LBB12_7
	movl	8(%r11), %edx
	movq	%rcx, %r8
	shlq	$5, %r8
	cmpl	%edx, 24(%rsi,%r8)
	jne	.LBB12_7
	addq	%rsi, %r8
	cmpb	$0, 16(%r8)
	je	.LBB12_9
.LBB12_7:
	movb	%r10b, 1(%rdi)
	movb	%al, (%rdi)
	retq
.LBB12_9:
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movzbl	16(%rsp), %r8d
	movzbl	24(%r11), %r10d
	movl	%r8d, %r11d
	orb	$4, %r11b
	notb	%r10b
	testb	%r11b, %r10b
	jne	.LBB12_19
	leaq	4608(%rsi), %r10
	xorl	%r11d, %r11d
	xorl	%ebx, %ebx
	jmp	.LBB12_11
.LBB12_15:
	addq	$2, %r11
	addq	$80, %rbx
	cmpq	$5120, %rbx
	je	.LBB12_16
.LBB12_11:
	cmpb	$2, 4633(%rsi,%rbx)
	jne	.LBB12_13
	cmpl	$0, 4640(%rsi,%rbx)
	jne	.LBB12_18
.LBB12_13:
	cmpb	$2, 4673(%rsi,%rbx)
	jne	.LBB12_15
	cmpl	$0, 4680(%rsi,%rbx)
	je	.LBB12_15
	incq	%r11
.LBB12_18:
	leaq	(%r11,%r11,4), %rax
	movq	%rcx, (%r10,%rax,8)
	movl	%edx, 8(%r10,%rax,8)
	movq	%r9, 16(%r10,%rax,8)
	movb	%r8b, 24(%r10,%rax,8)
	movb	$0, 25(%r10,%rax,8)
	movl	32(%r10,%rax,8), %eax
	movq	%r11, 8(%rdi)
	movl	%eax, 16(%rdi)
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	movb	%al, (%rdi)
	retq
.LBB12_19:
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movb	$4, 1(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	movb	%al, (%rdi)
	retq
.LBB12_16:
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movb	$7, 1(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	movb	%al, (%rdi)
	retq
.Lfunc_end12:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant, .Lfunc_end12-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats,"ax",@progbits
	.prefalign	4, .Lfunc_end13, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats:
.Lfunc_begin13:
	.cfi_startproc
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB13_1:
	xorl	%edx, %edx
	cmpb	$2, 16(%rsi,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 48(%rsi,%rcx)
	setne	%dl
	xorl	%r8d, %r8d
	cmpb	$2, 80(%rsi,%rcx)
	setne	%r8b
	addq	%rdx, %r8
	addq	%rax, %r8
	xorl	%eax, %eax
	cmpb	$2, 112(%rsi,%rcx)
	setne	%al
	addq	%r8, %rax
	subq	$-128, %rcx
	cmpq	$2048, %rcx
	jne	.LBB13_1
	xorl	%edx, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB13_3:
	xorl	%r8d, %r8d
	cmpb	$2, 4633(%rsi,%rdx)
	setne	%r8b
	addq	%r8, %rcx
	xorl	%r8d, %r8d
	cmpb	$2, 4673(%rsi,%rdx)
	setne	%r8b
	xorl	%r9d, %r9d
	cmpb	$2, 4713(%rsi,%rdx)
	setne	%r9b
	addq	%r8, %r9
	addq	%rcx, %r9
	xorl	%ecx, %ecx
	cmpb	$2, 4753(%rsi,%rdx)
	setne	%cl
	addq	%r9, %rcx
	addq	$160, %rdx
	cmpq	$5120, %rdx
	jne	.LBB13_3
	xorl	%r8d, %r8d
	xorl	%edx, %edx
	.p2align	4
.LBB13_5:
	xorl	%r9d, %r9d
	cmpb	$2, 2072(%rsi,%r8)
	setne	%r9b
	addq	%r9, %rdx
	xorl	%r9d, %r9d
	cmpb	$2, 2112(%rsi,%r8)
	setne	%r9b
	xorl	%r10d, %r10d
	cmpb	$2, 2152(%rsi,%r8)
	setne	%r10b
	addq	%r9, %r10
	addq	%rdx, %r10
	xorl	%edx, %edx
	cmpb	$2, 2192(%rsi,%r8)
	setne	%dl
	addq	%r10, %rdx
	addq	$160, %r8
	cmpq	$2560, %r8
	jne	.LBB13_5
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	9752(%rsi), %r8
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	.p2align	4
.LBB13_7:
	xorl	%r11d, %r11d
	cmpl	$0, 24(%rsi,%r10)
	sete	%r11b
	cmpl	$1, 56(%rsi,%r10)
	movq	%r9, %rbx
	adcq	%r11, %rbx
	xorl	%r9d, %r9d
	cmpl	$0, 88(%rsi,%r10)
	sete	%r9b
	cmpl	$1, 120(%rsi,%r10)
	adcq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2048, %r10
	jne	.LBB13_7
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	.p2align	4
.LBB13_9:
	xorl	%ebx, %ebx
	cmpl	$0, 4640(%rsi,%r11)
	sete	%bl
	cmpl	$1, 4680(%rsi,%r11)
	movq	%r10, %r14
	adcq	%rbx, %r14
	xorl	%r10d, %r10d
	cmpl	$0, 4720(%rsi,%r11)
	sete	%r10b
	cmpl	$1, 4760(%rsi,%r11)
	adcq	%r14, %r10
	addq	$160, %r11
	cmpq	$5120, %r11
	jne	.LBB13_9
	xorl	%r11d, %r11d
	xorl	%ebx, %ebx
	.p2align	4
.LBB13_11:
	xorl	%r14d, %r14d
	cmpl	$0, 2080(%rsi,%rbx)
	sete	%r14b
	cmpl	$1, 2120(%rsi,%rbx)
	movq	%r11, %r15
	adcq	%r14, %r15
	xorl	%r11d, %r11d
	cmpl	$0, 2160(%rsi,%rbx)
	sete	%r11b
	cmpl	$1, 2200(%rsi,%rbx)
	adcq	%r15, %r11
	addq	$160, %rbx
	cmpq	$2560, %rbx
	jne	.LBB13_11
	movq	%rax, (%rdi)
	movq	%rcx, 8(%rdi)
	movq	%rdx, 16(%rdi)
	movq	%r8, 24(%rdi)
	movq	%r9, 32(%rdi)
	movq	%r10, 40(%rdi)
	movq	%r11, 48(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end13:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats, .Lfunc_end13-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel,"ax",@progbits
	.prefalign	4, .Lfunc_end14, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel:
.Lfunc_begin14:
	.cfi_startproc
	movb	$2, %al
	cmpq	$63, %rdx
	ja	.LBB14_8
	leaq	(%rdx,%rdx,4), %rdx
	cmpl	%ecx, 2080(%rdi,%rdx,8)
	jne	.LBB14_8
	leaq	(%rdi,%rdx,8), %rcx
	addq	$2048, %rcx
	cmpb	$2, 24(%rcx)
	je	.LBB14_8
	movq	8(%rcx), %rdx
	movb	$11, %al
	cmpq	$63, %rdx
	ja	.LBB14_8
	movl	16(%rcx), %r8d
	shlq	$5, %rdx
	cmpl	%r8d, 24(%rdi,%rdx)
	jne	.LBB14_8
	addq	%rdx, %rdi
	cmpb	$2, 16(%rdi)
	je	.LBB14_8
	movzbl	(%rcx), %eax
	movzwl	5(%rcx), %edx
	movzbl	7(%rcx), %edi
	shll	$16, %edi
	orl	%edx, %edi
	movl	1(%rcx), %edx
	shlq	$40, %rdi
	shlq	$8, %rdx
	orq	%rdi, %rdx
	orq	%rax, %rdx
	movb	$3, %al
	cmpq	%rsi, %rdx
	jne	.LBB14_8
	movq	%rsi, (%rcx)
	movb	$1, 24(%rcx)
	movb	$-1, %al
.LBB14_8:
	retq
.Lfunc_end14:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel, .Lfunc_end14-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6create,"ax",@progbits
	.prefalign	4, .Lfunc_end15, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6create,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6create:
.Lfunc_begin15:
	.cfi_startproc
	movq	9752(%rsi), %rax
	addq	%rdx, %rax
	jb	.LBB15_22
	cmpq	9728(%rsi), %rax
	jbe	.LBB15_2
	movb	$5, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.LBB15_2:
	xorl	%ecx, %ecx
	xorl	%r8d, %r8d
	jmp	.LBB15_3
	.p2align	4
.LBB15_7:
	addq	$64, %r8
	addq	$2, %rcx
	cmpq	$2048, %r8
	je	.LBB15_8
.LBB15_3:
	cmpb	$2, 16(%rsi,%r8)
	jne	.LBB15_5
	cmpl	$0, 24(%rsi,%r8)
	jne	.LBB15_11
.LBB15_5:
	cmpb	$2, 48(%rsi,%r8)
	jne	.LBB15_7
	cmpl	$0, 56(%rsi,%r8)
	je	.LBB15_7
	incq	%rcx
.LBB15_11:
	leaq	4608(%rsi), %r8
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	jmp	.LBB15_12
	.p2align	4
.LBB15_16:
	addq	$2, %r9
	addq	$80, %r10
	cmpq	$5120, %r10
	je	.LBB15_17
.LBB15_12:
	cmpb	$2, 4633(%rsi,%r10)
	jne	.LBB15_14
	cmpl	$0, 4640(%rsi,%r10)
	jne	.LBB15_20
.LBB15_14:
	cmpb	$2, 4673(%rsi,%r10)
	jne	.LBB15_16
	cmpl	$0, 4680(%rsi,%r10)
	je	.LBB15_16
	incq	%r9
.LBB15_20:
	movq	%rcx, %r10
	shlq	$5, %r10
	movl	24(%rsi,%r10), %r11d
	movq	$1, (%rsi,%r10)
	movq	%rdx, 8(%rsi,%r10)
	movb	$0, 16(%rsi,%r10)
	leaq	(%r9,%r9,4), %rdx
	movq	%rcx, (%r8,%rdx,8)
	movl	%r11d, 8(%r8,%rdx,8)
	movq	$1, 16(%r8,%rdx,8)
	movw	$263, 24(%r8,%rdx,8)
	movq	%rax, 9752(%rsi)
	movl	32(%r8,%rdx,8), %eax
	movq	%r9, 8(%rdi)
	movl	%eax, 16(%rdi)
	xorl	%eax, %eax
	movb	%al, (%rdi)
	retq
.LBB15_8:
	movb	$6, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.LBB15_17:
	movb	$7, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.LBB15_22:
	movb	$10, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.Lfunc_end15:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6create, .Lfunc_end15-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6create
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke,"ax",@progbits
	.prefalign	4, .Lfunc_end16, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke:
.Lfunc_begin16:
	.cfi_startproc
	movb	$1, %al
	cmpq	$127, %rdx
	ja	.LBB16_29
	leaq	(%rdx,%rdx,4), %rdx
	cmpl	%ecx, 4640(%rdi,%rdx,8)
	jne	.LBB16_29
	leaq	(%rdi,%rdx,8), %rcx
	addq	$4608, %rcx
	movzbl	25(%rcx), %r8d
	cmpb	$2, %r8b
	je	.LBB16_29
	movb	$3, %al
	cmpq	%rsi, 16(%rcx)
	jne	.LBB16_29
	movq	(%rcx), %rdx
	movb	$11, %al
	cmpq	$63, %rdx
	ja	.LBB16_29
	movl	8(%rcx), %esi
	movq	%rdx, %rcx
	shlq	$5, %rcx
	cmpl	%esi, 24(%rdi,%rcx)
	jne	.LBB16_29
	addq	%rdi, %rcx
	cmpb	$0, 16(%rcx)
	jne	.LBB16_29
	movb	$4, %al
	cmpb	$1, %r8b
	jne	.LBB16_29
	xorl	%eax, %eax
	jmp	.LBB16_9
.LBB16_15:
	addq	$80, %rax
	cmpq	$2560, %rax
	je	.LBB16_16
.LBB16_9:
	cmpb	$2, 2072(%rdi,%rax)
	je	.LBB16_12
	cmpl	%esi, 2064(%rdi,%rax)
	jne	.LBB16_12
	cmpq	%rdx, 2056(%rdi,%rax)
	je	.LBB16_30
.LBB16_12:
	cmpb	$2, 2112(%rdi,%rax)
	je	.LBB16_15
	cmpl	%esi, 2104(%rdi,%rax)
	jne	.LBB16_15
	cmpq	%rdx, 2096(%rdi,%rax)
	jne	.LBB16_15
.LBB16_30:
	leaq	9752(%rdi), %rax
	movq	9752(%rdi), %r8
	xorl	%r9d, %r9d
	jmp	.LBB16_18
.LBB16_16:
	movq	9752(%rdi), %r8
	movb	$11, %al
	subq	8(%rcx), %r8
	jb	.LBB16_29
	leaq	9752(%rdi), %rax
	movb	$1, %r9b
.LBB16_18:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset %rbx, -24
	.cfi_offset %rbp, -16
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	jmp	.LBB16_19
.LBB16_23:
	addq	$40, %r11
	cmpq	$5120, %r11
	je	.LBB16_24
.LBB16_19:
	cmpb	$2, 4633(%rdi,%r11)
	je	.LBB16_23
	cmpl	%esi, 4616(%rdi,%r11)
	jne	.LBB16_23
	cmpq	%rdx, 4608(%rdi,%r11)
	jne	.LBB16_23
	movl	4640(%rdi,%r11), %ebx
	leal	1(%rbx), %ebp
	cmpl	9744(%rdi), %ebx
	movb	$2, 4633(%rdi,%r11)
	cmovael	%r10d, %ebp
	movl	%ebp, 4640(%rdi,%r11)
	jmp	.LBB16_23
.LBB16_24:
	cmpb	$2, 16(%rcx)
	je	.LBB16_26
	movb	$1, 16(%rcx)
.LBB16_26:
	testb	%r9b, %r9b
	je	.LBB16_28
	movl	24(%rcx), %edx
	leal	1(%rdx), %esi
	xorl	%r9d, %r9d
	cmpl	9744(%rdi), %edx
	movb	$2, 16(%rcx)
	cmovbl	%esi, %r9d
	movl	%r9d, 24(%rcx)
.LBB16_28:
	movq	%r8, (%rax)
	movb	$-1, %al
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %rbp
.LBB16_29:
	retq
.Lfunc_end16:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke, .Lfunc_end16-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release,"ax",@progbits
	.prefalign	4, .Lfunc_end17, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release:
.Lfunc_begin17:
	.cfi_startproc
	movb	$1, %al
	cmpq	$127, %rdx
	ja	.LBB17_29
	leaq	(%rdx,%rdx,4), %r8
	cmpl	%ecx, 4640(%rdi,%r8,8)
	jne	.LBB17_29
	leaq	(%rdi,%r8,8), %r8
	addq	$4608, %r8
	cmpb	$2, 25(%r8)
	je	.LBB17_29
	movb	$3, %al
	cmpq	%rsi, 16(%r8)
	jne	.LBB17_29
	movq	(%r8), %r9
	movb	$11, %al
	cmpq	$63, %r9
	ja	.LBB17_29
	movl	8(%r8), %r10d
	movq	%r9, %rsi
	shlq	$5, %rsi
	cmpl	%r10d, 24(%rdi,%rsi)
	jne	.LBB17_29
	addq	%rdi, %rsi
	cmpb	$0, 16(%rsi)
	jne	.LBB17_29
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	xorl	%r11d, %r11d
	movq	%rdx, %rbx
	xorl	%r14d, %r14d
	jmp	.LBB17_8
.LBB17_16:
	addq	$2, %r14
	addq	$-2, %rbx
	addq	$80, %r11
	cmpq	$5120, %r11
	je	.LBB17_17
.LBB17_8:
	testq	%rbx, %rbx
	je	.LBB17_12
	cmpb	$2, 4633(%rdi,%r11)
	je	.LBB17_12
	cmpl	%r10d, 4616(%rdi,%r11)
	jne	.LBB17_12
	cmpq	%r9, 4608(%rdi,%r11)
	je	.LBB17_30
.LBB17_12:
	leaq	1(%r14), %r15
	cmpq	%rdx, %r15
	je	.LBB17_16
	cmpb	$2, 4673(%rdi,%r11)
	je	.LBB17_16
	cmpl	%r10d, 4656(%rdi,%r11)
	jne	.LBB17_16
	cmpq	%r9, 4648(%rdi,%r11)
	jne	.LBB17_16
	jmp	.LBB17_30
.LBB17_17:
	xorl	%edx, %edx
	jmp	.LBB17_18
.LBB17_24:
	addq	$80, %rdx
	cmpq	$2560, %rdx
	je	.LBB17_25
.LBB17_18:
	cmpb	$2, 2072(%rdi,%rdx)
	je	.LBB17_21
	cmpl	%r10d, 2064(%rdi,%rdx)
	jne	.LBB17_21
	cmpq	%r9, 2056(%rdi,%rdx)
	je	.LBB17_30
.LBB17_21:
	cmpb	$2, 2112(%rdi,%rdx)
	je	.LBB17_24
	cmpl	%r10d, 2104(%rdi,%rdx)
	jne	.LBB17_24
	cmpq	%r9, 2096(%rdi,%rdx)
	jne	.LBB17_24
.LBB17_30:
	leaq	9752(%rdi), %rax
	movq	9752(%rdi), %rdx
	leal	1(%rcx), %esi
	xorl	%r9d, %r9d
	cmpl	9744(%rdi), %ecx
	movb	$2, 25(%r8)
	cmovbl	%esi, %r9d
	movl	%r9d, 32(%r8)
.LBB17_27:
	movq	%rdx, (%rax)
	movb	$-1, %al
.LBB17_28:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
.LBB17_29:
	retq
.LBB17_25:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	9752(%rdi), %rdx
	subq	8(%rsi), %rdx
	jb	.LBB17_28
	movl	9744(%rdi), %eax
	addq	$9752, %rdi
	movb	$2, 25(%r8)
	leal	1(%rcx), %r9d
	xorl	%r10d, %r10d
	cmpl	%eax, %ecx
	cmovael	%r10d, %r9d
	movl	%r9d, 32(%r8)
	movb	$2, 16(%rsi)
	movl	24(%rsi), %ecx
	leal	1(%rcx), %r8d
	cmpl	%eax, %ecx
	cmovael	%r10d, %r8d
	movl	%r8d, 24(%rsi)
	movq	%rdi, %rax
	jmp	.LBB17_27
.Lfunc_end17:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release, .Lfunc_end17-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete,"ax",@progbits
	.prefalign	4, .Lfunc_end18, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete:
.Lfunc_begin18:
	.cfi_startproc
	movl	%edx, %ecx
	movb	$1, %al
	movb	$2, %dl
	cmpq	$63, %rsi
	ja	.LBB18_28
	leaq	(%rsi,%rsi,4), %r8
	cmpl	%ecx, 2080(%rdi,%r8,8)
	jne	.LBB18_28
	leaq	(%rdi,%r8,8), %r9
	addq	$2048, %r9
	movzbl	24(%r9), %r8d
	cmpb	$2, %r8b
	je	.LBB18_28
	movq	8(%r9), %r11
	movb	$11, %dl
	cmpq	$63, %r11
	ja	.LBB18_28
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movl	16(%r9), %ebx
	movq	%r11, %r10
	shlq	$5, %r10
	cmpl	%ebx, 24(%rdi,%r10)
	jne	.LBB18_27
	addq	%rdi, %r10
	cmpb	$2, 16(%r10)
	je	.LBB18_27
	xorl	%r14d, %r14d
	jmp	.LBB18_7
	.p2align	4
.LBB18_13:
	addq	$80, %r14
	cmpq	$5120, %r14
	je	.LBB18_14
.LBB18_7:
	cmpb	$2, 4633(%rdi,%r14)
	je	.LBB18_10
	cmpl	%ebx, 4616(%rdi,%r14)
	jne	.LBB18_10
	cmpq	%r11, 4608(%rdi,%r14)
	je	.LBB18_29
.LBB18_10:
	cmpb	$2, 4673(%rdi,%r14)
	je	.LBB18_13
	cmpl	%ebx, 4656(%rdi,%r14)
	jne	.LBB18_13
	cmpq	%r11, 4648(%rdi,%r14)
	jne	.LBB18_13
	jmp	.LBB18_29
.LBB18_14:
	xorl	%r14d, %r14d
	movq	%rsi, %r15
	xorl	%r12d, %r12d
	jmp	.LBB18_15
.LBB18_23:
	addq	$2, %r12
	addq	$-2, %r15
	addq	$80, %r14
	cmpq	$2560, %r14
	je	.LBB18_24
.LBB18_15:
	testq	%r15, %r15
	je	.LBB18_19
	cmpb	$2, 2072(%rdi,%r14)
	je	.LBB18_19
	cmpl	%ebx, 2064(%rdi,%r14)
	jne	.LBB18_19
	cmpq	%r11, 2056(%rdi,%r14)
	je	.LBB18_29
.LBB18_19:
	leaq	1(%r12), %r13
	cmpq	%rsi, %r13
	je	.LBB18_23
	cmpb	$2, 2112(%rdi,%r14)
	je	.LBB18_23
	cmpl	%ebx, 2104(%rdi,%r14)
	jne	.LBB18_23
	cmpq	%r11, 2096(%rdi,%r14)
	jne	.LBB18_23
.LBB18_29:
	leaq	9752(%rdi), %rax
	movq	9752(%rdi), %rsi
	leal	1(%rcx), %edx
	xorl	%r10d, %r10d
	cmpl	9744(%rdi), %ecx
	movb	$2, 24(%r9)
	cmovbl	%edx, %r10d
	movl	%r10d, 32(%r9)
.LBB18_26:
	movq	%rsi, (%rax)
	xorl	%eax, %eax
	movl	%r8d, %edx
.LBB18_27:
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r12
	.cfi_restore %r13
	.cfi_restore %r14
	.cfi_restore %r15
.LBB18_28:
	retq
.LBB18_24:
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	9752(%rdi), %rsi
	subq	8(%r10), %rsi
	jb	.LBB18_27
	movl	9744(%rdi), %eax
	addq	$9752, %rdi
	movb	$2, 24(%r9)
	leal	1(%rcx), %edx
	xorl	%r11d, %r11d
	cmpl	%eax, %ecx
	cmovael	%r11d, %edx
	movl	%edx, 32(%r9)
	movb	$2, 16(%r10)
	movl	24(%r10), %ecx
	leal	1(%rcx), %edx
	cmpl	%eax, %ecx
	cmovael	%r11d, %edx
	movl	%edx, 24(%r10)
	movq	%rdi, %rax
	jmp	.LBB18_26
.Lfunc_end18:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete, .Lfunc_end18-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse,"ax",@progbits
	.prefalign	4, .Lfunc_end19, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse:
.Lfunc_begin19:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$952, %rsp
	.cfi_def_cfa_offset 1008
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	cmpq	$1048576, %rdx
	jbe	.LBB19_2
	movb	$3, (%rdi)
	jmp	.LBB19_23
.LBB19_2:
	cmpq	$64, %rdx
	jae	.LBB19_4
	movb	$2, (%rdi)
	jmp	.LBB19_23
.LBB19_4:
	cmpl	$1179403647, (%rsi)
	jne	.LBB19_22
	cmpb	$2, 4(%rsi)
	jne	.LBB19_21
	cmpb	$1, 5(%rsi)
	jne	.LBB19_21
	cmpb	$1, 6(%rsi)
	jne	.LBB19_21
	cmpb	$0, 7(%rsi)
	jne	.LBB19_21
	cmpb	$0, 8(%rsi)
	jne	.LBB19_21
	cmpb	$0, 9(%rsi)
	jne	.LBB19_21
	cmpb	$0, 10(%rsi)
	jne	.LBB19_21
	cmpb	$0, 11(%rsi)
	jne	.LBB19_21
	cmpb	$0, 12(%rsi)
	jne	.LBB19_21
	cmpb	$0, 13(%rsi)
	jne	.LBB19_21
	cmpb	$0, 14(%rsi)
	jne	.LBB19_21
	cmpb	$0, 15(%rsi)
	jne	.LBB19_21
	movzwl	16(%rsi), %eax
	shll	$16, %eax
	cmpl	$131072, %eax
	jne	.LBB19_21
	movzwl	18(%rsi), %eax
	shll	$16, %eax
	cmpl	$11993088, %eax
	jne	.LBB19_21
	cmpl	$1, 20(%rsi)
	jne	.LBB19_21
	cmpl	$0, 48(%rsi)
	je	.LBB19_25
.LBB19_21:
	movb	$1, (%rdi)
	jmp	.LBB19_23
.LBB19_22:
	movb	$0, (%rdi)
.LBB19_23:
	movb	$-1, 48(%rdi)
.LBB19_24:
	addq	$952, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB19_25:
	.cfi_def_cfa_offset 1008
	movq	%rdi, %rbx
	movzwl	52(%rsi), %eax
	shll	$16, %eax
	cmpl	$4194304, %eax
	jne	.LBB19_29
	movq	%rsi, %r12
	movzwl	54(%rsi), %eax
	shll	$16, %eax
	cmpl	$3670016, %eax
	jne	.LBB19_29
	movzwl	56(%r12), %ebp
	movl	%ebp, %eax
	shll	$16, %eax
	addl	$-1114112, %eax
	cmpl	$-1114112, %eax
	ja	.LBB19_30
	movb	$3, (%rbx)
	movb	$-1, 48(%rbx)
	jmp	.LBB19_24
.LBB19_29:
	movb	$0, (%rbx)
	movb	$-1, 48(%rbx)
	jmp	.LBB19_24
.LBB19_30:
	movq	32(%r12), %r14
	cmpq	$63, %r14
	ja	.LBB19_32
	movb	$4, (%rbx)
	movb	$-1, 48(%rbx)
	jmp	.LBB19_24
.LBB19_32:
	imulq	$56, %rbp, %rax
	addq	%r14, %rax
	jb	.LBB19_34
	movq	%rdx, %r15
	cmpq	%rdx, %rax
	jbe	.LBB19_35
.LBB19_34:
	movb	$2, (%rbx)
	movb	$-1, 48(%rbx)
	jmp	.LBB19_24
.LBB19_35:
	movq	24(%r12), %rax
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 512(%rsp)
	movq	$1, 504(%rsp)
	movq	$1, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$1, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 680(%rsp)
	movq	$1, 672(%rsp)
	movq	$0, 776(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 736(%rsp)
	movq	$1, 728(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 824(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 808(%rsp)
	movq	$0, 800(%rsp)
	movq	$0, 792(%rsp)
	movq	$1, 784(%rsp)
	movq	$0, 888(%rsp)
	movq	$0, 880(%rsp)
	movq	$0, 872(%rsp)
	movq	$0, 864(%rsp)
	movq	$0, 856(%rsp)
	movq	$0, 848(%rsp)
	movq	$1, 840(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 928(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 912(%rsp)
	movq	$0, 904(%rsp)
	movq	$1, 896(%rsp)
	movq	%rax, 480(%rsp)
	leaq	32(%rsp), %rdi
	leaq	504(%rsp), %rsi
	movl	$448, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	addq	$56, %r14
	movq	$0, (%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
.LBB19_36:
	imulq	$56, 16(%rsp), %rax
	addq	%r14, %rax
	movq	%rax, 8(%rsp)
.LBB19_37:
	movq	8(%rsp), %rax
	leaq	-56(%rax), %rdx
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at
	movq	%rax, %r13
	testb	$1, %r13b
	jne	.LBB19_101
	incq	16(%rsp)
	shrq	$32, %r13
	je	.LBB19_93
	movq	8(%rsp), %rax
	leaq	-52(%rax), %rdx
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at
	testb	$1, %al
	jne	.LBB19_102
	movq	8(%rsp), %rdx
	leaq	-48(%rdx), %rcx
	cmpq	$-8, %rcx
	setae	%cl
	addq	$-40, %rdx
	cmpq	%r15, %rdx
	seta	%dl
	orb	%cl, %dl
	movb	$2, %dl
	jne	.LBB19_103
	movq	8(%rsp), %rcx
	addq	$-32, %rcx
	cmpq	%r15, %rcx
	ja	.LBB19_103
	movq	8(%rsp), %rsi
	leaq	-24(%rsi), %rcx
	cmpq	$-8, %rcx
	setae	%cl
	addq	$-16, %rsi
	cmpq	%r15, %rsi
	seta	%sil
	orb	%cl, %sil
	jne	.LBB19_103
	movq	8(%rsp), %rcx
	addq	$-8, %rcx
	cmpq	%r15, %rcx
	ja	.LBB19_103
	cmpq	%r15, 8(%rsp)
	ja	.LBB19_103
	shrq	$32, %rax
	movq	8(%rsp), %r8
	movq	-24(%r12,%r8), %rdi
	movq	-16(%r12,%r8), %rsi
	movq	-8(%r12,%r8), %rcx
	cmpl	$1, %r13d
	jne	.LBB19_95
	cmpq	$8, (%rsp)
	je	.LBB19_140
	testq	%rsi, %rsi
	je	.LBB19_143
	cmpq	%rsi, %rdi
	ja	.LBB19_143
	movq	8(%rsp), %r10
	movq	-48(%r12,%r10), %r9
	movq	-40(%r12,%r10), %r8
	cmpq	$1, %rcx
	jbe	.LBB19_52
	leaq	-1(%rcx), %r10
	testq	%r10, %rcx
	jne	.LBB19_143
	movq	%r8, %rcx
	xorq	%r9, %rcx
	testq	%rcx, %r10
	je	.LBB19_53
	jmp	.LBB19_143
.LBB19_52:
	movq	%r8, %rcx
	xorq	%r9, %rcx
.LBB19_53:
	shlq	$52, %rcx
	jne	.LBB19_143
	addl	$-4, %eax
	cmpl	$2, %eax
	ja	.LBB19_142
	shll	$3, %eax
	movl	$66048, %r10d
	movl	%eax, %ecx
	shrl	%cl, %r10d
	movq	%rdi, %rax
	addq	%r9, %rax
	setb	%cl
	cmpq	%r15, %rax
	seta	%al
	orb	%cl, %al
	jne	.LBB19_103
	movq	%rsi, %rax
	addq	%r8, %rax
	jb	.LBB19_103
	cmpq	$-4096, %rax
	ja	.LBB19_103
	movq	%r8, %rcx
	shrq	$32, %rcx
	je	.LBB19_103
	movabsq	$4296015872, %rcx
	cmpq	%rcx, %rax
	ja	.LBB19_103
	addq	$4095, %rax
	movq	%rax, %rcx
	andq	$-4096, %rcx
	movabsq	$4296015872, %r11
	cmpq	%r11, %rcx
	ja	.LBB19_103
	cmpq	$9, (%rsp)
	jae	.LBB19_156
	movq	%r8, %r11
	andq	$-4096, %r11
	cmpq	$0, (%rsp)
	je	.LBB19_90
	cmpq	%r8, 48(%rsp)
	ja	.LBB19_143
	cmpq	72(%rsp), %r11
	jae	.LBB19_66
	cmpq	%rcx, 64(%rsp)
	jb	.LBB19_143
.LBB19_66:
	cmpq	$1, (%rsp)
	je	.LBB19_90
	cmpq	%r8, 104(%rsp)
	ja	.LBB19_143
	cmpq	128(%rsp), %r11
	jae	.LBB19_70
	cmpq	%rcx, 120(%rsp)
	jb	.LBB19_143
.LBB19_70:
	cmpq	$2, (%rsp)
	je	.LBB19_90
	cmpq	%r8, 160(%rsp)
	ja	.LBB19_143
	cmpq	184(%rsp), %r11
	jae	.LBB19_74
	cmpq	%rcx, 176(%rsp)
	jb	.LBB19_143
.LBB19_74:
	cmpq	$3, (%rsp)
	je	.LBB19_90
	cmpq	%r8, 216(%rsp)
	ja	.LBB19_143
	cmpq	240(%rsp), %r11
	jae	.LBB19_78
	cmpq	%rcx, 232(%rsp)
	jb	.LBB19_143
.LBB19_78:
	cmpq	$4, (%rsp)
	je	.LBB19_90
	cmpq	%r8, 272(%rsp)
	ja	.LBB19_143
	cmpq	296(%rsp), %r11
	jae	.LBB19_82
	cmpq	%rcx, 288(%rsp)
	jb	.LBB19_143
.LBB19_82:
	cmpq	$5, (%rsp)
	je	.LBB19_90
	cmpq	%r8, 328(%rsp)
	ja	.LBB19_143
	cmpq	352(%rsp), %r11
	jae	.LBB19_86
	cmpq	%rcx, 344(%rsp)
	jb	.LBB19_143
.LBB19_86:
	cmpq	$6, (%rsp)
	je	.LBB19_90
	cmpq	%r8, 384(%rsp)
	ja	.LBB19_143
	cmpq	408(%rsp), %r11
	jae	.LBB19_90
	movb	$4, %dl
	cmpq	%rcx, 400(%rsp)
	jb	.LBB19_103
.LBB19_90:
	subq	%r11, %rax
	shrq	$12, %rax
	addq	496(%rsp), %rax
	jb	.LBB19_140
	movq	%rax, 496(%rsp)
	movb	$3, %dl
	cmpq	$256, %rax
	ja	.LBB19_103
	addq	%r12, %r9
	imulq	$56, (%rsp), %rax
	movq	%r9, 32(%rsp,%rax)
	movq	%rdi, 40(%rsp,%rax)
	movq	%r8, 48(%rsp,%rax)
	movq	%rsi, 56(%rsp,%rax)
	movq	%r11, 64(%rsp,%rax)
	movq	%rcx, 72(%rsp,%rax)
	movb	%r10b, 80(%rsp,%rax)
	movq	488(%rsp), %rcx
	incq	%rcx
	movq	%rcx, (%rsp)
	movq	%rcx, 488(%rsp)
	addq	$56, 8(%rsp)
	cmpq	%rbp, 16(%rsp)
	jb	.LBB19_37
	jmp	.LBB19_104
.LBB19_93:
	movq	24(%rsp), %rax
	movl	%eax, %edx
.LBB19_94:
	movl	%edx, %eax
	movq	%rax, 24(%rsp)
	cmpq	%rbp, 16(%rsp)
	jb	.LBB19_36
	jmp	.LBB19_104
.LBB19_95:
	movb	$1, %dl
	cmpl	$1685382481, %r13d
	jne	.LBB19_103
	cmpl	$6, %eax
	jne	.LBB19_103
	movq	24(%rsp), %rax
	xorb	$1, %al
	testb	$1, %al
	je	.LBB19_103
	orq	%rdi, %rsi
	jne	.LBB19_103
	cmpq	$2, %rcx
	jb	.LBB19_94
	leaq	-1(%rcx), %rax
	xorq	%rax, %rcx
	cmpq	%rax, %rcx
	ja	.LBB19_94
	jmp	.LBB19_103
.LBB19_101:
	shrl	$8, %r13d
	movl	%r13d, %edx
	jmp	.LBB19_103
.LBB19_102:
	shrl	$8, %eax
	movl	%eax, %edx
.LBB19_103:
	movb	%dl, (%rbx)
	movb	$-1, 48(%rbx)
	jmp	.LBB19_24
.LBB19_104:
	cmpq	$0, (%rsp)
	je	.LBB19_143
	movq	480(%rsp), %rax
	movb	$6, %dl
	cmpq	$-5, %rax
	ja	.LBB19_103
	testb	$3, %al
	jne	.LBB19_103
	cmpq	$9, (%rsp)
	jae	.LBB19_156
	leaq	4(%rax), %rcx
	cmpb	$2, 80(%rsp)
	jne	.LBB19_111
	movq	48(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB19_111
	addq	40(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB19_139
.LBB19_111:
	cmpq	$1, (%rsp)
	je	.LBB19_103
	cmpb	$2, 136(%rsp)
	jne	.LBB19_115
	movq	104(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB19_115
	addq	96(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB19_139
.LBB19_115:
	cmpq	$2, (%rsp)
	je	.LBB19_103
	cmpb	$2, 192(%rsp)
	jne	.LBB19_119
	movq	160(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB19_119
	addq	152(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB19_139
.LBB19_119:
	cmpq	$3, (%rsp)
	je	.LBB19_103
	cmpb	$2, 248(%rsp)
	jne	.LBB19_123
	movq	216(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB19_123
	addq	208(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB19_139
.LBB19_123:
	cmpq	$4, (%rsp)
	je	.LBB19_103
	cmpb	$2, 304(%rsp)
	jne	.LBB19_127
	movq	272(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB19_127
	addq	264(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB19_139
.LBB19_127:
	cmpq	$5, (%rsp)
	je	.LBB19_103
	cmpb	$2, 360(%rsp)
	jne	.LBB19_131
	movq	328(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB19_131
	addq	320(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB19_139
.LBB19_131:
	cmpq	$6, (%rsp)
	je	.LBB19_103
	cmpb	$2, 416(%rsp)
	jne	.LBB19_135
	movq	384(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB19_135
	addq	376(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB19_139
.LBB19_135:
	cmpq	$7, (%rsp)
	je	.LBB19_103
	cmpb	$2, 472(%rsp)
	jne	.LBB19_103
	movq	440(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB19_103
	addq	432(%rsp), %rsi
	setb	%al
	cmpq	%rsi, %rcx
	seta	%cl
	orb	%al, %cl
	jne	.LBB19_103
.LBB19_139:
	leaq	32(%rsp), %rsi
	movl	$472, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	jmp	.LBB19_24
.LBB19_143:
	movb	$4, %dl
	jmp	.LBB19_103
.LBB19_140:
	movb	$3, %dl
	jmp	.LBB19_103
.LBB19_142:
	movb	$5, %dl
	jmp	.LBB19_103
.LBB19_156:
	movl	$8, %edx
	xorl	%edi, %edi
	movq	(%rsp), %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end19:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse, .Lfunc_end19-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at,"ax",@progbits
	.prefalign	4, .Lfunc_end20, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at:
.Lfunc_begin20:
	.cfi_startproc
	movq	%rdx, %rax
	subq	$-4, %rax
	setae	%cl
	cmpq	%rsi, %rax
	seta	%al
	orb	%cl, %al
	je	.LBB20_2
	movb	$2, %dl
	jmp	.LBB20_3
.LBB20_2:
	movl	(%rdi,%rdx), %edx
	movl	%edx, %ecx
	shrl	$8, %ecx
.LBB20_3:
	shll	$8, %ecx
	movzbl	%dl, %edx
	orl	%edx, %ecx
	shlq	$32, %rcx
	xorl	%esi, %esi
	testb	%al, %al
	cmoveq	%rcx, %rsi
	shll	$8, %edx
	movzbl	%al, %eax
	orl	%edx, %eax
	movzwl	%ax, %eax
	orq	%rsi, %rax
	retq
.Lfunc_end20:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at, .Lfunc_end20-_RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse,"ax",@progbits
	.prefalign	4, .Lfunc_end21, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse:
.Lfunc_begin21:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1656, %rsp
	.cfi_def_cfa_offset 1712
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	cmpq	$40, %rdx
	jb	.LBB21_8
	cmpl	$-302117424, (%rsi)
	jne	.LBB21_8
	movl	4(%rsi), %ebx
	bswapl	%ebx
	leal	-40(%rbx), %eax
	cmpl	$2097113, %eax
	jae	.LBB21_8
	cmpl	$285212672, 20(%rsi)
	jne	.LBB21_8
	cmpl	$268435456, 24(%rsi)
	jne	.LBB21_8
	cmpq	%rbx, %rdx
	jb	.LBB21_6
	movl	8(%rsi), %r14d
	movl	12(%rsi), %r13d
	bswapl	%r14d
	bswapl	%r13d
	movl	36(%rsi), %r12d
	bswapl	%r12d
	leaq	(%r12,%r14), %rax
	cmpq	%r13, %rax
	ja	.LBB21_8
	movl	16(%rsi), %ebp
	bswapl	%ebp
	cmpl	%r14d, %ebp
	jae	.LBB21_8
	cmpl	$40, %ebp
	jb	.LBB21_8
	movl	%ebp, %ecx
	andl	$7, %ecx
	shlq	$32, %rcx
	movl	%r12d, %edx
	orl	%r14d, %edx
	andl	$3, %edx
	shlq	$32, %rdx
	orq	%rcx, %rdx
	jne	.LBB21_8
	cmpq	%rbx, %rax
	ja	.LBB21_6
	movl	32(%rsi), %ecx
	movl	%ecx, %edx
	bswapl	%edx
	leaq	(%rdx,%r13), %rax
	cmpq	%rbx, %rax
	jbe	.LBB21_19
.LBB21_6:
	movw	$257, (%rdi)
	jmp	.LBB21_9
.LBB21_8:
	movw	$1, (%rdi)
.LBB21_9:
	addq	$1656, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB21_19:
	.cfi_def_cfa_offset 1712
	movq	%rdx, 64(%rsp)
	movl	%ecx, 28(%rsp)
	movq	%rsi, 8(%rsp)
	movq	%r14, %r15
	subq	%rbp, %r15
	leaq	856(%rsp), %rax
	movl	$792, %edx
	movq	%rdi, (%rsp)
	movq	%rax, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	(%rsp), %rax
	movq	%rbx, 1648(%rsp)
	cmpq	$16, %r15
	jb	.LBB21_31
	movq	%r15, %rbx
	movq	8(%rsp), %r15
	addq	%r15, %r14
	addq	%r15, %r13
	addq	%r15, %rbp
	movl	$16, %edi
	xorl	%esi, %esi
	xorl	%ecx, %ecx
.LBB21_21:
	movq	(%rbp,%rcx), %rdx
	movq	8(%rbp,%rcx), %r8
	movq	%rdi, %rcx
	bswapq	%rdx
	movq	%r8, %rdi
	bswapq	%rdi
	movq	%rdi, %r9
	orq	%rdx, %r9
	je	.LBB21_33
	testq	%r8, %r8
	je	.LBB21_82
	addq	%rdx, %rdi
	jb	.LBB21_82
	cmpq	$33, %rsi
	jae	.LBB21_86
	movq	%rsi, %r9
	shlq	$4, %r9
	leaq	(%rsp,%r9), %r8
	addq	$856, %r8
	leaq	856(%rsp), %r10
.LBB21_26:
	testq	%r9, %r9
	je	.LBB21_29
	movq	%r10, %r11
	addq	$16, %r10
	addq	$-16, %r9
	cmpq	%rdi, (%r11)
	jae	.LBB21_26
	cmpq	8(%r11), %rdx
	jae	.LBB21_26
	jmp	.LBB21_32
.LBB21_29:
	cmpq	$32, %rsi
	je	.LBB21_85
	movq	%rdx, (%r8)
	movq	%rdi, 8(%r8)
	movq	1632(%rsp), %rsi
	incq	%rsi
	movq	%rsi, 1632(%rsp)
	leaq	16(%rcx), %rdi
	leaq	15(%rcx), %rdx
	cmpq	%rbx, %rdx
	jb	.LBB21_21
.LBB21_31:
	movw	$257, (%rax)
	jmp	.LBB21_9
.LBB21_32:
	movw	$1793, (%rax)
	jmp	.LBB21_9
.LBB21_33:
	movq	%r14, 32(%rsp)
	movq	%r12, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$1024, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$1024, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$1024, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$1024, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$1024, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$1024, 224(%rsp)
	movq	$1024, 248(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$1024, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$1024, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$1024, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$1024, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$1024, 368(%rsp)
	movq	$1024, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 376(%rsp)
	movq	$1024, 416(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$1024, 440(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 424(%rsp)
	movq	$1024, 464(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 448(%rsp)
	movq	$1024, 488(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$1024, 512(%rsp)
	movq	$1024, 536(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 520(%rsp)
	movq	$1024, 560(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	movq	$1024, 584(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 568(%rsp)
	movq	$1024, 608(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 592(%rsp)
	movq	$1024, 632(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 616(%rsp)
	movq	$1024, 656(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 640(%rsp)
	movq	$1024, 680(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 664(%rsp)
	movq	$1024, 704(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 688(%rsp)
	movq	$1024, 728(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 712(%rsp)
	movq	$1024, 752(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 736(%rsp)
	movq	$1024, 776(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 760(%rsp)
	movq	$1024, 800(%rsp)
	movq	$0, 792(%rsp)
	movq	$0, 784(%rsp)
	movq	$1024, 824(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 808(%rsp)
	movq	$1024, 848(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 832(%rsp)
	cmpl	$4, %r12d
	jb	.LBB21_83
	movl	$4, %ebp
	xorl	%ebx, %ebx
	movq	%r12, 8(%rsp)
	xorl	%r15d, %r15d
	movq	$0, 56(%rsp)
	movq	$0, 16(%rsp)
.LBB21_35:
	movq	%rbp, 48(%rsp)
	movl	(%r14,%rbx), %eax
	bswapl	%eax
	decl	%eax
	cmpl	$8, %eax
	ja	.LBB21_92
	jmpq	*.LJTI21_0(,%rax,8)
.LBB21_37:
	leaq	72(%rsp), %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_6Cursor4name
	movq	72(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB21_93
	movq	32(%rsp), %r14
	movq	80(%rsp), %rax
	testq	%r15, %r15
	je	.LBB21_60
	testq	%rax, %rax
	je	.LBB21_92
	cmpq	$33, %r15
	jae	.LBB21_92
	leaq	(%r15,%r15,2), %rcx
	movb	$1, 82(%rsp,%rcx,8)
	movzbl	81(%rsp,%rcx,8), %ecx
	jmpq	*.LJTI21_1(,%rcx,8)
.LBB21_42:
	cmpq	$6, %rax
	je	.LBB21_72
	cmpq	$15, %rax
	jne	.LBB21_73
	movzwl	12(%rsi), %eax
	movzbl	14(%rsi), %ecx
	shll	$16, %ecx
	orl	%eax, %ecx
	shlq	$32, %rcx
	movl	8(%rsi), %eax
	orq	%rcx, %rax
	movabsq	$34184295084289325, %rcx
	xorq	%rcx, %rax
	movq	(%rsi), %rcx
	movabsq	$7234318610140980594, %rdx
	xorq	%rdx, %rcx
	orq	%rax, %rcx
	jne	.LBB21_74
	testb	$1, 56(%rsp)
	jne	.LBB21_97
	movb	$2, %al
	movb	$1, %cl
	movq	%rcx, 56(%rsp)
	cmpq	$32, %r15
	jne	.LBB21_77
	jmp	.LBB21_81
.LBB21_47:
	testq	%r15, %r15
	je	.LBB21_92
	cmpq	$33, %r15
	jae	.LBB21_92
	movq	%r15, %rax
	decq	%rax
	movq	%rax, %r15
	leaq	(%rax,%rax,2), %rax
	leaq	(%rsp,%rax,8), %rdi
	addq	$88, %rdi
	leaq	856(%rsp), %rsi
	callq	_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node6finish
	movq	%rbp, %rbx
	cmpb	$-1, %al
	je	.LBB21_78
	jmp	.LBB21_94
.LBB21_50:
	movq	%rbp, %rbx
	jmp	.LBB21_78
.LBB21_51:
	cmpq	$-5, %rbp
	ja	.LBB21_83
	leaq	4(%rbp), %rax
	cmpq	8(%rsp), %rax
	ja	.LBB21_83
	movq	%rax, 48(%rsp)
	cmpq	$-5, %rax
	ja	.LBB21_83
	leaq	8(%rbp), %rcx
	cmpq	8(%rsp), %rcx
	ja	.LBB21_83
	movl	(%r14,%rax), %edx
	movl	%edx, %eax
	bswapl	%eax
	cmpl	64(%rsp), %eax
	ja	.LBB21_83
	cmpl	28(%rsp), %edx
	je	.LBB21_92
	movl	(%r14,%rbp), %r8d
	bswapl	%r8d
	movl	%eax, %edx
	leaq	(%rdx,%r13), %rsi
	movq	64(%rsp), %rax
	subq	%rdx, %rax
	xorl	%edx, %edx
.LBB21_58:
	cmpb	$0, (%rsi,%rdx)
	je	.LBB21_64
	incq	%rdx
	cmpq	%rdx, %rax
	jne	.LBB21_58
	jmp	.LBB21_92
.LBB21_60:
	testq	%rax, %rax
	jne	.LBB21_92
	testb	$1, 16(%rsp)
	jne	.LBB21_92
	xorl	%eax, %eax
	movb	$1, %cl
	movq	%rcx, 16(%rsp)
	jmp	.LBB21_77
.LBB21_63:
	movb	$3, %al
	cmpq	$32, %r15
	jne	.LBB21_77
	jmp	.LBB21_81
.LBB21_64:
	testq	%rdx, %rdx
	je	.LBB21_92
	movq	%rcx, %rax
	addq	%r8, %rax
	jb	.LBB21_83
	cmpq	8(%rsp), %rax
	ja	.LBB21_83
	movl	%eax, %ebx
	negl	%ebx
	andl	$3, %ebx
	addq	%rax, %rbx
	jb	.LBB21_83
	cmpq	8(%rsp), %rbx
	ja	.LBB21_83
	movq	%rbx, 48(%rsp)
	testq	%r15, %r15
	je	.LBB21_92
	cmpq	$33, %r15
	jae	.LBB21_98
	addq	%r14, %rcx
	leaq	(%r15,%r15,2), %rax
	leaq	(%rsp,%rax,8), %rdi
	addq	$64, %rdi
	callq	_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property
	cmpb	$-1, %al
	je	.LBB21_78
	jmp	.LBB21_94
.LBB21_72:
	movl	(%rsi), %eax
	movzwl	4(%rsi), %ecx
	shlq	$32, %rcx
	orq	%rax, %rcx
	movb	$1, %al
	movabsq	$133532402673005, %rdx
	cmpq	%rdx, %rcx
	jne	.LBB21_75
	jmp	.LBB21_76
.LBB21_73:
	cmpq	$7, %rax
	jb	.LBB21_75
.LBB21_74:
	movl	$7, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.62, %rdi
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	je	.LBB21_80
.LBB21_75:
	movb	$4, %al
.LBB21_76:
	cmpq	$32, %r15
	je	.LBB21_81
.LBB21_77:
	leaq	(%r15,%r15,2), %rcx
	movq	$0, 88(%rsp,%rcx,8)
	movb	$0, 104(%rsp,%rcx,8)
	movb	%al, 105(%rsp,%rcx,8)
	movb	$0, 106(%rsp,%rcx,8)
	incq	%r15
	movq	40(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	48(%rsp), %rbx
.LBB21_78:
	cmpq	$-5, %rbx
	ja	.LBB21_83
	leaq	4(%rbx), %rbp
	cmpq	8(%rsp), %rbp
	ja	.LBB21_83
	jmp	.LBB21_35
.LBB21_80:
	movb	$1, %al
	cmpq	$32, %r15
	jne	.LBB21_77
.LBB21_81:
	movq	(%rsp), %rax
	movb	$5, 1(%rax)
	jmp	.LBB21_84
.LBB21_82:
	movw	$1537, (%rax)
	jmp	.LBB21_9
.LBB21_83:
	movq	(%rsp), %rax
	movb	$1, 1(%rax)
.LBB21_84:
	movb	$1, %cl
	movb	%cl, (%rax)
	jmp	.LBB21_9
.LBB21_85:
	movw	$1281, (%rax)
	jmp	.LBB21_9
.LBB21_86:
	movl	$32, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB21_87:
	testq	%r15, %r15
	jne	.LBB21_92
	testb	$1, 16(%rsp)
	je	.LBB21_92
	cmpq	%r12, %rbp
	jne	.LBB21_92
	cmpq	$0, 1624(%rsp)
	je	.LBB21_96
	movq	(%rsp), %rbx
	leaq	8(%rbx), %rdi
	leaq	856(%rsp), %rsi
	movl	$800, %edx
	callq	*memcpy@GOTPCREL(%rip)
	xorl	%eax, %eax
	movb	%al, (%rbx)
	jmp	.LBB21_9
.LBB21_92:
	movq	(%rsp), %rax
	movb	$2, 1(%rax)
	jmp	.LBB21_84
.LBB21_93:
	movzbl	80(%rsp), %eax
.LBB21_94:
	movq	(%rsp), %rcx
	movb	%al, 1(%rcx)
	movb	$1, %al
	movb	%al, (%rcx)
	jmp	.LBB21_9
.LBB21_95:
	movq	(%rsp), %rax
	movb	$3, 1(%rax)
	jmp	.LBB21_84
.LBB21_96:
	movq	(%rsp), %rax
	movb	$8, 1(%rax)
	jmp	.LBB21_84
.LBB21_97:
	movq	(%rsp), %rax
	movb	$4, 1(%rax)
	jmp	.LBB21_84
.LBB21_98:
	movb	$2, %al
	jmp	.LBB21_94
.Lfunc_end21:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse, .Lfunc_end21-_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse,"a",@progbits
	.p2align	3, 0x0
.LJTI21_0:
	.quad	.LBB21_37
	.quad	.LBB21_47
	.quad	.LBB21_51
	.quad	.LBB21_50
	.quad	.LBB21_92
	.quad	.LBB21_92
	.quad	.LBB21_92
	.quad	.LBB21_92
	.quad	.LBB21_87
.LJTI21_1:
	.quad	.LBB21_42
	.quad	.LBB21_95
	.quad	.LBB21_63
	.quad	.LBB21_95
	.quad	.LBB21_75

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_6Cursor4name,"ax",@progbits
	.prefalign	4, .Lfunc_end22, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_6Cursor4name,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_6Cursor4name:
.Lfunc_begin22:
	.cfi_startproc
	movq	8(%rsi), %rdx
	movq	16(%rsi), %r8
	cmpq	%r8, %rdx
	jae	.LBB22_2
	movb	$1, 8(%rdi)
	movq	$0, (%rdi)
	retq
.LBB22_2:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rcx
	subq	%r8, %rcx
	je	.LBB22_6
	movq	(%rsi), %rax
	leaq	(%rax,%r8), %rbx
	xorl	%r14d, %r14d
	.p2align	4
.LBB22_4:
	cmpb	$0, (%rbx,%r14)
	je	.LBB22_8
	incq	%r14
	cmpq	%r14, %rcx
	jne	.LBB22_4
.LBB22_6:
	movb	$2, 8(%rdi)
.LBB22_7:
	movq	$0, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
	retq
.LBB22_8:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	leaq	(%r8,%r14), %rcx
	incq	%rcx
	cmpq	%r8, %rcx
	setae	%r8b
	cmpq	%rdx, %rcx
	setbe	%r9b
	testb	%r9b, %r8b
	jne	.LBB22_10
	movb	$1, 8(%rdi)
	jmp	.LBB22_7
.LBB22_10:
	movq	%rcx, 16(%rsi)
	movl	%ecx, %r8d
	negl	%r8d
	andl	$3, %r8d
	movq	%r8, %r9
	addq	%rcx, %r9
	setb	%r10b
	cmpq	%rdx, %r9
	seta	%dl
	orb	%r10b, %dl
	movb	$1, %dl
	jne	.LBB22_13
	movq	%r9, 16(%rsi)
	testq	%r8, %r8
	je	.LBB22_15
	movb	$2, %dl
	cmpb	$0, (%rax,%rcx)
	je	.LBB22_14
.LBB22_13:
	movb	%dl, 8(%rdi)
	jmp	.LBB22_7
.LBB22_14:
	cmpl	$1, %r8d
	jne	.LBB22_22
.LBB22_15:
	cmpq	$15, %r14
	ja	.LBB22_20
	testq	%r14, %r14
	je	.LBB22_21
	xorl	%eax, %eax
.LBB22_18:
	cmpb	$47, (%rbx,%rax)
	je	.LBB22_6
	incq	%rax
	cmpq	%rax, %r14
	jne	.LBB22_18
	jmp	.LBB22_21
.LBB22_20:
	movq	%rdi, %r15
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned
	movq	%r15, %rdi
	testb	$1, %al
	jne	.LBB22_6
.LBB22_21:
	movq	%rbx, (%rdi)
	movq	%r14, 8(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
	retq
.LBB22_22:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	cmpb	$0, 1(%rax,%rcx)
	jne	.LBB22_13
	cmpl	$2, %r8d
	je	.LBB22_15
	cmpb	$0, 2(%rax,%rcx)
	jne	.LBB22_13
	jmp	.LBB22_15
.Lfunc_end22:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_6Cursor4name, .Lfunc_end22-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_6Cursor4name
	.cfi_endproc

	.section	.text._RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node6finish,"ax",@progbits
	.prefalign	4, .Lfunc_end23, nop
	.type	_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node6finish,@function
_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node6finish:
.Lfunc_begin23:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movzbl	17(%rdi), %r8d
	leal	(,%r8,8), %ecx
	movabsq	$1099376945148, %rdx
	shrq	%cl, %rdx
	orb	16(%rdi), %dl
	movb	$2, %al
	cmpb	$-1, %dl
	jne	.LBB23_22
	movq	(%rdi), %rdx
	testq	%rdx, %rdx
	je	.LBB23_19
	movq	8(%rdi), %rdi
	andq	$-16, %rdi
	je	.LBB23_19
	addq	%rdx, %rdi
	cmpb	$1, %r8b
	jne	.LBB23_15
	leaq	512(%rsi), %r8
	movb	$6, %al
.LBB23_5:
	movq	8(%rdx), %r9
	testq	%r9, %r9
	je	.LBB23_22
	movq	(%rdx), %r10
	bswapq	%r10
	bswapq	%r9
	movq	%r9, %r11
	addq	%r10, %r11
	jb	.LBB23_22
	movq	768(%rsi), %rcx
	cmpq	$16, %rcx
	ja	.LBB23_24
	addq	$16, %rdx
	movq	%rcx, %r14
	shlq	$4, %r14
	leaq	(%r8,%r14), %rbx
	movq	%r8, %r12
	.p2align	4
.LBB23_9:
	testq	%r14, %r14
	je	.LBB23_12
	movq	%r12, %r15
	addq	$16, %r12
	addq	$-16, %r14
	cmpq	%r11, (%r15)
	jae	.LBB23_9
	cmpq	8(%r15), %r10
	jae	.LBB23_9
	jmp	.LBB23_20
.LBB23_12:
	addq	784(%rsi), %r9
	jb	.LBB23_22
	cmpq	$16, %rcx
	je	.LBB23_21
	movq	%r10, (%rbx)
	movq	%r11, 8(%rbx)
	incq	768(%rsi)
	movq	%r9, 784(%rsi)
	cmpq	%rdi, %rdx
	jne	.LBB23_5
	jmp	.LBB23_19
	.p2align	4
.LBB23_15:
	movq	8(%rdx), %rcx
	movb	$6, %al
	testq	%rcx, %rcx
	je	.LBB23_22
	movq	(%rdx), %r8
	bswapq	%r8
	bswapq	%rcx
	addq	%r8, %rcx
	jb	.LBB23_22
	movq	776(%rsi), %rax
	cmpq	$32, %rax
	jae	.LBB23_21
	shlq	$4, %rax
	movq	%r8, (%rsi,%rax)
	movq	%rcx, 8(%rsi,%rax)
	incq	776(%rsi)
	addq	$16, %rdx
	cmpq	%rdi, %rdx
	jne	.LBB23_15
.LBB23_19:
	movb	$-1, %al
	jmp	.LBB23_22
.LBB23_20:
	movb	$7, %al
	jmp	.LBB23_22
.LBB23_21:
	movb	$5, %al
.LBB23_22:
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB23_24:
	.cfi_def_cfa_offset 48
	movl	$16, %edx
	xorl	%edi, %edi
	movq	%rcx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end23:
	.size	_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node6finish, .Lfunc_end23-_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node6finish
	.cfi_endproc

	.section	.text._RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property,"ax",@progbits
	.prefalign	4, .Lfunc_end24, nop
	.type	_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property,@function
_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property:
.Lfunc_begin24:
	.cfi_startproc
	movb	$2, %al
	cmpb	$0, 18(%rdi)
	je	.LBB24_2
.LBB24_1:
	retq
.LBB24_2:
	cmpq	$11, %rdx
	jne	.LBB24_10
	movzwl	8(%rsi), %eax
	movzbl	10(%rsi), %r9d
	shll	$16, %r9d
	orq	%rax, %r9
	movabsq	$8385532508832687460, %rax
	xorq	(%rsi), %rax
	xorq	$6647929, %r9
	orq	%rax, %r9
	jne	.LBB24_10
	movzbl	16(%rdi), %r9d
	movb	$4, %al
	testb	$16, %r9b
	jne	.LBB24_1
	orb	$16, %r9b
	movb	%r9b, 16(%rdi)
	cmpb	$1, 17(%rdi)
	jne	.LBB24_8
	movb	$3, %al
	cmpq	$7, %r8
	jne	.LBB24_1
	movzwl	4(%rcx), %r9d
	movzbl	6(%rcx), %r10d
	shll	$16, %r10d
	orl	%r9d, %r10d
	shlq	$32, %r10
	movl	(%rcx), %r9d
	orq	%r10, %r9
	movabsq	$133532402673005, %r10
	cmpq	%r10, %r9
	je	.LBB24_10
	jmp	.LBB24_1
.LBB24_8:
	cmpq	$7, %r8
	jne	.LBB24_10
	movzwl	4(%rcx), %eax
	movzbl	6(%rcx), %r9d
	shll	$16, %r9d
	orl	%eax, %r9d
	shlq	$32, %r9
	movl	(%rcx), %r10d
	orq	%r9, %r10
	movb	$3, %al
	movabsq	$133532402673005, %r9
	cmpq	%r9, %r10
	je	.LBB24_1
.LBB24_10:
	movzbl	17(%rdi), %r9d
	movzbl	%r9b, %eax
	jmpq	*.LJTI24_0(,%rax,8)
.LBB24_11:
	cmpq	$6, %rdx
	je	.LBB24_50
	cmpl	$11, %edx
	je	.LBB24_36
	cmpl	$14, %edx
	jne	.LBB24_65
	cmpb	$35, (%rsi)
	jne	.LBB24_65
	cmpb	$97, 1(%rsi)
	jne	.LBB24_65
	cmpb	$100, 2(%rsi)
	jne	.LBB24_65
	cmpb	$100, 3(%rsi)
	jne	.LBB24_65
	cmpb	$114, 4(%rsi)
	jne	.LBB24_65
	cmpb	$101, 5(%rsi)
	jne	.LBB24_65
	cmpb	$115, 6(%rsi)
	jne	.LBB24_65
	cmpb	$115, 7(%rsi)
	jne	.LBB24_65
	cmpb	$45, 8(%rsi)
	jne	.LBB24_65
	cmpb	$99, 9(%rsi)
	jne	.LBB24_65
	cmpb	$101, 10(%rsi)
	jne	.LBB24_65
	cmpb	$108, 11(%rsi)
	jne	.LBB24_65
	cmpb	$108, 12(%rsi)
	jne	.LBB24_65
	cmpb	$115, 13(%rsi)
	jne	.LBB24_65
	movl	8(%rsi), %eax
	movzwl	12(%rsi), %r10d
	shlq	$32, %r10
	orq	%rax, %r10
	movabsq	$8319104478668415267, %rax
	xorq	(%rsi), %rax
	movabsq	$126909512246061, %r11
	xorq	%r10, %r11
	orq	%rax, %r11
	sete	%al
	movb	$2, %r10b
	subb	%al, %r10b
	jmp	.LBB24_47
.LBB24_29:
	cmpq	$3, %rdx
	je	.LBB24_32
	cmpl	$6, %edx
	je	.LBB24_59
	jmp	.LBB24_65
.LBB24_32:
	movzwl	(%rsi), %eax
	movzbl	2(%rsi), %r10d
	shll	$16, %r10d
	orl	%eax, %r10d
	cmpl	$6776178, %r10d
	jne	.LBB24_65
	movzbl	16(%rdi), %r10d
	movb	$4, %al
	testb	$8, %r10b
	jne	.LBB24_1
	orb	$8, %r10b
	movb	%r10b, 16(%rdi)
	testq	%r8, %r8
	sete	%al
	testb	$15, %r8b
	setne	%r10b
	orb	%al, %r10b
	movb	$2, %al
	jne	.LBB24_1
	movq	%rcx, (%rdi)
	movq	%r8, 8(%rdi)
	jmp	.LBB24_65
.LBB24_36:
	cmpb	$35, (%rsi)
	jne	.LBB24_65
	cmpb	$115, 1(%rsi)
	jne	.LBB24_65
	cmpb	$105, 2(%rsi)
	jne	.LBB24_65
	cmpb	$122, 3(%rsi)
	jne	.LBB24_65
	cmpb	$101, 4(%rsi)
	jne	.LBB24_65
	cmpb	$45, 5(%rsi)
	jne	.LBB24_65
	cmpb	$99, 6(%rsi)
	jne	.LBB24_65
	cmpb	$101, 7(%rsi)
	jne	.LBB24_65
	cmpb	$108, 8(%rsi)
	jne	.LBB24_65
	cmpb	$108, 9(%rsi)
	jne	.LBB24_65
	movb	$2, %r10b
	cmpb	$115, 10(%rsi)
	jne	.LBB24_65
.LBB24_47:
	movzbl	16(%rdi), %r11d
	movb	$4, %al
	testb	%r10b, %r11b
	jne	.LBB24_1
	orb	%r10b, %r11b
	movb	%r11b, 16(%rdi)
	movb	$3, %al
	cmpq	$4, %r8
	jne	.LBB24_1
	cmpl	$33554432, (%rcx)
	jne	.LBB24_1
	jmp	.LBB24_65
.LBB24_50:
	cmpb	$114, (%rsi)
	jne	.LBB24_59
	cmpb	$97, 1(%rsi)
	jne	.LBB24_59
	cmpb	$110, 2(%rsi)
	jne	.LBB24_59
	cmpb	$103, 3(%rsi)
	jne	.LBB24_59
	cmpb	$101, 4(%rsi)
	jne	.LBB24_59
	cmpb	$2, %r9b
	jne	.LBB24_59
	cmpb	$115, 5(%rsi)
	jne	.LBB24_59
	movzbl	16(%rdi), %r10d
	movb	$4, %al
	testb	$4, %r10b
	jne	.LBB24_1
	orb	$4, %r10b
	movb	%r10b, 16(%rdi)
	movb	$3, %al
	testq	%r8, %r8
	jne	.LBB24_1
.LBB24_59:
	movl	(%rsi), %eax
	movzwl	4(%rsi), %r10d
	shlq	$32, %r10
	orq	%rax, %r10
	movabsq	$126948300911731, %rax
	cmpq	%rax, %r10
	jne	.LBB24_65
	movzbl	16(%rdi), %r10d
	movb	$4, %al
	testb	$32, %r10b
	jne	.LBB24_1
	orb	$32, %r10b
	movb	%r10b, 16(%rdi)
	movb	$3, %al
	cmpq	$3, %r8
	je	.LBB24_64
	cmpl	$5, %r8d
	jne	.LBB24_1
	movl	(%rcx), %edi
	movzbl	4(%rcx), %ecx
	shlq	$32, %rcx
	orq	%rdi, %rcx
	cmpq	$2036427631, %rcx
	jne	.LBB24_1
	jmp	.LBB24_65
.LBB24_64:
	movzwl	(%rcx), %edi
	movzbl	2(%rcx), %ecx
	shll	$16, %ecx
	orl	%edi, %ecx
	cmpl	$27503, %ecx
	jne	.LBB24_1
.LBB24_65:
	andb	$6, %r9b
	cmpb	$2, %r9b
	jne	.LBB24_31
	addl	$-4, %edx
	cmpl	$8, %edx
	ja	.LBB24_31
	jmpq	*.LJTI24_1(,%rdx,8)
.LBB24_68:
	cmpb	$115, (%rsi)
	jne	.LBB24_31
	cmpb	$105, 1(%rsi)
	jne	.LBB24_31
	cmpb	$122, 2(%rsi)
	movb	$-1, %al
	jne	.LBB24_1
	movb	$101, %al
	movl	$3, %ecx
.LBB24_72:
	cmpb	%al, (%rsi,%rcx)
	setne	%al
	negb	%al
	orb	$3, %al
	retq
.LBB24_74:
	cmpb	$114, (%rsi)
	jne	.LBB24_31
	cmpb	$101, 1(%rsi)
	jne	.LBB24_31
	cmpb	$117, 2(%rsi)
	jne	.LBB24_31
	cmpb	$115, 3(%rsi)
	jne	.LBB24_31
	cmpb	$97, 4(%rsi)
	jne	.LBB24_31
	cmpb	$98, 5(%rsi)
	jne	.LBB24_31
	cmpb	$108, 6(%rsi)
	movb	$-1, %al
	jne	.LBB24_1
	movb	$101, %al
	movl	$7, %ecx
	jmp	.LBB24_72
.LBB24_82:
	cmpb	$110, (%rsi)
	jne	.LBB24_31
	cmpb	$111, 1(%rsi)
	jne	.LBB24_31
	cmpb	$45, 2(%rsi)
	jne	.LBB24_31
	cmpb	$109, 3(%rsi)
	jne	.LBB24_31
	cmpb	$97, 4(%rsi)
	movb	$-1, %al
	jne	.LBB24_1
	movb	$112, %al
	movl	$5, %ecx
	jmp	.LBB24_72
.LBB24_88:
	cmpb	$97, (%rsi)
	jne	.LBB24_31
	cmpb	$108, 1(%rsi)
	jne	.LBB24_31
	cmpb	$105, 2(%rsi)
	jne	.LBB24_31
	cmpb	$103, 3(%rsi)
	jne	.LBB24_31
	cmpb	$110, 4(%rsi)
	jne	.LBB24_31
	cmpb	$109, 5(%rsi)
	jne	.LBB24_31
	cmpb	$101, 6(%rsi)
	jne	.LBB24_31
	cmpb	$110, 7(%rsi)
	movb	$-1, %al
	jne	.LBB24_1
	movb	$116, %al
	movl	$8, %ecx
	jmp	.LBB24_72
.LBB24_97:
	cmpb	$97, (%rsi)
	jne	.LBB24_31
	cmpb	$108, 1(%rsi)
	jne	.LBB24_31
	cmpb	$108, 2(%rsi)
	jne	.LBB24_31
	cmpb	$111, 3(%rsi)
	jne	.LBB24_31
	cmpb	$99, 4(%rsi)
	jne	.LBB24_31
	cmpb	$45, 5(%rsi)
	jne	.LBB24_31
	cmpb	$114, 6(%rsi)
	jne	.LBB24_31
	cmpb	$97, 7(%rsi)
	jne	.LBB24_31
	cmpb	$110, 8(%rsi)
	jne	.LBB24_31
	cmpb	$103, 9(%rsi)
	jne	.LBB24_31
	cmpb	$101, 10(%rsi)
	movb	$-1, %al
	jne	.LBB24_1
	movb	$115, %al
	movl	$11, %ecx
	jmp	.LBB24_72
.LBB24_31:
	movb	$-1, %al
	retq
.Lfunc_end24:
	.size	_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property, .Lfunc_end24-_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property
	.cfi_endproc
	.section	.rodata._RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property,"a",@progbits
	.p2align	3, 0x0
.LJTI24_0:
	.quad	.LBB24_11
	.quad	.LBB24_29
	.quad	.LBB24_11
	.quad	.LBB24_29
	.quad	.LBB24_31
.LJTI24_1:
	.quad	.LBB24_68
	.quad	.LBB24_31
	.quad	.LBB24_82
	.quad	.LBB24_31
	.quad	.LBB24_74
	.quad	.LBB24_88
	.quad	.LBB24_31
	.quad	.LBB24_31
	.quad	.LBB24_97

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse,"ax",@progbits
	.prefalign	4, .Lfunc_end25, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse:
.Lfunc_begin25:
	.cfi_startproc
	cmpq	$40, %rdx
	jb	.LBB25_7
	cmpl	$-302117424, (%rsi)
	jne	.LBB25_7
	movl	4(%rsi), %ecx
	bswapl	%ecx
	leal	-40(%rcx), %eax
	cmpl	$2097113, %eax
	jae	.LBB25_7
	cmpl	$285212672, 20(%rsi)
	jne	.LBB25_7
	cmpl	$268435456, 24(%rsi)
	jne	.LBB25_7
	cmpl	$0, 28(%rsi)
	je	.LBB25_8
	movb	$3, (%rdi)
	movb	$-1, 24(%rdi)
	retq
.LBB25_7:
	movb	$0, (%rdi)
	movb	$-1, 24(%rdi)
	retq
.LBB25_8:
	cmpq	%rcx, %rdx
	jae	.LBB25_10
	movb	$1, (%rdi)
	movb	$-1, 24(%rdi)
	retq
.LBB25_10:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$2264, %rsp
	.cfi_def_cfa_offset 6416
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	8(%rsi), %eax
	bswapl	%eax
	movl	16(%rsi), %edx
	bswapl	%edx
	cmpl	%eax, %edx
	jae	.LBB25_17
	cmpl	$40, %edx
	jb	.LBB25_17
	movl	36(%rsi), %ebp
	bswapl	%ebp
	movl	%edx, %r8d
	andl	$7, %r8d
	shlq	$32, %r8
	movl	%ebp, %r9d
	orl	%eax, %r9d
	andl	$3, %r9d
	shlq	$32, %r9
	orq	%r8, %r9
	jne	.LBB25_17
	movl	12(%rsi), %ebx
	bswapl	%ebx
	leaq	(%rax,%rbp), %r8
	cmpq	%rbx, %r8
	ja	.LBB25_17
	cmpq	%rcx, %r8
	ja	.LBB25_16
	movl	32(%rsi), %r14d
	bswapl	%r14d
	leaq	(%r14,%rbx), %r8
	cmpq	%rcx, %r8
	jbe	.LBB25_20
.LBB25_16:
	movb	$1, (%rdi)
	jmp	.LBB25_18
.LBB25_17:
	movb	$0, (%rdi)
.LBB25_18:
	movb	$-1, 24(%rdi)
.LBB25_19:
	addq	$6360, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r12
	.cfi_restore %r13
	.cfi_restore %r14
	.cfi_restore %r15
	.cfi_restore %rbp
	retq
.LBB25_20:
	.cfi_def_cfa_offset 6416
	.cfi_offset %rbx, -56
	.cfi_offset %rbp, -16
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	leaq	(%rsi,%rax), %r15
	addq	%rsi, %rbx
	subq	%rdx, %rax
	addq	%rdx, %rsi
	movl	$15, %ecx
.LBB25_21:
	cmpq	%rax, %rcx
	jae	.LBB25_16
	movq	-15(%rsi,%rcx), %rdx
	movq	-7(%rsi,%rcx), %r8
	bswapq	%rdx
	bswapq	%r8
	movq	%r8, %r9
	orq	%rdx, %r9
	je	.LBB25_25
	negq	%r8
	addq	$16, %rcx
	cmpq	%r8, %rdx
	jb	.LBB25_21
	movb	$2, (%rdi)
	jmp	.LBB25_18
.LBB25_25:
	movq	%rdi, 16(%rsp)
	movq	%r15, 56(%rsp)
	movq	%rbp, 64(%rsp)
	movq	$0, 72(%rsp)
	leaq	216(%rsp), %rdi
	movq	memcpy@GOTPCREL(%rip), %r12
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	408(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	600(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	792(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	984(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	1176(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	1368(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	1560(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	1752(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	1944(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	2136(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	2328(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	2520(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	2712(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	2904(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	3096(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	3288(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	3480(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	3672(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	3864(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	4056(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	4248(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	4440(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	4632(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	4824(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	5016(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	5208(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	5400(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	5592(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	5784(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	5976(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	leaq	6168(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, %rsi
	callq	*%r12
	movw	$0, 28(%rsp)
	movw	$0, 30(%rsp)
	cmpl	$4, %ebp
	jb	.LBB25_105
	movb	$2, 15(%rsp)
	movl	$4, %eax
	xorl	%r13d, %r13d
	movq	%rbp, 32(%rsp)
	xorl	%r12d, %r12d
	movq	$0, 80(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
.LBB25_27:
	movq	%rax, 72(%rsp)
	movl	(%r15,%r13), %ecx
	bswapl	%ecx
	decl	%ecx
	cmpl	$8, %ecx
	ja	.LBB25_115
	jmpq	*.LJTI25_0(,%rcx,8)
.LBB25_29:
	leaq	88(%rsp), %rdi
	leaq	56(%rsp), %rsi
	callq	_RNvMs_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB4_6Cursor4name
	movq	88(%rsp), %r13
	testq	%r13, %r13
	je	.LBB25_116
	movq	56(%rsp), %r15
	movq	96(%rsp), %rdx
	testq	%r12, %r12
	je	.LBB25_59
	testq	%rdx, %rdx
	je	.LBB25_115
	cmpq	$33, %r12
	jae	.LBB25_115
	leaq	(%r12,%r12,2), %rax
	shlq	$6, %rax
	movb	$1, 208(%rsp,%rax)
	movzbl	214(%rsp,%rax), %eax
	jmpq	*.LJTI25_1(,%rax,8)
.LBB25_34:
	cmpq	$4, %rdx
	jne	.LBB25_88
	movl	(%r13), %eax
	cmpl	$1768125296, %eax
	je	.LBB25_103
	cmpl	$1937076323, %eax
	jne	.LBB25_86
	testb	$1, 40(%rsp)
	jne	.LBB25_120
	movb	$1, %al
	movq	%rax, 40(%rsp)
	movb	$1, %al
	jmp	.LBB25_96
.LBB25_39:
	testq	%r12, %r12
	je	.LBB25_115
	cmpq	$33, %r12
	jae	.LBB25_115
	leaq	-1(%r12), %rcx
	leaq	(%rcx,%rcx,2), %rdx
	shlq	$6, %rdx
	leaq	(%rsp,%rdx), %rsi
	addq	$216, %rsi
	movzbl	406(%rsp,%rdx), %edi
	cmpl	$3, %edi
	je	.LBB25_71
	cmpl	$2, %edi
	je	.LBB25_62
	cmpl	$1, %edi
	jne	.LBB25_82
	cmpl	$0, 16(%rsi)
	je	.LBB25_106
	cmpb	$0, 24(%rsi)
	je	.LBB25_106
	cmpl	$0, 28(%rsi)
	movq	%rax, %r13
	movq	%rcx, %r12
	je	.LBB25_99
	jmp	.LBB25_106
.LBB25_47:
	movq	%rax, %r13
	jmp	.LBB25_99
.LBB25_48:
	cmpq	$-5, %rax
	ja	.LBB25_105
	leaq	4(%rax), %rcx
	cmpq	32(%rsp), %rcx
	ja	.LBB25_105
	movq	%rcx, 72(%rsp)
	cmpq	$-5, %rcx
	ja	.LBB25_105
	leaq	8(%rax), %r8
	cmpq	32(%rsp), %r8
	ja	.LBB25_105
	movl	(%r15,%rax), %r9d
	bswapl	%r9d
	movq	%r8, %rax
	addq	%r9, %rax
	jb	.LBB25_105
	cmpq	32(%rsp), %rax
	ja	.LBB25_105
	movl	%eax, %r13d
	negl	%r13d
	andl	$3, %r13d
	addq	%rax, %r13
	jb	.LBB25_105
	cmpq	32(%rsp), %r13
	ja	.LBB25_105
	movl	(%r15,%rcx), %ecx
	movq	%r13, 72(%rsp)
	testq	%r12, %r12
	je	.LBB25_115
	cmpq	$33, %r12
	jae	.LBB25_115
	bswapl	%ecx
	addq	%r15, %r8
	leaq	(%r12,%r12,2), %rax
	shlq	$6, %rax
	leaq	(%rsp,%rax), %rdi
	addq	$24, %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB5_4Node8property
	cmpb	$-1, %al
	je	.LBB25_99
	jmp	.LBB25_117
.LBB25_59:
	testq	%rdx, %rdx
	jne	.LBB25_115
	testb	$1, 48(%rsp)
	jne	.LBB25_115
	movl	$16, %ecx
	leaq	88(%rsp), %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65+32, %rsi
	rep;movsq (%rsi), %es:(%rdi)
	movb	$1, %al
	movq	%rax, 48(%rsp)
	xorl	%edx, %edx
	xorl	%eax, %eax
	jmp	.LBB25_98
.LBB25_62:
	testq	%rcx, %rcx
	je	.LBB25_115
	leaq	(%r12,%r12,2), %rsi
	shlq	$6, %rsi
	cmpl	$1, -152(%rsp,%rsi)
	jne	.LBB25_106
	leaq	(%rsp,%rsi), %rdi
	addq	$216, %rdi
	cmpb	$0, -360(%rdi)
	je	.LBB25_106
	cmpl	$0, -356(%rdi)
	jne	.LBB25_106
	cmpb	$0, 401(%rsp,%rdx)
	je	.LBB25_106
	movq	384(%rsp,%rdx), %rdi
	testq	%rdi, %rdi
	je	.LBB25_115
	movq	392(%rsp,%rdx), %r9
	movl	-148(%rsp,%rsi), %r10d
	leaq	(,%r10,4), %rsi
	cmpq	%rsi, %r9
	jne	.LBB25_115
	movq	216(%rsp,%rdx), %r8
	movq	224(%rsp,%rdx), %rsi
	movzbl	402(%rsp,%rdx), %edx
	cmpl	$1, %r10d
	jne	.LBB25_75
	movl	(%rdi), %edi
	bswapl	%edi
	jmp	.LBB25_77
.LBB25_71:
	movzbl	187(%rsi), %edx
	testb	%dl, 188(%rsi)
	je	.LBB25_106
	movzbl	189(%rsi), %edx
	movb	%dl, 15(%rsp)
	jmp	.LBB25_82
.LBB25_73:
	cmpq	$4, %rdx
	jae	.LBB25_83
	cmpq	$3, %rdx
	jne	.LBB25_95
	jmp	.LBB25_94
.LBB25_75:
	cmpq	$8, %r9
	jb	.LBB25_105
	movq	(%rdi), %rdi
	bswapq	%rdi
.LBB25_77:
	testq	%r8, %r8
	je	.LBB25_106
	cmpq	%rdi, %rsi
	jne	.LBB25_106
	cmpq	$2, %rdi
	jae	.LBB25_106
	cmpb	$1, 28(%rsp,%rsi)
	je	.LBB25_120
	movb	$1, 28(%rsp,%rsi)
	movb	%dl, 30(%rsp,%rsi)
.LBB25_82:
	movq	%rax, %r13
	movq	%rcx, %r12
	jmp	.LBB25_99
.LBB25_83:
	cmpl	$1081438307, (%r13)
	je	.LBB25_101
.LBB25_84:
	cmpq	$4, %rdx
	jne	.LBB25_88
	movl	(%r13), %eax
.LBB25_86:
	cmpl	$1768125296, %eax
	je	.LBB25_106
	cmpl	$1937076323, %eax
	jne	.LBB25_93
	jmp	.LBB25_106
.LBB25_88:
	cmpq	$5, %rdx
	jae	.LBB25_91
	cmpq	$3, %rdx
	je	.LBB25_94
	cmpq	$4, %rdx
	je	.LBB25_93
	jmp	.LBB25_95
.LBB25_91:
	movl	$5, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.66, %rdi
	movq	%r13, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	je	.LBB25_106
	movl	$5, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.67, %rdi
	movq	%r13, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	je	.LBB25_106
.LBB25_93:
	cmpl	$1081438307, (%r13)
	jne	.LBB25_95
	jmp	.LBB25_106
.LBB25_94:
	movzwl	(%r13), %eax
	movzbl	2(%r13), %ecx
	shll	$16, %ecx
	orl	%eax, %ecx
	cmpl	$7696483, %ecx
	je	.LBB25_106
.LBB25_95:
	movb	$4, %al
.LBB25_96:
	xorl	%edx, %edx
.LBB25_97:
	movl	$16, %ecx
	leaq	88(%rsp), %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.65+32, %rsi
	rep;movsq (%rsi), %es:(%rdi)
	cmpq	$32, %r12
	je	.LBB25_118
.LBB25_98:
	leaq	(%r12,%r12,2), %r9
	shlq	$6, %r9
	movq	%rdx, 216(%rsp,%r9)
	movq	%r8, 224(%rsp,%r9)
	movl	$0, 232(%rsp,%r9)
	movl	$0, 240(%rsp,%r9)
	leaq	248(%rsp,%r9), %rdi
	movl	$16, %ecx
	leaq	88(%rsp), %rsi
	rep;movsq (%rsi), %es:(%rdi)
	movq	$0, 384(%rsp,%r9)
	movq	$0, 376(%rsp,%r9)
	movl	$0, 400(%rsp,%r9)
	movw	$0, 404(%rsp,%r9)
	movb	%al, 406(%rsp,%r9)
	incq	%r12
	movq	64(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	72(%rsp), %r13
.LBB25_99:
	cmpq	$-5, %r13
	ja	.LBB25_105
	leaq	4(%r13), %rax
	cmpq	32(%rsp), %rax
	ja	.LBB25_105
	jmp	.LBB25_27
.LBB25_101:
	leaq	88(%rsp), %rdi
	movq	%r13, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology12unit_address
	cmpb	$1, 88(%rsp)
	je	.LBB25_125
	movq	96(%rsp), %r8
	movl	$1, %edx
	movb	$2, %al
	jmp	.LBB25_97
.LBB25_103:
	testb	$1, 80(%rsp)
	jne	.LBB25_120
	movb	$3, %al
	movb	$1, %cl
	movq	%rcx, 80(%rsp)
	jmp	.LBB25_96
.LBB25_105:
	movq	16(%rsp), %rax
	movb	$1, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB25_19
.LBB25_106:
	movq	16(%rsp), %rax
	movb	$3, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB25_19
.LBB25_107:
	cmpb	$1, 48(%rsp)
	jne	.LBB25_115
	testq	%r12, %r12
	jne	.LBB25_115
	cmpq	%rbp, %rax
	jne	.LBB25_115
	cmpb	$1, 40(%rsp)
	jne	.LBB25_119
	cmpb	$0, 28(%rsp)
	je	.LBB25_119
	cmpb	$0, 29(%rsp)
	je	.LBB25_121
	cmpb	$2, 15(%rsp)
	je	.LBB25_123
	movl	$2, %eax
	movzwl	30(%rsp), %ecx
	cmpl	$257, %ecx
	je	.LBB25_124
	jmp	.LBB25_123
.LBB25_115:
	movq	16(%rsp), %rax
	movb	$2, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB25_19
.LBB25_116:
	movzbl	96(%rsp), %eax
.LBB25_117:
	movq	16(%rsp), %rcx
	movb	%al, (%rcx)
	movb	$-1, 24(%rcx)
	jmp	.LBB25_19
.LBB25_118:
	movq	16(%rsp), %rax
	movb	$5, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB25_19
.LBB25_119:
	movq	16(%rsp), %rax
	movb	$6, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB25_19
.LBB25_120:
	movq	16(%rsp), %rax
	movb	$4, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB25_19
.LBB25_121:
	movl	$1, %eax
	cmpb	$1, 30(%rsp)
	jne	.LBB25_124
	cmpb	$2, 15(%rsp)
	jne	.LBB25_124
.LBB25_123:
	movq	16(%rsp), %rax
	movb	$7, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB25_19
.LBB25_124:
	movq	16(%rsp), %rcx
	movq	$0, (%rcx)
	movq	$1, 8(%rcx)
	movq	%rax, 16(%rcx)
	movzbl	15(%rsp), %eax
	movb	%al, 24(%rcx)
	jmp	.LBB25_19
.LBB25_125:
	movzbl	89(%rsp), %eax
	jmp	.LBB25_117
.Lfunc_end25:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse, .Lfunc_end25-_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse,"a",@progbits
	.p2align	3, 0x0
.LJTI25_0:
	.quad	.LBB25_29
	.quad	.LBB25_39
	.quad	.LBB25_48
	.quad	.LBB25_47
	.quad	.LBB25_115
	.quad	.LBB25_115
	.quad	.LBB25_115
	.quad	.LBB25_115
	.quad	.LBB25_107
.LJTI25_1:
	.quad	.LBB25_34
	.quad	.LBB25_73
	.quad	.LBB25_106
	.quad	.LBB25_106
	.quad	.LBB25_84

	.section	.text._RNvMs_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB4_6Cursor4name,"ax",@progbits
	.prefalign	4, .Lfunc_end26, nop
	.type	_RNvMs_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB4_6Cursor4name,@function
_RNvMs_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB4_6Cursor4name:
.Lfunc_begin26:
	.cfi_startproc
	movq	8(%rsi), %rdx
	movq	16(%rsi), %r8
	cmpq	%r8, %rdx
	jae	.LBB26_2
	movb	$1, 8(%rdi)
	movq	$0, (%rdi)
	retq
.LBB26_2:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rcx
	subq	%r8, %rcx
	je	.LBB26_6
	movq	(%rsi), %rax
	leaq	(%rax,%r8), %rbx
	xorl	%r14d, %r14d
	.p2align	4
.LBB26_4:
	cmpb	$0, (%rbx,%r14)
	je	.LBB26_8
	incq	%r14
	cmpq	%r14, %rcx
	jne	.LBB26_4
.LBB26_6:
	movb	$2, 8(%rdi)
.LBB26_7:
	movq	$0, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
	retq
.LBB26_8:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	leaq	(%r8,%r14), %rcx
	incq	%rcx
	cmpq	%r8, %rcx
	setae	%r8b
	cmpq	%rdx, %rcx
	setbe	%r9b
	testb	%r9b, %r8b
	jne	.LBB26_10
	movb	$1, 8(%rdi)
	jmp	.LBB26_7
.LBB26_10:
	movq	%rcx, 16(%rsi)
	movl	%ecx, %r8d
	negl	%r8d
	andl	$3, %r8d
	movq	%r8, %r9
	addq	%rcx, %r9
	setb	%r10b
	cmpq	%rdx, %r9
	seta	%dl
	orb	%r10b, %dl
	movb	$1, %dl
	jne	.LBB26_13
	movq	%r9, 16(%rsi)
	testq	%r8, %r8
	je	.LBB26_15
	movb	$2, %dl
	cmpb	$0, (%rax,%rcx)
	je	.LBB26_14
.LBB26_13:
	movb	%dl, 8(%rdi)
	jmp	.LBB26_7
.LBB26_14:
	cmpl	$1, %r8d
	jne	.LBB26_22
.LBB26_15:
	cmpq	$15, %r14
	ja	.LBB26_20
	testq	%r14, %r14
	je	.LBB26_21
	xorl	%eax, %eax
.LBB26_18:
	cmpb	$47, (%rbx,%rax)
	je	.LBB26_6
	incq	%rax
	cmpq	%rax, %r14
	jne	.LBB26_18
	jmp	.LBB26_21
.LBB26_20:
	movq	%rdi, %r15
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned
	movq	%r15, %rdi
	testb	$1, %al
	jne	.LBB26_6
.LBB26_21:
	movq	%rbx, (%rdi)
	movq	%r14, 8(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
	retq
.LBB26_22:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	cmpb	$0, 1(%rax,%rcx)
	jne	.LBB26_13
	cmpl	$2, %r8d
	je	.LBB26_15
	cmpb	$0, 2(%rax,%rcx)
	jne	.LBB26_13
	jmp	.LBB26_15
.Lfunc_end26:
	.size	_RNvMs_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB4_6Cursor4name, .Lfunc_end26-_RNvMs_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB4_6Cursor4name
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology12unit_address,"ax",@progbits
	.prefalign	4, .Lfunc_end27, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology12unit_address,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology12unit_address:
.Lfunc_begin27:
	.cfi_startproc
	cmpl	$1081438307, (%rsi)
	je	.LBB27_1
	movb	$3, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.LBB27_1:
	leaq	-21(%rdx), %rax
	cmpq	$-16, %rax
	jae	.LBB27_6
	movb	$2, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.LBB27_6:
	movl	$4, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB27_7:
	movzbl	(%rsi,%rax), %r8d
	leal	-48(%r8), %r9d
	cmpb	$10, %r9b
	jb	.LBB27_12
	leal	-97(%r8), %r9d
	cmpb	$5, %r9b
	ja	.LBB27_9
	addb	$-87, %r8b
	movl	%r8d, %r9d
.LBB27_12:
	movq	%rcx, %r8
	shrq	$60, %r8
	jne	.LBB27_13
	movq	%rcx, %r8
	shlq	$4, %r8
	movzbl	%r9b, %ecx
	addq	%r8, %rcx
	incq	%rax
	cmpq	%rax, %rdx
	jne	.LBB27_7
	movq	%rcx, 8(%rdi)
	xorl	%eax, %eax
	movb	%al, (%rdi)
	retq
.LBB27_9:
	movb	$2, %al
	movb	%al, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.LBB27_13:
	movb	$3, %al
	movb	%al, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.Lfunc_end27:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology12unit_address, .Lfunc_end27-_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology12unit_address
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB5_4Node8property,"ax",@progbits
	.prefalign	4, .Lfunc_end28, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB5_4Node8property,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB5_4Node8property:
.Lfunc_begin28:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	cmpb	$0, 184(%rdi)
	je	.LBB28_2
.LBB28_1:
	movb	$2, %al
	jmp	.LBB28_194
.LBB28_2:
	movl	%ecx, %ebx
	movb	$1, %al
	cmpq	%rbx, %rdx
	jae	.LBB28_3
.LBB28_194:
	addq	$72, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB28_3:
	.cfi_def_cfa_offset 128
	movq	%rdx, %r10
	subq	%rbx, %r10
	je	.LBB28_1
	addq	%rsi, %rbx
	xorl	%r14d, %r14d
	.p2align	4
.LBB28_5:
	cmpb	$0, (%rbx,%r14)
	je	.LBB28_7
	incq	%r14
	cmpq	%r14, %r10
	jne	.LBB28_5
	jmp	.LBB28_1
.LBB28_7:
	testq	%r14, %r14
	je	.LBB28_1
	movl	%ecx, 20(%rsp)
	movq	%r9, 8(%rsp)
	movq	%r8, (%rsp)
	movq	160(%rdi), %r15
	cmpq	$33, %r15
	jae	.LBB28_182
	leaq	(%rdi,%r15,4), %r12
	addq	$32, %r12
	testq	%r15, %r15
	je	.LBB28_20
	leaq	32(%rdi), %r13
	movq	memcmp@GOTPCREL(%rip), %rbp
.LBB28_11:
	movl	(%r13), %ecx
	cmpq	%rcx, %rdx
	jb	.LBB28_194
	movq	%rdx, %r8
	subq	%rcx, %r8
	je	.LBB28_1
	addq	$4, %r13
	addq	%rsi, %rcx
	xorl	%r9d, %r9d
	.p2align	4
.LBB28_14:
	cmpb	$0, (%rcx,%r9)
	je	.LBB28_16
	incq	%r9
	cmpq	%r9, %r8
	jne	.LBB28_14
	jmp	.LBB28_1
.LBB28_16:
	cmpq	%r14, %r9
	jne	.LBB28_18
	movq	%rdi, 40(%rsp)
	movq	%rcx, %rdi
	movq	%rsi, 32(%rsp)
	movq	%rbx, %rsi
	movq	%rdx, 24(%rsp)
	movq	%r14, %rdx
	callq	*%rbp
	movq	32(%rsp), %rsi
	movq	24(%rsp), %rdx
	movq	40(%rsp), %rdi
	movl	%eax, %ecx
	movb	$1, %al
	testl	%ecx, %ecx
	je	.LBB28_193
.LBB28_18:
	cmpq	%r12, %r13
	jne	.LBB28_11
	movb	$5, %al
	cmpq	$32, %r15
	je	.LBB28_194
.LBB28_20:
	movl	20(%rsp), %eax
	movl	%eax, (%r12)
	incq	160(%rdi)
	cmpq	$10, %r14
	je	.LBB28_27
	cmpq	$11, %r14
	movq	(%rsp), %rdx
	movq	8(%rsp), %rax
	jne	.LBB28_30
	movzwl	8(%rbx), %ecx
	movzbl	10(%rbx), %esi
	shll	$16, %esi
	orq	%rcx, %rsi
	movabsq	$8385532508832687460, %rcx
	xorq	(%rbx), %rcx
	xorq	$6647929, %rsi
	orq	%rcx, %rsi
	jne	.LBB28_46
	testq	%rax, %rax
	je	.LBB28_1
	xorl	%esi, %esi
.LBB28_25:
	cmpb	$0, (%rdx,%rsi)
	je	.LBB28_39
	incq	%rsi
	cmpq	%rsi, %rax
	jne	.LBB28_25
	jmp	.LBB28_1
.LBB28_27:
	movzwl	8(%rbx), %eax
	movabsq	$7091327050118426467, %rcx
	xorq	(%rbx), %rcx
	xorq	$25964, %rax
	orq	%rcx, %rax
	movq	(%rsp), %rax
	movq	8(%rsp), %rsi
	jne	.LBB28_46
	movq	%rdi, %r15
	movq	%rax, %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology10compatible
	movl	%eax, %ebp
	cmpb	$2, %bpl
	jne	.LBB28_37
	movzwl	%bp, %eax
	shrl	$8, %eax
	jmp	.LBB28_194
.LBB28_30:
	movzbl	190(%rdi), %ecx
.LBB28_31:
	cmpb	$4, %cl
	setne	%sil
	cmpq	$6, %r14
	sete	%r8b
	testb	%sil, %r8b
	je	.LBB28_47
	movl	(%rbx), %esi
	movzwl	4(%rbx), %r8d
	shlq	$32, %r8
	orq	%rsi, %r8
	movl	$6, %r14d
	movabsq	$126948300911731, %rsi
	cmpq	%rsi, %r8
	jne	.LBB28_47
	testq	%rax, %rax
	je	.LBB28_1
	xorl	%esi, %esi
.LBB28_35:
	cmpb	$0, (%rdx,%rsi)
	je	.LBB28_155
	incq	%rsi
	cmpq	%rsi, %rax
	jne	.LBB28_35
	jmp	.LBB28_1
.LBB28_37:
	testb	$1, %bpl
	je	.LBB28_43
	movb	$3, %al
	movq	%r15, %rdi
	cmpb	$3, 190(%r15)
	je	.LBB28_45
	jmp	.LBB28_194
.LBB28_39:
	leaq	1(%rsi), %rcx
	cmpq	%rax, %rcx
	jne	.LBB28_1
	movzbl	190(%rdi), %ecx
	cmpq	$3, %rsi
	jne	.LBB28_177
	cmpb	$2, %cl
	sete	%al
	movzwl	(%rdx), %esi
	movzbl	2(%rdx), %edx
	shll	$16, %edx
	orl	%esi, %edx
	cmpl	$7696483, %edx
	sete	%sil
	xorb	%al, %sil
	movb	$3, %al
	jne	.LBB28_194
	cmpl	$7696483, %edx
	sete	%al
	jmp	.LBB28_179
.LBB28_43:
	movq	(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	8(%rsp), %rax
	movq	%rax, 56(%rsp)
	movb	$0, 64(%rsp)
	leaq	48(%rsp), %rdi
	callq	_RINvYINtNtNtCs1R9DcZHJAgT_4core5slice4iter5SplithNCNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_
	testb	%al, %al
	movq	%r15, %rdi
	je	.LBB28_45
	movb	$3, %al
	cmpb	$3, 190(%rdi)
	jne	.LBB28_194
.LBB28_45:
	movw	%bp, 188(%rdi)
.LBB28_46:
	movzbl	190(%rdi), %ecx
.LBB28_47:
	movb	$-1, %al
	cmpb	$1, %cl
	je	.LBB28_83
	movzbl	%cl, %ecx
	cmpl	$2, %ecx
	je	.LBB28_64
	cmpl	$3, %ecx
	jne	.LBB28_194
	cmpq	$6, %r14
	je	.LBB28_144
	cmpq	$7, %r14
	je	.LBB28_121
	cmpq	$11, %r14
	jne	.LBB28_194
	cmpb	$99, (%rbx)
	jne	.LBB28_194
	cmpb	$112, 1(%rbx)
	jne	.LBB28_194
	cmpb	$117, 2(%rbx)
	jne	.LBB28_194
	cmpb	$95, 3(%rbx)
	jne	.LBB28_187
	cmpb	$115, 4(%rbx)
	jne	.LBB28_187
	cmpb	$117, 5(%rbx)
	jne	.LBB28_187
	cmpb	$115, 6(%rbx)
	jne	.LBB28_187
	cmpb	$112, 7(%rbx)
	jne	.LBB28_187
	cmpb	$101, 8(%rbx)
	jne	.LBB28_187
	cmpb	$110, 9(%rbx)
	jne	.LBB28_187
	movl	$-1006632959, %ecx
	cmpb	$100, 10(%rbx)
	jmp	.LBB28_173
.LBB28_64:
	cmpq	$3, %r14
	je	.LBB28_104
	cmpq	$13, %r14
	jne	.LBB28_194
	cmpb	$101, (%rbx)
	jne	.LBB28_194
	cmpb	$110, 1(%rbx)
	jne	.LBB28_194
	cmpb	$97, 2(%rbx)
	jne	.LBB28_194
	cmpb	$98, 3(%rbx)
	jne	.LBB28_194
	cmpb	$108, 4(%rbx)
	jne	.LBB28_187
	cmpb	$101, 5(%rbx)
	jne	.LBB28_187
	cmpb	$45, 6(%rbx)
	jne	.LBB28_187
	cmpb	$109, 7(%rbx)
	jne	.LBB28_187
	cmpb	$101, 8(%rbx)
	jne	.LBB28_187
	cmpb	$116, 9(%rbx)
	jne	.LBB28_187
	cmpb	$104, 10(%rbx)
	jne	.LBB28_187
	cmpb	$111, 11(%rbx)
	jne	.LBB28_187
	cmpb	$100, 12(%rbx)
	jne	.LBB28_187
	cmpq	$0, 8(%rsp)
	je	.LBB28_1
	xorl	%ecx, %ecx
	movq	(%rsp), %rax
.LBB28_81:
	cmpb	$0, (%rax,%rcx)
	je	.LBB28_188
	incq	%rcx
	cmpq	%rcx, 8(%rsp)
	jne	.LBB28_81
	jmp	.LBB28_1
.LBB28_83:
	cmpq	$11, %r14
	je	.LBB28_129
	cmpq	$13, %r14
	je	.LBB28_108
	cmpq	$14, %r14
	jne	.LBB28_194
	cmpb	$35, (%rbx)
	jne	.LBB28_194
	cmpb	$97, 1(%rbx)
	jne	.LBB28_194
	cmpb	$100, 2(%rbx)
	jne	.LBB28_194
	cmpb	$100, 3(%rbx)
	jne	.LBB28_187
	cmpb	$114, 4(%rbx)
	jne	.LBB28_187
	cmpb	$101, 5(%rbx)
	jne	.LBB28_187
	cmpb	$115, 6(%rbx)
	jne	.LBB28_187
	cmpb	$115, 7(%rbx)
	jne	.LBB28_187
	cmpb	$45, 8(%rbx)
	jne	.LBB28_187
	cmpb	$99, 9(%rbx)
	jne	.LBB28_187
	cmpb	$101, 10(%rbx)
	jne	.LBB28_187
	cmpb	$108, 11(%rbx)
	jne	.LBB28_187
	cmpb	$108, 12(%rbx)
	jne	.LBB28_187
	cmpb	$115, 13(%rbx)
	jne	.LBB28_187
	movb	$2, %al
	cmpq	$4, 8(%rsp)
	jne	.LBB28_194
	movq	(%rsp), %rax
	movl	(%rax), %ecx
	movl	8(%rbx), %eax
	movabsq	$8319104478668415267, %rdx
	xorq	(%rbx), %rdx
	movzwl	12(%rbx), %esi
	shlq	$32, %rsi
	orq	%rax, %rsi
	movabsq	$126909512246061, %rax
	xorq	%rsi, %rax
	orq	%rdx, %rax
	jne	.LBB28_142
	bswapl	%ecx
	leal	-1(%rcx), %edx
	movb	$3, %al
	cmpl	$1, %edx
	ja	.LBB28_194
	movl	$1, 16(%rdi)
	movl	%ecx, 20(%rdi)
	movb	$-1, %al
	jmp	.LBB28_194
.LBB28_104:
	cmpb	$114, (%rbx)
	jne	.LBB28_194
	cmpb	$101, 1(%rbx)
	jne	.LBB28_194
	cmpb	$103, 2(%rbx)
	jne	.LBB28_194
	movq	(%rsp), %rax
	movq	%rax, 168(%rdi)
	movq	8(%rsp), %rax
	movq	%rax, 176(%rdi)
	movb	$-1, %al
	jmp	.LBB28_194
.LBB28_108:
	cmpb	$101, (%rbx)
	jne	.LBB28_194
	cmpb	$110, 1(%rbx)
	jne	.LBB28_194
	cmpb	$97, 2(%rbx)
	jne	.LBB28_194
	cmpb	$98, 3(%rbx)
	jne	.LBB28_187
	cmpb	$108, 4(%rbx)
	jne	.LBB28_187
	cmpb	$101, 5(%rbx)
	jne	.LBB28_187
	cmpb	$45, 6(%rbx)
	jne	.LBB28_187
	cmpb	$109, 7(%rbx)
	jne	.LBB28_187
	cmpb	$101, 8(%rbx)
	jne	.LBB28_187
	cmpb	$116, 9(%rbx)
	jne	.LBB28_187
	cmpb	$104, 10(%rbx)
	jne	.LBB28_187
	cmpb	$111, 11(%rbx)
	movb	$-1, %al
	jne	.LBB28_194
	cmpb	$100, 12(%rbx)
	setne	%al
	jmp	.LBB28_176
.LBB28_121:
	movzbl	(%rbx), %ecx
	cmpl	$109, %ecx
	je	.LBB28_162
	cmpl	$99, %ecx
	jne	.LBB28_194
	cmpb	$112, 1(%rbx)
	jne	.LBB28_194
	cmpb	$117, 2(%rbx)
	jne	.LBB28_194
	cmpb	$95, 3(%rbx)
	jne	.LBB28_187
	cmpb	$111, 4(%rbx)
	jne	.LBB28_187
	cmpb	$102, 5(%rbx)
	jne	.LBB28_187
	movl	$-2080374782, %ecx
	cmpb	$102, 6(%rbx)
	jmp	.LBB28_173
.LBB28_129:
	cmpb	$35, (%rbx)
	jne	.LBB28_194
	cmpb	$115, 1(%rbx)
	jne	.LBB28_194
	cmpb	$105, 2(%rbx)
	jne	.LBB28_194
	cmpb	$122, 3(%rbx)
	jne	.LBB28_187
	cmpb	$101, 4(%rbx)
	jne	.LBB28_187
	cmpb	$45, 5(%rbx)
	jne	.LBB28_187
	cmpb	$99, 6(%rbx)
	jne	.LBB28_187
	cmpb	$101, 7(%rbx)
	jne	.LBB28_187
	cmpb	$108, 8(%rbx)
	jne	.LBB28_187
	cmpb	$108, 9(%rbx)
	jne	.LBB28_187
	cmpb	$115, 10(%rbx)
	jne	.LBB28_187
	movb	$2, %al
	cmpq	$4, 8(%rsp)
	jne	.LBB28_194
	movq	(%rsp), %rax
	movl	(%rax), %ecx
.LBB28_142:
	movb	$3, %al
	testl	%ecx, %ecx
	jne	.LBB28_194
	movq	$1, 24(%rdi)
	movb	$-1, %al
	jmp	.LBB28_194
.LBB28_144:
	movzbl	(%rbx), %ecx
	cmpl	$99, %ecx
	je	.LBB28_168
	cmpl	$109, %ecx
	jne	.LBB28_194
	cmpb	$101, 1(%rbx)
	jne	.LBB28_194
	cmpb	$116, 2(%rbx)
	jne	.LBB28_194
	cmpb	$104, 3(%rbx)
	jne	.LBB28_187
	cmpb	$111, 4(%rbx)
	jne	.LBB28_187
	cmpb	$100, 5(%rbx)
	jne	.LBB28_187
	cmpq	$0, 8(%rsp)
	je	.LBB28_1
	xorl	%ecx, %ecx
	movq	(%rsp), %rax
.LBB28_153:
	cmpb	$0, (%rax,%rcx)
	je	.LBB28_183
	incq	%rcx
	cmpq	%rcx, 8(%rsp)
	jne	.LBB28_153
	jmp	.LBB28_1
.LBB28_155:
	leaq	1(%rsi), %r8
	cmpq	%rax, %r8
	jne	.LBB28_1
	movb	$3, %al
	cmpq	$2, %rsi
	je	.LBB28_180
	cmpq	$4, %rsi
	jne	.LBB28_194
	cmpb	$111, (%rdx)
	jne	.LBB28_192
	movq	(%rsp), %rax
	cmpb	$107, 1(%rax)
	jne	.LBB28_192
	movq	(%rsp), %rax
	cmpb	$97, 2(%rax)
	jne	.LBB28_192
	movq	(%rsp), %rax
	cmpb	$121, 3(%rax)
	movb	$3, %al
	je	.LBB28_47
	jmp	.LBB28_194
.LBB28_193:
	movb	$4, %al
	jmp	.LBB28_194
.LBB28_162:
	cmpb	$105, 1(%rbx)
	jne	.LBB28_194
	cmpb	$103, 2(%rbx)
	jne	.LBB28_194
	cmpb	$114, 3(%rbx)
	jne	.LBB28_187
	cmpb	$97, 4(%rbx)
	jne	.LBB28_187
	cmpb	$116, 5(%rbx)
	jne	.LBB28_187
	movl	$-1006632955, %ecx
	cmpb	$101, 6(%rbx)
	jmp	.LBB28_173
.LBB28_168:
	cmpb	$112, 1(%rbx)
	jne	.LBB28_194
	cmpb	$117, 2(%rbx)
	jne	.LBB28_194
	cmpb	$95, 3(%rbx)
	jne	.LBB28_187
	cmpb	$111, 4(%rbx)
	jne	.LBB28_187
	movl	$-1006632957, %ecx
	cmpb	$110, 5(%rbx)
.LBB28_173:
	movb	$-1, %al
	jne	.LBB28_194
	movb	$2, %al
	cmpq	$4, 8(%rsp)
	jne	.LBB28_194
	movq	(%rsp), %rax
	movl	(%rax), %eax
	bswapl	%eax
	cmpl	%eax, %ecx
	sete	%al
.LBB28_176:
	negb	%al
	orb	$3, %al
	jmp	.LBB28_194
.LBB28_177:
	movb	$3, %al
	cmpb	$2, %cl
	je	.LBB28_194
	xorl	%eax, %eax
.LBB28_179:
	movb	%al, 185(%rdi)
	movq	(%rsp), %rdx
	movq	8(%rsp), %rax
	jmp	.LBB28_31
.LBB28_180:
	cmpb	$111, (%rdx)
	jne	.LBB28_194
	movq	(%rsp), %rdx
	cmpb	$107, 1(%rdx)
	je	.LBB28_47
	jmp	.LBB28_194
.LBB28_182:
	movl	$32, %edx
	xorl	%edi, %edi
	movq	%r15, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB28_183:
	leaq	1(%rcx), %rdx
	movb	$2, %al
	cmpq	8(%rsp), %rdx
	jne	.LBB28_194
	cmpq	$3, %rcx
	jne	.LBB28_192
	movq	(%rsp), %rax
	movzwl	(%rax), %ecx
	movzbl	2(%rax), %eax
	shll	$16, %eax
	orl	%ecx, %eax
	cmpl	$6518376, %eax
	movb	$3, %al
	jne	.LBB28_194
	movb	$1, 187(%rdi)
.LBB28_187:
	movb	$-1, %al
	jmp	.LBB28_194
.LBB28_188:
	leaq	1(%rcx), %rdx
	movb	$2, %al
	cmpq	8(%rsp), %rdx
	jne	.LBB28_194
	cmpq	$4, %rcx
	jne	.LBB28_192
	movq	(%rsp), %rax
	cmpl	$1768125296, (%rax)
	movb	$3, %al
	jne	.LBB28_194
	movb	$1, 186(%rdi)
	movb	$-1, %al
	jmp	.LBB28_194
.LBB28_192:
	movb	$3, %al
	jmp	.LBB28_194
.Lfunc_end28:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB5_4Node8property, .Lfunc_end28-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB5_4Node8property
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology10compatible,"ax",@progbits
	.prefalign	4, .Lfunc_end29, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology10compatible,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology10compatible:
.Lfunc_begin29:
	.cfi_startproc
	movw	$514, %ax
	testq	%rsi, %rsi
	je	.LBB29_2
	cmpb	$0, -1(%rdi,%rsi)
	je	.LBB29_3
.LBB29_2:
	retq
.LBB29_3:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %rbp, -16
	decq	%rsi
	xorl	%ecx, %ecx
	movabsq	$7594040322295689825, %rdx
	movl	$1, %r8d
	xorl	%r9d, %r9d
	jmp	.LBB29_6
	.p2align	4
.LBB29_4:
	movl	8(%rdi), %ebx
	movq	(%rdi), %rdi
	xorq	%rdx, %rdi
	movq	%rbx, %r14
	xorq	$841887789, %r14
	xorq	$808333613, %rbx
	xorl	%ebp, %ebp
	orq	%rdi, %rbx
	sete	%bpl
	orq	%rdi, %r14
	movl	%ebp, %edi
	cmovel	%r8d, %edi
	orb	%cl, %dil
	orb	%bpl, %r9b
	movl	%edi, %ecx
.LBB29_5:
	movq	%r11, %rdi
	testb	%r10b, %r10b
	jne	.LBB29_14
.LBB29_6:
	testq	%rsi, %rsi
	je	.LBB29_13
	xorl	%ebx, %ebx
	.p2align	4
.LBB29_8:
	movzbl	(%rdi,%rbx), %r10d
	testb	%r10b, %r10b
	je	.LBB29_11
	incq	%rbx
	cmpq	%rbx, %rsi
	jne	.LBB29_8
	movq	%rdi, %r11
	movq	%rsi, %rbx
	cmpq	$12, %rbx
	jne	.LBB29_12
	jmp	.LBB29_4
	.p2align	4
.LBB29_11:
	leaq	1(%rbx), %r11
	subq	%r11, %rsi
	leaq	(%rdi,%rbx), %r11
	incq	%r11
	cmpq	$12, %rbx
	je	.LBB29_4
.LBB29_12:
	testq	%rbx, %rbx
	jne	.LBB29_5
.LBB29_13:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %rbp
	retq
.LBB29_14:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %rbp, -16
	.cfi_offset %r14, -24
	movzbl	%r9b, %edx
	shll	$8, %edx
	movzbl	%cl, %eax
	orl	%edx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %rbp
	retq
.Lfunc_end29:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology10compatible, .Lfunc_end29-_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology10compatible
	.cfi_endproc

	.section	.text._RINvYINtNtNtCs1R9DcZHJAgT_4core5slice4iter5SplithNCNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_,"ax",@progbits
	.prefalign	4, .Lfunc_end30, nop
	.type	_RINvYINtNtNtCs1R9DcZHJAgT_4core5slice4iter5SplithNCNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_,@function
_RINvYINtNtNtCs1R9DcZHJAgT_4core5slice4iter5SplithNCNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_:
.Lfunc_begin30:
	.cfi_startproc
	testb	$1, 16(%rdi)
	jne	.LBB30_1
	movq	(%rdi), %r8
	movq	8(%rdi), %rdx
	movabsq	$7594040322295689825, %rcx
	movb	$1, %sil
.LBB30_4:
	testq	%rdx, %rdx
	je	.LBB30_13
	movq	%r8, %rax
	xorl	%r9d, %r9d
	.p2align	4
.LBB30_6:
	cmpb	$0, (%rax,%r9)
	je	.LBB30_10
	incq	%r9
	cmpq	%r9, %rdx
	jne	.LBB30_6
	jmp	.LBB30_8
	.p2align	4
.LBB30_10:
	leaq	1(%r9), %r8
	subq	%r8, %rdx
	leaq	(%rax,%r9), %r8
	incq	%r8
	movq	%r8, (%rdi)
	movq	%rdx, 8(%rdi)
	cmpq	$8, %r9
	jne	.LBB30_4
	cmpq	%rcx, (%rax)
	sete	%al
	je	.LBB30_2
	testb	%sil, %sil
	jne	.LBB30_4
	jmp	.LBB30_2
.LBB30_8:
	movb	$1, 16(%rdi)
	cmpq	$8, %rdx
	jne	.LBB30_1
	cmpq	%rcx, (%rax)
	sete	%al
	retq
.LBB30_13:
	movb	$1, 16(%rdi)
.LBB30_1:
	xorl	%eax, %eax
.LBB30_2:
	retq
.Lfunc_end30:
	.size	_RINvYINtNtNtCs1R9DcZHJAgT_4core5slice4iter5SplithNCNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_, .Lfunc_end30-_RINvYINtNtNtCs1R9DcZHJAgT_4core5slice4iter5SplithNCNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests10boundaries,"ax",@progbits
	.prefalign	4, .Lfunc_end31, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests10boundaries,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests10boundaries:
.Lfunc_begin31:
	.cfi_startproc
	subq	$872, %rsp
	.cfi_def_cfa_offset 880
	movq	$0, 40(%rsp)
	movq	$16777216, 48(%rsp)
	movq	$0, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	40(%rsp), %rcx
	movl	$16777216, %edx
	movl	$1, %r8d
	movl	$8, %r9d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 72(%rsp)
	je	.LBB31_1
	cmpq	$4096, 608(%rsp)
	jne	.LBB31_1
	movq	40(%rsp), %rax
	movq	48(%rsp), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rax, 72(%rsp)
	leaq	72(%rsp), %rdx
	movl	$16777216, %esi
	movl	$1, %ecx
	movl	$8, %r8d
	xorl	%edi, %edi
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB31_24
	movq	$9000, 8(%rsp)
	movq	$9000, 16(%rsp)
	movq	$0, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$4096, %edx
	movl	$1, %r8d
	movl	$8, %r9d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 72(%rsp)
	jne	.LBB31_1
	cmpb	$0, 73(%rsp)
	jne	.LBB31_1
	movq	$0, 24(%rsp)
	movq	$4096, 32(%rsp)
	movq	8(%rsp), %rax
	movq	16(%rsp), %rcx
	movq	%rcx, 624(%rsp)
	movq	%rax, 616(%rsp)
	movq	$1, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	24(%rsp), %rcx
	leaq	616(%rsp), %r9
	movl	$4096, %edx
	movl	$1, %r8d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 72(%rsp)
	jne	.LBB31_1
	cmpb	$0, 73(%rsp)
	jne	.LBB31_1
	movq	$-1, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$4096, %edx
	movl	$1, %r8d
	movl	$8, %r9d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 72(%rsp)
	jne	.LBB31_1
	cmpb	$0, 73(%rsp)
	jne	.LBB31_1
	movq	$0, 24(%rsp)
	movq	$4096, 32(%rsp)
	movq	8(%rsp), %rax
	movq	16(%rsp), %rcx
	movq	%rcx, 624(%rsp)
	movq	%rax, 616(%rsp)
	movq	$1, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	24(%rsp), %rcx
	leaq	616(%rsp), %r9
	movl	$4096, %edx
	movl	$1, %r8d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 72(%rsp)
	jne	.LBB31_1
	cmpb	$0, 73(%rsp)
	jne	.LBB31_1
	movq	$0, 616(%rsp)
	movq	$4096, 624(%rsp)
	movq	$4095, 632(%rsp)
	movq	$8192, 640(%rsp)
	movq	$0, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	616(%rsp), %rcx
	movl	$4096, %edx
	movl	$2, %r8d
	movl	$8, %r9d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 72(%rsp)
	jne	.LBB31_1
	cmpb	$3, 73(%rsp)
	movl	$0, %eax
	jne	.LBB31_24
	movq	$0, 616(%rsp)
	movq	$4096, 624(%rsp)
	movq	$4096, 632(%rsp)
	movq	$8192, 640(%rsp)
	movq	$8192, 648(%rsp)
	movq	$12288, 656(%rsp)
	movq	$12288, 664(%rsp)
	movq	$16384, 672(%rsp)
	movq	$16384, 680(%rsp)
	movq	$20480, 688(%rsp)
	movq	$20480, 696(%rsp)
	movq	$24576, 704(%rsp)
	movq	$24576, 712(%rsp)
	movq	$28672, 720(%rsp)
	movq	$28672, 728(%rsp)
	movq	$32768, 736(%rsp)
	movq	$32768, 744(%rsp)
	movq	$36864, 752(%rsp)
	movq	$36864, 760(%rsp)
	movq	$40960, 768(%rsp)
	movq	$40960, 776(%rsp)
	movq	$45056, 784(%rsp)
	movq	$45056, 792(%rsp)
	movq	$49152, 800(%rsp)
	movq	$49152, 808(%rsp)
	movq	$53248, 816(%rsp)
	movq	$53248, 824(%rsp)
	movq	$57344, 832(%rsp)
	movq	$57344, 840(%rsp)
	movq	$61440, 848(%rsp)
	movq	$61440, 856(%rsp)
	movq	$65536, 864(%rsp)
	movq	$268435456, 72(%rsp)
	movq	$268439552, 80(%rsp)
	movq	$268435456, 88(%rsp)
	movq	$268439552, 96(%rsp)
	movq	$268435456, 104(%rsp)
	movq	$268439552, 112(%rsp)
	movq	$268435456, 120(%rsp)
	movq	$268439552, 128(%rsp)
	movq	$268435456, 136(%rsp)
	movq	$268439552, 144(%rsp)
	movq	$268435456, 152(%rsp)
	movq	$268439552, 160(%rsp)
	movq	$268435456, 168(%rsp)
	movq	$268439552, 176(%rsp)
	movq	$268435456, 184(%rsp)
	movq	$268439552, 192(%rsp)
	movq	$268435456, 200(%rsp)
	movq	$268439552, 208(%rsp)
	movq	$268435456, 216(%rsp)
	movq	$268439552, 224(%rsp)
	movq	$268435456, 232(%rsp)
	movq	$268439552, 240(%rsp)
	movq	$268435456, 248(%rsp)
	movq	$268439552, 256(%rsp)
	movq	$268435456, 264(%rsp)
	movq	$268439552, 272(%rsp)
	movq	$268435456, 280(%rsp)
	movq	$268439552, 288(%rsp)
	movq	$268435456, 296(%rsp)
	movq	$268439552, 304(%rsp)
	movq	$268435456, 312(%rsp)
	movq	$268439552, 320(%rsp)
	movq	$268435456, 328(%rsp)
	movq	$268439552, 336(%rsp)
	movq	$268435456, 344(%rsp)
	movq	$268439552, 352(%rsp)
	movq	$268435456, 360(%rsp)
	movq	$268439552, 368(%rsp)
	movq	$268435456, 376(%rsp)
	movq	$268439552, 384(%rsp)
	movq	$268435456, 392(%rsp)
	movq	$268439552, 400(%rsp)
	movq	$268435456, 408(%rsp)
	movq	$268439552, 416(%rsp)
	movq	$268435456, 424(%rsp)
	movq	$268439552, 432(%rsp)
	movq	$268435456, 440(%rsp)
	movq	$268439552, 448(%rsp)
	movq	$268435456, 456(%rsp)
	movq	$268439552, 464(%rsp)
	movq	$268435456, 472(%rsp)
	movq	$268439552, 480(%rsp)
	movq	$268435456, 488(%rsp)
	movq	$268439552, 496(%rsp)
	movq	$268435456, 504(%rsp)
	movq	$268439552, 512(%rsp)
	movq	$268435456, 520(%rsp)
	movq	$268439552, 528(%rsp)
	movq	$268435456, 536(%rsp)
	movq	$268439552, 544(%rsp)
	movq	$268435456, 552(%rsp)
	movq	$268439552, 560(%rsp)
	movq	$268435456, 568(%rsp)
	movq	$268439552, 576(%rsp)
	movq	$268435456, 584(%rsp)
	movq	$268439552, 592(%rsp)
	movq	$268435456, 600(%rsp)
	movq	$268439552, 608(%rsp)
	leaq	616(%rsp), %rdx
	leaq	72(%rsp), %r8
	movl	$16777216, %esi
	movl	$16, %ecx
	movl	$34, %r9d
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	testb	%al, %al
	je	.LBB31_1
	movq	$-8192, 56(%rsp)
	movq	$-1, 64(%rsp)
	movq	$0, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	56(%rsp), %rcx
	movl	$1, %r8d
	movl	$8, %r9d
	movq	$-8192, %rsi
	movq	$-4096, %rdx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$0, 72(%rsp)
	jne	.LBB31_1
	cmpq	$1, 608(%rsp)
	jne	.LBB31_1
	movq	56(%rsp), %rax
	movq	64(%rsp), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rax, 72(%rsp)
	leaq	72(%rsp), %rdx
	movl	$1, %ecx
	movl	$8, %r8d
	movq	$-8192, %rdi
	movq	$-4096, %rsi
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB31_24
	movq	$-8192, 24(%rsp)
	movq	$-4096, 32(%rsp)
	movq	$-4097, 72(%rsp)
	movq	$-1, 80(%rsp)
	leaq	24(%rsp), %rdx
	leaq	72(%rsp), %r8
	movl	$1, %ecx
	movl	$1, %r9d
	movq	$-8192, %rdi
	movq	$-4096, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
.LBB31_24:
	addq	$872, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB31_1:
	.cfi_def_cfa_offset 880
	xorl	%eax, %eax
	addq	$872, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end31:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests10boundaries, .Lfunc_end31-_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests10boundaries
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle,"ax",@progbits
	.prefalign	4, .Lfunc_end32, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle:
.Lfunc_begin32:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1112, %rsp
	.cfi_def_cfa_offset 1168
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %rax
	movq	%rcx, %r13
	movq	%rdx, %rcx
	movq	%rsi, %rbx
	movq	%rdi, %r14
	movq	%r9, 16(%rsp)
	movq	%r9, (%rsp)
	leaq	56(%rsp), %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	movq	%rcx, 40(%rsp)
	movq	%r13, %r8
	movq	%rax, 48(%rsp)
	movq	%rax, %r9
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 56(%rsp)
	jne	.LBB32_1
.LBB32_16:
	xorl	%eax, %eax
	jmp	.LBB32_17
.LBB32_1:
	leaq	64(%rsp), %rsi
	movq	576(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	584(%rsp), %r12
	leaq	600(%rsp), %rdi
	movl	$512, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movq	592(%rsp), %rax
	movq	%rax, 24(%rsp)
	subq	%r14, %rbx
	shrq	$12, %rbx
	je	.LBB32_2
	shlq	$4, %r13
	shlq	$4, 16(%rsp)
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	jmp	.LBB32_5
	.p2align	4
.LBB32_15:
	testb	%r8b, %r8b
	jne	.LBB32_16
.LBB32_14:
	movzbl	%r8b, %eax
	addq	%rax, %rcx
	cmpq	%rbx, %rdx
	je	.LBB32_3
.LBB32_5:
	movq	%rdx, %rsi
	incq	%rdx
	movq	%rsi, %rdi
	shlq	$12, %rdi
	leaq	(%rdi,%r14), %r8
	addq	$4096, %r8
	addq	%r14, %rdi
	movq	%r13, %r11
	movq	40(%rsp), %r10
	.p2align	4
.LBB32_6:
	movq	%r11, %r9
	testq	%r11, %r11
	je	.LBB32_8
	movq	(%r10), %rax
	movq	8(%r10), %r11
	cmpq	%r8, %r11
	cmovaeq	%r8, %r11
	cmpq	%rdi, %rax
	cmovbeq	%rdi, %rax
	subq	%rax, %r11
	movl	$0, %eax
	cmovaeq	%r11, %rax
	addq	$16, %r10
	leaq	-16(%r9), %r11
	cmpq	$4096, %rax
	jne	.LBB32_6
.LBB32_8:
	movq	16(%rsp), %r10
	movq	48(%rsp), %r11
	.p2align	4
.LBB32_9:
	movq	%r10, %rax
	testq	%r10, %r10
	je	.LBB32_11
	movq	(%r11), %rbp
	movq	8(%r11), %r15
	cmpq	%r8, %r15
	cmovaeq	%r8, %r15
	cmpq	%rdi, %rbp
	cmovbeq	%rdi, %rbp
	addq	$16, %r11
	leaq	-16(%rax), %r10
	cmpq	%rbp, %r15
	jbe	.LBB32_9
.LBB32_11:
	testq	%rax, %rax
	sete	%al
	testq	%r9, %r9
	setne	%r8b
	andb	%al, %r8b
	cmpq	%r12, %rsi
	jae	.LBB32_15
	movq	%rsi, %rdi
	shrq	$6, %rdi
	cmpq	$4096, %rsi
	jae	.LBB32_18
	movq	600(%rsp,%rdi,8), %rax
	btq	%rsi, %rax
	movl	%r8d, %eax
	sbbb	$0, %al
	je	.LBB32_14
	jmp	.LBB32_16
.LBB32_2:
	xorl	%ecx, %ecx
.LBB32_3:
	movq	24(%rsp), %rdx
	xorq	%rcx, %rdx
	movq	32(%rsp), %rax
	xorq	%r14, %rax
	xorq	%rbx, %r12
	orq	%rax, %r12
	orq	%rdx, %r12
	sete	%al
.LBB32_17:
	addq	$1112, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB32_18:
	.cfi_def_cfa_offset 1168
	movl	$64, %esi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.Lfunc_end32:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle, .Lfunc_end32-_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests6ranges,"ax",@progbits
	.prefalign	4, .Lfunc_end33, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests6ranges,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests6ranges:
.Lfunc_begin33:
	.cfi_startproc
	subq	$776, %rsp
	.cfi_def_cfa_offset 784
	movq	$0, 24(%rsp)
	movq	$24576, 32(%rsp)
	movq	$28673, 40(%rsp)
	movq	$65537, 48(%rsp)
	movq	$8193, 152(%rsp)
	movq	$8194, 160(%rsp)
	movq	$16383, 168(%rsp)
	movq	$16385, 176(%rsp)
	movq	$16384, 184(%rsp)
	movq	$20480, 192(%rsp)
	movq	$131072, 200(%rsp)
	movq	$196608, 208(%rsp)
	movq	$65536, 216(%rsp)
	movq	$69632, 224(%rsp)
	movq	$5, (%rsp)
	leaq	232(%rsp), %rdi
	leaq	24(%rsp), %rcx
	leaq	152(%rsp), %r9
	movl	$4096, %esi
	movl	$69632, %edx
	movl	$2, %r8d
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 232(%rsp)
	je	.LBB33_19
	cmpq	$10, 768(%rsp)
	jne	.LBB33_19
	leaq	24(%rsp), %rdx
	leaq	152(%rsp), %r8
	movl	$4096, %edi
	movl	$69632, %esi
	movl	$2, %ecx
	movl	$5, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	testb	%al, %al
	je	.LBB33_19
	movq	$1073741824, 8(%rsp)
	movq	$1207959552, 16(%rsp)
	movq	$1073741824, 104(%rsp)
	movq	$1075838976, 112(%rsp)
	movq	$1075838976, 120(%rsp)
	movq	$1076035875, 128(%rsp)
	movq	$1083179009, 136(%rsp)
	movq	$1083179010, 144(%rsp)
	leaq	8(%rsp), %rdx
	leaq	104(%rsp), %r8
	movl	$1073741824, %edi
	movl	$1090519040, %esi
	movl	$1, %ecx
	movl	$3, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	testb	%al, %al
	je	.LBB33_19
	movq	$3, (%rsp)
	leaq	232(%rsp), %rdi
	leaq	8(%rsp), %rcx
	leaq	104(%rsp), %r9
	movl	$1073741824, %esi
	movl	$1090519040, %edx
	movl	$1, %r8d
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$0, 232(%rsp)
	je	.LBB33_6
.LBB33_19:
	xorl	%eax, %eax
	addq	$776, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB33_6:
	.cfi_def_cfa_offset 784
	movq	760(%rsp), %rax
	cmpq	$561, %rax
	jb	.LBB33_19
	cmpq	$3534, 768(%rsp)
	jne	.LBB33_19
	movq	304(%rsp), %rcx
	movq	%rcx, %rdx
	shrq	$48, %rdx
	andl	$1, %edx
	cmpq	$562, %rax
	setb	%al
	orb	%dl, %al
	btq	$49, %rcx
	setae	%cl
	orb	%al, %cl
	jne	.LBB33_19
	movq	$0, 56(%rsp)
	movq	$2048, 64(%rsp)
	movq	$2048, 72(%rsp)
	movq	$8192, 80(%rsp)
	movq	$0, (%rsp)
	leaq	232(%rsp), %rdi
	leaq	56(%rsp), %rcx
	movl	$8192, %edx
	movl	$2, %r8d
	movl	$8, %r9d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 232(%rsp)
	je	.LBB33_19
	movq	760(%rsp), %rcx
	xorl	%eax, %eax
	testq	%rcx, %rcx
	je	.LBB33_18
	cmpq	$1, 768(%rsp)
	jne	.LBB33_18
	xorl	%eax, %eax
	cmpq	$2, %rcx
	jb	.LBB33_18
	movq	240(%rsp), %rcx
	andl	$3, %ecx
	cmpl	$2, %ecx
	jne	.LBB33_18
	leaq	56(%rsp), %rdx
	movl	$8192, %esi
	movl	$2, %ecx
	movl	$8, %r8d
	xorl	%edi, %edi
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB33_18
	movq	$0, 232(%rsp)
	movq	$4096, 240(%rsp)
	movq	$4096, 248(%rsp)
	movq	$8192, 256(%rsp)
	leaq	232(%rsp), %rdx
	movl	$8192, %esi
	movl	$2, %ecx
	movl	$8, %r8d
	xorl	%edi, %edi
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB33_18
	movl	$8192, %esi
	movl	$8, %edx
	movl	$8, %r8d
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB33_18
	movq	$0, 88(%rsp)
	movq	$8192, 96(%rsp)
	movq	$8192, 240(%rsp)
	movq	$0, 232(%rsp)
	leaq	88(%rsp), %rdx
	leaq	232(%rsp), %r8
	movl	$8192, %esi
	movl	$1, %ecx
	movl	$1, %r9d
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
.LBB33_18:
	addq	$776, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end33:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests6ranges, .Lfunc_end33-_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests6ranges
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5valid,"ax",@progbits
	.prefalign	4, .Lfunc_end34, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5valid,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5valid:
.Lfunc_begin34:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$1640, %rsp
	.cfi_def_cfa_offset 9872
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17capacity_boundary
	testb	%al, %al
	je	.LBB34_56
	movabsq	$9007199254740992, %r15
	leaq	808(%rsp), %rbx
	movl	$4096, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$608, 4904(%rsp)
	movq	$0, 4912(%rsp)
	movb	$1, 4920(%rsp)
	movabsq	$4503874505277440, %rax
	movq	%rax, 848(%rsp)
	movq	%r15, 856(%rsp)
	movl	$1, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, 4928(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, 4928(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$5, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.49, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	leaq	17(%rax), %rdi
	addq	$20, %rax
	cmpq	%rdi, %rax
	jb	.LBB34_59
	cmpq	$4097, %rax
	jae	.LBB34_59
	movb	$9, 810(%rsp,%rdi)
	movw	$1023, 808(%rsp,%rdi)
	movq	4904(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB34_6
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB34_58
	movl	$67108864, 808(%rsp,%rax)
	movq	%rcx, 4904(%rsp)
	jmp	.LBB34_7
.LBB34_6:
	movb	$0, 4920(%rsp)
.LBB34_7:
	movabsq	$4503599627370496, %r12
	leaq	808(%rsp), %rbx
	movl	$3, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.71, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$10, %edx
	movl	$9, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.33, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.89, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$8, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.90, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movq	$0, 4928(%rsp)
	movq	%r12, 4936(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %rcx
	movq	%rcx, %rdx
	addq	$4, %rdx
	movq	$-1, %rax
	cmovaeq	%rdx, %rax
	cmpq	$4096, %rax
	ja	.LBB34_11
	movq	%rax, %rdi
	subq	%rcx, %rdi
	cmpq	$4, %rdi
	jne	.LBB34_58
	movl	$33554432, 808(%rsp,%rcx)
	movq	%rax, 4904(%rsp)
	cmpq	$4093, %rax
	jae	.LBB34_11
	movl	$33554432, 808(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4904(%rsp)
	jmp	.LBB34_12
.LBB34_11:
	movb	$0, 4920(%rsp)
.LBB34_12:
	leaq	808(%rsp), %rbx
	movl	$15, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.18, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.20, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$274877906944, %rax
	movq	%rax, 4928(%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 4936(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB34_15
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB34_58
	movl	$33554432, 808(%rsp,%rax)
	movq	%rcx, 4904(%rsp)
	jmp	.LBB34_16
.LBB34_15:
	movb	$0, 4920(%rsp)
.LBB34_16:
	movl	$2415919104, %r14d
	leaq	808(%rsp), %rbx
	movl	$15, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.91, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.20, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$3, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.50, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$343597383680, %rax
	movq	%rax, 4928(%rsp)
	leaq	1879048192(%r14), %rax
	movq	%rax, 4936(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB34_19
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB34_58
	movl	$33554432, 808(%rsp,%rax)
	movq	%rcx, 4904(%rsp)
	jmp	.LBB34_20
.LBB34_19:
	movb	$0, 4920(%rsp)
.LBB34_20:
	leaq	808(%rsp), %rbx
	movl	$15, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.61, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, 4928(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, 4928(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$1, %ecx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.78, %rsi
	xorl	%r8d, %r8d
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$15, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.92, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movabsq	$9007474132647936, %rax
	movq	%rax, 4928(%rsp)
	movq	%r15, 4936(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB34_23
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB34_58
	movl	$33554432, 808(%rsp,%rax)
	movq	%rcx, 4904(%rsp)
	jmp	.LBB34_24
.LBB34_23:
	movb	$0, 4920(%rsp)
.LBB34_24:
	leaq	808(%rsp), %rbx
	movl	$16, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.93, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movabsq	$618475290624, %rax
	movq	%rax, 4928(%rsp)
	movq	%r12, 4936(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %r15
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB34_30
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB34_58
	movl	$33554432, 808(%rsp,%r15)
	movq	%rax, 4904(%rsp)
	cmpq	$4092, %rax
	ja	.LBB34_31
	leaq	4(%rax), %r15
	movl	$33554432, 808(%rsp,%rax)
	movq	%r15, 4904(%rsp)
	cmpq	$4088, %rax
	ja	.LBB34_32
	leaq	8(%rax), %r15
	movl	$33554432, 812(%rsp,%rax)
	movq	%r15, 4904(%rsp)
	cmpq	$4085, %rax
	jae	.LBB34_32
	movl	$150994944, 816(%rsp,%rax)
	addq	$12, %rax
	movq	%rax, 4904(%rsp)
	movq	%rax, %r15
	jmp	.LBB34_33
.LBB34_30:
	movb	$0, 4920(%rsp)
	jmp	.LBB34_32
.LBB34_31:
	movq	%rax, %r15
.LBB34_32:
	movb	$0, 4920(%rsp)
.LBB34_33:
	movq	%r15, %rax
	addq	$112, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB34_36
	movq	%rbx, %rdi
	subq	%r15, %rdi
	cmpq	$112, %rdi
	jne	.LBB34_61
	leaq	(%rsp,%r15), %rdi
	addq	$808, %rdi
	movl	$112, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.17, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4904(%rsp)
	jmp	.LBB34_37
.LBB34_36:
	movb	$0, 4920(%rsp)
	movq	%r15, %rbx
.LBB34_37:
	movq	%rbx, 4912(%rsp)
	movl	$-302117424, 808(%rsp)
	movl	%ebx, %eax
	bswapl	%eax
	movl	%eax, 812(%rsp)
	movl	$1610743808, 816(%rsp)
	movl	%r15d, %eax
	bswapl	%eax
	movl	%eax, 820(%rsp)
	movabsq	$1224979099315863552, %rax
	movq	%rax, 824(%rsp)
	movl	$268435456, 832(%rsp)
	movl	$1879048192, 840(%rsp)
	addl	$-608, %r15d
	bswapl	%r15d
	movl	%r15d, 844(%rsp)
	leaq	4928(%rsp), %rdi
	leaq	808(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcpy@GOTPCREL(%rip)
	cmpq	$4097, %rbx
	jae	.LBB34_60
	leaq	9024(%rsp), %rdi
	leaq	808(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	cmpb	$1, 9024(%rsp)
	je	.LBB34_56
	leaq	9032(%rsp), %rsi
	leaq	8(%rsp), %rdi
	movl	$800, %edx
	callq	*memcpy@GOTPCREL(%rip)
	cmpb	$1, 4920(%rsp)
	jne	.LBB34_56
	leaq	808(%rsp), %rdi
	leaq	4928(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	jne	.LBB34_56
	leaq	8(%rsp), %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map
	testb	%al, %al
	je	.LBB34_56
	movq	800(%rsp), %rax
	cmpq	4912(%rsp), %rax
	jne	.LBB34_56
	movq	776(%rsp), %rsi
	cmpq	$17, %rsi
	jae	.LBB34_62
	xorl	%eax, %eax
	cmpq	$2, %rsi
	jne	.LBB34_57
	cmpq	$1073741824, 520(%rsp)
	jne	.LBB34_57
	cmpq	$1207959552, 528(%rsp)
	jne	.LBB34_57
	xorl	%eax, %eax
	cmpq	$1342177280, 536(%rsp)
	jne	.LBB34_57
	cmpq	$1358954496, 544(%rsp)
	jne	.LBB34_57
	movq	784(%rsp), %rsi
	cmpq	$33, %rsi
	jae	.LBB34_63
	xorl	%eax, %eax
	cmpq	$3, %rsi
	jne	.LBB34_57
	cmpq	$1073745920, 8(%rsp)
	jne	.LBB34_57
	cmpq	$1073754112, 16(%rsp)
	jne	.LBB34_57
	xorl	%eax, %eax
	cmpq	$1073750016, 24(%rsp)
	jne	.LBB34_57
	cmpq	$1073758208, 32(%rsp)
	jne	.LBB34_57
	movq	40(%rsp), %rax
	xorq	%r14, %rax
	addq	$4096, %r14
	xorq	48(%rsp), %r14
	orq	%rax, %r14
	sete	%al
	jmp	.LBB34_57
.LBB34_56:
	xorl	%eax, %eax
.LBB34_57:
	addq	$9832, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB34_58:
	.cfi_def_cfa_offset 9872
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB34_59:
	movl	$4096, %edx
	movq	%rax, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB34_60:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB34_61:
	movl	$112, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB34_62:
	movl	$16, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB34_63:
	movl	$32, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end34:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5valid, .Lfunc_end34-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5valid
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17capacity_boundary,"ax",@progbits
	.prefalign	4, .Lfunc_end35, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17capacity_boundary,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17capacity_boundary:
.Lfunc_begin35:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$1896, %rsp
	.cfi_def_cfa_offset 6016
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	leaq	264(%rsp), %rbx
	movl	$4096, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$608, 4360(%rsp)
	movq	$0, 4368(%rsp)
	movb	$1, 4376(%rsp)
	movabsq	$618475290624, %rax
	movq	%rax, 304(%rsp)
	movabsq	$4503599627370496, %r14
	movq	%r14, 312(%rsp)
	movabsq	$4504218102661120, %rax
	movq	%rax, 320(%rsp)
	movq	%r14, 328(%rsp)
	movabsq	$9007817730031616, %rax
	movq	%rax, 336(%rsp)
	movq	%r14, 344(%rsp)
	movabsq	$13511417357402112, %rax
	movq	%rax, 352(%rsp)
	movq	%r14, 360(%rsp)
	movabsq	$18015016984772608, %rax
	movq	%rax, 368(%rsp)
	movq	%r14, 376(%rsp)
	movabsq	$22518616612143104, %rax
	movq	%rax, 384(%rsp)
	movq	%r14, 392(%rsp)
	movabsq	$27022216239513600, %rax
	movq	%rax, 400(%rsp)
	movq	%r14, 408(%rsp)
	movabsq	$31525815866884096, %rax
	movq	%rax, 416(%rsp)
	movq	%r14, 424(%rsp)
	movabsq	$36029415494254592, %rax
	movq	%rax, 432(%rsp)
	movq	%r14, 440(%rsp)
	movabsq	$40533015121625088, %rax
	movq	%rax, 448(%rsp)
	movq	%r14, 456(%rsp)
	movabsq	$45036614748995584, %rax
	movq	%rax, 464(%rsp)
	movq	%r14, 472(%rsp)
	movabsq	$49540214376366080, %rax
	movq	%rax, 480(%rsp)
	movq	%r14, 488(%rsp)
	movabsq	$54043814003736576, %rax
	movq	%rax, 496(%rsp)
	movq	%r14, 504(%rsp)
	movabsq	$58547413631107072, %rax
	movq	%rax, 512(%rsp)
	movq	%r14, 520(%rsp)
	movabsq	$63051013258477568, %rax
	movq	%rax, 528(%rsp)
	movq	%r14, 536(%rsp)
	movabsq	$67554612885848064, %rax
	movq	%rax, 544(%rsp)
	movq	%r14, 552(%rsp)
	movabsq	$1717986918400, %rax
	movq	%rax, 560(%rsp)
	movq	%r14, 568(%rsp)
	movabsq	$4505317614288896, %rax
	movq	%rax, 576(%rsp)
	movq	%r14, 584(%rsp)
	movabsq	$9008917241659392, %rax
	movq	%rax, 592(%rsp)
	movq	%r14, 600(%rsp)
	movabsq	$13512516869029888, %rax
	movq	%rax, 608(%rsp)
	movq	%r14, 616(%rsp)
	movabsq	$18016116496400384, %rax
	movq	%rax, 624(%rsp)
	movq	%r14, 632(%rsp)
	movabsq	$22519716123770880, %rax
	movq	%rax, 640(%rsp)
	movq	%r14, 648(%rsp)
	movabsq	$27023315751141376, %rax
	movq	%rax, 656(%rsp)
	movq	%r14, 664(%rsp)
	movabsq	$31526915378511872, %rax
	movq	%rax, 672(%rsp)
	movq	%r14, 680(%rsp)
	movabsq	$36030515005882368, %rax
	movq	%rax, 688(%rsp)
	movq	%r14, 696(%rsp)
	movabsq	$40534114633252864, %rax
	movq	%rax, 704(%rsp)
	movq	%r14, 712(%rsp)
	movabsq	$45037714260623360, %rax
	movq	%rax, 720(%rsp)
	movq	%r14, 728(%rsp)
	movabsq	$49541313887993856, %rax
	movq	%rax, 736(%rsp)
	movq	%r14, 744(%rsp)
	movabsq	$54044913515364352, %rax
	movq	%rax, 752(%rsp)
	movq	%r14, 760(%rsp)
	movabsq	$58548513142734848, %rax
	movq	%rax, 768(%rsp)
	movq	%r14, 776(%rsp)
	movabsq	$63052112770105344, %rax
	movq	%rax, 784(%rsp)
	movq	%r14, 792(%rsp)
	movabsq	$67555712397475840, %rax
	movq	%rax, 800(%rsp)
	movq	%r14, 808(%rsp)
	movl	$1, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, 4384(%rsp)
	leaq	4384(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, 4384(%rsp)
	leaq	4384(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$15, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.18, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.20, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movq	%r14, 16(%rsp)
	movabsq	$4503874505277440, %rax
	movq	%rax, 24(%rsp)
	movq	%r14, 32(%rsp)
	movabsq	$9007474132647936, %rax
	movq	%rax, 40(%rsp)
	movq	%r14, 48(%rsp)
	movabsq	$13511073760018432, %rax
	movq	%rax, 56(%rsp)
	movq	%r14, 64(%rsp)
	movabsq	$18014673387388928, %rax
	movq	%rax, 72(%rsp)
	movq	%r14, 80(%rsp)
	movabsq	$22518273014759424, %rax
	movq	%rax, 88(%rsp)
	movq	%r14, 96(%rsp)
	movabsq	$27021872642129920, %rax
	movq	%rax, 104(%rsp)
	movq	%r14, 112(%rsp)
	movabsq	$31525472269500416, %rax
	movq	%rax, 120(%rsp)
	movq	%r14, 128(%rsp)
	movabsq	$36029071896870912, %rax
	movq	%rax, 136(%rsp)
	movq	%r14, 144(%rsp)
	movabsq	$40532671524241408, %rax
	movq	%rax, 152(%rsp)
	movq	%r14, 160(%rsp)
	movabsq	$45036271151611904, %rax
	movq	%rax, 168(%rsp)
	movq	%r14, 176(%rsp)
	movabsq	$49539870778982400, %rax
	movq	%rax, 184(%rsp)
	movq	%r14, 192(%rsp)
	movabsq	$54043470406352896, %rax
	movq	%rax, 200(%rsp)
	movq	%r14, 208(%rsp)
	movabsq	$58547070033723392, %rax
	movq	%rax, 216(%rsp)
	movq	%r14, 224(%rsp)
	movabsq	$63050669661093888, %rax
	movq	%rax, 232(%rsp)
	movq	%r14, 240(%rsp)
	movabsq	$67554269288464384, %rax
	movq	%rax, 248(%rsp)
	movq	%r14, 256(%rsp)
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$256, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4360(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB35_7
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB35_28
	movl	$33554432, 264(%rsp,%r14)
	movq	%rax, 4360(%rsp)
	cmpq	$4092, %rax
	ja	.LBB35_6
	leaq	4(%rax), %r14
	movl	$33554432, 264(%rsp,%rax)
	movq	%r14, 4360(%rsp)
	cmpq	$4089, %rax
	jae	.LBB35_7
	movl	$150994944, 268(%rsp,%rax)
	addq	$8, %rax
	movq	%rax, 4360(%rsp)
	movq	%rax, %r14
	jmp	.LBB35_8
.LBB35_6:
	movq	%rax, %r14
.LBB35_7:
	movb	$0, 4376(%rsp)
.LBB35_8:
	movq	%r14, %rax
	addq	$112, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB35_11
	movq	%rbx, %rdi
	subq	%r14, %rdi
	cmpq	$112, %rdi
	jne	.LBB35_29
	leaq	(%rsp,%r14), %rdi
	addq	$264, %rdi
	movl	$112, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.17, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4360(%rsp)
	jmp	.LBB35_12
.LBB35_11:
	movb	$0, 4376(%rsp)
	movq	%r14, %rbx
.LBB35_12:
	movq	%rbx, 4368(%rsp)
	movl	$-302117424, 264(%rsp)
	movl	%ebx, %eax
	bswapl	%eax
	movl	%eax, 268(%rsp)
	movl	$1610743808, 272(%rsp)
	movl	%r14d, %eax
	bswapl	%eax
	movl	%eax, 276(%rsp)
	movabsq	$1224979099315863552, %rax
	movq	%rax, 280(%rsp)
	movl	$268435456, 288(%rsp)
	movl	$1879048192, 296(%rsp)
	addl	$-608, %r14d
	bswapl	%r14d
	movl	%r14d, 300(%rsp)
	cmpq	$4097, %rbx
	jae	.LBB35_27
	leaq	4384(%rsp), %rdi
	leaq	264(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	cmpb	$1, 4384(%rsp)
	je	.LBB35_14
	leaq	4392(%rsp), %rsi
	leaq	5192(%rsp), %rdi
	movl	$800, %edx
	callq	*memcpy@GOTPCREL(%rip)
	cmpb	$1, 4376(%rsp)
	jne	.LBB35_14
	leaq	5192(%rsp), %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map
	testb	%al, %al
	je	.LBB35_14
	movq	5960(%rsp), %rsi
	cmpq	$17, %rsi
	jae	.LBB35_30
	cmpq	$16, %rsi
	jne	.LBB35_14
	movq	5968(%rsp), %rsi
	cmpq	$33, %rsi
	jae	.LBB35_31
	cmpq	$32, %rsi
	jne	.LBB35_14
	cmpq	$65536, 5976(%rsp)
	sete	%al
	addq	$5992, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB35_14:
	.cfi_def_cfa_offset 6016
	xorl	%eax, %eax
	addq	$5992, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB35_27:
	.cfi_def_cfa_offset 6016
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB35_28:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB35_29:
	movl	$112, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB35_30:
	movl	$16, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB35_31:
	movl	$32, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end35:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17capacity_boundary, .Lfunc_end35-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17capacity_boundary
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin,"ax",@progbits
	.prefalign	4, .Lfunc_end36, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin:
.Lfunc_begin36:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rdi, %rbx
	movq	4096(%rdi), %rdi
	movq	%rdi, %rax
	addq	$4, %rax
	movq	$-1, %rcx
	cmovaeq	%rax, %rcx
	cmpq	$4097, %rcx
	jae	.LBB36_3
	movq	%rcx, %rax
	subq	%rdi, %rax
	cmpq	$4, %rax
	jne	.LBB36_21
	movl	$16777216, (%rbx,%rdi)
	movq	%rcx, 4096(%rbx)
	movq	%rcx, %rdi
	jmp	.LBB36_4
.LBB36_3:
	movb	$0, 4112(%rbx)
.LBB36_4:
	movq	%rdi, %rax
	addq	%rdx, %rax
	movq	$-1, %r14
	cmovaeq	%rax, %r14
	cmpq	$4097, %r14
	jae	.LBB36_7
	movq	%r14, %rax
	subq	%rdi, %rax
	cmpq	%rdx, %rax
	jne	.LBB36_22
	addq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r14, 4096(%rbx)
	movq	%r14, %rdi
	jmp	.LBB36_8
.LBB36_7:
	movb	$0, 4112(%rbx)
.LBB36_8:
	movq	%rdi, %rax
	incq	%rax
	movq	$-1, %rcx
	cmovneq	%rax, %rcx
	cmpq	$4097, %rcx
	jae	.LBB36_19
	movq	%rcx, %rax
	subq	%rdi, %rax
	cmpq	$1, %rax
	jne	.LBB36_23
	movb	$0, (%rbx,%rdi)
	movq	%rcx, 4096(%rbx)
	testb	$3, %cl
	je	.LBB36_17
	cmpb	$0, 4112(%rbx)
	je	.LBB36_17
	movq	$-1, %rax
	movq	%rcx, %rdx
	.p2align	4
.LBB36_13:
	incq	%rdx
	cmoveq	%rax, %rdx
	cmpq	$4097, %rdx
	jae	.LBB36_19
	movq	%rdx, %rdi
	subq	%rcx, %rdi
	cmpq	$1, %rdi
	jne	.LBB36_20
	movb	$0, (%rbx,%rcx)
	movq	%rdx, 4096(%rbx)
	testb	$3, %dl
	je	.LBB36_17
	cmpb	$0, 4112(%rbx)
	movq	%rdx, %rcx
	jne	.LBB36_13
.LBB36_17:
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB36_19:
	.cfi_def_cfa_offset 32
	movb	$0, 4112(%rbx)
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB36_20:
	.cfi_def_cfa_offset 32
	movl	$1, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB36_21:
	movl	$4, %esi
	movq	%rax, %rdi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB36_22:
	movq	%rax, %rdi
	movq	%rdx, %rsi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB36_23:
	movl	$1, %esi
	movq	%rax, %rdi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end36:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin, .Lfunc_end36-_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property,"ax",@progbits
	.prefalign	4, .Lfunc_end37, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property:
.Lfunc_begin37:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %r14
	movq	%rcx, (%rsp)
	movq	%rdx, %r12
	movq	%rsi, %r13
	movq	%rdi, %rbx
	xorl	%ebp, %ebp
	movq	memcmp@GOTPCREL(%rip), %r15
	jmp	.LBB37_2
	.p2align	4
.LBB37_1:
	leaq	(%r12,%rbp), %rax
	incq	%rax
	incq	%rbp
	cmpq	$112, %rax
	je	.LBB37_9
.LBB37_2:
	leaq	.Lanon.a24a8216ad3259fdc76a412b00af4a98.17(%rbp), %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	*%r15
	testl	%eax, %eax
	jne	.LBB37_1
	cmpb	$0, .Lanon.a24a8216ad3259fdc76a412b00af4a98.17(%r12,%rbp)
	jne	.LBB37_1
	movq	4096(%rbx), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	movq	%rax, %rdi
	cmpq	$4096, %rcx
	ja	.LBB37_13
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB37_27
	movl	$50331648, (%rbx,%rax)
	movq	%rcx, 4096(%rbx)
	cmpq	$4092, %rcx
	ja	.LBB37_12
	leaq	4(%rcx), %rdi
	movl	%r14d, %edx
	bswapl	%edx
	movl	%edx, (%rbx,%rcx)
	movq	%rdi, 4096(%rbx)
	cmpq	$4089, %rcx
	jae	.LBB37_13
	bswapl	%ebp
	movl	%ebp, 4(%rbx,%rcx)
	addq	$8, %rcx
	movq	%rcx, 4096(%rbx)
	movq	%rcx, %rdi
	jmp	.LBB37_14
.LBB37_9:
	movb	$0, 4112(%rbx)
	xorl	%eax, %eax
.LBB37_10:
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB37_12:
	.cfi_def_cfa_offset 64
	movq	%rcx, %rdi
.LBB37_13:
	movb	$0, 4112(%rbx)
.LBB37_14:
	movq	%rdi, %rcx
	addq	%r14, %rcx
	movq	$-1, %r12
	cmovaeq	%rcx, %r12
	cmpq	$4097, %r12
	jae	.LBB37_24
	movq	%rax, %r15
	movq	%r12, %rax
	subq	%rdi, %rax
	cmpq	%r14, %rax
	jne	.LBB37_28
	addq	%rbx, %rdi
	movq	(%rsp), %rsi
	movq	%r14, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r12, 4096(%rbx)
	testb	$3, %r12b
	je	.LBB37_25
	cmpb	$0, 4112(%rbx)
	movq	%r15, %rax
	je	.LBB37_10
	movq	$-1, %rcx
	movq	%r12, %rdx
	.p2align	4
.LBB37_19:
	incq	%rdx
	cmoveq	%rcx, %rdx
	cmpq	$4097, %rdx
	jae	.LBB37_24
	movq	%rdx, %rdi
	subq	%r12, %rdi
	cmpq	$1, %rdi
	jne	.LBB37_26
	movb	$0, (%rbx,%r12)
	movq	%rdx, 4096(%rbx)
	testb	$3, %dl
	je	.LBB37_10
	cmpb	$0, 4112(%rbx)
	movq	%rdx, %r12
	jne	.LBB37_19
	jmp	.LBB37_10
.LBB37_24:
	movb	$0, 4112(%rbx)
	jmp	.LBB37_10
.LBB37_25:
	movq	%r15, %rax
	jmp	.LBB37_10
.LBB37_26:
	movl	$1, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB37_27:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB37_28:
	movq	%rax, %rdi
	movq	%r14, %rsi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end37:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property, .Lfunc_end37-_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map,"ax",@progbits
	.prefalign	4, .Lfunc_end38, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map:
.Lfunc_begin38:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	768(%rdi), %rax
	cmpq	$17, %rax
	jae	.LBB38_19
	testq	%rax, %rax
	je	.LBB38_12
	leaq	512(%rdi), %rdx
	movq	%rax, %rcx
	shlq	$4, %rcx
	leaq	(%rdi,%rcx), %rsi
	addq	$512, %rsi
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	xorl	%ecx, %ecx
	jmp	.LBB38_5
	.p2align	4
.LBB38_4:
	addq	$16, %rdx
	incq	%r9
	addq	$16, %r8
	cmpq	%rsi, %rdx
	je	.LBB38_14
.LBB38_5:
	movq	(%rdx), %r10
	movq	8(%rdx), %r11
	movq	%r11, %rbx
	subq	%r10, %rbx
	jbe	.LBB38_12
	addq	%rbx, %rcx
	jb	.LBB38_12
	cmpq	%rax, %r9
	ja	.LBB38_20
	testq	%r9, %r9
	je	.LBB38_4
	xorl	%ebx, %ebx
	jmp	.LBB38_10
	.p2align	4
.LBB38_3:
	addq	$16, %rbx
	cmpq	%rbx, %r8
	je	.LBB38_4
.LBB38_10:
	cmpq	520(%rdi,%rbx), %r10
	jae	.LBB38_3
	cmpq	%r11, 512(%rdi,%rbx)
	jae	.LBB38_3
.LBB38_12:
	xorl	%eax, %eax
.LBB38_13:
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB38_14:
	.cfi_def_cfa_offset 16
	movq	776(%rdi), %rsi
	cmpq	$33, %rsi
	jae	.LBB38_21
	shlq	$4, %rsi
	movq	%rdi, %rdx
	.p2align	4
.LBB38_16:
	testq	%rsi, %rsi
	je	.LBB38_18
	movq	(%rdx), %r8
	addq	$-16, %rsi
	xorl	%eax, %eax
	cmpq	8(%rdx), %r8
	leaq	16(%rdx), %rdx
	jb	.LBB38_16
	jmp	.LBB38_13
.LBB38_18:
	cmpq	%rcx, 784(%rdi)
	sete	%al
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB38_20:
	.cfi_def_cfa_offset 16
	leaq	1(%rax), %rsi
	xorl	%edi, %edi
	movq	%rax, %rdx
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB38_19:
	movl	$16, %edx
	xorl	%edi, %edi
	movq	%rax, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB38_21:
	movl	$32, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end38:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map, .Lfunc_end38-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9malformed,"ax",@progbits
	.prefalign	4, .Lfunc_end39, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9malformed,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9malformed:
.Lfunc_begin39:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests25truncations_and_mutations
	testb	%al, %al
	je	.LBB39_60
	xorl	%edi, %edi
	xorl	%esi, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$4, %edi
	movl	$39, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$4, %edi
	movl	$2097153, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$8, %edi
	movl	$609, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$8, %edi
	movl	$-1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$12, %edi
	movl	$608, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$16, %edi
	movl	$41, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$16, %edi
	movl	$608, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$20, %edi
	movl	$16, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$20, %edi
	movl	$18, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$24, %edi
	movl	$17, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$32, %edi
	movl	$-1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$36, %edi
	movl	$-1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$608, %edi
	movl	$2, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	movl	$628, %edi
	movl	$1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB39_60
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB39_60
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB39_60
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB39_60
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB39_60
	movl	$4, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB39_60
	movl	$5, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB39_60
	movl	$6, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB39_60
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$4, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$5, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$6, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$7, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$8, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$9, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$10, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$11, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$12, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$13, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$14, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$15, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$16, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$17, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$18, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	movl	$19, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB39_60
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$4, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$5, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$6, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$7, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$8, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$9, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$10, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$11, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$12, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB39_60
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation
	testb	%al, %al
	je	.LBB39_60
	movl	$4, %edi
	popq	%rax
	.cfi_def_cfa_offset 8
	jmp	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation
.LBB39_60:
	.cfi_def_cfa_offset 16
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end39:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9malformed, .Lfunc_end39-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9malformed
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests25truncations_and_mutations,"ax",@progbits
	.prefalign	4, .Lfunc_end40, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests25truncations_and_mutations,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests25truncations_and_mutations:
.Lfunc_begin40:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$1640, %rsp
	.cfi_def_cfa_offset 5792
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	leaq	816(%rsp), %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic
	cmpb	$1, 4928(%rsp)
	jne	.LBB40_6
	movq	4920(%rsp), %rbx
	cmpq	$4097, %rbx
	jae	.LBB40_16
	leaq	8(%rsp), %rdi
	leaq	816(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	cmpb	$0, 8(%rsp)
	je	.LBB40_3
.LBB40_6:
	xorl	%eax, %eax
.LBB40_7:
	addq	$5736, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB40_3:
	.cfi_def_cfa_offset 5792
	movb	$1, %al
	testq	%rbx, %rbx
	je	.LBB40_7
	xorl	%r14d, %r14d
	leaq	8(%rsp), %r15
	leaq	816(%rsp), %r12
	.p2align	4
.LBB40_5:
	movq	%r15, %rdi
	movq	%r12, %rsi
	movq	%r14, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	cmpb	$0, 8(%rsp)
	je	.LBB40_6
	incq	%r14
	cmpq	%r14, %rbx
	jne	.LBB40_5
	xorl	%ebp, %ebp
	leaq	8(%rsp), %r15
	leaq	816(%rsp), %r12
	leaq	4936(%rsp), %r13
	jmp	.LBB40_14
	.p2align	4
.LBB40_9:
	movb	%r14b, 816(%rsp,%rbp)
	incq	%rbp
	cmpq	%rbp, %rbx
	je	.LBB40_10
.LBB40_14:
	movzbl	816(%rsp,%rbp), %r14d
	movl	%r14d, %eax
	notb	%al
	movb	%al, 816(%rsp,%rbp)
	movq	4920(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB40_15
	movq	%r15, %rdi
	movq	%r12, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	cmpb	$1, 8(%rsp)
	je	.LBB40_9
	movl	$800, %edx
	movq	%r13, %rdi
	leaq	16(%rsp), %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r13, %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map
	testb	%al, %al
	jne	.LBB40_9
	jmp	.LBB40_6
.LBB40_10:
	movb	$1, %al
	jmp	.LBB40_7
.LBB40_15:
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB40_16:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end40:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests25truncations_and_mutations, .Lfunc_end40-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests25truncations_and_mutations
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header,"ax",@progbits
	.prefalign	4, .Lfunc_end41, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header:
.Lfunc_begin41:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$840, %rsp
	.cfi_def_cfa_offset 4960
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movl	%esi, %ebx
	movq	%rdi, %r14
	leaq	816(%rsp), %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic
	bswapl	%ebx
	movl	%ebx, 816(%rsp,%r14)
	cmpb	$1, 4928(%rsp)
	jne	.LBB41_3
	movq	4920(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB41_5
	leaq	8(%rsp), %rdi
	leaq	816(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	movzbl	8(%rsp), %eax
	addq	$4936, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB41_3:
	.cfi_def_cfa_offset 4960
	xorl	%eax, %eax
	addq	$4936, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB41_5:
	.cfi_def_cfa_offset 4960
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end41:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header, .Lfunc_end41-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure,"ax",@progbits
	.prefalign	4, .Lfunc_end42, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure:
.Lfunc_begin42:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$840, %rsp
	.cfi_def_cfa_offset 4960
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movl	%edi, %ebx
	leaq	816(%rsp), %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic
	testb	%bl, %bl
	je	.LBB42_6
	movzbl	%bl, %eax
	cmpl	$1, %eax
	je	.LBB42_4
	cmpl	$5, %eax
	jne	.LBB42_7
	movl	$-1, 1440(%rsp)
	cmpb	$1, 4928(%rsp)
	je	.LBB42_12
.LBB42_37:
	xorl	%eax, %eax
	addq	$4936, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB42_4:
	.cfi_def_cfa_offset 4960
	movq	4920(%rsp), %rsi
	leaq	-724(%rsi), %rdx
	cmpq	$3485, %rdx
	jae	.LBB42_40
	leaq	1428(%rsp), %rdi
	movl	$120, %esi
	callq	*memset@GOTPCREL(%rip)
	cmpb	$1, 4928(%rsp)
	je	.LBB42_12
	jmp	.LBB42_37
.LBB42_6:
	movb	$1, 1429(%rsp)
	cmpb	$1, 4928(%rsp)
	jne	.LBB42_37
.LBB42_12:
	movq	4920(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB42_39
	leaq	8(%rsp), %rdi
	leaq	816(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	movzbl	8(%rsp), %eax
	addq	$4936, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB42_7:
	.cfi_def_cfa_offset 4960
	cmpb	$5, %bl
	jae	.LBB42_10
	leaq	816(%rsp), %r14
	movl	$4096, %edx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$608, 4912(%rsp)
	movq	$0, 4920(%rsp)
	movl	$1, %esi
	movq	%r14, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	cmpb	$4, %bl
	jne	.LBB42_14
	movq	4912(%rsp), %r14
.LBB42_18:
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB42_21
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB42_41
	movl	$33554432, 816(%rsp,%r14)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r14
	cmpb	$3, %bl
	je	.LBB42_22
	jmp	.LBB42_28
.LBB42_10:
	movq	4920(%rsp), %rdi
	decq	%rdi
	cmpq	$4096, %rdi
	jae	.LBB42_43
	movb	$120, 816(%rsp,%rdi)
	movl	$1694498816, 1440(%rsp)
	cmpb	$1, 4928(%rsp)
	jne	.LBB42_37
	jmp	.LBB42_12
.LBB42_14:
	leaq	816(%rsp), %r14
	movl	$15, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.18, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.20, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 16(%rsp)
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4912(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB42_17
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB42_41
	movl	$33554432, 816(%rsp,%r14)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r14
	cmpb	$2, %bl
	jne	.LBB42_18
	jmp	.LBB42_28
.LBB42_21:
	movb	$0, 4928(%rsp)
	cmpb	$3, %bl
	jne	.LBB42_28
.LBB42_22:
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB42_27
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB42_41
	movl	$150994944, 816(%rsp,%r14)
	movq	%rax, 4912(%rsp)
	cmpq	$4093, %rax
	jae	.LBB42_26
	movl	$67108864, 816(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4912(%rsp)
	movq	%rax, %r14
	jmp	.LBB42_28
.LBB42_17:
	movb	$0, 4928(%rsp)
	cmpb	$2, %bl
	je	.LBB42_28
	jmp	.LBB42_18
.LBB42_26:
	movq	%rax, %r14
.LBB42_27:
	movb	$0, 4928(%rsp)
.LBB42_28:
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB42_31
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB42_41
	movl	$150994944, 816(%rsp,%r14)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r14
	jmp	.LBB42_32
.LBB42_31:
	movb	$0, 4928(%rsp)
.LBB42_32:
	movq	%r14, %rax
	addq	$112, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB42_35
	movq	%rbx, %rdi
	subq	%r14, %rdi
	cmpq	$112, %rdi
	jne	.LBB42_42
	leaq	(%rsp,%r14), %rdi
	addq	$816, %rdi
	movl	$112, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.17, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4912(%rsp)
	jmp	.LBB42_36
.LBB42_35:
	movb	$0, 4928(%rsp)
	movq	%r14, %rbx
.LBB42_36:
	movq	%rbx, 4920(%rsp)
	movl	$-302117424, 816(%rsp)
	bswapl	%ebx
	movl	%ebx, 820(%rsp)
	movl	$1610743808, 824(%rsp)
	movl	%r14d, %eax
	bswapl	%eax
	movl	%eax, 828(%rsp)
	movabsq	$1224979099315863552, %rax
	movq	%rax, 832(%rsp)
	movl	$268435456, 840(%rsp)
	movl	$1879048192, 848(%rsp)
	addl	$-608, %r14d
	bswapl	%r14d
	movl	%r14d, 852(%rsp)
	cmpb	$1, 4928(%rsp)
	je	.LBB42_12
	jmp	.LBB42_37
.LBB42_39:
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB42_40:
	addq	$-112, %rsi
	movl	$612, %edi
	movl	$4096, %edx
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB42_41:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB42_42:
	movl	$112, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB42_43:
	movl	$4096, %esi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.Lfunc_end42:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure, .Lfunc_end42-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree,"ax",@progbits
	.prefalign	4, .Lfunc_end43, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree:
.Lfunc_begin43:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$840, %rsp
	.cfi_def_cfa_offset 4976
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	%edi, %ebx
	leaq	816(%rsp), %r14
	movl	$4096, %edx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$608, 4912(%rsp)
	movq	$0, 4920(%rsp)
	movb	$1, 4928(%rsp)
	movl	$1, %esi
	movq	%r14, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movzbl	%bl, %r14d
	cmpb	$3, %r14b
	ja	.LBB43_9
	jmpq	*.LJTI43_0(,%r14,8)
.LBB43_2:
	movl	$33554432, 8(%rsp)
	leaq	816(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	jmp	.LBB43_8
.LBB43_3:
	movq	4912(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB43_11
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_88
	movl	$33554432, 816(%rsp,%rax)
	movq	%rcx, 4912(%rsp)
	jmp	.LBB43_12
.LBB43_6:
	leaq	816(%rsp), %rdi
	movl	$3, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.71, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movb	$1, %bpl
	jmp	.LBB43_14
.LBB43_7:
	leaq	816(%rsp), %rdi
	movl	$6, %edx
	movl	$9, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.69, %rcx
.LBB43_8:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	jmp	.LBB43_13
.LBB43_9:
	leaq	816(%rsp), %rdi
	movl	$15, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.18, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	cmpb	$4, %bl
	jne	.LBB43_50
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 16(%rsp)
	leaq	816(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	xorl	%ebp, %ebp
	jmp	.LBB43_25
.LBB43_11:
	movb	$0, 4928(%rsp)
.LBB43_12:
	leaq	816(%rsp), %rdi
	movl	$11, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.70, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
.LBB43_13:
	xorl	%ebp, %ebp
.LBB43_14:
	leaq	816(%rsp), %rdi
	movl	$15, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.18, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
.LBB43_15:
	leaq	816(%rsp), %rdi
	movl	$11, %edx
	movl	$7, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.20, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	leal	-5(%r14), %eax
	cmpl	$4, %eax
	ja	.LBB43_47
	jmpq	*.LJTI43_1(,%rax,8)
.LBB43_17:
	movabsq	$-72057594037927937, %rax
	movq	%rax, 8(%rsp)
	movabsq	$288230376151711744, %rax
	movq	%rax, 16(%rsp)
	jmp	.LBB43_22
.LBB43_18:
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movabsq	$4503599627370496, %rax
	movq	%rax, 16(%rsp)
	movabsq	$4503874505277440, %rcx
	movq	%rcx, 24(%rsp)
	movq	%rax, 32(%rsp)
	movabsq	$9007474132647936, %rcx
	movq	%rcx, 40(%rsp)
	movq	%rax, 48(%rsp)
	movabsq	$13511073760018432, %rcx
	movq	%rcx, 56(%rsp)
	movq	%rax, 64(%rsp)
	movabsq	$18014673387388928, %rcx
	movq	%rcx, 72(%rsp)
	movq	%rax, 80(%rsp)
	movabsq	$22518273014759424, %rcx
	movq	%rcx, 88(%rsp)
	movq	%rax, 96(%rsp)
	movabsq	$27021872642129920, %rcx
	movq	%rcx, 104(%rsp)
	movq	%rax, 112(%rsp)
	movabsq	$31525472269500416, %rcx
	movq	%rcx, 120(%rsp)
	movq	%rax, 128(%rsp)
	movabsq	$36029071896870912, %rcx
	movq	%rcx, 136(%rsp)
	movq	%rax, 144(%rsp)
	movabsq	$40532671524241408, %rcx
	movq	%rcx, 152(%rsp)
	movq	%rax, 160(%rsp)
	movabsq	$45036271151611904, %rcx
	movq	%rcx, 168(%rsp)
	movq	%rax, 176(%rsp)
	movabsq	$49539870778982400, %rcx
	movq	%rcx, 184(%rsp)
	movq	%rax, 192(%rsp)
	movabsq	$54043470406352896, %rcx
	movq	%rcx, 200(%rsp)
	movq	%rax, 208(%rsp)
	movabsq	$58547070033723392, %rcx
	movq	%rcx, 216(%rsp)
	movq	%rax, 224(%rsp)
	movabsq	$63050669661093888, %rcx
	movq	%rcx, 232(%rsp)
	movq	%rax, 240(%rsp)
	movabsq	$67554269288464384, %rcx
	movq	%rcx, 248(%rsp)
	movq	%rax, 256(%rsp)
	movabsq	$1374389534720, %rcx
	movq	%rcx, 264(%rsp)
	movq	%rax, 272(%rsp)
	leaq	816(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$272, %r8d
	jmp	.LBB43_23
.LBB43_19:
	leaq	816(%rsp), %rdi
	movl	$3, %edx
	movl	$15, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.72, %rcx
	jmp	.LBB43_24
.LBB43_20:
	leaq	816(%rsp), %rdi
	movl	$3, %edx
	movl	$1, %ecx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	xorl	%r8d, %r8d
	jmp	.LBB43_24
.LBB43_21:
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movq	$0, 16(%rsp)
.LBB43_22:
	leaq	816(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
.LBB43_23:
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
.LBB43_24:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
.LBB43_25:
	movq	4912(%rsp), %r15
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB43_28
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_88
	movl	$33554432, 816(%rsp,%r15)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	testb	%bpl, %bpl
	jne	.LBB43_29
.LBB43_32:
	addl	$-15, %r14d
	cmpl	$3, %r14d
	jbe	.LBB43_34
	jmp	.LBB43_66
.LBB43_28:
	movb	$0, 4928(%rsp)
	testb	%bpl, %bpl
	je	.LBB43_32
.LBB43_29:
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB43_33
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_88
	movl	$33554432, 816(%rsp,%r15)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	addl	$-15, %r14d
	cmpl	$3, %r14d
	jbe	.LBB43_34
	jmp	.LBB43_66
.LBB43_33:
	movb	$0, 4928(%rsp)
	addl	$-15, %r14d
	cmpl	$3, %r14d
	ja	.LBB43_66
.LBB43_34:
	jmpq	*.LJTI43_3(,%r14,8)
.LBB43_35:
	leaq	816(%rsp), %r14
	movl	$15, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.18, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.20, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 16(%rsp)
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4912(%rsp), %r15
.LBB43_36:
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB43_37
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_88
	movl	$33554432, 816(%rsp,%r15)
	jmp	.LBB43_65
.LBB43_38:
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB43_37
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_88
	movl	$117440512, 816(%rsp,%r15)
.LBB43_65:
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	jmp	.LBB43_66
.LBB43_37:
	movb	$0, 4928(%rsp)
	jmp	.LBB43_66
.LBB43_41:
	leaq	816(%rsp), %r14
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33, %eax
	movq	4912(%rsp), %r15
	movq	$-1, %rcx
	jmp	.LBB43_43
	.p2align	4
.LBB43_42:
	movb	$0, 4928(%rsp)
	decl	%eax
	je	.LBB43_66
.LBB43_43:
	movq	%r15, %rdx
	addq	$4, %rdx
	cmovbq	%rcx, %rdx
	cmpq	$4097, %rdx
	jae	.LBB43_42
	movq	%rdx, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_88
	movl	$33554432, 816(%rsp,%r15)
	movq	%rdx, 4912(%rsp)
	movq	%rdx, %r15
	decl	%eax
	jne	.LBB43_43
	jmp	.LBB43_66
.LBB43_46:
	leaq	816(%rsp), %rdi
	movl	$6, %edx
	movl	$5, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.49, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4912(%rsp), %r15
.LBB43_66:
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB43_69
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_88
	movl	$33554432, 816(%rsp,%r15)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	cmpb	$19, %bl
	je	.LBB43_70
	jmp	.LBB43_74
.LBB43_69:
	movb	$0, 4928(%rsp)
	cmpb	$19, %bl
	jne	.LBB43_74
.LBB43_70:
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB43_73
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_88
	movl	$33554432, 816(%rsp,%r15)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	jmp	.LBB43_74
.LBB43_73:
	movb	$0, 4928(%rsp)
.LBB43_74:
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB43_77
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_88
	movl	$150994944, 816(%rsp,%r15)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	jmp	.LBB43_78
.LBB43_77:
	movb	$0, 4928(%rsp)
.LBB43_78:
	movq	%r15, %rax
	addq	$112, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB43_81
	movq	%rbx, %rdi
	subq	%r15, %rdi
	cmpq	$112, %rdi
	jne	.LBB43_90
	leaq	(%rsp,%r15), %rdi
	addq	$816, %rdi
	movl	$112, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.17, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4912(%rsp)
	movzbl	4928(%rsp), %eax
	jmp	.LBB43_82
.LBB43_81:
	movb	$0, 4928(%rsp)
	xorl	%eax, %eax
	movq	%r15, %rbx
.LBB43_82:
	movq	%rbx, 4920(%rsp)
	movl	$-302117424, 816(%rsp)
	movl	%ebx, %ecx
	bswapl	%ecx
	movl	%ecx, 820(%rsp)
	movl	$1610743808, 824(%rsp)
	movl	%r15d, %ecx
	bswapl	%ecx
	movl	%ecx, 828(%rsp)
	movabsq	$1224979099315863552, %rcx
	movq	%rcx, 832(%rsp)
	movl	$268435456, 840(%rsp)
	movl	$1879048192, 848(%rsp)
	addl	$-608, %r15d
	bswapl	%r15d
	movl	%r15d, 852(%rsp)
	testb	%al, %al
	je	.LBB43_85
	cmpq	$4097, %rbx
	jae	.LBB43_89
	leaq	8(%rsp), %rdi
	leaq	816(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	movzbl	8(%rsp), %eax
	jmp	.LBB43_86
.LBB43_85:
	xorl	%eax, %eax
.LBB43_86:
	addq	$4936, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB43_47:
	.cfi_def_cfa_offset 4976
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 16(%rsp)
	leaq	816(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	leal	-10(%r14), %eax
	cmpl	$4, %eax
	ja	.LBB43_25
	jmpq	*.LJTI43_2(,%rax,8)
.LBB43_49:
	movabsq	$343597383680, %rax
	movq	%rax, 8(%rsp)
	movabsq	$4503599627370496, %rax
	movq	%rax, 16(%rsp)
	leaq	816(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	jmp	.LBB43_57
.LBB43_50:
	xorl	%ebp, %ebp
	jmp	.LBB43_15
.LBB43_51:
	leaq	816(%rsp), %rdi
	movl	$11, %edx
	movl	$7, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.20, %rcx
	jmp	.LBB43_57
.LBB43_52:
	leaq	816(%rsp), %rdi
	movl	$6, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.73, %rcx
	jmp	.LBB43_57
.LBB43_53:
	leaq	816(%rsp), %rdi
	movl	$5, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.74, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movq	4912(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB43_87
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_88
	movl	$33554432, 816(%rsp,%rax)
	movq	%rcx, 4912(%rsp)
	jmp	.LBB43_58
.LBB43_56:
	leaq	816(%rsp), %rdi
	movl	$6, %edx
	movl	$9, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.69, %rcx
.LBB43_57:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
.LBB43_58:
	movq	4912(%rsp), %r15
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB43_61
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_88
	movl	$33554432, 816(%rsp,%r15)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	testb	%bpl, %bpl
	jne	.LBB43_36
	jmp	.LBB43_66
.LBB43_61:
	movb	$0, 4928(%rsp)
	testb	%bpl, %bpl
	jne	.LBB43_36
	jmp	.LBB43_66
.LBB43_87:
	movb	$0, 4928(%rsp)
	jmp	.LBB43_58
.LBB43_88:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB43_89:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB43_90:
	movl	$112, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end43:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree, .Lfunc_end43-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree,"a",@progbits
	.p2align	3, 0x0
.LJTI43_0:
	.quad	.LBB43_2
	.quad	.LBB43_7
	.quad	.LBB43_3
	.quad	.LBB43_6
.LJTI43_1:
	.quad	.LBB43_17
	.quad	.LBB43_21
	.quad	.LBB43_19
	.quad	.LBB43_20
	.quad	.LBB43_18
.LJTI43_2:
	.quad	.LBB43_49
	.quad	.LBB43_56
	.quad	.LBB43_52
	.quad	.LBB43_53
	.quad	.LBB43_51
.LJTI43_3:
	.quad	.LBB43_35
	.quad	.LBB43_46
	.quad	.LBB43_38
	.quad	.LBB43_41

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation,"ax",@progbits
	.prefalign	4, .Lfunc_end44, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation:
.Lfunc_begin44:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$832, %rsp
	.cfi_def_cfa_offset 4960
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movl	%edi, %ebx
	leaq	808(%rsp), %r14
	movl	$4096, %edx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$608, 4904(%rsp)
	movq	$0, 4912(%rsp)
	movb	$1, 4920(%rsp)
	movl	$1, %esi
	movq	%r14, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$15, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.18, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.20, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$274877906944, %rax
	movq	%rax, (%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 8(%rsp)
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB44_1
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB44_53
	movl	$33554432, 808(%rsp,%rax)
	movq	%rcx, 4904(%rsp)
	jmp	.LBB44_4
.LBB44_1:
	movb	$0, 4920(%rsp)
.LBB44_4:
	movabsq	$4503599627370496, %r15
	leaq	808(%rsp), %r14
	movl	$15, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.61, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movzbl	%bl, %r14d
	cmpb	$1, %r14b
	je	.LBB44_10
	leaq	808(%rsp), %rdi
	movl	$6, %edx
	testl	%r14d, %r14d
	jne	.LBB44_7
	movl	$16, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.78, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.79, %rcx
	jmp	.LBB44_9
.LBB44_7:
	movl	$1, %ecx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.78, %rsi
	xorl	%r8d, %r8d
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	leaq	808(%rsp), %rdi
	movl	$6, %edx
	cmpb	$2, %bl
	jne	.LBB44_11
	movl	$9, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.69, %rcx
.LBB44_9:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
.LBB44_10:
	leaq	808(%rsp), %rdi
	movl	$6, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
.LBB44_12:
	movabsq	$1374389534720, %rax
	movq	%rax, (%rsp)
	movq	%r15, 8(%rsp)
	leaq	808(%rsp), %rdi
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	addl	$-4, %r14d
	cmpl	$7, %r14d
	ja	.LBB44_16
	jmpq	*.LJTI44_0(,%r14,8)
.LBB44_25:
	movq	%r15, (%rsp)
	leaq	808(%rsp), %rdi
	movq	%rsp, %rcx
	movl	$9, %edx
	movl	$8, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.82, %rsi
	jmp	.LBB44_15
.LBB44_11:
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	cmpb	$3, %bl
	jne	.LBB44_12
.LBB44_14:
	movq	%r15, (%rsp)
	leaq	808(%rsp), %rdi
	movq	%rsp, %rcx
	movl	$4, %edx
	movl	$8, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.81, %rsi
	jmp	.LBB44_15
.LBB44_29:
	leaq	808(%rsp), %rdi
	movl	$8, %edx
	movl	$1, %ecx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.85, %rsi
	xorl	%r8d, %r8d
	jmp	.LBB44_15
.LBB44_26:
	leaq	808(%rsp), %rdi
	movl	$12, %edx
	movl	$16, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.83, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.79, %rcx
	jmp	.LBB44_15
.LBB44_27:
	leaq	808(%rsp), %rdi
	movl	$6, %edx
	movl	$1, %ecx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.84, %rsi
	xorl	%r8d, %r8d
	jmp	.LBB44_15
.LBB44_35:
	movabsq	$2473901162496, %rax
	movq	%rax, (%rsp)
	movq	%r15, 8(%rsp)
	leaq	808(%rsp), %rdi
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	jmp	.LBB44_15
.LBB44_30:
	leaq	808(%rsp), %rdi
	movl	$6, %edx
	movl	$9, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.69, %rcx
.LBB44_15:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
.LBB44_16:
	movq	4904(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB44_20
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB44_53
	movl	$33554432, 808(%rsp,%r14)
	movq	%rax, 4904(%rsp)
	cmpq	$4093, %rax
	jae	.LBB44_19
	movl	$33554432, 808(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4904(%rsp)
	movq	%rax, %r14
	cmpb	$12, %bl
	je	.LBB44_23
	jmp	.LBB44_38
.LBB44_19:
	movq	%rax, %r14
.LBB44_20:
	movb	$0, 4920(%rsp)
	cmpb	$12, %bl
	jne	.LBB44_38
.LBB44_23:
	leaq	808(%rsp), %rbx
	movl	$15, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.61, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$1, %ecx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.78, %rsi
	xorl	%r8d, %r8d
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB44_24
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB44_53
	movl	$33554432, 808(%rsp,%r14)
	movq	%rax, 4904(%rsp)
	movq	%rax, %r14
	jmp	.LBB44_38
.LBB44_24:
	movb	$0, 4920(%rsp)
.LBB44_38:
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB44_42
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB44_53
	movl	$33554432, 808(%rsp,%r14)
	movq	%rax, 4904(%rsp)
	cmpq	$4093, %rax
	jae	.LBB44_41
	movl	$150994944, 808(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4904(%rsp)
	movq	%rax, %r14
	jmp	.LBB44_44
.LBB44_41:
	movq	%rax, %r14
.LBB44_42:
	movb	$0, 4920(%rsp)
.LBB44_44:
	movq	%r14, %rax
	addq	$112, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB44_45
	movq	%rbx, %rdi
	subq	%r14, %rdi
	cmpq	$112, %rdi
	jne	.LBB44_54
	leaq	(%rsp,%r14), %rdi
	addq	$808, %rdi
	movl	$112, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.17, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4904(%rsp)
	movzbl	4920(%rsp), %eax
	jmp	.LBB44_48
.LBB44_45:
	movb	$0, 4920(%rsp)
	xorl	%eax, %eax
	movq	%r14, %rbx
.LBB44_48:
	movq	%rbx, 4912(%rsp)
	movl	$-302117424, 808(%rsp)
	movl	%ebx, %ecx
	bswapl	%ecx
	movl	%ecx, 812(%rsp)
	movl	$1610743808, 816(%rsp)
	movl	%r14d, %ecx
	bswapl	%ecx
	movl	%ecx, 820(%rsp)
	movabsq	$1224979099315863552, %rcx
	movq	%rcx, 824(%rsp)
	movl	$268435456, 832(%rsp)
	movl	$1879048192, 840(%rsp)
	addl	$-608, %r14d
	bswapl	%r14d
	movl	%r14d, 844(%rsp)
	testb	%al, %al
	je	.LBB44_49
	cmpq	$4097, %rbx
	jae	.LBB44_55
	movq	%rsp, %rdi
	leaq	808(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	movzbl	(%rsp), %eax
	jmp	.LBB44_52
.LBB44_49:
	xorl	%eax, %eax
.LBB44_52:
	addq	$4928, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB44_31:
	.cfi_def_cfa_offset 4960
	leaq	808(%rsp), %rdi
	movl	$5, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.74, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movq	4904(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB44_32
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB44_53
	movl	$33554432, 808(%rsp,%rax)
	movq	%rcx, 4904(%rsp)
	jmp	.LBB44_16
.LBB44_32:
	movb	$0, 4920(%rsp)
	jmp	.LBB44_16
.LBB44_53:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB44_55:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB44_54:
	movl	$112, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end44:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation, .Lfunc_end44-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation,"a",@progbits
	.p2align	3, 0x0
.LJTI44_0:
	.quad	.LBB44_14
	.quad	.LBB44_25
	.quad	.LBB44_26
	.quad	.LBB44_27
	.quad	.LBB44_29
	.quad	.LBB44_30
	.quad	.LBB44_31
	.quad	.LBB44_35

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation,"ax",@progbits
	.prefalign	4, .Lfunc_end45, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation:
.Lfunc_begin45:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$832, %rsp
	.cfi_def_cfa_offset 4944
	.cfi_offset %rbx, -16
	movl	%edi, %ebx
	movq	%rsp, %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic
	cmpb	$3, %bl
	ja	.LBB45_4
	movzbl	%bl, %eax
	jmpq	*.LJTI45_0(,%rax,8)
.LBB45_5:
	movabsq	$4503599627370496, %rax
	movabsq	$274877906944, %rsi
	leaq	592(%rsp), %rcx
	movl	$1342308352, 16(%rsp)
	movl	$600, %edx
	jmp	.LBB45_7
.LBB45_2:
	movabsq	$72057594037927936, %rax
	movl	$40, %edx
	movq	%rax, (%rsp,%rdx)
	cmpb	$1, 4112(%rsp)
	je	.LBB45_10
.LBB45_9:
	xorl	%eax, %eax
	addq	$4928, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB45_6:
	.cfi_def_cfa_offset 4944
	movabsq	$4503599627370496, %rax
	leaq	56(%rsp), %rcx
	movabsq	$274877906944, %rdx
	movq	%rdx, 40(%rsp)
	movq	%rax, 48(%rsp)
	movl	$64, %edx
	movabsq	$72057868915834880, %rsi
	jmp	.LBB45_7
.LBB45_3:
	leaq	40(%rsp), %rcx
	movabsq	$144115188075855872, %rax
	movl	$48, %edx
	movq	$-1, %rsi
	jmp	.LBB45_7
.LBB45_4:
	movabsq	$4503599627370496, %rax
	leaq	552(%rsp), %rcx
	movabsq	$274877906944, %rdx
	movq	%rdx, 40(%rsp)
	movq	%rax, 48(%rsp)
	movabsq	$4503874505277440, %rdx
	movq	%rdx, 56(%rsp)
	movq	%rax, 64(%rsp)
	movabsq	$9007474132647936, %rdx
	movq	%rdx, 72(%rsp)
	movq	%rax, 80(%rsp)
	movabsq	$13511073760018432, %rdx
	movq	%rdx, 88(%rsp)
	movq	%rax, 96(%rsp)
	movabsq	$18014673387388928, %rdx
	movq	%rdx, 104(%rsp)
	movq	%rax, 112(%rsp)
	movabsq	$22518273014759424, %rdx
	movq	%rdx, 120(%rsp)
	movq	%rax, 128(%rsp)
	movabsq	$27021872642129920, %rdx
	movq	%rdx, 136(%rsp)
	movq	%rax, 144(%rsp)
	movabsq	$31525472269500416, %rdx
	movq	%rdx, 152(%rsp)
	movq	%rax, 160(%rsp)
	movabsq	$36029071896870912, %rdx
	movq	%rdx, 168(%rsp)
	movq	%rax, 176(%rsp)
	movabsq	$40532671524241408, %rdx
	movq	%rdx, 184(%rsp)
	movq	%rax, 192(%rsp)
	movabsq	$45036271151611904, %rdx
	movq	%rdx, 200(%rsp)
	movq	%rax, 208(%rsp)
	movabsq	$49539870778982400, %rdx
	movq	%rdx, 216(%rsp)
	movq	%rax, 224(%rsp)
	movabsq	$54043470406352896, %rdx
	movq	%rdx, 232(%rsp)
	movq	%rax, 240(%rsp)
	movabsq	$58547070033723392, %rdx
	movq	%rdx, 248(%rsp)
	movq	%rax, 256(%rsp)
	movabsq	$63050669661093888, %rdx
	movq	%rdx, 264(%rsp)
	movq	%rax, 272(%rsp)
	movabsq	$67554269288464384, %rdx
	movq	%rdx, 280(%rsp)
	movq	%rax, 288(%rsp)
	movabsq	$1374389534720, %rdx
	movq	%rdx, 296(%rsp)
	movq	%rax, 304(%rsp)
	movabsq	$4504974016905216, %rdx
	movq	%rdx, 312(%rsp)
	movq	%rax, 320(%rsp)
	movabsq	$9008573644275712, %rdx
	movq	%rdx, 328(%rsp)
	movq	%rax, 336(%rsp)
	movabsq	$13512173271646208, %rdx
	movq	%rdx, 344(%rsp)
	movq	%rax, 352(%rsp)
	movabsq	$18015772899016704, %rdx
	movq	%rdx, 360(%rsp)
	movq	%rax, 368(%rsp)
	movabsq	$22519372526387200, %rdx
	movq	%rdx, 376(%rsp)
	movq	%rax, 384(%rsp)
	movabsq	$27022972153757696, %rdx
	movq	%rdx, 392(%rsp)
	movq	%rax, 400(%rsp)
	movabsq	$31526571781128192, %rdx
	movq	%rdx, 408(%rsp)
	movq	%rax, 416(%rsp)
	movabsq	$36030171408498688, %rdx
	movq	%rdx, 424(%rsp)
	movq	%rax, 432(%rsp)
	movabsq	$40533771035869184, %rdx
	movq	%rdx, 440(%rsp)
	movq	%rax, 448(%rsp)
	movabsq	$45037370663239680, %rdx
	movq	%rdx, 456(%rsp)
	movq	%rax, 464(%rsp)
	movabsq	$49540970290610176, %rdx
	movq	%rdx, 472(%rsp)
	movq	%rax, 480(%rsp)
	movabsq	$54044569917980672, %rdx
	movq	%rdx, 488(%rsp)
	movq	%rax, 496(%rsp)
	movabsq	$58548169545351168, %rdx
	movq	%rdx, 504(%rsp)
	movq	%rax, 512(%rsp)
	movabsq	$63051769172721664, %rdx
	movq	%rdx, 520(%rsp)
	movq	%rax, 528(%rsp)
	movabsq	$67555368800092160, %rdx
	movq	%rdx, 536(%rsp)
	movq	%rax, 544(%rsp)
	movl	$560, %edx
	movabsq	$2473901162496, %rsi
.LBB45_7:
	movq	%rsi, (%rcx)
	movq	%rax, (%rsp,%rdx)
	cmpb	$1, 4112(%rsp)
	jne	.LBB45_9
.LBB45_10:
	movq	4104(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB45_13
	leaq	4120(%rsp), %rdi
	movq	%rsp, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	movzbl	4120(%rsp), %eax
	addq	$4928, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB45_13:
	.cfi_def_cfa_offset 4944
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end45:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation, .Lfunc_end45-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation,"a",@progbits
	.p2align	3, 0x0
.LJTI45_0:
	.quad	.LBB45_5
	.quad	.LBB45_3
	.quad	.LBB45_2
	.quad	.LBB45_6

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic,"ax",@progbits
	.prefalign	4, .Lfunc_end46, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic:
.Lfunc_begin46:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$48, %rsp
	.cfi_def_cfa_offset 4176
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rbx
	leaq	24(%rsp), %r14
	movl	$4096, %edx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$608, 4120(%rsp)
	movq	$0, 4128(%rsp)
	movb	$1, 4136(%rsp)
	movl	$1, %esi
	movq	%r14, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$15, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.18, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.20, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 16(%rsp)
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4120(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB46_7
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB46_13
	movl	$33554432, 24(%rsp,%r14)
	movq	%rax, 4120(%rsp)
	cmpq	$4092, %rax
	ja	.LBB46_6
	leaq	4(%rax), %r14
	movl	$33554432, 24(%rsp,%rax)
	movq	%r14, 4120(%rsp)
	cmpq	$4089, %rax
	jae	.LBB46_7
	movl	$150994944, 28(%rsp,%rax)
	addq	$8, %rax
	movq	%rax, 4120(%rsp)
	movq	%rax, %r14
	jmp	.LBB46_8
.LBB46_6:
	movq	%rax, %r14
.LBB46_7:
	movb	$0, 4136(%rsp)
.LBB46_8:
	movq	%r14, %rax
	addq	$112, %rax
	movq	$-1, %r15
	cmovaeq	%rax, %r15
	cmpq	$4097, %r15
	jae	.LBB46_11
	movq	%r15, %rdi
	subq	%r14, %rdi
	cmpq	$112, %rdi
	jne	.LBB46_14
	leaq	(%rsp,%r14), %rdi
	addq	$24, %rdi
	movl	$112, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.17, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r15, 4120(%rsp)
	jmp	.LBB46_12
.LBB46_11:
	movb	$0, 4136(%rsp)
	movq	%r14, %r15
.LBB46_12:
	movq	%r15, 4128(%rsp)
	movl	$-302117424, 24(%rsp)
	bswapl	%r15d
	movl	%r15d, 28(%rsp)
	movl	$1610743808, 32(%rsp)
	movl	%r14d, %eax
	bswapl	%eax
	movl	%eax, 36(%rsp)
	movabsq	$1224979099315863552, %rax
	movq	%rax, 40(%rsp)
	movl	$268435456, 48(%rsp)
	movl	$1879048192, 56(%rsp)
	addl	$-608, %r14d
	bswapl	%r14d
	movl	%r14d, 60(%rsp)
	leaq	24(%rsp), %rsi
	movl	$4120, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	addq	$4144, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB46_13:
	.cfi_def_cfa_offset 4176
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB46_14:
	movl	$112, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end46:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic, .Lfunc_end46-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5valid,"ax",@progbits
	.prefalign	4, .Lfunc_end47, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5valid,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5valid:
.Lfunc_begin47:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$56, %rsp
	.cfi_def_cfa_offset 8272
	.cfi_offset %rbx, -24
	.cfi_offset %rbp, -16
	leaq	32(%rsp), %rbx
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.106, %rsi
	movl	$1, %ecx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	leaq	4152(%rsp), %rdi
	movl	$4096, %edx
	movq	%rbx, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	4136(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB47_34
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ebp
	cmpb	$-1, %bpl
	je	.LBB47_48
	cmpb	$1, 4144(%rsp)
	jne	.LBB47_48
	movq	16(%rsp), %rbx
	cmpq	$3, %rbx
	jae	.LBB47_45
	movq	(%rsp), %rax
	cmpq	$2, %rbx
	je	.LBB47_7
	cmpq	$1, %rbx
	jne	.LBB47_48
	testq	%rax, %rax
	jne	.LBB47_48
	jmp	.LBB47_8
.LBB47_7:
	movq	8(%rsp), %rcx
	xorq	$1, %rcx
	orq	%rcx, %rax
	setne	%al
	cmpb	$2, %bpl
	sete	%cl
	orb	%al, %cl
	jne	.LBB47_48
.LBB47_8:
	leaq	32(%rsp), %rdi
	leaq	4152(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	setne	%al
	cmpq	$1, %rbx
	setne	%cl
	cmpb	$2, %bpl
	setne	%dl
	orb	%cl, %dl
	orb	%al, %dl
	jne	.LBB47_48
	leaq	32(%rsp), %rbx
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.106, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	leaq	4152(%rsp), %rdi
	movl	$4096, %edx
	movq	%rbx, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB47_34
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ebp
	cmpb	$-1, %bpl
	je	.LBB47_48
	cmpb	$1, 4144(%rsp)
	jne	.LBB47_48
	movq	16(%rsp), %rbx
	cmpq	$2, %rbx
	ja	.LBB47_45
	movq	(%rsp), %rax
	cmpq	$1, %rbx
	je	.LBB47_16
	cmpq	$2, %rbx
	jne	.LBB47_48
	movq	8(%rsp), %rcx
	xorq	$1, %rcx
	orq	%rcx, %rax
	sete	%al
	cmpb	$2, %bpl
	setne	%cl
	testb	%al, %cl
	jne	.LBB47_17
	jmp	.LBB47_48
.LBB47_16:
	testq	%rax, %rax
	jne	.LBB47_48
.LBB47_17:
	leaq	32(%rsp), %rdi
	leaq	4152(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	setne	%al
	cmpq	$1, %rbx
	setne	%cl
	testb	$-3, %bpl
	sete	%dl
	orb	%cl, %dl
	orb	%al, %dl
	jne	.LBB47_48
	leaq	32(%rsp), %rbx
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.106, %rsi
	movl	$2, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	leaq	4152(%rsp), %rdi
	movl	$4096, %edx
	movq	%rbx, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB47_34
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ebp
	cmpb	$-1, %bpl
	je	.LBB47_48
	cmpb	$1, 4144(%rsp)
	jne	.LBB47_48
	movq	16(%rsp), %rbx
	cmpq	$2, %rbx
	ja	.LBB47_45
	movq	(%rsp), %rax
	cmpq	$1, %rbx
	je	.LBB47_25
	cmpq	$2, %rbx
	jne	.LBB47_48
	movq	8(%rsp), %rcx
	xorq	$1, %rcx
	orq	%rcx, %rax
	sete	%al
	cmpb	$2, %bpl
	setne	%cl
	testb	%al, %cl
	jne	.LBB47_26
	jmp	.LBB47_48
.LBB47_25:
	testq	%rax, %rax
	jne	.LBB47_48
.LBB47_26:
	leaq	32(%rsp), %rdi
	leaq	4152(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	setne	%al
	cmpq	$1, %rbx
	setne	%cl
	testb	$-3, %bpl
	sete	%dl
	orb	%cl, %dl
	orb	%al, %dl
	jne	.LBB47_48
	leaq	32(%rsp), %rbx
	movl	$2, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.57, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	leaq	4152(%rsp), %rdi
	movl	$4096, %edx
	movq	%rbx, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB47_34
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ebp
	cmpb	$-1, %bpl
	je	.LBB47_48
	cmpb	$1, 4144(%rsp)
	jne	.LBB47_48
	movq	16(%rsp), %rbx
	cmpq	$2, %rbx
	ja	.LBB47_45
	movq	(%rsp), %rax
	cmpq	$1, %rbx
	je	.LBB47_36
	cmpq	$2, %rbx
	jne	.LBB47_48
	movq	8(%rsp), %rcx
	xorq	$1, %rcx
	orq	%rcx, %rax
	sete	%al
	cmpb	$2, %bpl
	setne	%cl
	testb	%al, %cl
	jne	.LBB47_37
	jmp	.LBB47_48
.LBB47_34:
	movq	%rdx, %rax
.LBB47_35:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rax, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB47_36:
	testq	%rax, %rax
	jne	.LBB47_48
.LBB47_37:
	leaq	32(%rsp), %rdi
	leaq	4152(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	setne	%al
	cmpq	$2, %rbx
	setne	%cl
	testb	$-3, %bpl
	sete	%dl
	orb	%cl, %dl
	orb	%al, %dl
	jne	.LBB47_48
	leaq	32(%rsp), %rbx
	movl	$2, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.115, %rsi
	movl	$2, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	leaq	4152(%rsp), %rdi
	movl	$4096, %edx
	movq	%rbx, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	4136(%rsp), %rcx
	movq	%rcx, %rax
	cmpq	$4096, %rcx
	ja	.LBB47_35
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	movq	%rax, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ebp
	cmpb	$-1, %bpl
	je	.LBB47_48
	cmpb	$1, 4144(%rsp)
	jne	.LBB47_48
	movq	16(%rsp), %rbx
	cmpq	$2, %rbx
	ja	.LBB47_45
	movq	(%rsp), %rax
	cmpq	$1, %rbx
	je	.LBB47_46
	cmpq	$2, %rbx
	jne	.LBB47_48
	movq	8(%rsp), %rcx
	xorq	$1, %rcx
	orq	%rcx, %rax
	sete	%al
	cmpb	$2, %bpl
	setne	%cl
	testb	%al, %cl
	jne	.LBB47_47
	jmp	.LBB47_48
.LBB47_45:
	movl	$2, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB47_46:
	testq	%rax, %rax
	jne	.LBB47_48
.LBB47_47:
	leaq	32(%rsp), %rdi
	leaq	4152(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	sete	%al
	cmpq	$2, %rbx
	sete	%cl
	andb	%al, %cl
	testb	$-3, %bpl
	setne	%al
	testb	%al, %cl
	jne	.LBB47_50
.LBB47_48:
	xorl	%eax, %eax
	addq	$8248, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB47_50:
	.cfi_def_cfa_offset 8272
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11extra_valid
	addq	$8248, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end47:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5valid, .Lfunc_end47-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5valid
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic,"ax",@progbits
	.prefalign	4, .Lfunc_end48, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic:
.Lfunc_begin48:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$40, %rsp
	.cfi_def_cfa_offset 4192
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	%r9d, %r13d
	movl	%r8d, 4(%rsp)
	movl	%ecx, %r14d
	movq	%rdx, %r15
	movq	%rsi, %r12
	movq	%rdi, 8(%rsp)
	leaq	16(%rsp), %rbx
	movl	$4096, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$80, 4112(%rsp)
	movq	$0, 4120(%rsp)
	movb	$1, 4128(%rsp)
	movl	$1, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$4, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.30, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	%r14d, %eax
	shll	$24, %eax
	movl	%eax, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	testq	%r15, %r15
	je	.LBB48_3
	shlq	$3, %r15
	xorl	%ebp, %ebp
	movzbl	%r13b, %ebx
	leaq	16(%rsp), %r13
	.p2align	4
.LBB48_2:
	movq	(%r12,%rbp), %rsi
	movq	%r13, %rdi
	movl	%r14d, %edx
	movl	%ebx, %ecx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu
	addq	$8, %rbp
	cmpq	%rbp, %r15
	jne	.LBB48_2
.LBB48_3:
	movq	4112(%rsp), %rbx
	movq	%rbx, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB48_4
	movq	%rax, %rdi
	subq	%rbx, %rdi
	cmpq	$4, %rdi
	jne	.LBB48_20
	movl	$33554432, 16(%rsp,%rbx)
	movq	%rax, 4112(%rsp)
	movq	%rax, %rbx
	movl	4(%rsp), %eax
	testb	%al, %al
	jne	.LBB48_19
	jmp	.LBB48_8
.LBB48_4:
	movb	$0, 4128(%rsp)
	movl	4(%rsp), %eax
	testb	%al, %al
	je	.LBB48_8
.LBB48_19:
	leaq	16(%rsp), %rdi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci
	movq	4112(%rsp), %rbx
.LBB48_8:
	movq	%rbx, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB48_12
	movq	%rax, %rdi
	subq	%rbx, %rdi
	cmpq	$4, %rdi
	jne	.LBB48_20
	movl	$33554432, 16(%rsp,%rbx)
	movq	%rax, 4112(%rsp)
	cmpq	$4093, %rax
	jae	.LBB48_11
	movl	$150994944, 16(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4112(%rsp)
	movq	%rax, %rbx
	jmp	.LBB48_14
.LBB48_11:
	movq	%rax, %rbx
.LBB48_12:
	movb	$0, 4128(%rsp)
.LBB48_14:
	movq	%rbx, %rax
	addq	$117, %rax
	movq	$-1, %r14
	cmovaeq	%rax, %r14
	cmpq	$4097, %r14
	jae	.LBB48_15
	movq	%r14, %rdi
	subq	%rbx, %rdi
	cmpq	$117, %rdi
	jne	.LBB48_21
	leaq	(%rsp,%rbx), %rdi
	addq	$16, %rdi
	movl	$117, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.41, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r14, 4112(%rsp)
	jmp	.LBB48_18
.LBB48_15:
	movb	$0, 4128(%rsp)
	movq	%rbx, %r14
.LBB48_18:
	movq	%r14, 4120(%rsp)
	movl	$-302117424, 16(%rsp)
	bswapl	%r14d
	movl	%r14d, 20(%rsp)
	movl	$1342177280, 24(%rsp)
	movl	%ebx, %eax
	bswapl	%eax
	movl	%eax, 28(%rsp)
	movabsq	$1224979099315863552, %rax
	movq	%rax, 32(%rsp)
	movq	$268435456, 40(%rsp)
	movl	$1962934272, 48(%rsp)
	addl	$-80, %ebx
	bswapl	%ebx
	movl	%ebx, 52(%rsp)
	leaq	16(%rsp), %rsi
	movl	$4120, %edx
	movq	8(%rsp), %rdi
	callq	*memcpy@GOTPCREL(%rip)
	addq	$4136, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB48_20:
	.cfi_def_cfa_offset 4192
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB48_21:
	movl	$117, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end48:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic, .Lfunc_end48-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11extra_valid,"ax",@progbits
	.prefalign	4, .Lfunc_end49, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11extra_valid,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11extra_valid:
.Lfunc_begin49:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$56, %rsp
	.cfi_def_cfa_offset 4176
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	leaq	32(%rsp), %rbx
	movl	$4096, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$80, 4128(%rsp)
	movq	$0, 4136(%rsp)
	movb	$1, 4144(%rsp)
	movl	$4194304, 76(%rsp)
	movl	$1048576, 84(%rsp)
	movl	$1, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB49_3
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB49_48
	movl	$67108864, 32(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	jmp	.LBB49_4
.LBB49_3:
	movb	$0, 4144(%rsp)
.LBB49_4:
	leaq	32(%rsp), %rbx
	movl	$4, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.30, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$16777216, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$5, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.26, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$5, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.49, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	leaq	17(%rax), %rdi
	addq	$20, %rax
	cmpq	%rdi, %rax
	jb	.LBB49_49
	cmpq	$4097, %rax
	jae	.LBB49_49
	movb	$9, 34(%rsp,%rdi)
	movw	$1023, 32(%rsp,%rdi)
	leaq	32(%rsp), %rdi
	movl	$13, %edx
	movl	$5, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.27, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.28, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB49_9
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB49_48
	movl	$33554432, 32(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	jmp	.LBB49_10
.LBB49_9:
	movb	$0, 4144(%rsp)
.LBB49_10:
	leaq	32(%rsp), %rbx
	movl	$5, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.24, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.26, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$16777216, (%rsp)
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$3, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.50, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$13, %edx
	movl	$5, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.27, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.28, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB49_13
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB49_48
	movl	$33554432, 32(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	jmp	.LBB49_14
.LBB49_13:
	movb	$0, 4144(%rsp)
.LBB49_14:
	leaq	32(%rsp), %rbx
	movl	$7, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.98, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$8, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.99, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$5, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.100, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movq	4128(%rsp), %rcx
	movq	%rcx, %rdx
	addq	$4, %rdx
	movq	$-1, %rax
	cmovaeq	%rdx, %rax
	cmpq	$4096, %rax
	ja	.LBB49_20
	movq	%rax, %rdi
	subq	%rcx, %rdi
	cmpq	$4, %rdi
	jne	.LBB49_48
	movl	$33554432, 32(%rsp,%rcx)
	movq	%rax, 4128(%rsp)
	cmpq	$4092, %rax
	ja	.LBB49_20
	leaq	4(%rax), %rcx
	movl	$33554432, 32(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	cmpq	$4088, %rax
	ja	.LBB49_20
	leaq	8(%rax), %rcx
	movl	$33554432, 36(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	cmpq	$4085, %rax
	jae	.LBB49_20
	movl	$33554432, 40(%rsp,%rax)
	addq	$12, %rax
	movq	%rax, 4128(%rsp)
	jmp	.LBB49_21
.LBB49_20:
	movb	$0, 4144(%rsp)
.LBB49_21:
	leaq	32(%rsp), %rbx
	movl	$4, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.32, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$10, %edx
	movl	$13, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.33, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.101, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.35, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.36, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$5, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.49, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB49_24
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB49_48
	movl	$33554432, 32(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	jmp	.LBB49_25
.LBB49_24:
	movb	$0, 4144(%rsp)
.LBB49_25:
	leaq	32(%rsp), %rbx
	movl	$9, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.102, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$10, %edx
	movl	$12, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.33, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.103, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB49_32
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB49_48
	movl	$33554432, 32(%rsp,%r14)
	movq	%rax, 4128(%rsp)
	cmpq	$4092, %rax
	ja	.LBB49_31
	leaq	4(%rax), %r14
	movl	$33554432, 32(%rsp,%rax)
	movq	%r14, 4128(%rsp)
	cmpq	$4089, %rax
	jae	.LBB49_32
	movl	$150994944, 36(%rsp,%rax)
	addq	$8, %rax
	movq	%rax, 4128(%rsp)
	movq	%rax, %r14
	jmp	.LBB49_33
.LBB49_31:
	movq	%rax, %r14
.LBB49_32:
	movb	$0, 4144(%rsp)
.LBB49_33:
	movq	%r14, %rax
	addq	$117, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB49_36
	movq	%rbx, %rdi
	subq	%r14, %rdi
	cmpq	$117, %rdi
	jne	.LBB49_52
	leaq	(%rsp,%r14), %rdi
	addq	$32, %rdi
	movl	$117, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.41, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4128(%rsp)
	movzbl	4144(%rsp), %eax
	jmp	.LBB49_37
.LBB49_36:
	movb	$0, 4144(%rsp)
	xorl	%eax, %eax
	movq	%r14, %rbx
.LBB49_37:
	movq	%rbx, 4136(%rsp)
	movl	$-302117424, 32(%rsp)
	movl	%ebx, %ecx
	bswapl	%ecx
	movl	%ecx, 36(%rsp)
	movl	$1342177280, 40(%rsp)
	movl	%r14d, %ecx
	bswapl	%ecx
	movl	%ecx, 44(%rsp)
	movabsq	$1224979099315863552, %rcx
	movq	%rcx, 48(%rsp)
	movq	$268435456, 56(%rsp)
	movl	$1962934272, 64(%rsp)
	addl	$-80, %r14d
	bswapl	%r14d
	movl	%r14d, 68(%rsp)
	testb	%al, %al
	je	.LBB49_46
	cmpq	$4097, %rbx
	jae	.LBB49_50
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ecx
	cmpb	$-1, %cl
	je	.LBB49_46
	movq	16(%rsp), %rsi
	cmpq	$3, %rsi
	jae	.LBB49_51
	xorl	%eax, %eax
	cmpq	$2, %rsi
	jne	.LBB49_47
	cmpb	$2, %cl
	je	.LBB49_47
	movq	8(%rsp), %rdx
	xorq	$1, %rdx
	orq	(%rsp), %rdx
	jne	.LBB49_47
	xorb	$1, %cl
	movl	%ecx, %eax
	jmp	.LBB49_47
.LBB49_46:
	xorl	%eax, %eax
.LBB49_47:
	andb	$1, %al
	addq	$4152, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB49_48:
	.cfi_def_cfa_offset 4176
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB49_49:
	movl	$4096, %edx
	movq	%rax, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB49_50:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB49_51:
	movl	$2, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB49_52:
	movl	$117, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end49:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11extra_valid, .Lfunc_end49-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11extra_valid
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin,"ax",@progbits
	.prefalign	4, .Lfunc_end50, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin:
.Lfunc_begin50:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rdi, %rbx
	movq	4096(%rdi), %rdi
	movq	%rdi, %rax
	addq	$4, %rax
	movq	$-1, %rcx
	cmovaeq	%rax, %rcx
	cmpq	$4097, %rcx
	jae	.LBB50_1
	movq	%rcx, %rax
	subq	%rdi, %rax
	cmpq	$4, %rax
	jne	.LBB50_26
	movl	$16777216, (%rbx,%rdi)
	movq	%rcx, 4096(%rbx)
	movq	%rcx, %rdi
	jmp	.LBB50_4
.LBB50_1:
	movb	$0, 4112(%rbx)
.LBB50_4:
	movq	%rdi, %rax
	addq	%rdx, %rax
	movq	$-1, %r14
	cmovaeq	%rax, %r14
	cmpq	$4097, %r14
	jae	.LBB50_5
	movq	%r14, %rax
	subq	%rdi, %rax
	cmpq	%rdx, %rax
	jne	.LBB50_27
	addq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r14, 4096(%rbx)
	movq	%r14, %rdi
	jmp	.LBB50_8
.LBB50_5:
	movb	$0, 4112(%rbx)
.LBB50_8:
	movq	%rdi, %rax
	incq	%rax
	movq	$-1, %rcx
	cmovneq	%rax, %rcx
	cmpq	$4097, %rcx
	jae	.LBB50_9
	movq	%rcx, %rax
	subq	%rdi, %rax
	cmpq	$1, %rax
	jne	.LBB50_28
	movb	$0, (%rbx,%rdi)
	movq	%rcx, 4096(%rbx)
	testb	$3, %cl
	je	.LBB50_25
	cmpb	$0, 4112(%rbx)
	je	.LBB50_25
	cmpq	$4096, %rcx
	jne	.LBB50_15
.LBB50_14:
	movb	$0, 4112(%rbx)
.LBB50_25:
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB50_9:
	.cfi_def_cfa_offset 32
	movb	$0, 4112(%rbx)
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB50_15:
	.cfi_def_cfa_offset 32
	leaq	1(%rcx), %rax
	movb	$0, (%rbx,%rcx)
	movq	%rax, 4096(%rbx)
	cmpb	$1, 4112(%rbx)
	jne	.LBB50_25
	movl	%eax, %edx
	andl	$3, %edx
	je	.LBB50_25
	cmpq	$4096, %rax
	je	.LBB50_14
	leaq	2(%rcx), %rdx
	movb	$0, (%rbx,%rax)
	movq	%rdx, 4096(%rbx)
	cmpb	$1, 4112(%rbx)
	jne	.LBB50_25
	movl	%edx, %eax
	andl	$3, %eax
	je	.LBB50_25
	cmpq	$4096, %rdx
	je	.LBB50_14
	leaq	3(%rcx), %rax
	movb	$0, (%rbx,%rdx)
	movq	%rax, 4096(%rbx)
	cmpb	$1, 4112(%rbx)
	jne	.LBB50_25
	movl	%eax, %edx
	andl	$3, %edx
	je	.LBB50_25
	cmpq	$4096, %rax
	je	.LBB50_14
	movb	$0, 3(%rbx,%rcx)
	addq	$4, %rcx
	movq	%rcx, 4096(%rbx)
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB50_26:
	.cfi_def_cfa_offset 32
	movl	$4, %esi
	movq	%rax, %rdi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB50_27:
	movq	%rax, %rdi
	movq	%rdx, %rsi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB50_28:
	movl	$1, %esi
	movq	%rax, %rdi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end50:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin, .Lfunc_end50-_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property,"ax",@progbits
	.prefalign	4, .Lfunc_end51, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property:
.Lfunc_begin51:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %r14
	movq	%rcx, (%rsp)
	movq	%rdx, %r12
	movq	%rsi, %r13
	movq	%rdi, %rbx
	xorl	%ebp, %ebp
	movq	memcmp@GOTPCREL(%rip), %r15
	jmp	.LBB51_2
	.p2align	4
.LBB51_1:
	leaq	(%r12,%rbp), %rax
	incq	%rax
	incq	%rbp
	cmpq	$117, %rax
	je	.LBB51_9
.LBB51_2:
	leaq	.Lanon.a24a8216ad3259fdc76a412b00af4a98.41(%rbp), %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	*%r15
	testl	%eax, %eax
	jne	.LBB51_1
	cmpb	$0, .Lanon.a24a8216ad3259fdc76a412b00af4a98.41(%r12,%rbp)
	jne	.LBB51_1
	movq	4096(%rbx), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	movq	%rax, %rdi
	cmpq	$4096, %rcx
	ja	.LBB51_13
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB51_32
	movl	$50331648, (%rbx,%rax)
	movq	%rcx, 4096(%rbx)
	cmpq	$4092, %rcx
	ja	.LBB51_12
	leaq	4(%rcx), %rdi
	movl	%r14d, %edx
	shll	$24, %edx
	movl	%edx, (%rbx,%rcx)
	movq	%rdi, 4096(%rbx)
	cmpq	$4089, %rcx
	jae	.LBB51_13
	bswapl	%ebp
	movl	%ebp, 4(%rbx,%rcx)
	addq	$8, %rcx
	movq	%rcx, 4096(%rbx)
	movq	%rcx, %rdi
	jmp	.LBB51_14
.LBB51_9:
	movb	$0, 4112(%rbx)
	xorl	%eax, %eax
	jmp	.LBB51_10
.LBB51_12:
	movq	%rcx, %rdi
.LBB51_13:
	movb	$0, 4112(%rbx)
.LBB51_14:
	movq	%rdi, %rcx
	addq	%r14, %rcx
	movq	$-1, %r12
	cmovaeq	%rcx, %r12
	cmpq	$4097, %r12
	jae	.LBB51_20
	movq	%rax, %r15
	movq	%r12, %rax
	subq	%rdi, %rax
	cmpq	%r14, %rax
	jne	.LBB51_33
	addq	%rbx, %rdi
	movq	(%rsp), %rsi
	movq	%r14, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r12, 4096(%rbx)
	testb	$3, %r12b
	je	.LBB51_21
	cmpb	$0, 4112(%rbx)
	movq	%r15, %rax
	je	.LBB51_10
	cmpq	$4096, %r12
	jne	.LBB51_22
.LBB51_20:
	movb	$0, 4112(%rbx)
.LBB51_10:
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB51_21:
	.cfi_def_cfa_offset 64
	movq	%r15, %rax
	jmp	.LBB51_10
.LBB51_22:
	leaq	1(%r12), %rcx
	movb	$0, (%rbx,%r12)
	movq	%rcx, 4096(%rbx)
	cmpb	$1, 4112(%rbx)
	jne	.LBB51_10
	movl	%ecx, %edx
	andl	$3, %edx
	je	.LBB51_10
	cmpq	$4096, %rcx
	je	.LBB51_20
	leaq	2(%r12), %rdx
	movb	$0, (%rbx,%rcx)
	movq	%rdx, 4096(%rbx)
	cmpb	$1, 4112(%rbx)
	jne	.LBB51_10
	movl	%edx, %ecx
	andl	$3, %ecx
	je	.LBB51_10
	cmpq	$4096, %rdx
	je	.LBB51_20
	leaq	3(%r12), %rcx
	movb	$0, (%rbx,%rdx)
	movq	%rcx, 4096(%rbx)
	cmpb	$1, 4112(%rbx)
	jne	.LBB51_10
	movl	%ecx, %edx
	andl	$3, %edx
	je	.LBB51_10
	cmpq	$4096, %rcx
	je	.LBB51_20
	movb	$0, 3(%rbx,%r12)
	addq	$4, %r12
	movq	%r12, 4096(%rbx)
	jmp	.LBB51_10
.LBB51_32:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB51_33:
	movq	%rax, %rdi
	movq	%r14, %rsi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end51:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property, .Lfunc_end51-_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu,"ax",@progbits
	.prefalign	4, .Lfunc_end52, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu:
.Lfunc_begin52:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	%ecx, %ebp
	movl	%edx, %r15d
	movq	%rsi, %r14
	movq	%rdi, %rbx
	cmpq	$1, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.24, %rax
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.25, %rcx
	cmoveq	%rax, %rcx
	testq	%rsi, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.23, %rsi
	cmovneq	%rcx, %rsi
	movl	$5, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.26, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	cmpl	$2, %r15d
	jne	.LBB52_2
	bswapq	%r14
	movq	%r14, 16(%rsp)
	leaq	16(%rsp), %rcx
	movl	$3, %edx
	movl	$8, %r8d
	jmp	.LBB52_3
.LBB52_2:
	bswapl	%r14d
	movl	%r14d, 12(%rsp)
	leaq	12(%rsp), %rcx
	movl	$3, %edx
	movl	$4, %r8d
.LBB52_3:
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	testb	%bpl, %bpl
	je	.LBB52_4
	movl	$13, %edx
	movl	$5, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.27, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.28, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB52_4:
	movq	4096(%rbx), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB52_5
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB52_10
	movl	$33554432, (%rbx,%rax)
	movq	%rcx, 4096(%rbx)
	jmp	.LBB52_8
.LBB52_5:
	movb	$0, 4112(%rbx)
.LBB52_8:
	addq	$24, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB52_10:
	.cfi_def_cfa_offset 64
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end52:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu, .Lfunc_end52-_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci,"ax",@progbits
	.prefalign	4, .Lfunc_end53, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci:
.Lfunc_begin53:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movl	$4, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.32, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$10, %edx
	movl	$35, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.33, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.34, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.35, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.36, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$50331844, 12(%rsp)
	leaq	12(%rsp), %rcx
	movl	$6, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.37, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554564, 12(%rsp)
	leaq	12(%rsp), %rcx
	movl	$7, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.38, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$16777412, 12(%rsp)
	leaq	12(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.39, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$83886276, 12(%rsp)
	leaq	12(%rsp), %rcx
	movl	$7, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.40, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4096(%rbx), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB53_1
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB53_5
	movl	$33554432, (%rbx,%rax)
	movq	%rcx, 4096(%rbx)
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB53_1:
	.cfi_def_cfa_offset 32
	movb	$0, 4112(%rbx)
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB53_5:
	.cfi_def_cfa_offset 32
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end53:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci, .Lfunc_end53-_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9malformed,"ax",@progbits
	.prefalign	4, .Lfunc_end54, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9malformed,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9malformed:
.Lfunc_begin54:
	.cfi_startproc
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$56, %rsp
	.cfi_def_cfa_offset 4160
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9mutations
	testb	%al, %al
	je	.LBB54_1
	leaq	32(%rsp), %rdi
	movl	$8, %esi
	xorl	%edx, %edx
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB54_1
	movq	4136(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB54_5
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB54_1
	leaq	32(%rsp), %rdi
	movl	$1, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.116, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB54_1
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB54_5
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB54_1
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.79, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB54_1
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB54_5
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB54_1
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.58, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB54_1
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB54_5
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB54_1
	leaq	32(%rsp), %rdi
	movl	$3, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.117, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB54_1
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB54_5
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB54_1
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.57, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB54_1
	movq	4136(%rsp), %rcx
	movq	%rcx, %rax
	cmpq	$4096, %rcx
	ja	.LBB54_6
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	movq	%rax, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB54_1
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.57, %rsi
	movl	$1, %ecx
	xorl	%r8d, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB54_1
	movq	4136(%rsp), %rcx
	movq	%rcx, %rax
	cmpq	$4096, %rcx
	ja	.LBB54_6
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	movq	%rax, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	je	.LBB54_7
.LBB54_1:
	xorl	%eax, %eax
.LBB54_2:
	addq	$4152, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB54_5:
	.cfi_def_cfa_offset 4160
	movq	%rdx, %rax
.LBB54_6:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rax, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB54_7:
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB54_2
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$4, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$5, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$6, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$7, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$8, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$9, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$10, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$11, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$12, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$13, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$14, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$15, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$16, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$17, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$18, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	movl	$19, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB54_1
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB54_2
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$4, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$5, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$6, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$7, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$8, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$9, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$10, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$11, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$12, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$13, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$14, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$15, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$16, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	movl	$17, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB54_1
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB54_2
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB54_1
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB54_1
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB54_1
	movl	$4, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB54_1
	movl	$5, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB54_1
	movl	$6, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB54_1
	movl	$7, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB54_1
	movl	$8, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB54_1
	movl	$9, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB54_1
	movl	$10, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB54_1
	xorl	%edi, %edi
	xorl	%esi, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$4, %edi
	movl	$39, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$4, %edi
	movl	$2097153, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$8, %edi
	movl	$65, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$8, %edi
	movl	$-1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$12, %edi
	movl	$80, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$16, %edi
	movl	$41, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$16, %edi
	movl	$80, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$20, %edi
	movl	$16, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$20, %edi
	movl	$18, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$24, %edi
	movl	$17, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$28, %edi
	movl	$1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$32, %edi
	movl	$-1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB54_1
	movl	$36, %edi
	movl	$-1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	movl	%eax, %ecx
	movb	$1, %al
	testb	%cl, %cl
	je	.LBB54_1
	jmp	.LBB54_2
.Lfunc_end54:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9malformed, .Lfunc_end54-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9malformed
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9mutations,"ax",@progbits
	.prefalign	4, .Lfunc_end55, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9mutations,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9mutations:
.Lfunc_begin55:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$56, %rsp
	.cfi_def_cfa_offset 4208
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.57, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB55_6
	movq	4136(%rsp), %rbx
	cmpq	$4097, %rbx
	jae	.LBB55_20
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	je	.LBB55_6
	movb	$1, %bpl
	testq	%rbx, %rbx
	je	.LBB55_7
	xorl	%r14d, %r14d
	movq	%rsp, %r15
	leaq	32(%rsp), %r12
	.p2align	4
.LBB55_5:
	movq	%r15, %rdi
	movq	%r12, %rsi
	movq	%r14, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB55_6
	incq	%r14
	cmpq	%r14, %rbx
	jne	.LBB55_5
	xorl	%r12d, %r12d
	movq	%rsp, %r14
	leaq	32(%rsp), %r15
	jmp	.LBB55_18
	.p2align	4
.LBB55_9:
	movb	%r13b, 32(%rsp,%r12)
	incq	%r12
	cmpq	%r12, %rbx
	je	.LBB55_7
.LBB55_18:
	movzbl	32(%rsp,%r12), %r13d
	movl	%r13d, %eax
	notb	%al
	movb	%al, 32(%rsp,%r12)
	movq	4136(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB55_19
	movq	%r14, %rdi
	movq	%r15, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ecx
	cmpb	$-1, %cl
	je	.LBB55_9
	movq	16(%rsp), %rsi
	cmpq	$3, %rsi
	jae	.LBB55_21
	movq	(%rsp), %rax
	cmpq	$2, %rsi
	je	.LBB55_14
	cmpq	$1, %rsi
	jne	.LBB55_6
	testq	%rax, %rax
	je	.LBB55_9
	jmp	.LBB55_6
	.p2align	4
.LBB55_14:
	cmpb	$2, %cl
	je	.LBB55_6
	movq	8(%rsp), %rcx
	xorq	$1, %rcx
	orq	%rcx, %rax
	je	.LBB55_9
.LBB55_6:
	xorl	%ebp, %ebp
.LBB55_7:
	movl	%ebp, %eax
	addq	$4152, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB55_19:
	.cfi_def_cfa_offset 4208
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB55_21:
	movl	$2, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB55_20:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end55:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9mutations, .Lfunc_end55-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9mutations
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu,"ax",@progbits
	.prefalign	4, .Lfunc_end56, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu:
.Lfunc_begin56:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$64, %rsp
	.cfi_def_cfa_offset 4192
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movl	%edi, %ebx
	leaq	40(%rsp), %r14
	movl	$4096, %edx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$80, 4136(%rsp)
	movq	$0, 4144(%rsp)
	movb	$1, 4152(%rsp)
	movl	$1, %esi
	movq	%r14, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movzbl	%bl, %r15d
	cmpb	$17, %bl
	jne	.LBB56_2
	leaq	40(%rsp), %r14
	movl	$3, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.71, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$4, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.30, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$16777216, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	jmp	.LBB56_5
.LBB56_2:
	leaq	40(%rsp), %rdi
	movl	$4, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.30, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	testb	%bl, %bl
	je	.LBB56_6
	cmpl	$1, %r15d
	jne	.LBB56_15
	movl	$50331648, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
.LBB56_5:
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB56_6:
	movl	$0, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB56_7:
	leaq	40(%rsp), %rdi
	movl	$5, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	cmpb	$7, %bl
	je	.LBB56_11
	cmpl	$8, %r15d
	jne	.LBB56_17
	leaq	40(%rsp), %rdi
	movl	$11, %edx
	movl	$7, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.105, %rcx
.LBB56_10:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB56_11:
	movl	$0, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB56_12:
	leaq	40(%rsp), %rdi
	movl	$13, %edx
	movl	$5, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.27, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.28, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	leal	-13(%r15), %eax
	cmpl	$3, %eax
	ja	.LBB56_29
	jmpq	*.LJTI56_0(,%rax,8)
.LBB56_14:
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$9, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.69, %rcx
	jmp	.LBB56_28
.LBB56_15:
	movl	$16777216, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	cmpb	$2, %bl
	jne	.LBB56_60
.LBB56_16:
	leaq	40(%rsp), %rdi
	movl	$5, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
.LBB56_17:
	leaq	40(%rsp), %rdi
	movl	$11, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.26, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	cmpb	$9, %bl
	je	.LBB56_27
	cmpl	$10, %r15d
	je	.LBB56_25
	cmpl	$11, %r15d
	jne	.LBB56_58
	movl	$16777216, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	jmp	.LBB56_26
.LBB56_21:
	leaq	40(%rsp), %rdi
	movl	$5, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.74, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movq	4136(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB56_64
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB56_67
	movl	$33554432, 40(%rsp,%rax)
	movq	%rcx, 4136(%rsp)
	jmp	.LBB56_29
.LBB56_24:
	movl	$0, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	jmp	.LBB56_28
.LBB56_25:
	leaq	40(%rsp), %rdi
	movl	$3, %edx
	movl	$8, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.106, %rcx
.LBB56_26:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB56_27:
	leaq	40(%rsp), %rdi
	movl	$13, %edx
	movl	$5, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.27, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.28, %rcx
.LBB56_28:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB56_29:
	movq	4136(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4096, %rcx
	ja	.LBB56_35
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB56_67
	movl	$33554432, 40(%rsp,%rax)
	movq	%rcx, 4136(%rsp)
	cmpq	$4093, %rcx
	jae	.LBB56_34
	movl	$33554432, 40(%rsp,%rcx)
	addq	$4, %rcx
	movq	%rcx, 4136(%rsp)
	movq	%rcx, %rax
	cmpb	$19, %bl
	jne	.LBB56_36
.LBB56_33:
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$5, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.49, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	jmp	.LBB56_43
.LBB56_34:
	movq	%rcx, %rax
.LBB56_35:
	movb	$0, 4152(%rsp)
	cmpb	$19, %bl
	je	.LBB56_33
.LBB56_36:
	cmpl	$18, %r15d
	je	.LBB56_40
	cmpl	$17, %r15d
	jne	.LBB56_43
	jmp	.LBB56_38
.LBB56_40:
	leaq	40(%rsp), %rbx
	movl	$4, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.30, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$16777216, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	%rbx, %rdi
	xorl	%esi, %esi
	movl	$1, %edx
	movl	$1, %ecx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu
	movq	4136(%rsp), %rax
.LBB56_38:
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB56_39
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB56_67
	movl	$33554432, 40(%rsp,%rax)
	movq	%rcx, 4136(%rsp)
	jmp	.LBB56_43
.LBB56_39:
	movb	$0, 4152(%rsp)
.LBB56_43:
	leaq	40(%rsp), %rdi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci
	movq	4136(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB56_48
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB56_67
	movl	$33554432, 40(%rsp,%r14)
	movq	%rax, 4136(%rsp)
	cmpq	$4093, %rax
	jae	.LBB56_47
	movl	$150994944, 40(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4136(%rsp)
	movq	%rax, %r14
	jmp	.LBB56_49
.LBB56_47:
	movq	%rax, %r14
.LBB56_48:
	movb	$0, 4152(%rsp)
.LBB56_49:
	movq	%r14, %rax
	addq	$117, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB56_52
	movq	%rbx, %rdi
	subq	%r14, %rdi
	cmpq	$117, %rdi
	jne	.LBB56_69
	leaq	(%rsp,%r14), %rdi
	addq	$40, %rdi
	movl	$117, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.41, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4136(%rsp)
	movzbl	4152(%rsp), %eax
	jmp	.LBB56_53
.LBB56_52:
	movb	$0, 4152(%rsp)
	xorl	%eax, %eax
	movq	%r14, %rbx
.LBB56_53:
	movq	%rbx, 4144(%rsp)
	movl	$-302117424, 40(%rsp)
	movl	%ebx, %ecx
	bswapl	%ecx
	movl	%ecx, 44(%rsp)
	movl	$1342177280, 48(%rsp)
	movl	%r14d, %ecx
	bswapl	%ecx
	movl	%ecx, 52(%rsp)
	movabsq	$1224979099315863552, %rcx
	movq	%rcx, 56(%rsp)
	movq	$268435456, 64(%rsp)
	movl	$1962934272, 72(%rsp)
	addl	$-80, %r14d
	bswapl	%r14d
	movl	%r14d, 76(%rsp)
	testb	%al, %al
	je	.LBB56_56
	cmpq	$4097, %rbx
	jae	.LBB56_68
	leaq	8(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 32(%rsp)
	sete	%al
	jmp	.LBB56_57
.LBB56_56:
	xorl	%eax, %eax
.LBB56_57:
	addq	$4160, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB56_58:
	.cfi_def_cfa_offset 4192
	movl	$0, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	cmpb	$12, %bl
	jne	.LBB56_12
	leaq	40(%rsp), %rdi
	movl	$13, %edx
	movl	$11, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.27, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.107, %rcx
	jmp	.LBB56_28
.LBB56_60:
	xorl	%eax, %eax
	cmpb	$3, %bl
	sete	%al
	shll	$24, %eax
	movl	%eax, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	cmpb	$6, %bl
	je	.LBB56_66
	cmpl	$5, %r15d
	je	.LBB56_65
	cmpl	$4, %r15d
	jne	.LBB56_7
	movl	$16777216, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	jmp	.LBB56_16
.LBB56_64:
	movb	$0, 4152(%rsp)
	jmp	.LBB56_29
.LBB56_65:
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$9, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.69, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	jmp	.LBB56_16
.LBB56_66:
	leaq	40(%rsp), %r14
	movl	$3, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.42, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.26, %rcx
	jmp	.LBB56_10
.LBB56_67:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB56_68:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB56_69:
	movl	$117, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end56:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu, .Lfunc_end56-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu,"a",@progbits
	.p2align	3, 0x0
.LJTI56_0:
	.quad	.LBB56_14
	.quad	.LBB56_24
	.quad	.LBB56_27
	.quad	.LBB56_21

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci,"ax",@progbits
	.prefalign	4, .Lfunc_end57, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci:
.Lfunc_begin57:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$64, %rsp
	.cfi_def_cfa_offset 4192
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movl	%edi, %ebx
	leaq	40(%rsp), %r14
	movl	$4096, %edx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$80, 4136(%rsp)
	movq	$0, 4144(%rsp)
	movb	$1, 4152(%rsp)
	movl	$1, %esi
	movq	%r14, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$4, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.30, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$16777216, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	%r14, %rdi
	xorl	%esi, %esi
	movl	$1, %edx
	movl	$1, %ecx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu
	movl	$1, %esi
	movq	%r14, %rdi
	movl	$1, %edx
	movl	$1, %ecx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu
	movq	4136(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB57_10
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB57_63
	movl	$33554432, 40(%rsp,%r14)
	movq	%rax, 4136(%rsp)
	movq	%rax, %r14
	movzbl	%bl, %r15d
	cmpb	$13, %r15b
	jne	.LBB57_11
.LBB57_3:
	leaq	40(%rsp), %r14
	movl	$3, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.71, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$4, %edx
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.32, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$10, %edx
	movl	$13, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.33, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.101, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB57_4:
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.35, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.36, %rcx
.LBB57_5:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB57_6:
	movq	4136(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB57_15
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB57_63
	movl	$33554432, 40(%rsp,%r14)
	movq	%rax, 4136(%rsp)
	movq	%rax, %r14
	cmpb	$14, %bl
	jne	.LBB57_16
.LBB57_9:
	leaq	40(%rsp), %rdi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci
	movq	4136(%rsp), %r14
	jmp	.LBB57_47
.LBB57_10:
	movb	$0, 4152(%rsp)
	movzbl	%bl, %r15d
	cmpb	$13, %r15b
	je	.LBB57_3
.LBB57_11:
	testl	%r15d, %r15d
	je	.LBB57_47
	leaq	40(%rsp), %rdi
	movl	$4, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.32, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	leal	-1(%r15), %eax
	cmpl	$4, %eax
	ja	.LBB57_31
	jmpq	*.LJTI57_0(,%rax,8)
.LBB57_14:
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.108, %rcx
	movl	$9, %r8d
	jmp	.LBB57_27
.LBB57_15:
	movb	$0, 4152(%rsp)
	cmpb	$14, %bl
	je	.LBB57_9
.LBB57_16:
	cmpl	$13, %r15d
	jne	.LBB57_20
.LBB57_17:
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB57_46
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB57_63
	movl	$33554432, 40(%rsp,%r14)
	movq	%rax, 4136(%rsp)
	movq	%rax, %r14
	jmp	.LBB57_47
.LBB57_20:
	cmpb	$15, %bl
	jb	.LBB57_47
	cmpb	$16, %bl
	je	.LBB57_39
	cmpl	$17, %r15d
	jne	.LBB57_40
	leaq	40(%rsp), %rdi
	movl	$4, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.32, %rsi
	jmp	.LBB57_41
.LBB57_46:
	movb	$0, 4152(%rsp)
.LBB57_47:
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB57_52
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB57_63
	movl	$33554432, 40(%rsp,%r14)
	movq	%rax, 4136(%rsp)
	cmpq	$4093, %rax
	jae	.LBB57_51
	movl	$150994944, 40(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4136(%rsp)
	movq	%rax, %r14
	jmp	.LBB57_53
.LBB57_51:
	movq	%rax, %r14
.LBB57_52:
	movb	$0, 4152(%rsp)
.LBB57_53:
	movq	%r14, %rax
	addq	$117, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB57_56
	movq	%rbx, %rdi
	subq	%r14, %rdi
	cmpq	$117, %rdi
	jne	.LBB57_65
	leaq	(%rsp,%r14), %rdi
	addq	$40, %rdi
	movl	$117, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.41, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4136(%rsp)
	movzbl	4152(%rsp), %eax
	jmp	.LBB57_57
.LBB57_56:
	movb	$0, 4152(%rsp)
	xorl	%eax, %eax
	movq	%r14, %rbx
.LBB57_57:
	movq	%rbx, 4144(%rsp)
	movl	$-302117424, 40(%rsp)
	movl	%ebx, %ecx
	bswapl	%ecx
	movl	%ecx, 44(%rsp)
	movl	$1342177280, 48(%rsp)
	movl	%r14d, %ecx
	bswapl	%ecx
	movl	%ecx, 52(%rsp)
	movabsq	$1224979099315863552, %rcx
	movq	%rcx, 56(%rsp)
	movq	$268435456, 64(%rsp)
	movl	$1962934272, 72(%rsp)
	addl	$-80, %r14d
	bswapl	%r14d
	movl	%r14d, 76(%rsp)
	testb	%al, %al
	je	.LBB57_60
	cmpq	$4097, %rbx
	jae	.LBB57_64
	leaq	8(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 32(%rsp)
	sete	%al
	jmp	.LBB57_61
.LBB57_60:
	xorl	%eax, %eax
.LBB57_61:
	addq	$4160, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB57_24:
	.cfi_def_cfa_offset 4192
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.110, %rcx
	movl	$15, %r8d
	jmp	.LBB57_27
.LBB57_25:
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.63, %rcx
	movl	$12, %r8d
	jmp	.LBB57_27
.LBB57_26:
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.109, %rcx
	movl	$14, %r8d
.LBB57_27:
	leaq	40(%rsp), %rdi
	movl	$10, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.33, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB57_28:
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.35, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.36, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	leal	-8(%r15), %eax
	cmpl	$4, %eax
	ja	.LBB57_6
	jmpq	*.LJTI57_1(,%rax,8)
.LBB57_30:
	leaq	40(%rsp), %rdi
	movl	$10, %edx
	movl	$13, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.33, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.112, %rcx
	jmp	.LBB57_5
.LBB57_31:
	leaq	40(%rsp), %rdi
	movl	$10, %edx
	movl	$13, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.33, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.101, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	cmpb	$6, %bl
	je	.LBB57_6
	cmpl	$7, %r15d
	jne	.LBB57_28
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.35, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.111, %rcx
	jmp	.LBB57_5
.LBB57_34:
	leaq	40(%rsp), %rdi
	movl	$5, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.74, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movq	4136(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB57_62
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB57_63
	movl	$33554432, 40(%rsp,%rax)
	movq	%rcx, 4136(%rsp)
	jmp	.LBB57_6
.LBB57_37:
	movl	$50331780, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$6, %edx
	movl	$4, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.37, %rsi
	jmp	.LBB57_5
.LBB57_38:
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$9, %r8d
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.69, %rcx
	jmp	.LBB57_5
.LBB57_39:
	leaq	40(%rsp), %rdi
	movl	$3, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.71, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
.LBB57_40:
	leaq	40(%rsp), %rdi
	movl	$15, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.113, %rsi
.LBB57_41:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	leaq	40(%rsp), %r14
	movl	$10, %edx
	movl	$9, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.33, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.108, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.35, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.36, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4136(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB57_44
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB57_63
	movl	$33554432, 40(%rsp,%r14)
	movq	%rax, 4136(%rsp)
	movq	%rax, %r14
	cmpb	$16, %bl
	je	.LBB57_17
	jmp	.LBB57_47
.LBB57_44:
	movb	$0, 4152(%rsp)
	cmpb	$16, %bl
	je	.LBB57_17
	jmp	.LBB57_47
.LBB57_62:
	movb	$0, 4152(%rsp)
	jmp	.LBB57_6
.LBB57_63:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB57_64:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB57_65:
	movl	$117, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end57:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci, .Lfunc_end57-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci,"a",@progbits
	.p2align	3, 0x0
.LJTI57_0:
	.quad	.LBB57_4
	.quad	.LBB57_14
	.quad	.LBB57_25
	.quad	.LBB57_26
	.quad	.LBB57_24
.LJTI57_1:
	.quad	.LBB57_4
	.quad	.LBB57_30
	.quad	.LBB57_37
	.quad	.LBB57_38
	.quad	.LBB57_34

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure,"ax",@progbits
	.prefalign	4, .Lfunc_end58, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure:
.Lfunc_begin58:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$56, %rsp
	.cfi_def_cfa_offset 4176
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movl	%edi, %ebx
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.57, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$9, %bl
	ja	.LBB58_25
	movzbl	%bl, %eax
	jmpq	*.LJTI58_0(,%rax,8)
.LBB58_2:
	movb	$1, 117(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB58_40
	jmp	.LBB58_51
.LBB58_3:
	movl	$1207959552, 48(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB58_40
	jmp	.LBB58_51
.LBB58_4:
	movq	4136(%rsp), %rax
	addq	$-121, %rax
	movq	%rax, %rcx
	addq	$4, %rcx
	movq	$-1, %rdi
	cmovaeq	%rcx, %rdi
	cmpq	$4097, %rdi
	jae	.LBB58_39
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB58_32
	movl	$33554432, 32(%rsp,%rax)
	cmpb	$1, 4144(%rsp)
	jne	.LBB58_40
	jmp	.LBB58_51
.LBB58_7:
	movl	$-1, 128(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB58_40
	jmp	.LBB58_51
.LBB58_8:
	movl	$-1, 124(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB58_40
	jmp	.LBB58_51
.LBB58_9:
	movq	4136(%rsp), %rax
	addq	$-121, %rax
	movq	%rax, %rcx
	addq	$4, %rcx
	movq	$-1, %rdi
	cmovaeq	%rcx, %rdi
	cmpq	$4097, %rdi
	jae	.LBB58_39
	subq	%rax, %rdi
	cmpq	$4, %rdi
	je	.LBB58_11
	jmp	.LBB58_32
.LBB58_12:
	movl	$117440512, 112(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB58_40
	jmp	.LBB58_51
.LBB58_13:
	movq	$-1, 72(%rsp)
	movl	$16777216, 84(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB58_40
	jmp	.LBB58_51
.LBB58_14:
	leaq	32(%rsp), %rbx
	movl	$4096, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$80, 4128(%rsp)
	movq	$0, 4136(%rsp)
	movb	$1, 4144(%rsp)
	movl	$1, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33, %eax
	movq	4128(%rsp), %rdx
	movq	$-1, %rcx
	jmp	.LBB58_16
	.p2align	4
.LBB58_15:
	movb	$0, 4144(%rsp)
	decl	%eax
	je	.LBB58_19
.LBB58_16:
	movq	%rdx, %rsi
	addq	$4, %rsi
	cmovbq	%rcx, %rsi
	cmpq	$4097, %rsi
	jae	.LBB58_15
	movq	%rsi, %rdi
	subq	%rdx, %rdi
	cmpq	$4, %rdi
	jne	.LBB58_32
	movl	$33554432, 32(%rsp,%rdx)
	movq	%rsi, 4128(%rsp)
	movq	%rsi, %rdx
	decl	%eax
	jne	.LBB58_16
.LBB58_19:
	leaq	32(%rsp), %rbx
	movl	$4, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.30, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$16777216, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$5, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.26, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %rbx
	movq	%rbx, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB58_42
	movq	%rax, %rdi
	subq	%rbx, %rdi
	cmpq	$4, %rdi
	jne	.LBB58_32
	movl	$33554432, 32(%rsp,%rbx)
	movq	%rax, 4128(%rsp)
	cmpq	$4092, %rax
	ja	.LBB58_44
	leaq	4(%rax), %rbx
	movl	$33554432, 32(%rsp,%rax)
	movq	%rbx, 4128(%rsp)
	cmpq	$4088, %rax
	ja	.LBB58_45
	leaq	8(%rax), %rbx
	movl	$33554432, 36(%rsp,%rax)
	movq	%rbx, 4128(%rsp)
	cmpq	$4085, %rax
	jae	.LBB58_45
	movl	$150994944, 40(%rsp,%rax)
	addq	$12, %rax
	jmp	.LBB58_38
.LBB58_25:
	leaq	32(%rsp), %rbx
	movl	$4096, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$80, 4128(%rsp)
	movq	$0, 4136(%rsp)
	movb	$1, 4144(%rsp)
	movl	$1, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$4, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.30, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$16777216, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$5, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, %rsi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.26, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %rcx
	movq	%rcx, %rdx
	addq	$4, %rdx
	movq	$-1, %rax
	cmovaeq	%rdx, %rax
	cmpq	$4096, %rax
	ja	.LBB58_33
	movq	%rax, %rdi
	subq	%rcx, %rdi
	cmpq	$4, %rdi
	jne	.LBB58_32
	movl	$33554432, 32(%rsp,%rcx)
	movq	%rax, 4128(%rsp)
	cmpq	$4092, %rax
	ja	.LBB58_33
	leaq	4(%rax), %rcx
	movl	$33554432, 32(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	cmpq	$4089, %rax
	jae	.LBB58_33
	movl	$33554432, 36(%rsp,%rax)
	addq	$8, %rax
	movq	%rax, 4128(%rsp)
	jmp	.LBB58_34
.LBB58_30:
	movq	4136(%rsp), %rax
	addq	$-125, %rax
	movq	%rax, %rcx
	addq	$4, %rcx
	movq	$-1, %rdi
	cmovaeq	%rcx, %rdi
	cmpq	$4097, %rdi
	jae	.LBB58_39
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB58_32
.LBB58_11:
	movl	$67108864, 32(%rsp,%rax)
	cmpb	$1, 4144(%rsp)
	jne	.LBB58_40
	jmp	.LBB58_51
.LBB58_39:
	movb	$0, 4144(%rsp)
	cmpb	$1, 4144(%rsp)
	je	.LBB58_51
.LBB58_40:
	xorl	%eax, %eax
	addq	$4152, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB58_33:
	.cfi_def_cfa_offset 4176
	movb	$0, 4144(%rsp)
.LBB58_34:
	leaq	32(%rsp), %rdi
	movl	$12, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.114, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movq	4128(%rsp), %rbx
	movq	%rbx, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB58_45
	movq	%rax, %rdi
	subq	%rbx, %rdi
	cmpq	$4, %rdi
	jne	.LBB58_32
	movl	$33554432, 32(%rsp,%rbx)
	movq	%rax, 4128(%rsp)
	cmpq	$4093, %rax
	jae	.LBB58_44
	movl	$150994944, 32(%rsp,%rax)
	addq	$4, %rax
.LBB58_38:
	movq	%rax, 4128(%rsp)
	movq	%rax, %rbx
	jmp	.LBB58_46
.LBB58_44:
	movq	%rax, %rbx
	jmp	.LBB58_45
.LBB58_42:
	movb	$0, 4144(%rsp)
.LBB58_45:
	movb	$0, 4144(%rsp)
.LBB58_46:
	movq	%rbx, %rax
	addq	$117, %rax
	movq	$-1, %r14
	cmovaeq	%rax, %r14
	cmpq	$4097, %r14
	jae	.LBB58_49
	movq	%r14, %rdi
	subq	%rbx, %rdi
	cmpq	$117, %rdi
	jne	.LBB58_54
	leaq	(%rsp,%rbx), %rdi
	addq	$32, %rdi
	movl	$117, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.41, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r14, 4128(%rsp)
	jmp	.LBB58_50
.LBB58_49:
	movb	$0, 4144(%rsp)
	movq	%rbx, %r14
.LBB58_50:
	movq	%r14, 4136(%rsp)
	movl	$-302117424, 32(%rsp)
	bswapl	%r14d
	movl	%r14d, 36(%rsp)
	movl	$1342177280, 40(%rsp)
	movl	%ebx, %eax
	bswapl	%eax
	movl	%eax, 44(%rsp)
	movabsq	$1224979099315863552, %rax
	movq	%rax, 48(%rsp)
	movq	$268435456, 56(%rsp)
	movl	$1962934272, 64(%rsp)
	addl	$-80, %ebx
	bswapl	%ebx
	movl	%ebx, 68(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB58_40
.LBB58_51:
	movq	4136(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB58_53
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	sete	%al
	addq	$4152, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB58_32:
	.cfi_def_cfa_offset 4176
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB58_53:
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB58_54:
	movl	$117, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end58:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure, .Lfunc_end58-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure,"a",@progbits
	.p2align	3, 0x0
.LJTI58_0:
	.quad	.LBB58_2
	.quad	.LBB58_12
	.quad	.LBB58_7
	.quad	.LBB58_8
	.quad	.LBB58_3
	.quad	.LBB58_13
	.quad	.LBB58_14
	.quad	.LBB58_9
	.quad	.LBB58_30
	.quad	.LBB58_4

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header,"ax",@progbits
	.prefalign	4, .Lfunc_end59, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header:
.Lfunc_begin59:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$56, %rsp
	.cfi_def_cfa_offset 4176
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movl	%esi, %ebx
	movq	%rdi, %r14
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.57, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	bswapl	%ebx
	movl	%ebx, 32(%rsp,%r14)
	cmpb	$1, 4144(%rsp)
	jne	.LBB59_3
	movq	4136(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB59_5
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	sete	%al
	addq	$4152, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB59_3:
	.cfi_def_cfa_offset 4176
	xorl	%eax, %eax
	addq	$4152, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB59_5:
	.cfi_def_cfa_offset 4176
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end59:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header, .Lfunc_end59-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid,"ax",@progbits
	.prefalign	4, .Lfunc_end60, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid:
.Lfunc_begin60:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$520, %rsp
	.cfi_def_cfa_offset 4672
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movabsq	$4294967552, %r15
	movq	$0, 2688(%rsp)
	movl	$0, 2696(%rsp)
	movl	$0, 2706(%rsp)
	movw	$0, 2710(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1136(%rsp)
	movq	$0, 1144(%rsp)
	movq	$0, 1152(%rsp)
	movq	$0, 3152(%rsp)
	movq	$0, 3144(%rsp)
	movq	$0, 3136(%rsp)
	movq	$0, 3128(%rsp)
	movq	$0, 3120(%rsp)
	movq	$0, 3112(%rsp)
	movq	$0, 3104(%rsp)
	movq	$0, 3096(%rsp)
	movq	$0, 3088(%rsp)
	movq	$0, 3080(%rsp)
	movq	$0, 3072(%rsp)
	movq	$0, 3064(%rsp)
	movq	$0, 3056(%rsp)
	movq	$0, 3048(%rsp)
	movq	$0, 1631(%rsp)
	movb	$0, 1639(%rsp)
	movl	$1179403647, 1624(%rsp)
	movl	$16843334, 1627(%rsp)
	movabsq	$-6510615555426900571, %rbx
	movq	%rbx, 144(%rsp)
	movq	%rbx, 136(%rsp)
	movq	%rbx, 128(%rsp)
	movq	%rbx, 120(%rsp)
	movabsq	$6510615555426900570, %rax
	movq	%rax, 1168(%rsp)
	movq	%rax, 1160(%rsp)
	movq	1632(%rsp), %rax
	movq	%rax, 2656(%rsp)
	movq	1624(%rsp), %rax
	movq	%rax, 2648(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 2664(%rsp)
	movq	%r15, 2672(%rsp)
	movq	$64, 2680(%rsp)
	movl	$3670080, 2700(%rsp)
	movw	$2, 2704(%rsp)
	movabsq	$21474836481, %rax
	movq	%rax, 2712(%rsp)
	movq	$256, 2720(%rsp)
	movq	%r15, 2728(%rsp)
	movq	$-1, 2736(%rsp)
	movq	$32, 2744(%rsp)
	movq	$32, 2752(%rsp)
	movq	$4096, 2760(%rsp)
	movabsq	$25769803777, %rax
	movq	%rax, 2768(%rsp)
	movq	$384, 2776(%rsp)
	leaq	8320(%r15), %rax
	movq	%rax, 2784(%rsp)
	movq	$-1, 2792(%rsp)
	movq	$16, 2800(%rsp)
	movq	$4097, 2808(%rsp)
	movq	$4096, 2816(%rsp)
	leaq	2824(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %r14
	movl	$112, %edx
	callq	*%r14
	leaq	2936(%rsp), %rdi
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	callq	*%r14
	leaq	40(%rsp), %rdi
	leaq	2648(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	movzbl	88(%rsp), %r13d
	xorl	%eax, %eax
	cmpb	$-1, %r13b
	je	.LBB60_31
	cmpq	%r15, 488(%rsp)
	jne	.LBB60_31
	cmpq	$3, 504(%rsp)
	jne	.LBB60_31
	movq	496(%rsp), %rsi
	cmpq	$9, %rsi
	jae	.LBB60_43
	cmpq	$2, %rsi
	jne	.LBB60_30
	cmpq	$32, 48(%rsp)
	jne	.LBB60_30
	movq	40(%rsp), %rdi
	movq	56(%rsp), %rax
	movq	%rax, 1608(%rsp)
	movq	64(%rsp), %rax
	movq	%rax, 1616(%rsp)
	movq	72(%rsp), %r12
	movq	80(%rsp), %rbp
	movq	96(%rsp), %rax
	movq	%rax, 1576(%rsp)
	movq	104(%rsp), %r14
	movq	120(%rsp), %rax
	movq	%rax, 1584(%rsp)
	movq	128(%rsp), %rax
	movq	%rax, 1592(%rsp)
	movq	136(%rsp), %rax
	movq	%rax, 1600(%rsp)
	movzbl	144(%rsp), %eax
	movb	%al, 7(%rsp)
	movl	$32, %edx
	movq	$.Lanon.a24a8216ad3259fdc76a412b00af4a98.122, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	movl	%eax, %ecx
	xorl	%eax, %eax
	cmpq	$16, %r14
	jne	.LBB60_31
	leaq	3840(%r15), %rdx
	cmpq	%rdx, %rbp
	jne	.LBB60_31
	movabsq	$4294967296, %rdx
	cmpq	%rdx, %r12
	jne	.LBB60_31
	cmpq	$32, 1616(%rsp)
	jne	.LBB60_31
	cmpq	%r15, 1608(%rsp)
	jne	.LBB60_31
	cmpb	$2, %r13b
	jne	.LBB60_31
	testl	%ecx, %ecx
	movabsq	$21474836481, %r14
	movabsq	$4306960386, %r12
	movabsq	$6510615555426900570, %rsi
	jne	.LBB60_31
	leaq	16128(%r15), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 1600(%rsp)
	jne	.LBB60_31
	leaq	7936(%r15), %rcx
	cmpq	%rcx, 1592(%rsp)
	jne	.LBB60_31
	cmpq	$4097, 1584(%rsp)
	jne	.LBB60_31
	cmpb	$1, 7(%rsp)
	jne	.LBB60_31
	movq	1576(%rsp), %rdx
	movq	(%rdx), %rcx
	xorq	%rsi, %rcx
	movq	8(%rdx), %rdx
	xorq	%rsi, %rdx
	orq	%rcx, %rdx
	jne	.LBB60_31
	leaq	216(%rsp), %rdi
	leaq	328(%rsp), %r13
	movq	$0, 80(%rsp)
	movl	$0, 88(%rsp)
	movl	$0, 98(%rsp)
	movw	$0, 102(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1136(%rsp)
	movq	$0, 1624(%rsp)
	movq	$0, 1632(%rsp)
	movq	$0, 1640(%rsp)
	movq	$0, 1648(%rsp)
	movq	$0, 1656(%rsp)
	movq	$0, 1664(%rsp)
	movq	$0, 1672(%rsp)
	movq	$0, 1680(%rsp)
	movq	$0, 1688(%rsp)
	movq	$0, 1696(%rsp)
	movq	$0, 1704(%rsp)
	movq	$0, 1712(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 2143(%rsp)
	movb	$0, 2151(%rsp)
	movl	$1179403647, 2136(%rsp)
	movl	$16843334, 2139(%rsp)
	movq	%rbx, 1168(%rsp)
	movq	%rbx, 1160(%rsp)
	movq	%rbx, 1152(%rsp)
	movq	%rbx, 1144(%rsp)
	movq	%rsi, 1728(%rsp)
	movq	%rsi, 1720(%rsp)
	movq	2144(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	2136(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	%r12, 56(%rsp)
	movq	%r15, 64(%rsp)
	movq	$64, 72(%rsp)
	movl	$3670080, 92(%rsp)
	movw	$2, 96(%rsp)
	movq	%r14, 104(%rsp)
	movq	$256, 112(%rsp)
	movq	%r15, 120(%rsp)
	movq	$-1, 128(%rsp)
	movq	$32, 136(%rsp)
	movq	$32, 144(%rsp)
	movabsq	$25769803777, %r14
	movq	%r14, 160(%rsp)
	movq	$384, 168(%rsp)
	leaq	8320(%r15), %rbp
	movq	%rbp, 176(%rsp)
	movq	$-1, 184(%rsp)
	movq	$16, 192(%rsp)
	movq	$4097, 200(%rsp)
	movq	%rsi, %r12
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	callq	*memcpy@GOTPCREL(%rip)
	leaq	1624(%rsp), %rsi
	movl	$112, %edx
	movq	%r13, %rdi
	movq	memcpy@GOTPCREL(%rip), %r14
	callq	*%r14
	movq	$0, 152(%rsp)
	movq	$0, 208(%rsp)
	leaq	1064(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1112(%rsp)
	je	.LBB60_30
	leaq	80(%rsp), %rax
	movl	$0, 8(%rax)
	movq	$0, (%rax)
	movw	$0, 22(%rax)
	movl	$0, 18(%rax)
	movq	$0, 1136(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1624(%rsp)
	movq	$0, 1632(%rsp)
	movq	$0, 1640(%rsp)
	movq	$0, 1648(%rsp)
	movq	$0, 1656(%rsp)
	movq	$0, 1664(%rsp)
	movq	$0, 1672(%rsp)
	movq	$0, 1680(%rsp)
	movq	$0, 1688(%rsp)
	movq	$0, 1696(%rsp)
	movq	$0, 1704(%rsp)
	movq	$0, 1712(%rsp)
	movq	$0, 464(%rax)
	movq	$0, 456(%rax)
	movq	$0, 448(%rax)
	movq	$0, 440(%rax)
	movq	$0, 432(%rax)
	movq	$0, 424(%rax)
	movq	$0, 416(%rax)
	movq	$0, 408(%rax)
	movq	$0, 400(%rax)
	movq	$0, 392(%rax)
	movq	$0, 384(%rax)
	movq	$0, 376(%rax)
	movq	$0, 368(%rax)
	movq	%rax, %r13
	movq	$0, 360(%rax)
	movq	$0, 2143(%rsp)
	movb	$0, 2151(%rsp)
	movl	$1179403647, 2136(%rsp)
	movl	$16843334, 2139(%rsp)
	movq	%rbx, 1144(%rsp)
	movq	%rbx, 1152(%rsp)
	movq	%rbx, 1160(%rsp)
	movq	%rbx, 1168(%rsp)
	movq	%r12, 1720(%rsp)
	movq	%r12, 1728(%rsp)
	movq	2136(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	2144(%rsp), %rax
	movq	%rax, 48(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 56(%rsp)
	movq	%r15, 64(%rsp)
	movq	$64, 72(%rsp)
	movl	$3670080, 92(%rsp)
	movw	$2, 96(%rsp)
	movabsq	$21474836481, %rax
	movq	%rax, 104(%rsp)
	movq	$256, 112(%rsp)
	movq	%r15, 120(%rsp)
	movq	$-1, 128(%rsp)
	movq	$32, 136(%rsp)
	movq	$32, 144(%rsp)
	movabsq	$25769803777, %rax
	movq	%rax, 160(%rsp)
	movq	$384, 168(%rsp)
	movq	%rbp, 176(%rsp)
	movq	$-1, 184(%rsp)
	movq	$16, 192(%rsp)
	movq	$4097, 200(%rsp)
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	leaq	216(%rsp), %rdi
	callq	*%r14
	leaq	1624(%rsp), %rsi
	movl	$112, %edx
	leaq	328(%rsp), %rdi
	callq	*%r14
	movq	$1, 152(%rsp)
	movq	$1, 208(%rsp)
	leaq	1064(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1112(%rsp)
	je	.LBB60_30
	movl	$0, 8(%r13)
	movq	$0, (%r13)
	movw	$0, 22(%r13)
	movl	$0, 18(%r13)
	movq	$0, 1136(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1624(%rsp)
	movq	$0, 1632(%rsp)
	movq	$0, 1640(%rsp)
	movq	$0, 1648(%rsp)
	movq	$0, 1656(%rsp)
	movq	$0, 1664(%rsp)
	movq	$0, 1672(%rsp)
	movq	$0, 1680(%rsp)
	movq	$0, 1688(%rsp)
	movq	$0, 1696(%rsp)
	movq	$0, 1704(%rsp)
	movq	$0, 1712(%rsp)
	movq	$0, 464(%r13)
	movq	$0, 456(%r13)
	movq	$0, 448(%r13)
	movq	$0, 440(%r13)
	movq	$0, 432(%r13)
	movq	$0, 424(%r13)
	movq	$0, 416(%r13)
	movq	$0, 408(%r13)
	movq	$0, 400(%r13)
	movq	$0, 392(%r13)
	movq	$0, 384(%r13)
	movq	$0, 376(%r13)
	movq	$0, 368(%r13)
	movq	$0, 360(%r13)
	movq	$0, 2143(%rsp)
	movb	$0, 2151(%rsp)
	movl	$1179403647, 2136(%rsp)
	movl	$16843334, 2139(%rsp)
	movq	%rbx, 1144(%rsp)
	movq	%rbx, 1152(%rsp)
	movq	%rbx, 1160(%rsp)
	movq	%rbx, 1168(%rsp)
	movq	%r12, 1720(%rsp)
	movq	%r12, 1728(%rsp)
	movq	2136(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	2144(%rsp), %rax
	movq	%rax, 48(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 56(%rsp)
	movq	%r15, 64(%rsp)
	movq	$64, 72(%rsp)
	movl	$3670080, 92(%rsp)
	movw	$2, 96(%rsp)
	movabsq	$21474836481, %rax
	movq	%rax, 104(%rsp)
	movq	$256, 112(%rsp)
	movq	%r15, 120(%rsp)
	movq	$-1, 128(%rsp)
	movq	$32, 136(%rsp)
	movq	$32, 144(%rsp)
	movabsq	$25769803777, %rax
	movq	%rax, 160(%rsp)
	movq	$384, 168(%rsp)
	movq	%rbp, 176(%rsp)
	movq	$-1, 184(%rsp)
	movq	$16, 192(%rsp)
	movq	$4097, 200(%rsp)
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	leaq	216(%rsp), %rdi
	callq	*%r14
	leaq	1624(%rsp), %rsi
	movl	$112, %edx
	leaq	328(%rsp), %rdi
	callq	*%r14
	movq	$4096, 152(%rsp)
	movq	$4096, 208(%rsp)
	leaq	1064(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1112(%rsp)
	je	.LBB60_30
	movl	$0, 8(%r13)
	movq	$0, (%r13)
	movw	$0, 22(%r13)
	movl	$0, 18(%r13)
	movq	$0, 1136(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1624(%rsp)
	movq	$0, 1632(%rsp)
	movq	$0, 1640(%rsp)
	movq	$0, 1648(%rsp)
	movq	$0, 1656(%rsp)
	movq	$0, 1664(%rsp)
	movq	$0, 1672(%rsp)
	movq	$0, 1680(%rsp)
	movq	$0, 1688(%rsp)
	movq	$0, 1696(%rsp)
	movq	$0, 1704(%rsp)
	movq	$0, 1712(%rsp)
	movq	$0, 464(%r13)
	movq	$0, 456(%r13)
	movq	$0, 448(%r13)
	movq	$0, 440(%r13)
	movq	$0, 432(%r13)
	movq	$0, 424(%r13)
	movq	$0, 416(%r13)
	movq	$0, 408(%r13)
	movq	$0, 400(%r13)
	movq	$0, 392(%r13)
	movq	$0, 384(%r13)
	movq	$0, 376(%r13)
	movq	$0, 368(%r13)
	movq	$0, 360(%r13)
	movq	$0, 2143(%rsp)
	movb	$0, 2151(%rsp)
	movl	$1179403647, 2136(%rsp)
	movl	$16843334, 2139(%rsp)
	movq	%rbx, 1144(%rsp)
	movq	%rbx, 1152(%rsp)
	movq	%rbx, 1160(%rsp)
	movq	%rbx, 1168(%rsp)
	movq	%r12, 1720(%rsp)
	movq	%r12, 1728(%rsp)
	movq	2136(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	2144(%rsp), %rax
	movq	%rax, 48(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 56(%rsp)
	movq	%r15, 64(%rsp)
	movq	$64, 72(%rsp)
	movl	$3670080, 92(%rsp)
	movw	$2, 96(%rsp)
	movabsq	$21474836481, %rax
	movq	%rax, 104(%rsp)
	movq	$256, 112(%rsp)
	movq	%r15, 120(%rsp)
	movq	$-1, 128(%rsp)
	movq	$32, 136(%rsp)
	movq	$32, 144(%rsp)
	movabsq	$25769803777, %rax
	movq	%rax, 160(%rsp)
	movq	$384, 168(%rsp)
	movq	%rbp, 176(%rsp)
	movq	$-1, 184(%rsp)
	movq	$16, 192(%rsp)
	movq	$4097, 200(%rsp)
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	leaq	216(%rsp), %rdi
	callq	*%r14
	leaq	1624(%rsp), %rsi
	movl	$112, %edx
	leaq	328(%rsp), %rdi
	callq	*%r14
	movq	$8192, 152(%rsp)
	movq	$8192, 208(%rsp)
	leaq	1064(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1112(%rsp)
	je	.LBB60_30
	movq	$0, 3200(%rsp)
	movl	$0, 3208(%rsp)
	movl	$0, 3218(%rsp)
	movw	$0, 3222(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1136(%rsp)
	movq	$0, 1144(%rsp)
	movq	$0, 1152(%rsp)
	movq	$0, 3664(%rsp)
	movq	$0, 3656(%rsp)
	movq	$0, 3648(%rsp)
	movq	$0, 3640(%rsp)
	movq	$0, 3632(%rsp)
	movq	$0, 3624(%rsp)
	movq	$0, 3616(%rsp)
	movq	$0, 3608(%rsp)
	movq	$0, 3600(%rsp)
	movq	$0, 3592(%rsp)
	movq	$0, 3584(%rsp)
	movq	$0, 3576(%rsp)
	movq	$0, 3568(%rsp)
	movq	$0, 3560(%rsp)
	movq	$0, 1631(%rsp)
	movb	$0, 1639(%rsp)
	movl	$1179403647, 1624(%rsp)
	movl	$16843334, 1627(%rsp)
	movq	%rbx, 144(%rsp)
	movq	%rbx, 136(%rsp)
	movq	%rbx, 128(%rsp)
	movq	%rbx, 120(%rsp)
	movq	%r12, 1168(%rsp)
	movq	%r12, 1160(%rsp)
	movq	1632(%rsp), %rax
	movq	%rax, 3168(%rsp)
	movq	1624(%rsp), %rax
	movq	%rax, 3160(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 3176(%rsp)
	movq	%r15, 3184(%rsp)
	movq	$64, 3192(%rsp)
	movl	$3670080, 3212(%rsp)
	movw	$2, 3216(%rsp)
	movabsq	$21474836481, %rax
	movq	%rax, 3224(%rsp)
	movq	$256, 3232(%rsp)
	movq	%r15, 3240(%rsp)
	movq	$-1, 3248(%rsp)
	movq	$32, 3256(%rsp)
	movq	$32, 3264(%rsp)
	movq	$4096, 3272(%rsp)
	movabsq	$25769803777, %rax
	movq	%rax, 3280(%rsp)
	movq	$384, 3288(%rsp)
	movq	%rbp, 3296(%rsp)
	movq	$-1, 3304(%rsp)
	movq	$4097, 3320(%rsp)
	movq	$4096, 3328(%rsp)
	leaq	3336(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$112, %edx
	callq	*%r14
	leaq	3448(%rsp), %rdi
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	callq	*%r14
	movq	$0, 3312(%rsp)
	leaq	4144(%rsp), %rdi
	leaq	3160(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 4192(%rsp)
	je	.LBB60_30
	movq	%r14, %r13
	leaq	4144(%rsp), %rdi
	callq	_RNCNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid0B5_
	testb	%al, %al
	je	.LBB60_30
	movq	$0, 2176(%rsp)
	movl	$0, 2184(%rsp)
	movl	$0, 2194(%rsp)
	movw	$0, 2198(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1136(%rsp)
	movq	$0, 1144(%rsp)
	movq	$0, 1152(%rsp)
	movq	$0, 2640(%rsp)
	movq	$0, 2632(%rsp)
	movq	$0, 2624(%rsp)
	movq	$0, 2616(%rsp)
	movq	$0, 2608(%rsp)
	movq	$0, 2600(%rsp)
	movq	$0, 2592(%rsp)
	movq	$0, 2584(%rsp)
	movq	$0, 2576(%rsp)
	movq	$0, 2568(%rsp)
	movq	$0, 2560(%rsp)
	movq	$0, 2552(%rsp)
	movq	$0, 2544(%rsp)
	movq	$0, 2536(%rsp)
	movq	$0, 1631(%rsp)
	movb	$0, 1639(%rsp)
	movl	$1179403647, 1624(%rsp)
	movl	$16843334, 1627(%rsp)
	movq	%rbx, 144(%rsp)
	movq	%rbx, 136(%rsp)
	movq	%rbx, 128(%rsp)
	movq	%rbx, 120(%rsp)
	movabsq	$6510615555426900570, %rax
	movq	%rax, 1168(%rsp)
	movq	%rax, 1160(%rsp)
	movq	1632(%rsp), %rax
	movq	%rax, 2144(%rsp)
	movq	1624(%rsp), %rax
	movq	%rax, 2136(%rsp)
	movabsq	$4306960386, %r12
	movq	%r12, 2152(%rsp)
	movq	%r15, 2160(%rsp)
	movq	$64, 2168(%rsp)
	movl	$3670080, 2188(%rsp)
	movw	$2, 2192(%rsp)
	movabsq	$21474836481, %r14
	movq	%r14, 2200(%rsp)
	movq	$256, 2208(%rsp)
	movq	%r15, 2216(%rsp)
	movq	$-1, 2224(%rsp)
	movq	$32, 2232(%rsp)
	movq	$32, 2240(%rsp)
	movq	$4096, 2248(%rsp)
	movl	$1, 2256(%rsp)
	movq	$384, 2264(%rsp)
	movq	%rbp, 2272(%rsp)
	movq	$-1, 2280(%rsp)
	movq	$16, 2288(%rsp)
	movq	$4097, 2296(%rsp)
	movq	$4096, 2304(%rsp)
	leaq	2312(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$112, %edx
	callq	*%r13
	leaq	2424(%rsp), %rdi
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	callq	*%r13
	movl	$4, 2260(%rsp)
	leaq	40(%rsp), %rdi
	leaq	2136(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 88(%rsp)
	je	.LBB60_30
	movq	496(%rsp), %rsi
	cmpq	$9, %rsi
	jae	.LBB60_43
	cmpq	$2, %rsi
	jb	.LBB60_44
	cmpb	$0, 144(%rsp)
	je	.LBB60_32
.LBB60_30:
	xorl	%eax, %eax
.LBB60_31:
	addq	$4616, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB60_32:
	.cfi_def_cfa_offset 4672
	movl	$0, 1672(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1136(%rsp)
	movq	$0, 1144(%rsp)
	movq	$0, 1152(%rsp)
	movq	$0, 2128(%rsp)
	movq	$0, 2120(%rsp)
	movq	$0, 2112(%rsp)
	movq	$0, 2104(%rsp)
	movq	$0, 2096(%rsp)
	movq	$0, 2088(%rsp)
	movq	$0, 2080(%rsp)
	movq	$0, 2072(%rsp)
	movq	$0, 2064(%rsp)
	movq	$0, 2056(%rsp)
	movq	$0, 2048(%rsp)
	movq	$0, 2040(%rsp)
	movq	$0, 2032(%rsp)
	movq	$0, 2024(%rsp)
	movq	$0, 3679(%rsp)
	movb	$0, 3687(%rsp)
	movl	$1179403647, 3672(%rsp)
	movl	$16843334, 3675(%rsp)
	movq	%rbx, 144(%rsp)
	movq	%rbx, 136(%rsp)
	movq	%rbx, 128(%rsp)
	movq	%rbx, 120(%rsp)
	movabsq	$6510615555426900570, %rbp
	movq	%rbp, 1168(%rsp)
	movq	%rbp, 1160(%rsp)
	movq	3680(%rsp), %rax
	movq	%rax, 1632(%rsp)
	movq	3672(%rsp), %rax
	movq	%rax, 1624(%rsp)
	movq	%r12, 1640(%rsp)
	movq	%r15, 1648(%rsp)
	movq	$64, 1656(%rsp)
	movl	$3670080, 1676(%rsp)
	movw	$2, 1680(%rsp)
	movq	%r14, 1688(%rsp)
	movq	$256, 1696(%rsp)
	movq	%r15, 1704(%rsp)
	movq	$-1, 1712(%rsp)
	movq	$32, 1720(%rsp)
	movq	$32, 1728(%rsp)
	movq	$4096, 1736(%rsp)
	movabsq	$25769803777, %r12
	movq	%r12, 1744(%rsp)
	movq	$384, 1752(%rsp)
	leaq	8320(%r15), %r14
	movq	%r14, 1760(%rsp)
	movq	$-1, 1768(%rsp)
	movq	$16, 1776(%rsp)
	movq	$4097, 1784(%rsp)
	movq	$4096, 1792(%rsp)
	leaq	1800(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$112, %edx
	callq	*%r13
	leaq	1912(%rsp), %rdi
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	callq	*%r13
	movq	$-1, 1664(%rsp)
	movl	$-1, 1682(%rsp)
	movw	$-1, 1686(%rsp)
	leaq	40(%rsp), %rdi
	leaq	1624(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 88(%rsp)
	je	.LBB60_30
	movq	$0, 1104(%rsp)
	movl	$0, 1112(%rsp)
	movl	$0, 1122(%rsp)
	movw	$0, 1126(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 3672(%rsp)
	movq	$0, 3680(%rsp)
	movq	$0, 3688(%rsp)
	movq	$0, 3696(%rsp)
	movq	$0, 3704(%rsp)
	movq	$0, 3712(%rsp)
	movq	$0, 3720(%rsp)
	movq	$0, 3728(%rsp)
	movq	$0, 3736(%rsp)
	movq	$0, 3744(%rsp)
	movq	$0, 3752(%rsp)
	movq	$0, 3760(%rsp)
	movq	$0, 1568(%rsp)
	movq	$0, 1560(%rsp)
	movq	$0, 1552(%rsp)
	movq	$0, 1544(%rsp)
	movq	$0, 1536(%rsp)
	movq	$0, 1528(%rsp)
	movq	$0, 1520(%rsp)
	movq	$0, 1512(%rsp)
	movq	$0, 1504(%rsp)
	movq	$0, 1496(%rsp)
	movq	$0, 1488(%rsp)
	movq	$0, 1480(%rsp)
	movq	$0, 1472(%rsp)
	movq	$0, 1464(%rsp)
	movq	$0, 15(%rsp)
	movb	$0, 23(%rsp)
	movl	$1179403647, 8(%rsp)
	movl	$16843334, 11(%rsp)
	movq	%rbx, 144(%rsp)
	movq	%rbx, 136(%rsp)
	movq	%rbx, 128(%rsp)
	movq	%rbx, 120(%rsp)
	movq	%rbp, 3776(%rsp)
	movq	%rbp, 3768(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 1072(%rsp)
	movq	8(%rsp), %rax
	movq	%rax, 1064(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 1080(%rsp)
	movq	%r15, 1088(%rsp)
	movq	$64, 1096(%rsp)
	movl	$3670080, 1116(%rsp)
	movabsq	$21474836481, %rax
	movq	%rax, 1128(%rsp)
	movq	$256, 1136(%rsp)
	movq	%r15, 1144(%rsp)
	movq	$-1, 1152(%rsp)
	movq	$32, 1160(%rsp)
	movq	$4096, 1176(%rsp)
	movq	%r12, 1184(%rsp)
	movq	$384, 1192(%rsp)
	movq	%r14, 1200(%rsp)
	movq	$-1, 1208(%rsp)
	movq	$16, 1216(%rsp)
	movq	$4097, 1224(%rsp)
	movq	$4096, 1232(%rsp)
	leaq	1240(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$112, %edx
	callq	*%r13
	leaq	1352(%rsp), %rdi
	leaq	3672(%rsp), %rsi
	movl	$112, %edx
	callq	*%r13
	movw	$1, 1120(%rsp)
	movq	$1048320, 1168(%rsp)
	leaq	40(%rsp), %rdi
	leaq	1064(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 88(%rsp)
	je	.LBB60_30
	cmpq	$256, 504(%rsp)
	jne	.LBB60_30
	movq	496(%rsp), %rsi
	cmpq	$9, %rsi
	jae	.LBB60_43
	testq	%rsi, %rsi
	je	.LBB60_45
	leaq	1048320(%r15), %rax
	cmpq	%rax, 80(%rsp)
	movabsq	$21474836481, %rcx
	movabsq	$4306960386, %rdx
	jne	.LBB60_30
	movq	$0, 31(%rsp)
	movb	$0, 39(%rsp)
	movl	$1179403647, 24(%rsp)
	movl	$16843334, 27(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
	movq	$0, 960(%rsp)
	movq	$0, 968(%rsp)
	movq	$0, 976(%rsp)
	movq	$0, 984(%rsp)
	movq	$0, 992(%rsp)
	movq	$0, 1000(%rsp)
	movq	$0, 1008(%rsp)
	movq	$0, 1016(%rsp)
	movq	$0, 1024(%rsp)
	movq	$0, 1032(%rsp)
	movq	$0, 1040(%rsp)
	movq	$0, 1048(%rsp)
	movq	$0, 1056(%rsp)
	movq	24(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	32(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	%rdx, 56(%rsp)
	movq	$64, 72(%rsp)
	movabsq	$15762873573703680, %rax
	movq	%rax, 88(%rsp)
	movq	$0, 80(%rsp)
	movl	$0, 98(%rsp)
	movw	$0, 102(%rsp)
	movw	$16, 96(%rsp)
	leaq	704(%r15), %rax
	movq	%rax, 64(%rsp)
	movq	%rcx, 104(%rsp)
	movq	$960, 112(%rsp)
	movq	%rax, 120(%rsp)
	movq	$-1, 128(%rsp)
	movq	$16, 136(%rsp)
	movq	$16, 144(%rsp)
	movq	$4096, 152(%rsp)
	movabsq	$17179869185, %rax
	movq	%rax, 160(%rsp)
	movq	$0, 168(%rsp)
	leaq	7936(%r15), %rcx
	movq	%rcx, 176(%rsp)
	movq	$-1, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$4096, 200(%rsp)
	movq	$4096, 208(%rsp)
	movq	%rax, 216(%rsp)
	movq	$0, 224(%rsp)
	leaq	16128(%r15), %rcx
	movq	%rcx, 232(%rsp)
	movq	$-1, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$4096, 256(%rsp)
	movq	$4096, 264(%rsp)
	movq	%rax, 272(%rsp)
	movq	$0, 280(%rsp)
	leaq	24320(%r15), %rcx
	movq	%rcx, 288(%rsp)
	movq	$-1, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$4096, 312(%rsp)
	movq	$4096, 320(%rsp)
	movq	%rax, 328(%rsp)
	movq	$0, 336(%rsp)
	leaq	32512(%r15), %rcx
	movq	%rcx, 344(%rsp)
	movq	$-1, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$4096, 368(%rsp)
	movq	$4096, 376(%rsp)
	movq	%rax, 384(%rsp)
	movq	$0, 392(%rsp)
	leaq	40704(%r15), %rcx
	movq	%rcx, 400(%rsp)
	movq	$-1, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$4096, 424(%rsp)
	movq	$4096, 432(%rsp)
	movq	%rax, 440(%rsp)
	movq	$0, 448(%rsp)
	leaq	48896(%r15), %rcx
	movq	%rcx, 456(%rsp)
	movq	$-1, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$4096, 480(%rsp)
	movq	$4096, 488(%rsp)
	movq	%rax, 496(%rsp)
	movq	$0, 504(%rsp)
	addq	$57088, %r15
	movq	%r15, 512(%rsp)
	movq	$-1, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$4096, 536(%rsp)
	movq	$4096, 544(%rsp)
	movl	$4294967295, %eax
	movq	%rax, 604(%rsp)
	movq	$-1, 596(%rsp)
	movq	$-1, 588(%rsp)
	movq	$-1, 580(%rsp)
	movq	$-1, 572(%rsp)
	movq	$-1, 564(%rsp)
	movq	$-1, 556(%rsp)
	movl	$0, 552(%rsp)
	movq	$-1, 612(%rsp)
	movq	$-1, 620(%rsp)
	movq	$-1, 628(%rsp)
	movq	$-1, 636(%rsp)
	movq	$-1, 644(%rsp)
	movq	$-1, 652(%rsp)
	movl	$-1, 660(%rsp)
	movq	$-1, 668(%rsp)
	movq	$-1, 676(%rsp)
	movq	$-1, 684(%rsp)
	movq	$-1, 692(%rsp)
	movq	$-1, 700(%rsp)
	movq	$-1, 708(%rsp)
	movl	$-1, 716(%rsp)
	movl	$0, 664(%rsp)
	movq	%rax, 772(%rsp)
	movq	$-1, 764(%rsp)
	movq	$-1, 756(%rsp)
	movq	$-1, 748(%rsp)
	movq	$-1, 740(%rsp)
	movq	$-1, 732(%rsp)
	movq	$-1, 724(%rsp)
	movl	$0, 720(%rsp)
	movl	$-1, 828(%rsp)
	movq	$-1, 820(%rsp)
	movq	$-1, 812(%rsp)
	movq	$-1, 804(%rsp)
	movq	$-1, 796(%rsp)
	movq	$-1, 788(%rsp)
	movq	$-1, 780(%rsp)
	movl	$-1, 884(%rsp)
	movq	$-1, 876(%rsp)
	movq	$-1, 868(%rsp)
	movq	$-1, 860(%rsp)
	movq	$-1, 852(%rsp)
	movq	$-1, 844(%rsp)
	movq	$-1, 836(%rsp)
	movl	$0, 832(%rsp)
	movl	$-1, 940(%rsp)
	movq	$-1, 932(%rsp)
	movq	$-1, 924(%rsp)
	movq	$-1, 916(%rsp)
	movq	$-1, 908(%rsp)
	movq	$-1, 900(%rsp)
	movq	$-1, 892(%rsp)
	movl	$0, 888(%rsp)
	movl	$-1, 996(%rsp)
	movq	$-1, 988(%rsp)
	movq	$-1, 980(%rsp)
	movq	$-1, 972(%rsp)
	movq	$-1, 964(%rsp)
	movq	$-1, 956(%rsp)
	movq	$-1, 948(%rsp)
	movl	$0, 944(%rsp)
	leaq	3672(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$1024, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3720(%rsp)
	je	.LBB60_30
	movq	4128(%rsp), %rsi
	cmpq	$9, %rsi
	jae	.LBB60_43
	cmpq	$8, %rsi
	jne	.LBB60_30
	cmpq	$8, 4136(%rsp)
	jne	.LBB60_30
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movabsq	$27455186257, %rax
	movq	%rax, 552(%rsp)
	movq	$16, 600(%rsp)
	leaq	3672(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$1024, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3720(%rsp)
	setne	%al
	jmp	.LBB60_31
.LBB60_43:
	movl	$8, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB60_44:
	movl	$1, %edi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.LBB60_45:
	xorl	%edi, %edi
	xorl	%esi, %esi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.Lfunc_end60:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid, .Lfunc_end60-_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid
	.cfi_endproc

	.section	.text._RNCNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid0B5_,"ax",@progbits
	.prefalign	4, .Lfunc_end61, nop
	.type	_RNCNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid0B5_,@function
_RNCNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid0B5_:
.Lfunc_begin61:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	456(%rdi), %rsi
	cmpq	$9, %rsi
	jae	.LBB61_3
	cmpq	$2, %rsi
	jb	.LBB61_2
	movq	80(%rdi), %rax
	xorq	$4097, %rax
	orq	64(%rdi), %rax
	sete	%al
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB61_3:
	.cfi_def_cfa_offset 16
	movl	$8, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB61_2:
	movl	$1, %edi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.Lfunc_end61:
	.size	_RNCNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid0B5_, .Lfunc_end61-_RNCNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid0B5_
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests9malformed,"ax",@progbits
	.prefalign	4, .Lfunc_end62, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests9malformed,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests9malformed:
.Lfunc_begin62:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$984, %rsp
	.cfi_def_cfa_offset 5136
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movabsq	$4294967552, %r13
	movq	$0, 552(%rsp)
	movl	$0, 560(%rsp)
	movl	$0, 570(%rsp)
	movw	$0, 574(%rsp)
	movq	$0, 1024(%rsp)
	movq	$0, 1032(%rsp)
	movq	$0, 1040(%rsp)
	movq	$0, 1048(%rsp)
	movq	$0, 1056(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 1016(%rsp)
	movq	$0, 1008(%rsp)
	movq	$0, 1000(%rsp)
	movq	$0, 992(%rsp)
	movq	$0, 984(%rsp)
	movq	$0, 976(%rsp)
	movq	$0, 968(%rsp)
	movq	$0, 960(%rsp)
	movq	$0, 952(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 928(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 912(%rsp)
	movq	$0, 2055(%rsp)
	movb	$0, 2063(%rsp)
	movl	$16843334, 2051(%rsp)
	movl	$1179403647, 2048(%rsp)
	movabsq	$-6510615555426900571, %rax
	movq	%rax, 1128(%rsp)
	movq	%rax, 1120(%rsp)
	movq	%rax, 1112(%rsp)
	movq	%rax, 1104(%rsp)
	movabsq	$6510615555426900570, %rax
	movq	%rax, 104(%rsp)
	movq	%rax, 96(%rsp)
	movq	2056(%rsp), %rax
	movq	%rax, 520(%rsp)
	movq	2048(%rsp), %rax
	movq	%rax, 512(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 528(%rsp)
	movq	%r13, 536(%rsp)
	movq	$64, 544(%rsp)
	movl	$3670080, 564(%rsp)
	movw	$2, 568(%rsp)
	movabsq	$21474836481, %rbp
	movq	%rbp, 576(%rsp)
	movq	$256, 584(%rsp)
	movq	%r13, 592(%rsp)
	movq	$-1, 600(%rsp)
	movq	$32, 608(%rsp)
	movq	$32, 616(%rsp)
	movq	$4096, 624(%rsp)
	movabsq	$25769803777, %rax
	movq	%rax, 632(%rsp)
	movq	$384, 640(%rsp)
	leaq	8320(%r13), %rax
	movq	%rax, 648(%rsp)
	movq	$-1, 656(%rsp)
	movq	$16, 664(%rsp)
	movq	$4097, 672(%rsp)
	movq	$4096, 680(%rsp)
	leaq	688(%rsp), %rdi
	leaq	1024(%rsp), %rbx
	movq	memcpy@GOTPCREL(%rip), %r12
	movl	$112, %edx
	movq	%rbx, %rsi
	callq	*%r12
	leaq	800(%rsp), %rdi
	movq	%rsp, %rsi
	movl	$112, %edx
	callq	*%r12
	xorl	%r14d, %r14d
	leaq	512(%rsp), %r15
	.p2align	4
.LBB62_1:
	movq	%rbx, %rdi
	movq	%r15, %rsi
	movq	%r14, %rdx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1072(%rsp)
	jne	.LBB62_11
	incq	%r14
	cmpq	$400, %r14
	jne	.LBB62_1
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$0, 1024(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$1, 1028(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$2, 1029(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$0, 1030(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$3, 1031(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$1, 1032(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$1, 1033(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$1, 1039(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$3, 1040(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$62, 1042(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$63, 1076(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$55, 1078(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$0, 1080(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$17, 1080(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$-1, 1080(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$0, 1044(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$1, 1072(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$2, 1088(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$3, 1088(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$6, 1088(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$7, 1088(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$-1, 1088(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$0, 1092(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$1, 1092(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$2, 1092(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$3, 1092(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$7, 1092(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$-2147483643, 1092(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	je	.LBB62_35
.LBB62_11:
	xorl	%eax, %eax
.LBB62_12:
	addq	$5080, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB62_35:
	.cfi_def_cfa_offset 5136
	movq	$0, 2048(%rsp)
	movq	$21, 2056(%rsp)
	movq	$32, 2064(%rsp)
	movq	$0, 2072(%rsp)
	movq	$32, 2080(%rsp)
	movq	$63, 2088(%rsp)
	movq	$32, 2096(%rsp)
	movq	$-1, 2104(%rsp)
	movq	$72, 2112(%rsp)
	movq	$-1, 2120(%rsp)
	movq	$72, 2128(%rsp)
	movq	$257, 2136(%rsp)
	movq	$96, 2144(%rsp)
	movq	$33, 2152(%rsp)
	movq	$96, 2160(%rsp)
	movq	$-1, 2168(%rsp)
	movq	$104, 2176(%rsp)
	movq	$0, 2184(%rsp)
	movq	$104, 2192(%rsp)
	movq	$-1, 2200(%rsp)
	movq	$80, 2208(%rsp)
	movq	$256, 2216(%rsp)
	movq	$80, 2224(%rsp)
	leaq	1048576(%r13), %rax
	movq	%rax, 2232(%rsp)
	movq	$80, 2240(%rsp)
	movq	$-256, 2248(%rsp)
	movq	$112, 2256(%rsp)
	movq	$3, 2264(%rsp)
	movq	$112, 2272(%rsp)
	movabsq	$8589934592, %rax
	movq	%rax, 2280(%rsp)
	movq	$136, 2288(%rsp)
	leaq	128(%r13), %rax
	movq	%rax, 2296(%rsp)
	movq	$152, 2304(%rsp)
	movq	$-1, 2312(%rsp)
	movq	$160, 2320(%rsp)
	movq	$-1, 2328(%rsp)
	movq	$24, 2336(%rsp)
	leaq	1(%r13), %rax
	movq	%rax, 2344(%rsp)
	movq	$24, 2352(%rsp)
	leaq	32(%r13), %rax
	movq	%rax, 2360(%rsp)
	movq	$24, 2368(%rsp)
	leaq	8320(%r13), %rax
	movq	%rax, 2376(%rsp)
	movq	$24, 2384(%rsp)
	movq	$-4, 2392(%rsp)
	xorl	%r15d, %r15d
.LBB62_36:
	movq	2064(%rsp,%r15), %r14
	movq	2072(%rsp,%r15), %rbx
	movl	$512, %edx
	leaq	1024(%rsp), %rdi
	leaq	512(%rsp), %rsi
	callq	*%r12
	cmpq	$505, %r14
	jae	.LBB62_50
	movq	%rbx, 1024(%rsp,%r14)
	movl	$512, %edx
	movq	%rsp, %rdi
	leaq	1024(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	addq	$16, %r15
	cmpq	$336, %r15
	jne	.LBB62_36
	leaq	3544(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	$-1, 3640(%rsp)
	movq	$-1, 3648(%rsp)
	leaq	1024(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1072(%rsp)
	jne	.LBB62_11
	leaq	4056(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	$31, 4152(%rsp)
	leaq	28(%r13), %rax
	movq	%rax, 4080(%rsp)
	leaq	1024(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1072(%rsp)
	jne	.LBB62_11
	leaq	2560(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	leaq	576(%rsp), %rdx
	movq	(%rdx), %rax
	movq	8(%rdx), %rcx
	movq	%rax, 2680(%rsp)
	movq	%rcx, 2688(%rsp)
	movq	16(%rdx), %rax
	movq	%rax, 2696(%rsp)
	movq	24(%rdx), %rax
	movq	%rax, 2704(%rsp)
	movq	32(%rdx), %rax
	movq	%rax, 2712(%rsp)
	movq	40(%rdx), %rax
	movq	%rax, 2720(%rsp)
	movq	48(%rdx), %rax
	movq	%rax, 2728(%rsp)
	movq	56(%rdx), %rax
	movq	64(%rdx), %rcx
	movq	%rax, 2624(%rsp)
	movq	%rcx, 2632(%rsp)
	movq	72(%rdx), %rax
	movq	%rax, 2640(%rsp)
	movq	80(%rdx), %rax
	movq	%rax, 2648(%rsp)
	movq	88(%rdx), %rax
	movq	%rax, 2656(%rsp)
	movq	96(%rdx), %rax
	movq	%rax, 2664(%rsp)
	movq	104(%rdx), %rax
	movq	%rax, 2672(%rsp)
	leaq	1024(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1072(%rsp)
	jne	.LBB62_11
	leaq	4568(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$0, 4632(%rsp)
	movl	$0, 4688(%rsp)
	leaq	1024(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1072(%rsp)
	jne	.LBB62_11
	leaq	2048(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	$64, 2152(%rsp)
	leaq	32(%r13), %rax
	movq	%rax, 2072(%rsp)
	leaq	1024(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1072(%rsp)
	jne	.LBB62_11
	leaq	1592(%rsp), %rdi
	movl	$456, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	568(%rsp), %rax
	movq	%rax, 1080(%rsp)
	movq	512(%rsp), %rax
	movq	520(%rsp), %rcx
	movq	%rax, 1024(%rsp)
	movq	%rcx, 1032(%rsp)
	movq	528(%rsp), %rax
	movq	%rax, 1040(%rsp)
	movq	544(%rsp), %rax
	movq	%rax, 1056(%rsp)
	movq	552(%rsp), %rax
	movq	%rax, 1064(%rsp)
	movq	560(%rsp), %rax
	movq	%rax, 1072(%rsp)
	movw	$9, 1080(%rsp)
	leaq	704(%r13), %rax
	movq	%rax, 1048(%rsp)
	movq	%rbp, 1088(%rsp)
	movq	$960, 1096(%rsp)
	movq	%rax, 1104(%rsp)
	movq	$-1, 1112(%rsp)
	movq	$16, 1120(%rsp)
	movq	$16, 1128(%rsp)
	movq	$4096, 1136(%rsp)
	movabsq	$17179869185, %rax
	movq	%rax, 1144(%rsp)
	movq	$0, 1152(%rsp)
	leaq	7936(%r13), %rcx
	movq	%rcx, 1160(%rsp)
	movq	$-1, 1168(%rsp)
	movq	$0, 1176(%rsp)
	movq	$4096, 1184(%rsp)
	movq	$4096, 1192(%rsp)
	movq	%rax, 1200(%rsp)
	movq	$0, 1208(%rsp)
	leaq	16128(%r13), %rcx
	movq	%rcx, 1216(%rsp)
	movq	$-1, 1224(%rsp)
	movq	$0, 1232(%rsp)
	movq	$4096, 1240(%rsp)
	movq	$4096, 1248(%rsp)
	movq	%rax, 1256(%rsp)
	movq	$0, 1264(%rsp)
	leaq	24320(%r13), %rcx
	movq	%rcx, 1272(%rsp)
	movq	$-1, 1280(%rsp)
	movq	$0, 1288(%rsp)
	movq	$4096, 1296(%rsp)
	movq	$4096, 1304(%rsp)
	movq	%rax, 1312(%rsp)
	movq	$0, 1320(%rsp)
	leaq	32512(%r13), %rcx
	movq	%rcx, 1328(%rsp)
	movq	$-1, 1336(%rsp)
	movq	$0, 1344(%rsp)
	movq	$4096, 1352(%rsp)
	movq	$4096, 1360(%rsp)
	movq	%rax, 1368(%rsp)
	movq	$0, 1376(%rsp)
	leaq	40704(%r13), %rcx
	movq	%rcx, 1384(%rsp)
	movq	$-1, 1392(%rsp)
	movq	$0, 1400(%rsp)
	movq	$4096, 1408(%rsp)
	movq	$4096, 1416(%rsp)
	movq	%rax, 1424(%rsp)
	movq	$0, 1432(%rsp)
	leaq	48896(%r13), %rcx
	movq	%rcx, 1440(%rsp)
	movq	$-1, 1448(%rsp)
	movq	$0, 1456(%rsp)
	movq	$4096, 1464(%rsp)
	movq	$4096, 1472(%rsp)
	movq	%rax, 1480(%rsp)
	movq	$0, 1488(%rsp)
	leaq	57088(%r13), %rcx
	movq	%rcx, 1496(%rsp)
	movq	$-1, 1504(%rsp)
	movq	$0, 1512(%rsp)
	movq	$4096, 1520(%rsp)
	movq	$4096, 1528(%rsp)
	movq	%rax, 1536(%rsp)
	movq	$0, 1544(%rsp)
	addq	$65280, %r13
	movq	%r13, 1552(%rsp)
	movq	$-1, 1560(%rsp)
	movq	$0, 1568(%rsp)
	movq	$4096, 1576(%rsp)
	movq	$4096, 1584(%rsp)
	movq	%rsp, %rdi
	leaq	1024(%rsp), %rsi
	movl	$1024, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB62_11
	movq	%rsp, %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$3, 56(%rsp)
	movabsq	$31750153553, %rax
	movq	%rax, 176(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$16, 224(%rsp)
	leaq	3072(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3120(%rsp)
	jne	.LBB62_11
	movq	%rsp, %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$3, 56(%rsp)
	movabsq	$27455186257, %r14
	movq	%r14, 176(%rsp)
	movq	$1, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$16, 224(%rsp)
	leaq	3072(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3120(%rsp)
	jne	.LBB62_11
	movq	%rsp, %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$3, 56(%rsp)
	movq	%r14, 176(%rsp)
	movq	$0, 208(%rsp)
	movq	$1, 216(%rsp)
	movq	$16, 224(%rsp)
	leaq	3072(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3120(%rsp)
	jne	.LBB62_11
	leaq	208(%rsp), %r15
	movq	%rsp, %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$3, 56(%rsp)
	movq	%r14, 176(%rsp)
	movq	$0, (%r15)
	movq	$0, 8(%r15)
	movq	$3, 224(%rsp)
	leaq	3072(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3120(%rsp)
	jne	.LBB62_11
	movq	%rsp, %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$4, 56(%rsp)
	movq	%r14, 176(%rsp)
	movq	%r14, 232(%rsp)
	leaq	3072(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3120(%rsp)
	sete	%al
	jmp	.LBB62_12
.LBB62_50:
	leaq	8(%r14), %rsi
	movl	$512, %edx
	movq	%r14, %rdi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end62:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests9malformed, .Lfunc_end62-_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests9malformed
	.cfi_endproc

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.0,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.0,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.0:
	.ascii	"write_protect"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.0, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.1,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.1,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.1:
	.ascii	"nx"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.1, 2

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.2,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.2,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.2:
	.ascii	"user_execute_protect"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.2, 20

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.3,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.3,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.3:
	.ascii	"user_access_protect"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.3, 19

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.4,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.4,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.4:
	.ascii	"wx"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.4, 2

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.5,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.5,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.5:
	.ascii	"stack_guard"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.5, 11

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.6,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.6,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.6:
	.ascii	"null_guard"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.6, 10

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.7,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.7,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.7:
	.ascii	"checked_range"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.7, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.8,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.8,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.8:
	.ascii	"monitor_bounds"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.8, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.9,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9:
	.ascii	"cap_authority"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.10,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.10,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.10:
	.ascii	"cap_limits"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.10, 10

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.11,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.11,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.11:
	.ascii	"cap_lifetime"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.11, 12

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.12,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.12,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.12:
	.ascii	"cap_generation"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.12, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.13,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.13,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.13:
	.ascii	"boot_memory_valid"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.13, 17

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.14,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.14,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.14:
	.ascii	"boot_memory_malformed"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.14, 21

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.15,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.15,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.15:
	.ascii	"cpu_topology_valid"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.15, 18

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.16,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.16,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.16:
	.ascii	"cpu_topology_malformed"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.16, 22

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.17,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.17,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.17:
	.ascii	"cpu_topology_live"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.17, 17

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.18,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.18,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.18:
	.ascii	"elf_valid"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.18, 9

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.19,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.19,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.19:
	.ascii	"elf_malformed"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.19, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.20,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.20,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.20:
	.ascii	"frame_ranges"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.20, 12

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.21,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.21:
	.ascii	"frame_boundaries"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.21, 16

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.22,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.22,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.22:
	.ascii	"frame_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.22, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.23,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.23,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.23:
	.ascii	"heap_blocks"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.23, 11

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.24,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.24,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.24:
	.ascii	"heap_values"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.24, 11

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.25,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.25,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.25:
	.ascii	"event_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.25, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.26,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.26,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.26:
	.ascii	"mutex_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.26, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.27,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.27,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.27:
	.ascii	"mutex_lifetime"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.27, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.28,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.28,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.28:
	.ascii	"mutex_workers"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.28, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.29,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.29,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.29:
	.ascii	"thread_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.29, 15

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.30,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.30,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.30:
	.ascii	"thread_limits"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.30, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.31,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.31,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.31:
	.ascii	"thread_core"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.31, 11

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.32,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.32,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.32:
	.ascii	"timer_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.32, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.33,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.33,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.33:
	.ascii	"fault_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.33, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.34,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.34:
	.ascii	"mapping_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.34, 16

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.35,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.35,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.35:
	.ascii	"mapping_limits"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.35, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.36,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.36:
	.ascii	"mapping_hardware"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.36, 16

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.37,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.37,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.37:
	.ascii	"cpu_local_state"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.37, 15

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.38,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.38,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.38:
	.ascii	"gic_ownership"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.38, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.39,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.39:
	.ascii	"secondary_memory"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.39, 16

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.40,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.40,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.40:
	.ascii	"cap_orderings"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.40, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.41,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.41:
	.ascii	"HMTEST BEGIN 41\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.41, 16

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.42,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.42,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.42:
	.ascii	"HMTEST END 41\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.42, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.46,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.46,"a",@progbits
	.p2align	3, 0x0
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.46:
	.asciz	"\001\000\000\000\000\000\000\000\035\000\000\000\000\000\000\000\003\000\000\000\000\000\000"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.46, 24

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.47,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.47,"a",@progbits
	.p2align	3, 0x0
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.47:
	.asciz	"\001\000\000\000\000\000\000\000\035\000\000\000\000\000\000\000)\000\000\000\000\000\000"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.47, 24

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.48,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.48,"a",@progbits
	.p2align	3, 0x0
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.48:
	.asciz	"5\000\000\000\000\000\000\000\035\000\000\000\000\000\000\000)\000\000\000\000\000\000"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.48, 24

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.49,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.49,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.49:
	.ascii	"CAPMODEL failed ordering:"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.49, 25

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.50,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.50,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.50:
	.ascii	"revoke"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.50, 6

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.51,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.51,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.51:
	.ascii	"cancel"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.51, 6

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.52,@object
	.section	.rodata.cst8,"aM",@progbits,8
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.52:
	.ascii	"complete"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.52, 8

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.53,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.53,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.53:
	.ascii	"release"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.53, 7

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.54,"a",@progbits
	.p2align	3, 0x0
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54:
	.quad	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.50
	.asciz	"\006\000\000\000\000\000\000"
	.quad	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.51
	.asciz	"\006\000\000\000\000\000\000"
	.quad	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.52
	.asciz	"\b\000\000\000\000\000\000"
	.quad	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.53
	.asciz	"\007\000\000\000\000\000\000"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54, 64

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.57,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.57,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.57:
	.ascii	"hematite: x86_64 Rust kernel entered via PVH\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.57, 45

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.0,@object
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.0:
	.zero	16
	.byte	2
	.zero	7
	.asciz	"\001\000\000"
	.zero	4
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.0, 32

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.1,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.1,"a",@progbits
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.1:
	.zero	25
	.byte	2
	.zero	6
	.asciz	"\001\000\000"
	.zero	4
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.1, 40

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.2,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.2,"a",@progbits
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.2:
	.zero	24
	.byte	2
	.zero	7
	.asciz	"\001\000\000"
	.zero	4
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.2, 40

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.15,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.15,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.15:
	.ascii	"#address-cells"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.15, 14

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.16,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.16,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.16:
	.ascii	"#size-cells"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.16, 11

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.17,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.17,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.17:
	.asciz	"#address-cells\000#size-cells\000device_type\000reg\000status\000ranges\000size\000alignment\000alloc-ranges\000no-map\000reusable\000compatible"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.17, 112

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.18,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.18,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.18:
	.ascii	"memory@40000000"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.18, 15

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.19,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.19,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.19:
	.ascii	"device_type"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.19, 11

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.20,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.a24a8216ad3259fdc76a412b00af4a98.20:
	.asciz	"memory"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.20, 7

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.21,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.21,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.21:
	.ascii	"reg"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.21, 3

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.23,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.23,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.23:
	.ascii	"cpu@0"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.23, 5

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.24,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.24,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.24:
	.ascii	"cpu@1"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.24, 5

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.25,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.25,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.25:
	.ascii	"cpu@2"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.25, 5

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.26,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.a24a8216ad3259fdc76a412b00af4a98.26:
	.asciz	"cpu"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.26, 4

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.27,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.27,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.27:
	.ascii	"enable-method"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.27, 13

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.28,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.a24a8216ad3259fdc76a412b00af4a98.28:
	.asciz	"psci"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.28, 5

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.30,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.a24a8216ad3259fdc76a412b00af4a98.30:
	.ascii	"cpus"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.30, 4

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.32,@object
.Lanon.a24a8216ad3259fdc76a412b00af4a98.32:
	.ascii	"psci"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.32, 4

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.33,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.33,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.33:
	.ascii	"compatible"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.33, 10

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.34,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.34,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.34:
	.asciz	"arm,psci-1.0\000arm,psci-0.2\000arm,psci"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.34, 35

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.35,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.35,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.35:
	.ascii	"method"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.35, 6

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.36,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.a24a8216ad3259fdc76a412b00af4a98.36:
	.asciz	"hvc"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.36, 4

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.37,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.37,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.37:
	.ascii	"cpu_on"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.37, 6

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.38,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.38,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.38:
	.ascii	"cpu_off"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.38, 7

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.39,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.39,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.39:
	.ascii	"cpu_suspend"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.39, 11

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.40,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.40,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.40:
	.ascii	"migrate"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.40, 7

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.41,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.41,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.41:
	.asciz	"#address-cells\000#size-cells\000device_type\000reg\000status\000enable-method\000compatible\000method\000cpu_on\000cpu_off\000cpu_suspend\000migrate"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.41, 117

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.42,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.42,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.42:
	.ascii	"cpu"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.42, 3

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.43,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.43,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.43:
	.ascii	"status"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.43, 6

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.46,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.46,"a",@progbits
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.46:
	.quad	1
	.zero	41
	.zero	7
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.46, 56

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.49,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.a24a8216ad3259fdc76a412b00af4a98.49:
	.asciz	"okay"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.49, 5

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.50,@object
.Lanon.a24a8216ad3259fdc76a412b00af4a98.50:
	.asciz	"ok"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.50, 3

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.57,@object
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.57:
	.asciz	"\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.57, 16

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.58,@object
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.58:
	.asciz	"\000\000\000\000\000\000\000\000\002\000\000\000\000\000\000"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.58, 16

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.60,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.60,"a",@progbits
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.60:
	.zero	8
	.zero	8
	.asciz	"\000\004"
	.zero	5
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.60, 24

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.61,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.61,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.61:
	.ascii	"reserved-memory"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.61, 15

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.62,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.62,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.62:
	.ascii	"memory@"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.62, 7

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.63,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.63,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.63:
	.ascii	"arm,psci-0.2"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.63, 12

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.64,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.a24a8216ad3259fdc76a412b00af4a98.64:
	.ascii	"cpu@"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.64, 4

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.65,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.65,"a",@progbits
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.65:
	.zero	8
	.zero	8
	.zero	4
	.zero	4
	.zero	4
	.zero	4
	.zero	144
	.zero	8
	.ascii	"\000\000\000\000\000\000\004"
	.zero	1
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.65, 192

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.66,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.66,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.66:
	.ascii	"cpus@"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.66, 5

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.67,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.67,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.67:
	.ascii	"psci@"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.67, 5

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.69,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.a24a8216ad3259fdc76a412b00af4a98.69:
	.asciz	"disabled"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.69, 9

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.70,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.70,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.70:
	.ascii	"second-root"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.70, 11

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.71,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.71,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.71:
	.ascii	"bus"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.71, 3

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.72,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.72,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.72:
	.zero	15
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.72, 15

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.73,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.a24a8216ad3259fdc76a412b00af4a98.73:
	.ascii	"okay"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.73, 4

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.74,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.74,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.74:
	.ascii	"child"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.74, 5

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.75,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.75,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.75:
	.byte	97
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.75, 1

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.78,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.78,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.78:
	.ascii	"ranges"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.78, 6

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.79,@object
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.79:
	.zero	16
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.79, 16

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.80,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.80,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.80:
	.ascii	"buffer"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.80, 6

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.81,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.a24a8216ad3259fdc76a412b00af4a98.81:
	.ascii	"size"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.81, 4

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.82,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.82,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.82:
	.ascii	"alignment"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.82, 9

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.83,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.83,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.83:
	.ascii	"alloc-ranges"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.83, 12

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.84,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.84,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.84:
	.ascii	"no-map"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.84, 6

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.85,@object
	.section	.rodata.cst8,"aM",@progbits,8
.Lanon.a24a8216ad3259fdc76a412b00af4a98.85:
	.ascii	"reusable"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.85, 8

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.88,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.88,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.88:
	.ascii	"\377\003\t"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.88, 3

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.89,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.a24a8216ad3259fdc76a412b00af4a98.89:
	.asciz	"test,bus"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.89, 9

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.90,@object
	.section	.rodata.cst8,"aM",@progbits,8
.Lanon.a24a8216ad3259fdc76a412b00af4a98.90:
	.ascii	"device@0"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.90, 8

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.91,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.91,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.91:
	.ascii	"memory@50000000"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.91, 15

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.92,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.92,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.92:
	.ascii	"buffer@40002000"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.92, 15

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.93,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.a24a8216ad3259fdc76a412b00af4a98.93:
	.ascii	"outside@90000000"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.93, 16

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.98,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.98,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.98:
	.ascii	"cpu-map"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.98, 7

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.99,@object
	.section	.rodata.cst8,"aM",@progbits,8
.Lanon.a24a8216ad3259fdc76a412b00af4a98.99:
	.ascii	"cluster0"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.99, 8

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.100,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.100,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.100:
	.ascii	"core0"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.100, 5

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.101,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.a24a8216ad3259fdc76a412b00af4a98.101:
	.asciz	"arm,psci-0.2"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.101, 13

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.102,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.102,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.102:
	.ascii	"unrelated"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.102, 9

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.103,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.a24a8216ad3259fdc76a412b00af4a98.103:
	.asciz	"test,device"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.103, 12

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.105,@object
.Lanon.a24a8216ad3259fdc76a412b00af4a98.105:
	.asciz	"device"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.105, 7

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.106,@object
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.106:
	.zero	8
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.106, 8

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.107,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.a24a8216ad3259fdc76a412b00af4a98.107:
	.asciz	"spin-table"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.107, 11

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.108,@object
.Lanon.a24a8216ad3259fdc76a412b00af4a98.108:
	.asciz	"arm,psci"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.108, 9

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.109,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.109,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.109:
	.asciz	"arm,psci-0.2\000"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.109, 14

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.110,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.a24a8216ad3259fdc76a412b00af4a98.110:
	.asciz	"vendor,unknown"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.110, 15

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.111,@object
.Lanon.a24a8216ad3259fdc76a412b00af4a98.111:
	.asciz	"smc"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.111, 4

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.112,@object
.Lanon.a24a8216ad3259fdc76a412b00af4a98.112:
	.asciz	"arm,psci-1.0"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.112, 13

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.113,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.113,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.113:
	.ascii	"legacy-firmware"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.113, 15

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.114,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.114,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.114:
	.ascii	"another-root"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.114, 12

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.115,@object
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.115:
	.asciz	"\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.115, 16

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.116,@object
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.116:
	.asciz	"\001\000\000\000\000\000\000"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.116, 8

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.117,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.117,"a",@progbits
	.p2align	3, 0x0
.Lanon.a24a8216ad3259fdc76a412b00af4a98.117:
	.asciz	"\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\002\000\000\000\000\000\000"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.117, 24

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.122,@object
	.section	.rodata.cst32,"aM",@progbits,32
.Lanon.a24a8216ad3259fdc76a412b00af4a98.122:
	.zero	32,165
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.122, 32

	.type	.Lanon.a24a8216ad3259fdc76a412b00af4a98.125,@object
	.section	.rodata..Lanon.a24a8216ad3259fdc76a412b00af4a98.125,"a",@progbits
.Lanon.a24a8216ad3259fdc76a412b00af4a98.125:
	.ascii	"\177ELF\002\001\001"
	.size	.Lanon.a24a8216ad3259fdc76a412b00af4a98.125, 7

	.section	.debug_abbrev,"",@progbits
	.byte	1
	.byte	17
	.byte	1
	.byte	37
	.byte	14
	.byte	19
	.byte	5
	.byte	3
	.byte	14
	.byte	16
	.byte	23
	.byte	27
	.byte	14
	.byte	17
	.byte	1
	.byte	85
	.byte	23
	.byte	0
	.byte	0
	.byte	2
	.byte	57
	.byte	1
	.byte	3
	.byte	14
	.byte	0
	.byte	0
	.byte	3
	.byte	46
	.byte	0
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	54
	.byte	11
	.byte	63
	.byte	25
	.ascii	"\207\001"
	.byte	25
	.byte	0
	.byte	0
	.byte	4
	.byte	46
	.byte	0
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	54
	.byte	11
	.byte	63
	.byte	25
	.ascii	"\207\001"
	.byte	25
	.byte	0
	.byte	0
	.byte	5
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	6
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	7
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	54
	.byte	11
	.byte	63
	.byte	25
	.byte	0
	.byte	0
	.byte	8
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	9
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	10
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	11
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	12
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	13
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.ascii	"\207\001"
	.byte	25
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	14
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.ascii	"\207\001"
	.byte	25
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	15
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	54
	.byte	11
	.byte	63
	.byte	25
	.ascii	"\207\001"
	.byte	25
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.long	.Ldebug_info_end0-.Ldebug_info_start0
.Ldebug_info_start0:
	.short	4
	.long	.debug_abbrev
	.byte	8
	.byte	1
	.long	.Linfo_string0
	.short	28
	.long	.Linfo_string1
	.long	.Lline_table_start0
	.long	.Linfo_string2
	.quad	0
	.long	.Ldebug_ranges2
	.byte	2
	.long	.Linfo_string3
	.byte	2
	.long	.Linfo_string4
	.byte	3
	.quad	.Lfunc_begin4
	.long	.Lfunc_end4-.Lfunc_begin4
	.byte	1
	.byte	87
	.long	.Linfo_string26
	.long	.Linfo_string27
	.byte	1
	.byte	60
	.byte	3


	.byte	4
	.quad	.Lfunc_begin6
	.long	.Lfunc_end6-.Lfunc_begin6
	.byte	1
	.byte	86
	.long	.Linfo_string30
	.long	.Linfo_string31
	.byte	1
	.short	266
	.byte	3


	.byte	0
	.byte	2
	.long	.Linfo_string5
	.byte	2
	.long	.Linfo_string6
	.byte	3
	.quad	.Lfunc_begin5
	.long	.Lfunc_end5-.Lfunc_begin5
	.byte	1
	.byte	86
	.long	.Linfo_string28
	.long	.Linfo_string29
	.byte	2
	.byte	39
	.byte	3


	.byte	0
	.byte	2
	.long	.Linfo_string13
	.byte	2
	.long	.Linfo_string14
	.byte	5
	.long	.Linfo_string15
	.long	.Linfo_string16
	.byte	7
	.short	2623
	.byte	1
	.byte	0
	.byte	6
	.long	.Linfo_string17
	.long	.Linfo_string18
	.byte	4
	.byte	18
	.byte	1
	.byte	6
	.long	.Linfo_string19
	.long	.Linfo_string20
	.byte	4
	.byte	37
	.byte	1
	.byte	7
	.quad	.Lfunc_begin7
	.long	.Lfunc_end7-.Lfunc_begin7
	.byte	1
	.byte	87
	.long	.Linfo_string32
	.long	.Linfo_string14
	.byte	4
	.byte	53
	.byte	3

	.byte	8
	.long	153
	.long	.Ldebug_ranges0
	.byte	7
	.short	2636
	.byte	9
	.byte	9
	.long	489
	.quad	.Lfunc_begin7
	.long	.Ltmp13-.Lfunc_begin7
	.byte	4
	.byte	71
	.byte	34
	.byte	10
	.long	466
	.quad	.Lfunc_begin7
	.long	.Ltmp13-.Lfunc_begin7
	.byte	6
	.short	1286
	.byte	28
	.byte	0
	.byte	11
	.long	167
	.quad	.Ltmp16
	.long	.Ltmp17-.Ltmp16
	.byte	4
	.byte	91
	.byte	30
	.byte	11
	.long	167
	.quad	.Ltmp18
	.long	.Ltmp19-.Ltmp18
	.byte	4
	.byte	92
	.byte	30
	.byte	12
	.long	179
	.long	.Ldebug_ranges1
	.byte	4
	.byte	106
	.byte	30
	.byte	11
	.long	179
	.quad	.Ltmp22
	.long	.Ltmp23-.Ltmp22
	.byte	4
	.byte	76
	.byte	38
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string21
	.byte	2
	.long	.Linfo_string22
	.byte	2
	.long	.Linfo_string23
	.byte	13
	.long	.Linfo_string24
	.long	.Linfo_string16
	.byte	7
	.short	2623

	.byte	1
	.byte	0
	.byte	14
	.long	.Linfo_string25
	.long	.Linfo_string23
	.byte	3
	.byte	166

	.byte	1
	.byte	0
	.byte	15
	.quad	.Lfunc_begin8
	.long	.Lfunc_end8-.Lfunc_begin8
	.byte	1
	.byte	86
	.long	.Linfo_string33
	.long	.Linfo_string22
	.byte	8
	.short	5588
	.byte	3


	.byte	9
	.long	376
	.quad	.Ltmp32
	.long	.Ltmp33-.Ltmp32
	.byte	3
	.byte	177
	.byte	9
	.byte	10
	.long	362
	.quad	.Ltmp32
	.long	.Ltmp33-.Ltmp32
	.byte	7
	.short	2636
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string7
	.byte	5
	.long	.Linfo_string8
	.long	.Linfo_string9
	.byte	5
	.short	2288
	.byte	1
	.byte	2
	.long	.Linfo_string10
	.byte	2
	.long	.Linfo_string11
	.byte	5
	.long	.Linfo_string12
	.long	.Linfo_string9
	.byte	6
	.short	1277
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
.Ldebug_info_end0:
	.section	.text.unlikely._RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt,"ax",@progbits
.Lsec_end0:
	.section	.text.unlikely._RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail,"ax",@progbits
.Lsec_end1:
	.section	.text.unlikely._RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check,"ax",@progbits
.Lsec_end2:
	.section	.text._RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned,"ax",@progbits
.Lsec_end3:
	.section	.text.unlikely._RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail,"ax",@progbits
.Lsec_end4:
	.section	.debug_aranges,"",@progbits
	.long	108
	.short	2
	.long	.Lcu_begin0
	.byte	8
	.byte	0
	.zero	4,255
	.quad	.Lfunc_begin4
	.quad	.Lsec_end0-.Lfunc_begin4
	.quad	.Lfunc_begin5
	.quad	.Lsec_end1-.Lfunc_begin5
	.quad	.Lfunc_begin6
	.quad	.Lsec_end2-.Lfunc_begin6
	.quad	.Lfunc_begin7
	.quad	.Lsec_end3-.Lfunc_begin7
	.quad	.Lfunc_begin8
	.quad	.Lsec_end4-.Lfunc_begin8
	.quad	0
	.quad	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.quad	.Lfunc_begin7
	.quad	.Ltmp26
	.quad	.Ltmp27
	.quad	.Ltmp28
	.quad	.Ltmp29
	.quad	.Ltmp30
	.quad	0
	.quad	0
.Ldebug_ranges1:
	.quad	.Ltmp25
	.quad	.Ltmp26
	.quad	.Ltmp27
	.quad	.Ltmp28
	.quad	0
	.quad	0
.Ldebug_ranges2:
	.quad	.Lfunc_begin4
	.quad	.Lfunc_end4
	.quad	.Lfunc_begin5
	.quad	.Lfunc_end5
	.quad	.Lfunc_begin6
	.quad	.Lfunc_end6
	.quad	.Lfunc_begin7
	.quad	.Lfunc_end7
	.quad	.Lfunc_begin8
	.quad	.Lfunc_end8
	.quad	0
	.quad	0
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"clang LLVM (rustc version 1.99.0 (b940084d7 2026-09-28))"
.Linfo_string1:
	.asciz	"/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4/library/core/src/lib.rs/@/core.15a23645e69e4fd1-cgu.0"
.Linfo_string2:
	.asciz	"/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4"
.Linfo_string3:
	.asciz	"core"
.Linfo_string4:
	.asciz	"panicking"
.Linfo_string5:
	.asciz	"slice"
.Linfo_string6:
	.asciz	"index"
.Linfo_string7:
	.asciz	"ptr"
.Linfo_string8:
	.asciz	"_RINvNtCs1R9DcZHJAgT_4core3ptr12align_offsethEB4_"
.Linfo_string9:
	.asciz	"align_offset<u8>"
.Linfo_string10:
	.asciz	"const_ptr"
.Linfo_string11:
	.asciz	"{impl#0}"
.Linfo_string12:
	.asciz	"_RNvMNtNtCs1R9DcZHJAgT_4core3ptr9const_ptrPh12align_offsetB6_"
.Linfo_string13:
	.asciz	"memchr"
.Linfo_string14:
	.asciz	"memchr_aligned"
.Linfo_string15:
	.asciz	"_RNvNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned7runtime"
.Linfo_string16:
	.asciz	"runtime"
.Linfo_string17:
	.asciz	"_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr18contains_zero_byte"
.Linfo_string18:
	.asciz	"contains_zero_byte"
.Linfo_string19:
	.asciz	"_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr12memchr_naive"
.Linfo_string20:
	.asciz	"memchr_naive"
.Linfo_string21:
	.asciz	"copy_from_slice_impl"
.Linfo_string22:
	.asciz	"len_mismatch_fail"
.Linfo_string23:
	.asciz	"do_panic"
.Linfo_string24:
	.asciz	"_RNvNvNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail8do_panic7runtime"
.Linfo_string25:
	.asciz	"_RNvNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail8do_panic"
.Linfo_string26:
	.asciz	"_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt"
.Linfo_string27:
	.asciz	"panic_fmt"
.Linfo_string28:
	.asciz	"_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail"
.Linfo_string29:
	.asciz	"slice_index_fail"
.Linfo_string30:
	.asciz	"_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check"
.Linfo_string31:
	.asciz	"panic_bounds_check"
.Linfo_string32:
	.asciz	"_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned"
.Linfo_string33:
	.asciz	"_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail"
	.ident	"rustc version 1.99.0 (b940084d7 2026-09-28)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
