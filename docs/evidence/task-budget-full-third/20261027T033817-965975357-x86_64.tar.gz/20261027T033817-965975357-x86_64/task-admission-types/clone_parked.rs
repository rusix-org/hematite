#![no_std]
#![forbid(unsafe_code)]
use hm_kernel::native::{Session, Admission, TaskAdmission, ParkedSession, Request, Response, Status, Host, CopyError};
struct Empty;
impl Host for Empty {
    fn copy_from_user(&mut self, _: u64, _: &mut [u8]) -> Result<(), CopyError> { Err(CopyError) }
    fn write_console(&mut self, _: &[u8]) {}
}
fn request() -> Request { Request { version: 1, operation: 4, argument: 0, address: 0, length: 0 } }
fn response() -> Response { Response { status: Status::Ok, written: 0 } }
pub fn client(value: ParkedSession) { let _ = value.clone(); }
