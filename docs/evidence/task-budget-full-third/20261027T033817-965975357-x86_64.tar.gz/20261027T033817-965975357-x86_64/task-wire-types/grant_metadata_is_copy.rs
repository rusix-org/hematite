#![no_std]
#![forbid(unsafe_code)]
use hm_kernel::task_wire::{Spawn, Grant, Error};
pub fn client(bytes: &[u8]) -> Result<(Grant, Grant), Error> {
        let grant = Grant::decode(bytes)?; Ok((grant, grant))
    }
