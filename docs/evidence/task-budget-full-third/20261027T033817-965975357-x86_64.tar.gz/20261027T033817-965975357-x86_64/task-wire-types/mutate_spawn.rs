#![no_std]
#![forbid(unsafe_code)]
use hm_kernel::task_wire::{Spawn, Grant, Error};
pub fn client(mut value: Spawn) { value.max_frames = 0; }
