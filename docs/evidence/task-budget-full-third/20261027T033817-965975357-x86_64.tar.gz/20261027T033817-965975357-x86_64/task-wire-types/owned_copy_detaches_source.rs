#![no_std]
#![forbid(unsafe_code)]
use hm_kernel::task_wire::{Spawn, Grant, Error};
pub fn client(bytes: &mut [u8]) -> Result<Spawn, Error> {
        let spawn = Spawn::decode(bytes)?; bytes.fill(0); let copy = spawn;
        let _ = spawn.input(); Ok(copy)
    }
