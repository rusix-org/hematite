#![no_std]
#![forbid(unsafe_code)]
use hm_kernel::task_wire::{Spawn, Grant, Error};
pub fn client(value: Grant) { let _ = Grant { ..value }; }
