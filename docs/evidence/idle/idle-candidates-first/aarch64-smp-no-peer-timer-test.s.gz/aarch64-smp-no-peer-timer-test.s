	.file	"hematite.a70958de3b4211d3-cgu.0"

	// SAFETY: Reviewed fixed-site EL1 exception contract in design 0007. Boot
	// owns both stacks and mappings; only the exact table entries may recover.
	.arch	armv8.1-a
	.section	.text.exceptions,"ax",@progbits
	.p2align	11
	.globl	arm_vectors
arm_vectors:
	b	arm_nested_fatal
	.zero	124
	b	arm_exception_fatal
	.zero	124
	b	arm_exception_fatal
	.zero	124
	b	arm_exception_fatal
	.zero	124
	b	arm_sync_exception
	.zero	124
	b	arm_timer_irq
	.zero	124
	b	arm_exception_fatal
	.zero	124
	b	arm_exception_fatal
	.zero	124
	b	arm_exception_fatal
	.zero	124
	b	arm_exception_fatal
	.zero	124
	b	arm_exception_fatal
	.zero	124
	b	arm_exception_fatal
	.zero	124
	b	arm_exception_fatal
	.zero	124
	b	arm_exception_fatal
	.zero	124
	b	arm_exception_fatal
	.zero	124
	b	arm_exception_fatal
	.zero	124


	// Select the separately owned emergency stack before any memory access. A
	// fault after this switch uses the SP0 vector, whose path never touches a stack.
arm_sync_exception:
	msr	SPSel, #0
	sub	sp, sp, #256
	stp	x0, x1, [sp]
	stp	x2, x3, [sp, #16]
	stp	x4, x5, [sp, #32]
	stp	x6, x7, [sp, #48]
	stp	x8, x9, [sp, #64]
	stp	x10, x11, [sp, #80]
	stp	x12, x13, [sp, #96]
	stp	x14, x15, [sp, #112]
	stp	x16, x17, [sp, #128]
	stp	x18, x19, [sp, #144]
	stp	x20, x21, [sp, #160]
	stp	x22, x23, [sp, #176]
	stp	x24, x25, [sp, #192]
	stp	x26, x27, [sp, #208]
	stp	x28, x29, [sp, #224]
	str	x30, [sp, #240]
	mrs	x0, SPSR_EL1
	mov	x1, #991	// AArch64 mode bits plus DAIF.
	and	x0, x0, x1
	cmp	x0, #965	// EL1h, all asynchronous classes masked.
	b.ne	arm_exception_fatal
	mrs	x0, ELR_EL1
	mrs	x1, ESR_EL1
	ldr	x3, .Ltmp0	// EC, IL and relevant low abort syndrome.
	and	x1, x1, x3
	mrs	x2, FAR_EL1
	ldr	x3, .Ltmp1
	mov	x4, #6
.Lfind_fixup:
	ldp	x5, x6, [x3]	// Exact fault PC and trusted resume PC.
	cmp	x0, x5
	b.ne	.Lnext_fixup
	ldp	x7, x8, [x3, #16]	// Exact FAR and masked ESR.
	cmp	x2, x7
	b.ne	arm_exception_fatal
	cmp	x1, x8
	b.ne	arm_exception_fatal
	msr	ELR_EL1, x6
	// Leave SPSR intact: ERET restores the interrupted NZCV/DAIF/PAN/mode.

	ldp	x0, x1, [sp]
	ldp	x2, x3, [sp, #16]
	ldp	x4, x5, [sp, #32]
	ldp	x6, x7, [sp, #48]
	ldp	x8, x9, [sp, #64]
	ldp	x10, x11, [sp, #80]
	ldp	x12, x13, [sp, #96]
	ldp	x14, x15, [sp, #112]
	ldp	x16, x17, [sp, #128]
	ldp	x18, x19, [sp, #144]
	ldp	x20, x21, [sp, #160]
	ldp	x22, x23, [sp, #176]
	ldp	x24, x25, [sp, #192]
	ldp	x26, x27, [sp, #208]
	ldp	x28, x29, [sp, #224]
	ldr	x30, [sp, #240]
	add	sp, sp, #256
	msr	SPSel, #1
	eret
.Lnext_fixup:
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	.Lfind_fixup
	b	arm_exception_fatal

	// Fatal reporting must also work with either stack inside a guard. No calls,
	// stack accesses or unbounded UART polling appear on this path.
arm_nested_fatal:
	ldr	x0, .Ltmp2
	b	.Lfatal_print
	.globl	arm_exception_fatal
arm_exception_fatal:
	mrs	x0, MPIDR_EL1
	ldr	x1, .Ltmp3
	and	x0, x0, x1
	cbnz	x0, arm_secondary_failure
	ldr	x0, .Ltmp4
.Lfatal_print:
	mov	x1, #150994944
.Lfatal_character:
	ldrb	w2, [x0], #1
	cbz	w2, .Lfatal_exit
	mov	x4, #65535
.Lfatal_wait:
	ldr	w3, [x1, #24]
	tbz	w3, #5, .Lfatal_send
	subs	x4, x4, #1
	b.ne	.Lfatal_wait
	b	.Lfatal_exit
.Lfatal_send:
	str	w2, [x1]
	b	.Lfatal_character
.Lfatal_exit:
	b	arm_exception_fail

	.globl	arm_probe_null
arm_probe_null:
	mov	x0, #0
.Lnull_fault:
	ldr	x1, [x0]
	mov	x0, #0
	ret
.Lnull_resume:
	mov	x0, #1
	ret

	.globl	arm_probe_stack_guard
arm_probe_stack_guard:
	ldr	x0, .Ltmp5
.Lstack_fault:
	ldr	x1, [x0]
	mov	x0, #0
	ret
.Lstack_resume:
	mov	x0, #1
	ret

	.globl	arm_probe_exception_guard
arm_probe_exception_guard:
	ldr	x0, .Ltmp6
.Lexception_guard_fault:
	ldr	x1, [x0]
	mov	x0, #0
	ret
.Lexception_guard_resume:
	mov	x0, #1
	ret

	.globl	arm_probe_read_only
arm_probe_read_only:
	ldr	x0, .Ltmp7
	mov	w1, #0
.Lread_only_fault:
	str	w1, [x0]
	mov	x0, #0
	ret
.Lread_only_resume:
	ldr	w1, [x0]
	ldr	w2, .Ltmp8
	cmp	w1, w2
	cset	x0, eq
	ret

	.globl	arm_probe_no_execute
arm_probe_no_execute:
	stp	x29, x30, [sp, #-16]!
	ldr	x9, .Ltmp9
	blr	x9
	mov	x0, #0	// Missing protection reaches the valid RET.
	b	.Lno_execute_finish
.Lno_execute_resume:
	mov	x0, #1
.Lno_execute_finish:
	ldp	x29, x30, [sp], #16
	ret
	.p2align	3, 0x0
.Ltmp0:
	.xword	4261414911
	.p2align	3, 0x0
.Ltmp1:
	.xword	arm_fault_fixups
	.p2align	3, 0x0
.Ltmp2:
	.xword	arm_nested_message
	.p2align	3, 0x0
.Ltmp3:
	.xword	1095233437695
	.p2align	3, 0x0
.Ltmp4:
	.xword	arm_exception_message
	.p2align	3, 0x0
.Ltmp5:
	.xword	__stack_guard
	.p2align	3, 0x0
.Ltmp6:
	.xword	__exception_stack_guard
	.p2align	3, 0x0
.Ltmp7:
	.xword	arm_probe_ro_datum
	.p2align	2, 0x0
.Ltmp8:
	.word	305419896
	.p2align	3, 0x0
.Ltmp9:
	.xword	arm_probe_nx_target

	// Fixed 1072-byte normal-stack fixture. Post-fault GPRs occupy 0..248,
	// NZCV 248, Q0..Q31 256..768, FPCR/FPSR/SP 768/776/784. Saved caller
	// FPCR/FPSR/SP occupy 792/800/808; x18..x30 816..920, q8..q15 928..1056,
	// and expected/observed SP_EL0 1056/1064. Only the probe, never the handler,
	// executes SIMD instructions. The public ABI is restored independently.
	.globl	arm_probe_context
arm_probe_context:
	sub	sp, sp, #1072
	str	x18, [sp, #816]
	str	x19, [sp, #824]
	str	x20, [sp, #832]
	str	x21, [sp, #840]
	str	x22, [sp, #848]
	str	x23, [sp, #856]
	str	x24, [sp, #864]
	str	x25, [sp, #872]
	str	x26, [sp, #880]
	str	x27, [sp, #888]
	str	x28, [sp, #896]
	str	x29, [sp, #904]
	str	x30, [sp, #912]
	str	q8, [sp, #928]
	str	q9, [sp, #944]
	str	q10, [sp, #960]
	str	q11, [sp, #976]
	str	q12, [sp, #992]
	str	q13, [sp, #1008]
	str	q14, [sp, #1024]
	str	q15, [sp, #1040]
	mrs	x16, FPCR
	str	x16, [sp, #792]
	eor	x16, x16, #0x400000	// Toggle only the defined rounding-mode bit.
	msr	FPCR, x16
	mrs	x16, FPSR
	str	x16, [sp, #800]
	eor	x16, x16, #0x8000000	// Toggle only the defined cumulative QC bit.
	msr	FPSR, x16
	mov	x16, sp
	str	x16, [sp, #808]
	mrs	x16, SP_EL0
	str	x16, [sp, #1056]
	movi	v0.16b, #32
	movi	v1.16b, #33
	movi	v2.16b, #34
	movi	v3.16b, #35
	movi	v4.16b, #36
	movi	v5.16b, #37
	movi	v6.16b, #38
	movi	v7.16b, #39
	movi	v8.16b, #40
	movi	v9.16b, #41
	movi	v10.16b, #42
	movi	v11.16b, #43
	movi	v12.16b, #44
	movi	v13.16b, #45
	movi	v14.16b, #46
	movi	v15.16b, #47
	movi	v16.16b, #48
	movi	v17.16b, #49
	movi	v18.16b, #50
	movi	v19.16b, #51
	movi	v20.16b, #52
	movi	v21.16b, #53
	movi	v22.16b, #54
	movi	v23.16b, #55
	movi	v24.16b, #56
	movi	v25.16b, #57
	movi	v26.16b, #58
	movi	v27.16b, #59
	movi	v28.16b, #60
	movi	v29.16b, #61
	movi	v30.16b, #62
	movi	v31.16b, #63
	mov	x16, #2684354560
	msr	NZCV, x16
	mov	x0, #0
	mov	x1, #257
	mov	x2, #258
	mov	x3, #259
	mov	x4, #260
	mov	x5, #261
	mov	x6, #262
	mov	x7, #263
	mov	x8, #264
	mov	x9, #265
	mov	x10, #266
	mov	x11, #267
	mov	x12, #268
	mov	x13, #269
	mov	x14, #270
	mov	x15, #271
	mov	x16, #272
	mov	x17, #273
	mov	x18, #274
	mov	x19, #275
	mov	x20, #276
	mov	x21, #277
	mov	x22, #278
	mov	x23, #279
	mov	x24, #280
	mov	x25, #281
	mov	x26, #282
	mov	x27, #283
	mov	x28, #284
	mov	x29, #285
	mov	x30, #286
.Lcontext_fault:
	ldr	x0, [x0]
	b	.Lcontext_fail
.Lcontext_resume:
	stp	x0, x1, [sp]
	stp	x2, x3, [sp, #16]
	stp	x4, x5, [sp, #32]
	stp	x6, x7, [sp, #48]
	stp	x8, x9, [sp, #64]
	stp	x10, x11, [sp, #80]
	stp	x12, x13, [sp, #96]
	stp	x14, x15, [sp, #112]
	stp	x16, x17, [sp, #128]
	stp	x18, x19, [sp, #144]
	stp	x20, x21, [sp, #160]
	stp	x22, x23, [sp, #176]
	stp	x24, x25, [sp, #192]
	stp	x26, x27, [sp, #208]
	stp	x28, x29, [sp, #224]
	str	x30, [sp, #240]
	mrs	x16, NZCV	// Capture before comparisons change flags.
	str	x16, [sp, #248]
	stp	q0, q1, [sp, #256]
	stp	q2, q3, [sp, #288]
	stp	q4, q5, [sp, #320]
	stp	q6, q7, [sp, #352]
	stp	q8, q9, [sp, #384]
	stp	q10, q11, [sp, #416]
	stp	q12, q13, [sp, #448]
	stp	q14, q15, [sp, #480]
	stp	q16, q17, [sp, #512]
	stp	q18, q19, [sp, #544]
	stp	q20, q21, [sp, #576]
	stp	q22, q23, [sp, #608]
	stp	q24, q25, [sp, #640]
	stp	q26, q27, [sp, #672]
	stp	q28, q29, [sp, #704]
	stp	q30, q31, [sp, #736]
	mrs	x16, FPCR
	str	x16, [sp, #768]
	mrs	x16, FPSR
	str	x16, [sp, #776]
	mov	x16, sp
	str	x16, [sp, #784]
	mrs	x16, SP_EL0
	str	x16, [sp, #1064]

	ldr	x3, [sp]
	cbnz	x3, .Lcontext_fail
	add	x0, sp, #8
	mov	x1, #257
	mov	x2, #30
.Lcheck_gprs:
	ldr	x3, [x0], #8
	cmp	x3, x1
	b.ne	.Lcontext_fail
	add	x1, x1, #1
	subs	x2, x2, #1
	b.ne	.Lcheck_gprs
	ldr	x0, [sp, #248]
	mov	x1, #2684354560
	cmp	x0, x1
	b.ne	.Lcontext_fail
	ldr	x0, [sp, #768]
	ldr	x1, [sp, #792]
	eor	x1, x1, #0x400000
	cmp	x0, x1
	b.ne	.Lcontext_fail
	ldr	x0, [sp, #776]
	ldr	x1, [sp, #800]
	eor	x1, x1, #0x8000000
	cmp	x0, x1
	b.ne	.Lcontext_fail
	ldr	x0, [sp, #784]
	ldr	x1, [sp, #808]
	cmp	x0, x1
	b.ne	.Lcontext_fail
	ldr	x0, [sp, #1064]
	ldr	x1, [sp, #1056]
	cmp	x0, x1
	b.ne	.Lcontext_fail
	add	x0, sp, #256
	ldr	x1, .Ltmp10
	ldr	x4, .Ltmp11
	mov	x5, #32
.Lcheck_simd:
	ldp	x2, x3, [x0], #16
	cmp	x2, x1
	b.ne	.Lcontext_fail
	cmp	x3, x1
	b.ne	.Lcontext_fail
	add	x1, x1, x4
	subs	x5, x5, #1
	b.ne	.Lcheck_simd
	mov	x0, #1
	b	.Lcontext_finish
.Lcontext_fail:
	mov	x0, #0
.Lcontext_finish:
	ldr	x16, [sp, #792]
	msr	FPCR, x16
	ldr	x16, [sp, #800]
	msr	FPSR, x16
	ldr	q8, [sp, #928]
	ldr	q9, [sp, #944]
	ldr	q10, [sp, #960]
	ldr	q11, [sp, #976]
	ldr	q12, [sp, #992]
	ldr	q13, [sp, #1008]
	ldr	q14, [sp, #1024]
	ldr	q15, [sp, #1040]
	ldr	x18, [sp, #816]
	ldr	x19, [sp, #824]
	ldr	x20, [sp, #832]
	ldr	x21, [sp, #840]
	ldr	x22, [sp, #848]
	ldr	x23, [sp, #856]
	ldr	x24, [sp, #864]
	ldr	x25, [sp, #872]
	ldr	x26, [sp, #880]
	ldr	x27, [sp, #888]
	ldr	x28, [sp, #896]
	ldr	x29, [sp, #904]
	ldr	x30, [sp, #912]
	add	sp, sp, #1072
	ret
	.p2align	3, 0x0
.Ltmp10:
	.xword	2314885530818453536
	.p2align	3, 0x0
.Ltmp11:
	.xword	72340172838076673

	// Only nonreturning negative-profile wrappers call these entries. The first
	// proves recovery entry does not store to the corrupted normal stack; the
	// second forces the handler's first store into its own guard (SP0 fatal route).
	.globl	arm_probe_unexpected
arm_probe_unexpected:
	ldr	x0, .Ltmp5
	mov	sp, x0
	brk	#0
	b	arm_exception_fatal

	.globl	arm_probe_nested
arm_probe_nested:
	ldr	x0, .Ltmp6
	add	x0, x0, #256
	msr	SP_EL0, x0
	brk	#0
	b	arm_exception_fatal

	.section	.rodata.exceptions,"a",@progbits
	.p2align	3, 0x0
arm_fault_fixups:
	.xword	.Lnull_fault
	.xword	.Lnull_resume
	.xword	0
	.xword	2516582406
	.xword	.Lstack_fault
	.xword	.Lstack_resume
	.xword	__stack_guard
	.xword	2516582407
	.xword	.Lexception_guard_fault
	.xword	.Lexception_guard_resume
	.xword	__exception_stack_guard
	.xword	2516582407
	.xword	.Lread_only_fault
	.xword	.Lread_only_resume
	.xword	arm_probe_ro_datum
	.xword	2516582479
	.xword	arm_probe_nx_target
	.xword	.Lno_execute_resume
	.xword	arm_probe_nx_target
	.xword	2248146959
	.xword	.Lcontext_fault
	.xword	.Lcontext_resume
	.xword	0
	.xword	2516582406
arm_exception_message:
	.ascii	"HMEXCEPTION FATAL\n"
	.byte	0
arm_nested_message:
	.ascii	"HMEXCEPTION NESTED\nHMEXCEPTION FATAL\n"
	.byte	0
	.p2align	2, 0x0
	// Private assembly probe storage, never a Rust immutable object or live code.
arm_probe_ro_datum:
	.word	305419896
arm_probe_nx_target:
	.word	3596551104
	// RET: safe failure if PXN is missing.
	// SAFETY: Private caller retains audited roots and copies bounded buffers to
	// checked common RW identity storage. CPU0 owns BUSY and exceptions are masked,
	// peer is OFF. No changed mapping is dereferenced; no Rust runs until restored.
	.section	.text.arm_space_probe,"ax",@progbits
	.p2align	4
	.globl	arm_space_probe
	.type	arm_space_probe,@function
arm_space_probe:
	mrs	x5, TTBR0_EL1
	mrs	x6, PAR_EL1
	mov	x7, #0
.Lspace_pass:
	mov	x8, #0
.Lspace_query:
	cmp	x8, x3
	b.hs	.Lspace_done_pass
	add	x12, x1, x8, lsl #4
	ldp	x9, x10, [x12]
	cmp	x10, #0
	b.eq	.Lspace_e0r
	cmp	x10, #1
	b.eq	.Lspace_e0w
	cmp	x10, #2
	b.eq	.Lspace_e1r
	at	s1e1w, x9
	b	.Lspace_result
.Lspace_e0r:
	at	s1e0r, x9
	b	.Lspace_result
.Lspace_e0w:
	at	s1e0w, x9
	b	.Lspace_result
.Lspace_e1r:
	at	s1e1r, x9
.Lspace_result:
	isb
	mrs	x11, PAR_EL1
	add	x13, x8, x8, lsl #1
	add	x13, x2, x13, lsl #3
	str	x11, [x13, x7, lsl #3]
	add	x8, x8, #1
	b	.Lspace_query
.Lspace_done_pass:
	cmp	x7, #2
	b.eq	.Lspace_finish
	cmp	x7, #0
	csel	x14, x0, x5, eq
	// Drain preceding observations/accesses and invalidate the previous root.
	dsb	sy
	tlbi	vmalle1
	dsb	sy
	isb
	msr	TTBR0_EL1, x14
	isb
	// Includes global translations and refills made before root replacement.
	tlbi	vmalle1
	dsb	sy
	isb
	mrs	x15, TTBR0_EL1
	str	x15, [x4, x7, lsl #3]
	add	x7, x7, #1
	b	.Lspace_pass
.Lspace_finish:
	msr	PAR_EL1, x6
	isb
	ret
.Ltmp12:
	.size	arm_space_probe, .Ltmp12-arm_space_probe
	// SAFETY: Direct-ELF QEMU virt entry at EL1 with MMU/caches off; all storage
	// belongs to this image. The reviewed bootstrap establishes the Rust ABI.
	.arch	armv8.1-a
	.section	.text.boot,"ax",@progbits
	.globl	arm_start
arm_start:
	msr	DAIFSet, #15
	mov	x19, x0
	mrs	x0, CurrentEL
	cmp	x0, #4
	b.ne	arm_exception_fail
	mrs	x0, MPIDR_EL1
	ldr	x1, .Ltmp13
	tst	x0, x1
	b.ne	arm_exception_fail	// Reject peers before any shared stack/BSS write.
	msr	SPSel, #1
	ldr	x0, .Ltmp14
	mov	sp, x0
	ldr	x0, .Ltmp15
	msr	SP_EL0, x0
	ldr	x0, .Ltmp16
	msr	VBAR_EL1, x0
	isb
	mrs	x0, SCTLR_EL1
	mov	x1, #4101
	tst	x0, x1	// Require M/C/I off, not a warm boot.
	b.ne	arm_exception_fail
	ldr	x0, .Ltmp17
	ldr	x1, .Ltmp18
.Ltmp19:
	cmp	x0, x1
	b.hs	.Ltmp20
	str	xzr, [x0], #8
	b	.Ltmp19
.Ltmp20:
	ldr	x0, .Ltmp21
	msr	TPIDR_EL1, x0
	isb
	add	x0, x0, #128
	ldr	x1, .Ltmp22
	mov	x2, #16
.Lseed_inactive_cpu:
	str	x1, [x0], #8
	subs	x2, x2, #1
	b.ne	.Lseed_inactive_cpu
	bl	arm_uart_init
	mrs	x0, ID_AA64MMFR0_EL1
	ubfx	x0, x0, #28, #4	// 4 KiB granule supported (0 or LPA2=1).
	cmp	x0, #1
	b.hi	arm_exception_fail
	mrs	x0, ID_AA64MMFR1_EL1
	ubfx	x0, x0, #20, #4
	cbz	x0, arm_reject_pan

	ldr	x0, .Ltmp23
	ldr	x1, .Ltmp24
	orr	x1, x1, #0x3
	str	x1, [x0]
	ldr	x1, .Ltmp25
	orr	x1, x1, #0x3
	str	x1, [x0, #8]
	// CPU1's future root shares only immutable device/identity subtrees.
	ldr	x2, .Ltmp26
	ldr	x1, .Ltmp24
	orr	x1, x1, #0x3
	str	x1, [x2]
	ldr	x1, .Ltmp25
	orr	x1, x1, #0x3
	str	x1, [x2, #8]	// Entry2 remains zero: no owned arena.
	ldr	x1, .Ltmp27
	orr	x1, x1, #0x3
	str	x1, [x0, #16]	// Owned data arena at VA 0x80000000.
	ldr	x0, .Ltmp27
	ldr	x1, .Ltmp28
	orr	x1, x1, #0x3
	str	x1, [x0]	// Leaves remain invalid until owned map.
	ldr	x0, .Ltmp24
	ldr	x1, .Ltmp29
	orr	x1, x1, #0x3
	str	x1, [x0, #512]	// GIC MMIO lies in 0x08000000 / 2 MiB ==64.
	ldr	x2, .Ltmp29
	ldr	x1, .Ltmp30	// GICD first4KiB, Device EL1 RW PXN/UXN.
	str	x1, [x2]
	ldr	x1, .Ltmp31	// GICC first4KiB; no virtualization page.
	str	x1, [x2, #128]
	ldr	x1, .Ltmp32
	orr	x1, x1, #0x3
	str	x1, [x0, #576]	// 0x09000000 / 2 MiB == 72.
	ldr	x0, .Ltmp32
	ldr	x1, .Ltmp33	// PL011 only: Device, AF, EL1 RW, PXN/UXN.
	str	x1, [x0]
	ldr	x0, .Ltmp25
	ldr	x1, .Ltmp34
	mov	x2, #8
.Ltmp35:
	orr	x3, x1, #0x3
	str	x3, [x0], #8
	add	x1, x1, #1, lsl #12
	subs	x2, x2, #1
	b.ne	.Ltmp35

	ldr	x6, .Ltmp34
	mov	x3, #1073741824
	mov	x2, #4096
	ldr	x7, .Ltmp36
	ldr	x8, .Ltmp37
	ldr	x9, .Ltmp38
	ldr	x10, .Ltmp39
	ldr	x11, .Ltmp40
	ldr	x12, .Ltmp41
	ldr	x13, .Ltmp42
	ldr	x14, .Ltmp43
	ldr	x15, .Ltmp44
	ldr	x16, .Ltmp45
.Ltmp46:
	cmp	x3, x11
	b.eq	.Ltmp47
	cmp	x3, x12
	b.eq	.Ltmp47
	cmp	x3, x13
	b.eq	.Ltmp47
	cmp	x3, x14
	b.eq	.Ltmp47
	cmp	x3, x15
	b.eq	.Ltmp47
	cmp	x3, x16
	b.eq	.Ltmp47
	cmp	x3, x7
	b.lo	.Ltmp48
	cmp	x3, x8
	b.hs	.Ltmp49
	ldr	x4, .Ltmp50	// EL1 RX, read-only, UXN, normal WB.
	b	.Ltmp51
.Ltmp49:
	cmp	x3, x9
	b.lo	.Ltmp48
	cmp	x3, x10
	b.hs	.Ltmp48
	ldr	x4, .Ltmp52	// EL1 RO, PXN/UXN.
	b	.Ltmp51
.Ltmp48:
	ldr	x4, .Ltmp53	// EL1 RW, PXN/UXN.
	b	.Ltmp51
.Ltmp47:
	str	xzr, [x6], #8
	b	.Ltmp54
.Ltmp51:
	orr	x4, x4, x3
	str	x4, [x6], #8
.Ltmp54:
	add	x3, x3, #1, lsl #12
	subs	x2, x2, #1
	b.ne	.Ltmp46

	// Secondary guard edits happen only here, before caches/MMU and DSB SY.
	ldr	x0, .Ltmp34
	mov	x2, #1073741824
	ldr	x1, .Ltmp55
	sub	x1, x1, x2
	lsr	x1, x1, #12
	str	xzr, [x0, x1, lsl #3]
	ldr	x1, .Ltmp56
	sub	x1, x1, x2
	lsr	x1, x1, #12
	str	xzr, [x0, x1, lsl #3]
	ldr	x1, .Ltmp57
	sub	x1, x1, x2
	lsr	x1, x1, #12
	str	xzr, [x0, x1, lsl #3]
	ldr	x1, .Ltmp58
	sub	x1, x1, x2
	lsr	x1, x1, #12
	str	xzr, [x0, x1, lsl #3]
	ldr	x1, .Ltmp59
	sub	x1, x1, x2
	lsr	x1, x1, #12
	str	xzr, [x0, x1, lsl #3]
	ldr	x1, .Ltmp60
	sub	x1, x1, x2
	lsr	x1, x1, #12
	str	xzr, [x0, x1, lsl #3]

	dsb	sy
	mov	x0, #255	// Attr0 WB; Attr1 Device-nGnRnE=0.
	msr	MAIR_EL1, x0
	ldr	x0, .Ltmp61	// 39-bit TTBR0, 4 KiB, WB/ISH, TTBR1 off.
	msr	TCR_EL1, x0
	ldr	x0, .Ltmp23
	msr	TTBR0_EL1, x0
	msr	TTBR1_EL1, xzr
	isb
	tlbi	vmalle1
	dsb	sy
	isb
	ic	iallu
	dsb	sy
	isb
	ldr	x0, .Ltmp62	// RES1, M/C/I/WXN/SA; SPAN=0, little endian.
	msr	SCTLR_EL1, x0
	isb
	msr	PAN, #1
	mov	x0, #3145728
	msr	CPACR_EL1, x0
	isb
	msr	FPCR, xzr
	msr	FPSR, xzr
	mov	x0, x19
	bl	_RNvCsel89eI7eLYd_8hematite9boot_main
	b	arm_exception_fail

arm_reject_pan:
	ldr	x0, .Ltmp63
	mov	x1, #150994944
.Ltmp64:
	ldrb	w2, [x0], #1
	cbz	w2, .Ltmp65
	mov	x4, #65535
.Ltmp66:
	ldr	w3, [x1, #24]
	tbz	w3, #5, .Ltmp67
	subs	x4, x4, #1
	b.ne	.Ltmp66
	b	arm_exception_fail
.Ltmp67:
	str	w2, [x1]
	b	.Ltmp64
.Ltmp65:
	ldr	x1, .Ltmp68
	b	arm_semihost_exit

	.globl	arm_exception_fail
arm_exception_fail:
	ldr	x1, .Ltmp69
arm_semihost_exit:
	mov	x0, #32
	hlt	#0xf000
.Ltmp70:
	wfi
	b	.Ltmp70

arm_uart_init:
	mov	x0, #150994944
	str	wzr, [x0, #48]
	mov	w1, #2047
	str	w1, [x0, #68]
	mov	w1, #13
	str	w1, [x0, #36]
	mov	w1, #1
	str	w1, [x0, #40]
	mov	w1, #112
	str	w1, [x0, #44]
	mov	w1, #769
	str	w1, [x0, #48]
	ret
	.p2align	3, 0x0
.Ltmp13:
	.xword	1095233437695
	.p2align	3, 0x0
.Ltmp14:
	.xword	__stack_top
	.p2align	3, 0x0
.Ltmp15:
	.xword	__exception_stack_top
	.p2align	3, 0x0
.Ltmp16:
	.xword	arm_vectors
	.p2align	3, 0x0
.Ltmp17:
	.xword	__bss_start
	.p2align	3, 0x0
.Ltmp18:
	.xword	__bss_end
	.p2align	3, 0x0
.Ltmp21:
	.xword	arm_cpu_records
	.p2align	3, 0x0
.Ltmp22:
	.xword	-6531693644558503921
	.p2align	3, 0x0
.Ltmp23:
	.xword	arm_root
	.p2align	3, 0x0
.Ltmp24:
	.xword	arm_device_l2
	.p2align	3, 0x0
.Ltmp25:
	.xword	arm_ram_l2
	.p2align	3, 0x0
.Ltmp26:
	.xword	arm_secondary_root
	.p2align	3, 0x0
.Ltmp27:
	.xword	arm_owned_l2
	.p2align	3, 0x0
.Ltmp28:
	.xword	arm_owned_l3
	.p2align	3, 0x0
.Ltmp29:
	.xword	arm_gic_l3
	.p2align	3, 0x0
.Ltmp30:
	.xword	27021597898441735
	.p2align	3, 0x0
.Ltmp31:
	.xword	27021597898507271
	.p2align	3, 0x0
.Ltmp32:
	.xword	arm_device_l3
	.p2align	3, 0x0
.Ltmp33:
	.xword	27021597915218951
	.p2align	3, 0x0
.Ltmp34:
	.xword	arm_ram_l3
	.p2align	3, 0x0
.Ltmp36:
	.xword	__text_start
	.p2align	3, 0x0
.Ltmp37:
	.xword	__text_end
	.p2align	3, 0x0
.Ltmp38:
	.xword	__rodata_start
	.p2align	3, 0x0
.Ltmp39:
	.xword	__rodata_end
	.p2align	3, 0x0
.Ltmp40:
	.xword	__stack_guard
	.p2align	3, 0x0
.Ltmp41:
	.xword	__exception_stack_guard
	.p2align	3, 0x0
.Ltmp42:
	.xword	__thread0_guard
	.p2align	3, 0x0
.Ltmp43:
	.xword	__thread1_guard
	.p2align	3, 0x0
.Ltmp44:
	.xword	__thread2_guard
	.p2align	3, 0x0
.Ltmp45:
	.xword	__thread3_guard
	.p2align	3, 0x0
.Ltmp50:
	.xword	18014398509483907
	.p2align	3, 0x0
.Ltmp52:
	.xword	27021597764224899
	.p2align	3, 0x0
.Ltmp53:
	.xword	27021597764224771
	.p2align	3, 0x0
.Ltmp55:
	.xword	__secondary_stack_guard
	.p2align	3, 0x0
.Ltmp56:
	.xword	__secondary_exception_stack_guard
	.p2align	3, 0x0
.Ltmp57:
	.xword	__secondary_thread0_guard
	.p2align	3, 0x0
.Ltmp58:
	.xword	__secondary_thread1_guard
	.p2align	3, 0x0
.Ltmp59:
	.xword	__secondary_thread2_guard
	.p2align	3, 0x0
.Ltmp60:
	.xword	__secondary_thread3_guard
	.p2align	3, 0x0
.Ltmp61:
	.xword	2157524249
	.p2align	3, 0x0
.Ltmp62:
	.xword	811079693
	.p2align	3, 0x0
.Ltmp63:
	.xword	pan_message
	.p2align	3, 0x0
.Ltmp68:
	.xword	reject_block
	.p2align	3, 0x0
.Ltmp69:
	.xword	failure_block

	.section	.rodata.boot,"a",@progbits
	.p2align	3, 0x0
reject_block:
	.xword	131110
	.xword	1
failure_block:
	.xword	131110
	.xword	2
pan_message:
	.ascii	"HMBOOT REJECT PAN\n"
	.byte	0

	.section	.bss.tables,"aw",@nobits
	.p2align	12, 0x0
	.globl	arm_root
	.globl	arm_device_l2
	.globl	arm_device_l3
	.globl	arm_ram_l2
	.globl	arm_ram_l3
	.globl	arm_owned_l2
	.globl	arm_owned_l3
arm_root:
	.zero	4096
	.globl	arm_secondary_root
arm_secondary_root:
	.zero	4096
arm_device_l2:
	.zero	4096
arm_device_l3:
	.zero	4096
	.globl	arm_gic_l3
arm_gic_l3:
	.zero	4096
arm_ram_l2:
	.zero	4096
arm_ram_l3:
	.zero	32768
arm_owned_l2:
	.zero	4096
arm_owned_l3:
	.zero	4096
	// SAFETY: Design 0009. Only the fixed assembly window unmasks IRQ; IRQ
	// entry never calls Rust, touches borrowed Rust memory, or modifies mappings.
	.arch	armv8.1-a
	.section	.text.timer,"ax",@progbits
	.globl	arm_timer_probe
	.globl	arm_timer_timeout_probe
arm_timer_probe:
	mov	x0, #1
	b	.Ltimer_common
arm_timer_timeout_probe:
	mov	x0, #0
.Ltimer_common:
	sub	sp, sp, #1120
	str	x0, [sp, #1072]	// Fixed entry mode: allow/withhold timer PPI.
	str	xzr, [sp, #1080]	// Observation mask, not shared with IRQ.
	str	x18, [sp, #816]
	str	x19, [sp, #824]
	str	x20, [sp, #832]
	str	x21, [sp, #840]
	str	x22, [sp, #848]
	str	x23, [sp, #856]
	str	x24, [sp, #864]
	str	x25, [sp, #872]
	str	x26, [sp, #880]
	str	x27, [sp, #888]
	str	x28, [sp, #896]
	str	x29, [sp, #904]
	str	x30, [sp, #912]
	str	q8, [sp, #928]
	str	q9, [sp, #944]
	str	q10, [sp, #960]
	str	q11, [sp, #976]
	str	q12, [sp, #992]
	str	q13, [sp, #1008]
	str	q14, [sp, #1024]
	str	q15, [sp, #1040]
	mrs	x0, FPCR
	str	x0, [sp, #792]
	mrs	x0, FPSR
	str	x0, [sp, #800]
	mov	x0, sp
	str	x0, [sp, #808]
	mrs	x0, SP_EL0
	str	x0, [sp, #1056]
	mrs	x0, DAIF
	str	x0, [sp, #1088]
	and	x1, x0, #0x3c0
	cmp	x1, #960
	b.ne	.Ltimer_restore

	mov	x0, #134217728
	ldr	w2, [x0, #4]	// GICD_TYPER.SecurityExtn must be absent.
	tbnz	w2, #10, .Ltimer_restore
	mov	x1, #134283264
	ldr	w3, [x1, #252]	// GICC_IIDR.Architecture == GICv2.
	ubfx	w3, w3, #16, #4
	cmp	w3, #2
	b.ne	.Ltimer_restore
	str	wzr, [x0]	// No interrupt group forwarding during setup.
	str	wzr, [x1]
	mov	x3, #2
	msr	CNTP_CTL_EL0, x3	// Disable and mask the source first.
	isb
	and	w2, w2, #0x1f
	add	w2, w2, #1	// At most32 banks; all registers within page.
	add	x4, x0, #384
	add	x5, x0, #640
	mov	w3, #-1
.Ltimer_clear_banks:
	str	w3, [x4], #4
	str	w3, [x5], #4
	subs	w2, w2, #1
	b.ne	.Ltimer_clear_banks
	ldr	w2, [x0, #128]
	and	w2, w2, #0xbfffffff	// Explicit Group0 ownership, not a reset guess.
	str	w2, [x0, #128]
	ldr	w2, [x0, #128]
	tbnz	w2, #30, .Ltimer_cleanup
	ldr	w2, [x0, #3076]
	and	w2, w2, #0xdfffffff	// PPI30 level-sensitive.
	str	w2, [x0, #3076]
	ldr	w2, [x0, #3076]
	tbnz	w2, #29, .Ltimer_cleanup
	ldr	w2, [x0, #1052]
	mov	w3, #128
	bfi	w2, w3, #16, #8	// ID30 priority byte.
	str	w2, [x0, #1052]
	mov	w2, #255
	str	w2, [x1, #4]	// CPU priority mask.
	str	wzr, [x1, #8]	// Binary point0.
	mov	w2, #1
	str	w2, [x1]	// Enable, EOImode=0 (combined deactivate).
	str	w2, [x0]
	dsb	sy

	mrs	x1, CNTFRQ_EL0
	cmp	x1, #1000
	b.lo	.Ltimer_cleanup
	ldr	x2, .Ltmp71
	cmp	x1, x2
	b.hi	.Ltimer_cleanup
	isb
	mrs	x2, CNTPCT_EL0
	ldr	x3, .Ltmp72
	sub	x3, x3, x1	// Reserve1second before minimum56-bit wrap.
	cmp	x2, x3
	b.hi	.Ltimer_cleanup
	mrs	x0, TPIDR_EL1
	add	x0, x0, #0
	str	xzr, [x0]
	str	xzr, [x0, #32]
	mov	x3, #1000
	udiv	x3, x1, x3	// Nonzero1ms interval.
	str	x3, [x0, #8]
	add	x4, x2, x3
	msr	CNTP_CVAL_EL0, x4
	mov	x3, #10
	udiv	x3, x1, x3
	add	x2, x2, x3
	str	x2, [x0, #24]	//100ms delivery deadline.
	mov	x2, #1
	str	x2, [x0, #16]	// Handler authority active only in this call.
	mov	x0, #134217728
	ldr	x2, [sp, #1072]
	cbz	x2, .Ltimer_no_enable
	mov	w2, #1073741824
	str	w2, [x0, #256]	// Enable only the physical timer PPI.
.Ltimer_no_enable:
	mov	x0, #1
	msr	CNTP_CTL_EL0, x0
	dsb	sy
	isb

	ldr	x0, [sp, #792]
	eor	x0, x0, #0x400000
	msr	FPCR, x0
	ldr	x0, [sp, #800]
	eor	x0, x0, #0x8000000
	msr	FPSR, x0
	movi	v0.16b, #32
	movi	v1.16b, #33
	movi	v2.16b, #34
	movi	v3.16b, #35
	movi	v4.16b, #36
	movi	v5.16b, #37
	movi	v6.16b, #38
	movi	v7.16b, #39
	movi	v8.16b, #40
	movi	v9.16b, #41
	movi	v10.16b, #42
	movi	v11.16b, #43
	movi	v12.16b, #44
	movi	v13.16b, #45
	movi	v14.16b, #46
	movi	v15.16b, #47
	movi	v16.16b, #48
	movi	v17.16b, #49
	movi	v18.16b, #50
	movi	v19.16b, #51
	movi	v20.16b, #52
	movi	v21.16b, #53
	movi	v22.16b, #54
	movi	v23.16b, #55
	movi	v24.16b, #56
	movi	v25.16b, #57
	movi	v26.16b, #58
	movi	v27.16b, #59
	movi	v28.16b, #60
	movi	v29.16b, #61
	movi	v30.16b, #62
	movi	v31.16b, #63
	mov	x4, #260
	mov	x5, #261
	mov	x6, #262
	mov	x7, #263
	mov	x8, #264
	mov	x9, #265
	mov	x10, #266
	mov	x11, #267
	mov	x12, #268
	mov	x13, #269
	mov	x14, #270
	mov	x15, #271
	mov	x16, #272
	mov	x17, #273
	mov	x18, #274
	mov	x19, #275
	mov	x20, #276
	mov	x21, #277
	mov	x22, #278
	mov	x23, #279
	mov	x24, #280
	mov	x25, #281
	mov	x26, #282
	mov	x27, #283
	mov	x28, #284
	mov	x29, #285
	mov	x30, #286
	mov	x0, #2684354560
	msr	NZCV, x0
	mrs	x0, TPIDR_EL1
	add	x0, x0, #0
	mov	x3, #16777216	// Secondary bound if counter stops advancing.
	.globl	arm_timer_window_begin
arm_timer_window_begin:
.Ltimer_window_begin:
	msr	DAIFClr, #2
.Ltimer_poll:
	ldr	x1, [x0, #32]
	cbnz	x1, .Ltimer_poll_failure
	ldr	x1, [x0]
	sub	x1, x1, #8
	cbz	x1, .Ltimer_delivered
	isb
	mrs	x1, CNTPCT_EL0
	ldr	x2, [x0, #24]
	sub	x1, x1, x2
	tbz	x1, #63, .Ltimer_deadline
	sub	x3, x3, #1
	cbnz	x3, .Ltimer_poll
.Ltimer_poll_failure:
	mov	x2, #0
	b	.Ltimer_mask
.Ltimer_deadline:
	mov	x2, #8
	b	.Ltimer_mask
.Ltimer_delivered:
	mov	x2, #1
.Ltimer_mask:
	msr	DAIFSet, #2
	.globl	arm_timer_window_end
arm_timer_window_end:
.Ltimer_window_end:
	isb
	str	x2, [sp, #1080]
	// Snapshot before checking instructions change registers or NZCV.
	stp	x4, x5, [sp, #32]
	stp	x6, x7, [sp, #48]
	stp	x8, x9, [sp, #64]
	stp	x10, x11, [sp, #80]
	stp	x12, x13, [sp, #96]
	stp	x14, x15, [sp, #112]
	stp	x16, x17, [sp, #128]
	stp	x18, x19, [sp, #144]
	stp	x20, x21, [sp, #160]
	stp	x22, x23, [sp, #176]
	stp	x24, x25, [sp, #192]
	stp	x26, x27, [sp, #208]
	stp	x28, x29, [sp, #224]
	str	x30, [sp, #240]
	mrs	x0, NZCV
	str	x0, [sp, #248]
	stp	q0, q1, [sp, #256]
	stp	q2, q3, [sp, #288]
	stp	q4, q5, [sp, #320]
	stp	q6, q7, [sp, #352]
	stp	q8, q9, [sp, #384]
	stp	q10, q11, [sp, #416]
	stp	q12, q13, [sp, #448]
	stp	q14, q15, [sp, #480]
	stp	q16, q17, [sp, #512]
	stp	q18, q19, [sp, #544]
	stp	q20, q21, [sp, #576]
	stp	q22, q23, [sp, #608]
	stp	q24, q25, [sp, #640]
	stp	q26, q27, [sp, #672]
	stp	q28, q29, [sp, #704]
	stp	q30, q31, [sp, #736]
	mrs	x0, FPCR
	str	x0, [sp, #768]
	mrs	x0, FPSR
	str	x0, [sp, #776]
	mov	x0, sp
	str	x0, [sp, #784]
	mrs	x0, SP_EL0
	str	x0, [sp, #1064]
	add	x0, sp, #32
	mov	x1, #260
	mov	x2, #27
.Ltimer_check_gpr:
	ldr	x3, [x0], #8
	cmp	x3, x1
	b.ne	.Ltimer_cleanup
	add	x1, x1, #1
	subs	x2, x2, #1
	b.ne	.Ltimer_check_gpr
	ldr	x0, [sp, #248]
	mov	x1, #2684354560
	cmp	x0, x1
	b.ne	.Ltimer_cleanup
	ldr	x0, [sp, #768]
	ldr	x1, [sp, #792]
	eor	x1, x1, #0x400000
	cmp	x0, x1
	b.ne	.Ltimer_cleanup
	ldr	x0, [sp, #776]
	ldr	x1, [sp, #800]
	eor	x1, x1, #0x8000000
	cmp	x0, x1
	b.ne	.Ltimer_cleanup
	ldr	x0, [sp, #784]
	ldr	x1, [sp, #808]
	cmp	x0, x1
	b.ne	.Ltimer_cleanup
	ldr	x0, [sp, #1064]
	ldr	x1, [sp, #1056]
	cmp	x0, x1
	b.ne	.Ltimer_cleanup
	add	x0, sp, #256
	ldr	x1, .Ltmp73
	ldr	x4, .Ltmp74
	mov	x5, #32
.Ltimer_check_simd:
	ldp	x2, x3, [x0], #16
	cmp	x2, x1
	b.ne	.Ltimer_cleanup
	cmp	x3, x1
	b.ne	.Ltimer_cleanup
	add	x1, x1, x4
	subs	x5, x5, #1
	b.ne	.Ltimer_check_simd
	ldr	x0, [sp, #1080]
	orr	x0, x0, #0x2
	str	x0, [sp, #1080]

.Ltimer_cleanup:
	msr	DAIFSet, #2
	mov	x0, #2
	msr	CNTP_CTL_EL0, x0
	isb
	mov	x0, #134217728
	mov	w2, #1073741824
	str	w2, [x0, #384]
	dsb	sy
	str	w2, [x0, #640]	// Source is disabled before pending clear.
	str	wzr, [x0]
	mov	x1, #134283264
	str	wzr, [x1]
	dsb	sy
	isb
	mrs	x3, TPIDR_EL1
	add	x3, x3, #0
	ldr	x4, [x3]
	str	x4, [sp, #1104]	// No subsequent delivery may change this.
	ldr	x4, [x3, #8]
	cbz	x4, .Ltimer_no_quiescence
	isb
	mrs	x5, CNTPCT_EL0
	ldr	x6, .Ltmp72
	sub	x6, x6, x4
	cmp	x5, x6
	b.hi	.Ltimer_no_quiescence
	add	x5, x5, x4
	mov	x6, #16777216
.Ltimer_quiet_wait:
	isb
	mrs	x7, CNTPCT_EL0
	cmp	x7, x5
	b.hs	.Ltimer_check_quiet
	subs	x6, x6, #1
	b.ne	.Ltimer_quiet_wait
	b	.Ltimer_no_quiescence
.Ltimer_check_quiet:
	ldr	w2, [x0, #768]	// Do not fake deactivation with ICACTIVER.
	tbnz	w2, #30, .Ltimer_no_quiescence
	ldr	w2, [x0, #512]
	tbnz	w2, #30, .Ltimer_no_quiescence
	ldr	w2, [x0, #256]
	tbnz	w2, #30, .Ltimer_no_quiescence
	ldr	w2, [x0]
	cbnz	w2, .Ltimer_no_quiescence
	ldr	w2, [x1]
	cbnz	w2, .Ltimer_no_quiescence
	mrs	x2, CNTP_CTL_EL0
	and	x2, x2, #0x3
	cmp	x2, #2
	b.ne	.Ltimer_no_quiescence
	mrs	x2, DAIF
	ldr	x4, [sp, #1088]
	cmp	x2, x4
	b.ne	.Ltimer_no_quiescence
	mrs	x2, SP_EL0
	ldr	x4, [sp, #1056]
	cmp	x2, x4
	b.ne	.Ltimer_no_quiescence
	ldr	x2, [x3]
	ldr	x4, [sp, #1104]
	cmp	x2, x4
	b.ne	.Ltimer_no_quiescence
	ldr	x4, [sp, #1072]
	cbnz	x4, .Ltimer_quiet_observed
	cbnz	x2, .Ltimer_no_quiescence	// Disabled route must deliver exactlyzero.
.Ltimer_quiet_observed:
	ldr	x2, [sp, #1080]
	orr	x2, x2, #0x4
	str	x2, [sp, #1080]
.Ltimer_no_quiescence:
	mrs	x0, TPIDR_EL1
	add	x0, x0, #0
	str	xzr, [x0, #16]	// End handler authority only after shutdown.
.Ltimer_restore:
	ldr	x0, [sp, #1080]
	ldr	x16, [sp, #792]
	msr	FPCR, x16
	ldr	x16, [sp, #800]
	msr	FPSR, x16
	ldr	q8, [sp, #928]
	ldr	q9, [sp, #944]
	ldr	q10, [sp, #960]
	ldr	q11, [sp, #976]
	ldr	q12, [sp, #992]
	ldr	q13, [sp, #1008]
	ldr	q14, [sp, #1024]
	ldr	q15, [sp, #1040]
	ldr	x18, [sp, #816]
	ldr	x19, [sp, #824]
	ldr	x20, [sp, #832]
	ldr	x21, [sp, #840]
	ldr	x22, [sp, #848]
	ldr	x23, [sp, #856]
	ldr	x24, [sp, #864]
	ldr	x25, [sp, #872]
	ldr	x26, [sp, #880]
	ldr	x27, [sp, #888]
	ldr	x28, [sp, #896]
	ldr	x29, [sp, #904]
	ldr	x30, [sp, #912]
	add	sp, sp, #1120
	ret
	.p2align	3, 0x0
.Ltmp71:
	.xword	1000000000
	.p2align	3, 0x0
.Ltmp72:
	.xword	72057594037927935
	.p2align	3, 0x0
.Ltmp73:
	.xword	2314885530818453536
	.p2align	3, 0x0
.Ltmp74:
	.xword	72340172838076673

	.globl	arm_timer_irq
arm_timer_irq:
	msr	SPSel, #0
	sub	sp, sp, #256
	stp	x0, x1, [sp]
	stp	x2, x3, [sp, #16]
	stp	x4, x5, [sp, #32]
	stp	x6, x7, [sp, #48]
	stp	x8, x9, [sp, #64]
	stp	x10, x11, [sp, #80]
	stp	x12, x13, [sp, #96]
	stp	x14, x15, [sp, #112]
	stp	x16, x17, [sp, #128]
	stp	x18, x19, [sp, #144]
	stp	x20, x21, [sp, #160]
	stp	x22, x23, [sp, #176]
	stp	x24, x25, [sp, #192]
	stp	x26, x27, [sp, #208]
	stp	x28, x29, [sp, #224]
	str	x30, [sp, #240]
	mrs	x0, TPIDR_EL1
	add	x0, x0, #40
	ldr	x1, [x0, #16]
	cbnz	x1, arm_preempt_irq
	mrs	x0, SPSR_EL1
	mov	x1, #991
	and	x0, x0, x1
	cmp	x0, #837	// EL1h with only IRQ unmasked.
	b.ne	arm_exception_fatal
	mrs	x0, TPIDR_EL1
	add	x0, x0, #0
	ldr	x1, [x0, #16]
	cmp	x1, #1
	b.ne	arm_exception_fatal
	mrs	x1, ELR_EL1
	ldr	x2, .Ltmp75
	cmp	x1, x2
	b.lo	arm_exception_fatal
	ldr	x2, .Ltmp76
	cmp	x1, x2
	b.hs	arm_exception_fatal
	mov	x0, #134283264
	ldr	w1, [x0, #12]	// Retain complete acknowledged IAR for EOI.
	and	w2, w1, #0x3ff
	cmp	w2, #30
	b.eq	.Ltimer_irq_real
	cmp	w2, #1020
	b.hs	.Ltimer_irq_restore	// Special IDs do not have an EOI operation.
	b	arm_exception_fatal
.Ltimer_irq_real:
	mrs	x2, CNTP_CTL_EL0
	tbz	w2, #2, arm_exception_fatal
	mrs	x2, TPIDR_EL1
	add	x2, x2, #0
	ldr	x3, [x2]
	cmp	x3, #8
	b.hs	arm_exception_fatal
	add	x3, x3, #1
	str	x3, [x2]
	cmp	x3, #8
	b.eq	.Ltimer_irq_disable
	ldr	x4, [x2, #8]
	isb
	mrs	x5, CNTPCT_EL0
	ldr	x6, .Ltmp72
	sub	x6, x6, x4
	cmp	x5, x6
	b.hi	.Ltimer_irq_bad_counter
	add	x5, x5, x4
	msr	CNTP_CVAL_EL0, x5
	isb	// Rearm deasserts the level before EOI.
	b	.Ltimer_irq_eoi
.Ltimer_irq_bad_counter:
	mov	x3, #1
	str	x3, [x2, #32]
.Ltimer_irq_disable:
	mov	x3, #2
	msr	CNTP_CTL_EL0, x3
	isb
.Ltimer_irq_eoi:
	dsb	sy
	str	w1, [x0, #16]
	dsb	sy
.Ltimer_irq_restore:
	ldp	x0, x1, [sp]
	ldp	x2, x3, [sp, #16]
	ldp	x4, x5, [sp, #32]
	ldp	x6, x7, [sp, #48]
	ldp	x8, x9, [sp, #64]
	ldp	x10, x11, [sp, #80]
	ldp	x12, x13, [sp, #96]
	ldp	x14, x15, [sp, #112]
	ldp	x16, x17, [sp, #128]
	ldp	x18, x19, [sp, #144]
	ldp	x20, x21, [sp, #160]
	ldp	x22, x23, [sp, #176]
	ldp	x24, x25, [sp, #192]
	ldp	x26, x27, [sp, #208]
	ldp	x28, x29, [sp, #224]
	ldr	x30, [sp, #240]
	add	sp, sp, #256
	msr	SPSel, #1
	eret
	.p2align	3, 0x0
.Ltmp75:
	.xword	.Ltimer_window_begin
	.p2align	3, 0x0
.Ltmp76:
	.xword	.Ltimer_window_end
	// SAFETY: Design 0012. All entries are private; context/image addresses
	// are owned by the masked coordinator. IRQ never retains emergency frames.
	.arch	armv8.1-a
	.section	.text.preempt,"ax",@progbits

	// Separate negative-pressure diagnostic; production expansion is empty.


	// SAFETY: Session-only entries require CPU0, BUSY, masked DAIF and CPU1 off.
	// Shared distributor state is never accessed through the local lifecycle.
	.globl	arm_gic_session_start
	.globl	arm_gic_session_stop
	.globl	arm_gic_probe_seed
	.globl	arm_gic_probe_preserved
	.globl	arm_gic_probe_target
	.globl	arm_gic_probe_restore_target
arm_gic_session_start:
	mrs	x0, DAIF
	cmp	x0, #960
	b.ne	.Lgic_start_fail
	mrs	x0, TPIDR_EL1
	add	x1, x0, #40
	ldr	x2, [x1, #16]
	cbnz	x2, .Lgic_start_fail
	add	x1, x0, #0
	ldr	x2, [x1, #16]
	cbnz	x2, .Lgic_start_fail
	mov	x0, #134217728
	mov	x1, #134283264
	ldr	w2, [x0]
	cbnz	w2, .Lgic_start_fail
	ldr	w2, [x1]
	cbnz	w2, .Lgic_start_fail
	ldr	w2, [x0, #4]
	tbnz	w2, #10, .Lgic_start_fail
	and	w6, w2, #0x1f	// Number of SPI banks, excludes bank0.
	cbz	w6, .Lgic_start_fail	// Diagnostic SPI32 must exist.
	ldr	w2, [x1, #252]
	ubfx	w2, w2, #16, #4
	cmp	w2, #2
	b.ne	.Lgic_start_fail
	ldr	w2, [x0, #256]
	mov	w3, #-1073807360
	tst	w2, w3
	b.ne	.Lgic_start_fail
	ldr	w2, [x0, #512]
	and	w2, w2, #0xbfffffff
	cbnz	w2, .Lgic_start_fail
	ldr	w2, [x0, #768]
	cbnz	w2, .Lgic_start_fail
	add	x3, x0, #772
	mov	w4, w6
.Lgic_validate_spi:
	ldr	w2, [x3], #4
	cbnz	w2, .Lgic_start_fail
	subs	w4, w4, #1
	b.ne	.Lgic_validate_spi
	// All fallible preconditions passed; mutation begins with GICC disabled.
	add	x3, x0, #388
	add	x4, x0, #644
	mov	w5, #-1
.Lgic_reset_spi:
	str	w5, [x3], #4
	str	w5, [x4], #4
	subs	w6, w6, #1
	b.ne	.Lgic_reset_spi
	dsb	sy
	mov	w2, #1
	str	w2, [x0]
	dsb	sy
	ldr	w2, [x0]
	cmp	w2, #1
	b.ne	arm_exception_fatal
	mov	x0, #1
	ret
.Lgic_start_fail:
	mov	x0, #0
	ret

arm_gic_session_stop:
	mov	x0, #134217728
	mov	x1, #134283264
	ldr	w2, [x1]
	cbnz	w2, arm_exception_fatal
	ldr	w2, [x0, #256]
	tbnz	w2, #30, arm_exception_fatal
	ldr	w2, [x0, #512]
	tbnz	w2, #30, arm_exception_fatal
	ldr	w2, [x0, #768]
	tbnz	w2, #30, arm_exception_fatal
	str	wzr, [x0]
	dsb	sy
	ldr	w2, [x0]
	cbnz	w2, arm_exception_fatal
	ldr	w6, [x0, #4]
	and	w6, w6, #0x1f
	add	x3, x0, #644
	mov	w4, w6
	mov	w5, #-1
.Lgic_clear_pending:
	str	w5, [x3], #4
	subs	w4, w4, #1
	b.ne	.Lgic_clear_pending
	dsb	sy
	add	x3, x0, #260
	add	x4, x0, #516
	add	x5, x0, #772
.Lgic_verify_quiet:
	ldr	w2, [x3], #4
	cbnz	w2, arm_exception_fatal
	ldr	w2, [x4], #4
	cbnz	w2, arm_exception_fatal
	ldr	w2, [x5], #4
	cbnz	w2, arm_exception_fatal
	subs	w6, w6, #1
	b.ne	.Lgic_verify_quiet
	mov	x0, #1
	ret

	// Lease-owned diagnostic target only; not part of local setup/teardown.
arm_gic_probe_target:
	mov	x1, #134217728
	ldr	w2, [x1, #260]
	tbnz	w2, #0, arm_exception_fatal
	ldr	w2, [x1, #516]
	tbnz	w2, #0, arm_exception_fatal
	ldr	w2, [x1, #772]
	tbnz	w2, #0, arm_exception_fatal
	ldrb	w3, [x1, #2080]	// Save only SPI32's target byte.
	ldr	w2, [x1, #4]
	ubfx	w2, w2, #5, #3	// CPUNumber: zero permits RAZ/WI targets.
	cbz	w2, .Lgic_target_saved
	mov	w2, #1
	strb	w2, [x1, #2080]
	dsb	sy
	ldrb	w2, [x1, #2080]
	cmp	w2, #1
	b.ne	arm_exception_fatal
.Lgic_target_saved:
	mov	w0, w3
	ret

arm_gic_probe_restore_target:
	cmp	x0, #255
	b.hi	arm_exception_fatal
	mov	x1, #134217728
	ldr	w2, [x1]
	cbnz	w2, arm_exception_fatal
	ldr	w2, [x1, #260]
	tbnz	w2, #0, arm_exception_fatal
	ldr	w2, [x1, #516]
	tbnz	w2, #0, arm_exception_fatal
	ldr	w2, [x1, #772]
	tbnz	w2, #0, arm_exception_fatal
	ldr	w2, [x1, #4]
	ubfx	w2, w2, #5, #3
	cbz	w2, .Lgic_target_restored
	strb	w0, [x1, #2080]
	dsb	sy
.Lgic_target_restored:
	ldrb	w2, [x1, #2080]
	cmp	w2, w0
	b.ne	arm_exception_fatal
	mov	x0, #1
	ret

	// Lease-owned diagnostic: SPI32 was cleared/disabled by session start.
arm_gic_probe_seed:
	mov	x0, #134217728
	ldr	w1, [x0, #260]
	tbnz	w1, #0, .Lgic_probe_fail
	ldr	w1, [x0, #516]
	tbnz	w1, #0, .Lgic_probe_fail
	mov	w1, #1
	str	w1, [x0, #516]
	dsb	sy
arm_gic_probe_preserved:
	mov	x0, #134217728
	ldr	w1, [x0, #4]
	ubfx	w1, w1, #5, #3
	cbz	w1, .Lgic_probe_target_ok
	ldrb	w1, [x0, #2080]
	cmp	w1, #1
	b.ne	.Lgic_probe_fail
.Lgic_probe_target_ok:
	ldr	w1, [x0]
	cmp	w1, #1
	b.ne	.Lgic_probe_fail
	ldr	w1, [x0, #260]
	tbnz	w1, #0, .Lgic_probe_fail
	ldr	w1, [x0, #516]
	tbz	w1, #0, .Lgic_probe_fail
	mov	x0, #1
	ret
.Lgic_probe_fail:
	mov	x0, #0
	ret

	.globl	arm_preempt_setup
	.globl	arm_preempt_stop
	.globl	arm_preempt_dispatch
	.globl	arm_preempt_yield
	.globl	arm_preempt_start
	.globl	arm_preempt_irq
	.globl	arm_preempt_park
	.globl	arm_preempt_wait_mask
arm_preempt_setup:
	mrs	x0, DAIF
	cmp	x0, #960
	b.ne	.Lsetup_fail
	mrs	x0, TPIDR_EL1
	add	x0, x0, #40
	ldr	x1, [x0, #16]
	cbnz	x1, .Lsetup_fail
	mrs	x0, TPIDR_EL1
	add	x0, x0, #0
	ldr	x1, [x0, #16]
	cbnz	x1, .Lsetup_fail
	mov	x0, #134217728
	ldr	w2, [x0, #4]
	tbnz	w2, #10, .Lsetup_fail
	mov	x1, #134283264
	ldr	w3, [x1, #252]
	ubfx	w3, w3, #16, #4
	cmp	w3, #2
	b.ne	.Lsetup_fail
	mrs	x6, CNTFRQ_EL0
	cmp	x6, #1000
	b.lo	.Lsetup_fail
	ldr	x3, .Ltmp77
	cmp	x6, x3
	b.hi	.Lsetup_fail
	mov	x3, #1000
	udiv	x6, x6, x3
	isb
	mrs	x3, CNTPCT_EL0
	ldr	x4, .Ltmp78
	sub	x4, x4, x6
	cmp	x3, x4
	b.hi	.Lsetup_fail
	ldr	w3, [x0]
	cmp	w3, #1
	b.ne	.Lsetup_fail
	// Other local sources must be absent; SGI enable bits may be RAO.
	ldr	w3, [x0, #256]
	mov	w4, #-1073807360
	tst	w3, w4
	b.ne	.Lsetup_fail
	ldr	w3, [x0, #512]
	and	w3, w3, #0xbfffffff
	cbnz	w3, .Lsetup_fail
	ldr	w3, [x0, #768]
	cbnz	w3, .Lsetup_fail
	str	wzr, [x1]
	mov	x3, #2
	msr	CNTP_CTL_EL0, x3
	isb
	mov	w3, #1073741824
	str	w3, [x0, #384]	// Only this CPU's timer PPI30.
	dsb	sy
	str	w3, [x0, #640]
	dsb	sy
	ldr	w2, [x0, #128]
	and	w2, w2, #0xbfffffff
	str	w2, [x0, #128]
	ldr	w2, [x0, #128]
	tbnz	w2, #30, .Lsetup_rollback
	ldr	w2, [x0, #3076]
	and	w2, w2, #0xdfffffff
	str	w2, [x0, #3076]
	ldr	w2, [x0, #3076]
	tbnz	w2, #29, .Lsetup_rollback
	ldr	w2, [x0, #1052]
	mov	w3, #128
	bfi	w2, w3, #16, #8
	str	w2, [x0, #1052]
	mov	w2, #255
	str	w2, [x1, #4]
	str	wzr, [x1, #8]
	mov	w2, #1
	str	w2, [x1]
	dsb	sy
	mrs	x0, TPIDR_EL1
	add	x0, x0, #40
	str	xzr, [x0]
	str	xzr, [x0, #8]
	str	x6, [x0, #24]
	mrs	x3, TPIDR_EL1
	add	x3, x3, #80
	str	xzr, [x3]
	str	x2, [x0, #16]
	mov	x0, x6
	ret
.Lsetup_rollback:
	stp	x29, x30, [sp, #-16]!
	bl	arm_preempt_stop
	ldp	x29, x30, [sp], #16
.Lsetup_fail:
	mov	x0, #0
	ret

	// Masked, allocation-free per-return cleanup; no IRQ remains active here.
.Lquiet:
	mov	x2, #2
	msr	CNTP_CTL_EL0, x2
	isb
	mov	x0, #134217728
	mov	w2, #1073741824
	str	w2, [x0, #384]
	dsb	sy
	str	w2, [x0, #640]
	dsb	sy
	ldr	w3, [x0, #768]
	tbnz	w3, #30, arm_exception_fatal
	ldr	w3, [x0, #512]
	tbnz	w3, #30, arm_exception_fatal
	ret
arm_preempt_stop:
	stp	x29, x30, [sp, #-16]!
	bl	.Lquiet
	mov	x1, #134283264
	str	wzr, [x1]
	dsb	sy
	ldr	w2, [x0]
	cmp	w2, #1	// Local stop must preserve shared forwarding.
	b.ne	arm_exception_fatal
	ldr	w2, [x1]
	cbnz	w2, arm_exception_fatal
	ldr	w2, [x0, #256]
	tbnz	w2, #30, arm_exception_fatal
	mrs	x0, TPIDR_EL1
	add	x0, x0, #40
	str	xzr, [x0, #16]
	str	xzr, [x0]
	str	xzr, [x0, #8]
	mov	x0, #1
	ldp	x29, x30, [sp], #16
	ret

arm_preempt_dispatch:
	stp	x29, x30, [sp, #-16]!
	adr	x30, .Ldispatch_return
	stp	x18, x19, [x0]
	stp	x20, x21, [x0, #16]
	stp	x22, x23, [x0, #32]
	stp	x24, x25, [x0, #48]
	stp	x26, x27, [x0, #64]
	stp	x28, x29, [x0, #80]
	str	x30, [x0, #96]
	mov	x3, sp
	str	x3, [x0, #104]
	stp	q8, q9, [x0, #112]
	stp	q10, q11, [x0, #144]
	stp	q12, q13, [x0, #176]
	stp	q14, q15, [x0, #208]
	mrs	x3, FPCR
	str	x3, [x0, #240]
	mrs	x3, FPSR
	str	x3, [x0, #248]
	mrs	x3, TPIDR_EL1
	add	x3, x3, #40
	str	x0, [x3]
	str	x1, [x3, #8]
	mov	x4, #1
	str	x4, [x1, #264]
	// Fresh compare before publishing enabled source; checked minimum56bit wrap.
	isb
	mrs	x4, CNTPCT_EL0
	ldr	x5, .Ltmp78
	sub	x5, x5, x2
	cmp	x4, x5
	b.hi	arm_exception_fatal
	add	x4, x4, x2
	msr	CNTP_CVAL_EL0, x4
	mov	x4, #134217728
	mov	w5, #1073741824
	// Build-time negative image withholds delivery, preserving the workload.
	mov	x6, #1
	cbz	x6, .Lwithhold
	mov	x6, #0
	cbnz	x6, .Lpeer_delivery
	mrs	x6, MPIDR_EL1
	and	x6, x6, #0xff
	cmp	x6, #1
	b.eq	.Lwithhold
.Lpeer_delivery:
	str	w5, [x4, #256]
.Lwithhold:
	mov	x4, #1
	msr	CNTP_CTL_EL0, x4
	dsb	sy
	isb
	clrex
	ldr	x3, [x1, #280]
	cmp	x3, #1
	b.eq	.Lrestore_cooperative
	cmp	x3, #3
	b.eq	.Lrestore_cooperative
	add	x0, x1, #288
	b	.Lrestore_image
.Ldispatch_return:
	bl	.Lquiet
	ldp	x29, x30, [sp], #16
	ret

arm_preempt_yield:
	mrs	x9, DAIF
	msr	DAIFSet, #2
	isb
	stp	x9, x30, [sp, #-16]!
	ldr	x2, [x0, #272]
	adds	x3, x2, #1
	csel	x2, x2, x3, hs
	str	x2, [x0, #272]
	mov	x2, #1
	str	x2, [x0, #280]
	str	xzr, [x0, #264]
	mov	x2, #2
	msr	CNTP_CTL_EL0, x2
	isb
	clrex
	bl	arm_context_switch
	ldp	x9, x30, [sp], #16
	msr	DAIF, x9
	isb
	ret
	// Ordinary ABI call is a compiler barrier; return the actual prior mask.
arm_preempt_wait_mask:
	mrs	x0, DAIF
	msr	DAIFSet, #2
	isb
	ret

	// Caller has masked IRQ, published BLOCKED and retained its Event borrow.
	// Keep that state and its distinct counter; this is not a voluntary yield.
arm_preempt_park:
	stp	x29, x30, [sp, #-16]!
	// The timer can become pending during registration but must not execute
	// an IRQ handler against a BLOCKED task. No unmask occurs in this window.
	mov	x2, #2
	msr	CNTP_CTL_EL0, x2
	isb
	clrex
	bl	arm_context_switch
	ldp	x29, x30, [sp], #16
	ret

arm_preempt_start:
	mov	x0, x21
	mov	x1, x22
	bl	_RNvNtCsel89eI7eLYd_8hematite7preempt5entry
	msr	DAIFSet, #2
	isb
	str	x0, [x19, #256]
	mov	x0, #2
	str	x0, [x19, #264]
	msr	CNTP_CTL_EL0, x0
	isb
	mov	x0, x19
	mov	x1, x20
	clrex
	b	arm_context_switch

	// x1 points to a complete ordinary AAPCS context (host or explicit yield).
.Lrestore_cooperative:
	ldr	x2, [x1, #240]
	msr	FPCR, x2
	ldr	x2, [x1, #248]
	msr	FPSR, x2
	ldp	q8, q9, [x1, #112]
	ldp	q10, q11, [x1, #144]
	ldp	q12, q13, [x1, #176]
	ldp	q14, q15, [x1, #208]
	ldp	x18, x19, [x1]
	ldp	x20, x21, [x1, #16]
	ldp	x22, x23, [x1, #32]
	ldp	x24, x25, [x1, #48]
	ldp	x26, x27, [x1, #64]
	ldp	x28, x29, [x1, #80]
	ldr	x30, [x1, #96]
	ldr	x2, [x1, #104]
	mov	sp, x2
	ret

	// Existing IRQ entry has already saved all31GPRs in a256byte SP_EL0 frame.
arm_preempt_irq:
	sub	sp, sp, #544
	add	x0, sp, #544
	mov	x1, sp
	mov	x2, #31
.Lcopy_gprs:
	ldr	x3, [x0], #8
	str	x3, [x1], #8
	subs	x2, x2, #1
	b.ne	.Lcopy_gprs
	msr	SPSel, #1
	mov	x0, sp
	msr	SPSel, #0
	str	x0, [sp, #248]
	stp	q0, q1, [sp, #256]
	stp	q2, q3, [sp, #288]
	stp	q4, q5, [sp, #320]
	stp	q6, q7, [sp, #352]
	stp	q8, q9, [sp, #384]
	stp	q10, q11, [sp, #416]
	stp	q12, q13, [sp, #448]
	stp	q14, q15, [sp, #480]
	stp	q16, q17, [sp, #512]
	stp	q18, q19, [sp, #544]
	stp	q20, q21, [sp, #576]
	stp	q22, q23, [sp, #608]
	stp	q24, q25, [sp, #640]
	stp	q26, q27, [sp, #672]
	stp	q28, q29, [sp, #704]
	stp	q30, q31, [sp, #736]
	mrs	x0, ELR_EL1
	str	x0, [sp, #768]
	mrs	x0, SPSR_EL1
	str	x0, [sp, #776]
	mrs	x0, FPCR
	str	x0, [sp, #784]
	mrs	x0, FPSR
	str	x0, [sp, #792]
	ldr	x0, [sp, #776]
	mov	x1, #991
	and	x0, x0, x1
	cmp	x0, #837
	b.ne	arm_exception_fatal
	mrs	x4, TPIDR_EL1
	add	x4, x4, #40
	// Coordinator publishes only a bounded admitted task pointer; safe policy
	// cannot write publication. Pointer+RUNNING validate that authority here.
	ldr	x5, [x4, #8]
	cbz	x5, arm_exception_fatal
	ldr	x0, [x5, #264]
	cmp	x0, #1
	b.ne	arm_exception_fatal
	mov	x0, #134283264
	ldr	w1, [x0, #12]
	and	w2, w1, #0x3ff
	cmp	w2, #30
	b.eq	.Lreal_preemption
	cmp	w2, #1020
	b.lo	arm_exception_fatal
	// Spurious ID: no EOI, no scheduling, restore the exact interrupted image.
	mov	x0, sp
	add	sp, sp, #800
	msr	SPSel, #1
	b	.Lrestore_image
.Lreal_preemption:
	mrs	x6, TPIDR_EL1
	add	x6, x6, #72
	ldr	x7, [x6]
	adds	x8, x7, #1
	csel	x7, x7, x8, hs
	str	x7, [x6]
	mrs	x2, CNTP_CTL_EL0
	tbz	w2, #2, arm_exception_fatal
	mov	x2, #2
	msr	CNTP_CTL_EL0, x2
	isb
	dsb	sy
	str	w1, [x0, #16]
	dsb	sy
	mov	x0, sp
	add	x1, x5, #288
	mov	x2, #100
.Lcopy_image:
	ldr	x3, [x0], #8
	str	x3, [x1], #8
	subs	x2, x2, #1
	b.ne	.Lcopy_image
	ldr	x0, [x5, #1088]
	adds	x1, x0, #1
	csel	x0, x0, x1, hs
	str	x0, [x5, #1088]
	mov	x0, #2
	str	x0, [x5, #280]
	str	xzr, [x5, #264]
	ldr	x1, [x4]
	cbz	x1, arm_exception_fatal
	add	sp, sp, #800
	msr	SPSel, #1
	clrex
	b	.Lrestore_cooperative

	// x0 points to private saved image; no Rust/reference/stack use until ERET.
.Lrestore_image:
	mov	x30, x0
	ldr	x1, [x30, #248]
	mov	sp, x1
	ldr	x1, [x30, #768]
	msr	ELR_EL1, x1
	ldr	x1, [x30, #776]
	msr	SPSR_EL1, x1
	ldr	x1, [x30, #784]
	msr	FPCR, x1
	ldr	x1, [x30, #792]
	msr	FPSR, x1
	ldp	q0, q1, [x30, #256]
	ldp	q2, q3, [x30, #288]
	ldp	q4, q5, [x30, #320]
	ldp	q6, q7, [x30, #352]
	ldp	q8, q9, [x30, #384]
	ldp	q10, q11, [x30, #416]
	ldp	q12, q13, [x30, #448]
	ldp	q14, q15, [x30, #480]
	ldp	q16, q17, [x30, #512]
	ldp	q18, q19, [x30, #544]
	ldp	q20, q21, [x30, #576]
	ldp	q22, q23, [x30, #608]
	ldp	q24, q25, [x30, #640]
	ldp	q26, q27, [x30, #672]
	ldp	q28, q29, [x30, #704]
	ldp	q30, q31, [x30, #736]
	ldp	x0, x1, [x30]
	ldp	x2, x3, [x30, #16]
	ldp	x4, x5, [x30, #32]
	ldp	x6, x7, [x30, #48]
	ldp	x8, x9, [x30, #64]
	ldp	x10, x11, [x30, #80]
	ldp	x12, x13, [x30, #96]
	ldp	x14, x15, [x30, #112]
	ldp	x16, x17, [x30, #128]
	ldp	x18, x19, [x30, #144]
	ldp	x20, x21, [x30, #160]
	ldp	x22, x23, [x30, #176]
	ldp	x24, x25, [x30, #192]
	ldp	x26, x27, [x30, #208]
	ldp	x28, x29, [x30, #224]
	ldr	x30, [x30, #240]
	clrex
	eret
	.p2align	3, 0x0
.Ltmp77:
	.xword	1000000000
	.p2align	3, 0x0
.Ltmp78:
	.xword	72057594037927935
	// SAFETY: Private diagnostic preserves AAPCS caller state and uses only its
	// own bounded stack plus the scheduler's read-only IRQ counter. Two passes
	// keep polling scratch separate from every register's tested sentinel.
	.arch	armv8.1-a
	.section	.text.preempt_probe,"ax",@progbits
	.globl	arm_preempt_context_probe
arm_preempt_context_probe:
	sub	sp, sp, #1104
	add	x1, sp, #800
	stp	x18, x19, [x1]
	stp	x20, x21, [x1, #16]
	stp	x22, x23, [x1, #32]
	stp	x24, x25, [x1, #48]
	stp	x26, x27, [x1, #64]
	stp	x28, x29, [x1, #80]
	str	x30, [sp, #896]
	stp	q8, q9, [sp, #912]
	stp	q10, q11, [sp, #944]
	stp	q12, q13, [sp, #976]
	stp	q14, q15, [sp, #1008]
	mrs	x1, FPCR
	str	x1, [sp, #1040]
	mrs	x1, FPSR
	str	x1, [sp, #1048]
	str	x0, [sp, #1056]
	mov	x1, sp
	str	x1, [sp, #1072]
	str	xzr, [sp, #1064]
	mov	x1, #1
	str	x1, [sp, #1080]
	b	.Lprobe_pass0
.Lprobe_pass0:
	ldr	x17, [sp, #1056]
	and	x17, x17, #0x1
	lsl	x17, x17, #22
	msr	FPCR, x17
	lsl	x17, x17, #5
	msr	FPSR, x17
	ldr	x17, [sp, #1056]
	and	x17, x17, #0x3
	lsl	x17, x17, #28
	msr	NZCV, x17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #32
	dup	v0.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #33
	dup	v1.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #34
	dup	v2.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #35
	dup	v3.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #36
	dup	v4.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #37
	dup	v5.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #38
	dup	v6.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #39
	dup	v7.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #40
	dup	v8.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #41
	dup	v9.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #42
	dup	v10.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #43
	dup	v11.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #44
	dup	v12.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #45
	dup	v13.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #46
	dup	v14.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #47
	dup	v15.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #48
	dup	v16.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #49
	dup	v17.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #50
	dup	v18.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #51
	dup	v19.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #52
	dup	v20.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #53
	dup	v21.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #54
	dup	v22.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #55
	dup	v23.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #56
	dup	v24.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #57
	dup	v25.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #58
	dup	v26.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #59
	dup	v27.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #60
	dup	v28.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #61
	dup	v29.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #62
	dup	v30.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #63
	dup	v31.16b, w17
	ldr	x0, [sp, #1056]
	lsl	x0, x0, #8
	add	x0, x0, #256
	ldr	x1, [sp, #1056]
	lsl	x1, x1, #8
	add	x1, x1, #257
	ldr	x2, [sp, #1056]
	lsl	x2, x2, #8
	add	x2, x2, #258
	ldr	x3, [sp, #1056]
	lsl	x3, x3, #8
	add	x3, x3, #259
	ldr	x4, [sp, #1056]
	lsl	x4, x4, #8
	add	x4, x4, #260
	ldr	x5, [sp, #1056]
	lsl	x5, x5, #8
	add	x5, x5, #261
	ldr	x6, [sp, #1056]
	lsl	x6, x6, #8
	add	x6, x6, #262
	ldr	x7, [sp, #1056]
	lsl	x7, x7, #8
	add	x7, x7, #263
	ldr	x8, [sp, #1056]
	lsl	x8, x8, #8
	add	x8, x8, #264
	ldr	x9, [sp, #1056]
	lsl	x9, x9, #8
	add	x9, x9, #265
	ldr	x10, [sp, #1056]
	lsl	x10, x10, #8
	add	x10, x10, #266
	ldr	x11, [sp, #1056]
	lsl	x11, x11, #8
	add	x11, x11, #267
	ldr	x12, [sp, #1056]
	lsl	x12, x12, #8
	add	x12, x12, #268
	ldr	x13, [sp, #1056]
	lsl	x13, x13, #8
	add	x13, x13, #269
	ldr	x14, [sp, #1056]
	lsl	x14, x14, #8
	add	x14, x14, #270
	ldr	x15, [sp, #1056]
	lsl	x15, x15, #8
	add	x15, x15, #271
	ldr	x16, [sp, #1056]
	lsl	x16, x16, #8
	add	x16, x16, #272
	ldr	x18, [sp, #1056]
	lsl	x18, x18, #8
	add	x18, x18, #274
	ldr	x19, [sp, #1056]
	lsl	x19, x19, #8
	add	x19, x19, #275
	ldr	x20, [sp, #1056]
	lsl	x20, x20, #8
	add	x20, x20, #276
	ldr	x21, [sp, #1056]
	lsl	x21, x21, #8
	add	x21, x21, #277
	ldr	x22, [sp, #1056]
	lsl	x22, x22, #8
	add	x22, x22, #278
	ldr	x23, [sp, #1056]
	lsl	x23, x23, #8
	add	x23, x23, #279
	ldr	x24, [sp, #1056]
	lsl	x24, x24, #8
	add	x24, x24, #280
	ldr	x25, [sp, #1056]
	lsl	x25, x25, #8
	add	x25, x25, #281
	ldr	x26, [sp, #1056]
	lsl	x26, x26, #8
	add	x26, x26, #282
	ldr	x27, [sp, #1056]
	lsl	x27, x27, #8
	add	x27, x27, #283
	ldr	x28, [sp, #1056]
	lsl	x28, x28, #8
	add	x28, x28, #284
	ldr	x29, [sp, #1056]
	lsl	x29, x29, #8
	add	x29, x29, #285
	ldr	x30, [sp, #1056]
	lsl	x30, x30, #8
	add	x30, x30, #286
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #8
	add	x17, x17, #273
	mrs	x0, TPIDR_EL1
	add	x0, x0, #72
	ldr	x2, [x0]
	add	x2, x2, #8
.Lprobe_poll0:
	ldr	x1, [x0]
	sub	x1, x1, x2
	tbnz	x1, #63, .Lprobe_poll0
	b	.Lprobe_snapshot
.Lprobe_pass1:
	ldr	x17, [sp, #1056]
	and	x17, x17, #0x1
	lsl	x17, x17, #22
	msr	FPCR, x17
	lsl	x17, x17, #5
	msr	FPSR, x17
	ldr	x17, [sp, #1056]
	and	x17, x17, #0x3
	lsl	x17, x17, #28
	msr	NZCV, x17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #32
	dup	v0.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #33
	dup	v1.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #34
	dup	v2.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #35
	dup	v3.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #36
	dup	v4.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #37
	dup	v5.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #38
	dup	v6.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #39
	dup	v7.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #40
	dup	v8.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #41
	dup	v9.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #42
	dup	v10.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #43
	dup	v11.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #44
	dup	v12.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #45
	dup	v13.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #46
	dup	v14.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #47
	dup	v15.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #48
	dup	v16.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #49
	dup	v17.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #50
	dup	v18.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #51
	dup	v19.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #52
	dup	v20.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #53
	dup	v21.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #54
	dup	v22.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #55
	dup	v23.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #56
	dup	v24.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #57
	dup	v25.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #58
	dup	v26.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #59
	dup	v27.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #60
	dup	v28.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #61
	dup	v29.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #62
	dup	v30.16b, w17
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #5
	add	x17, x17, #63
	dup	v31.16b, w17
	ldr	x0, [sp, #1056]
	lsl	x0, x0, #8
	add	x0, x0, #256
	ldr	x1, [sp, #1056]
	lsl	x1, x1, #8
	add	x1, x1, #257
	ldr	x2, [sp, #1056]
	lsl	x2, x2, #8
	add	x2, x2, #258
	ldr	x3, [sp, #1056]
	lsl	x3, x3, #8
	add	x3, x3, #259
	ldr	x4, [sp, #1056]
	lsl	x4, x4, #8
	add	x4, x4, #260
	ldr	x5, [sp, #1056]
	lsl	x5, x5, #8
	add	x5, x5, #261
	ldr	x6, [sp, #1056]
	lsl	x6, x6, #8
	add	x6, x6, #262
	ldr	x7, [sp, #1056]
	lsl	x7, x7, #8
	add	x7, x7, #263
	ldr	x8, [sp, #1056]
	lsl	x8, x8, #8
	add	x8, x8, #264
	ldr	x9, [sp, #1056]
	lsl	x9, x9, #8
	add	x9, x9, #265
	ldr	x10, [sp, #1056]
	lsl	x10, x10, #8
	add	x10, x10, #266
	ldr	x11, [sp, #1056]
	lsl	x11, x11, #8
	add	x11, x11, #267
	ldr	x12, [sp, #1056]
	lsl	x12, x12, #8
	add	x12, x12, #268
	ldr	x13, [sp, #1056]
	lsl	x13, x13, #8
	add	x13, x13, #269
	ldr	x14, [sp, #1056]
	lsl	x14, x14, #8
	add	x14, x14, #270
	ldr	x15, [sp, #1056]
	lsl	x15, x15, #8
	add	x15, x15, #271
	ldr	x16, [sp, #1056]
	lsl	x16, x16, #8
	add	x16, x16, #272
	ldr	x18, [sp, #1056]
	lsl	x18, x18, #8
	add	x18, x18, #274
	ldr	x19, [sp, #1056]
	lsl	x19, x19, #8
	add	x19, x19, #275
	ldr	x20, [sp, #1056]
	lsl	x20, x20, #8
	add	x20, x20, #276
	ldr	x21, [sp, #1056]
	lsl	x21, x21, #8
	add	x21, x21, #277
	ldr	x22, [sp, #1056]
	lsl	x22, x22, #8
	add	x22, x22, #278
	ldr	x23, [sp, #1056]
	lsl	x23, x23, #8
	add	x23, x23, #279
	ldr	x24, [sp, #1056]
	lsl	x24, x24, #8
	add	x24, x24, #280
	ldr	x25, [sp, #1056]
	lsl	x25, x25, #8
	add	x25, x25, #281
	ldr	x26, [sp, #1056]
	lsl	x26, x26, #8
	add	x26, x26, #282
	ldr	x27, [sp, #1056]
	lsl	x27, x27, #8
	add	x27, x27, #283
	ldr	x28, [sp, #1056]
	lsl	x28, x28, #8
	add	x28, x28, #284
	ldr	x29, [sp, #1056]
	lsl	x29, x29, #8
	add	x29, x29, #285
	ldr	x30, [sp, #1056]
	lsl	x30, x30, #8
	add	x30, x30, #286
	ldr	x17, [sp, #1056]
	lsl	x17, x17, #8
	add	x17, x17, #273
	mrs	x3, TPIDR_EL1
	add	x3, x3, #72
	ldr	x5, [x3]
	add	x5, x5, #8
.Lprobe_poll1:
	ldr	x4, [x3]
	sub	x4, x4, x5
	tbnz	x4, #63, .Lprobe_poll1
	b	.Lprobe_snapshot
.Lprobe_snapshot:
	stp	x0, x1, [sp]
	stp	x2, x3, [sp, #16]
	stp	x4, x5, [sp, #32]
	stp	x6, x7, [sp, #48]
	stp	x8, x9, [sp, #64]
	stp	x10, x11, [sp, #80]
	stp	x12, x13, [sp, #96]
	stp	x14, x15, [sp, #112]
	stp	x16, x17, [sp, #128]
	stp	x18, x19, [sp, #144]
	stp	x20, x21, [sp, #160]
	stp	x22, x23, [sp, #176]
	stp	x24, x25, [sp, #192]
	stp	x26, x27, [sp, #208]
	stp	x28, x29, [sp, #224]
	str	x30, [sp, #240]
	mov	x0, sp
	str	x0, [sp, #248]
	stp	q0, q1, [sp, #256]
	stp	q2, q3, [sp, #288]
	stp	q4, q5, [sp, #320]
	stp	q6, q7, [sp, #352]
	stp	q8, q9, [sp, #384]
	stp	q10, q11, [sp, #416]
	stp	q12, q13, [sp, #448]
	stp	q14, q15, [sp, #480]
	stp	q16, q17, [sp, #512]
	stp	q18, q19, [sp, #544]
	stp	q20, q21, [sp, #576]
	stp	q22, q23, [sp, #608]
	stp	q24, q25, [sp, #640]
	stp	q26, q27, [sp, #672]
	stp	q28, q29, [sp, #704]
	stp	q30, q31, [sp, #736]
	mrs	x0, NZCV
	str	x0, [sp, #768]
	mrs	x0, FPCR
	str	x0, [sp, #776]
	mrs	x0, FPSR
	str	x0, [sp, #784]
	ldr	x0, [sp, #1056]
	lsl	x0, x0, #8
	add	x0, x0, #256
	mov	x1, #0
	mov	x2, sp
	ldr	x6, [sp, #1064]
.Lprobe_check_gpr:
	cbnz	x6, .Lprobe_skip_second
	cmp	x1, #3
	b.lo	.Lprobe_next_gpr
	b	.Lprobe_compare_gpr
.Lprobe_skip_second:
	cmp	x1, #3
	b.lo	.Lprobe_compare_gpr
	cmp	x1, #6
	b.lo	.Lprobe_next_gpr
.Lprobe_compare_gpr:
	ldr	x3, [x2, x1, lsl #3]
	add	x4, x0, x1
	cmp	x3, x4
	b.ne	.Lprobe_bad
.Lprobe_next_gpr:
	add	x1, x1, #1
	cmp	x1, #31
	b.lo	.Lprobe_check_gpr
	ldr	x0, [sp, #248]
	ldr	x1, [sp, #1072]
	cmp	x0, x1
	b.ne	.Lprobe_bad
	ldr	x0, [sp, #1056]
	and	x1, x0, #0x3
	lsl	x1, x1, #28
	ldr	x2, [sp, #768]
	cmp	x1, x2
	b.ne	.Lprobe_bad
	and	x1, x0, #0x1
	lsl	x1, x1, #22
	ldr	x2, [sp, #776]
	cmp	x1, x2
	b.ne	.Lprobe_bad
	lsl	x1, x1, #5
	ldr	x2, [sp, #784]
	cmp	x1, x2
	b.ne	.Lprobe_bad
	lsl	x0, x0, #5
	add	x0, x0, #32
	ldr	x5, .Ltmp79
	add	x2, sp, #256
	mov	x1, #0
.Lprobe_vectors:
	add	x3, x0, x1
	and	x3, x3, #0xff
	mul	x3, x3, x5
	ldp	x4, x7, [x2], #16
	cmp	x3, x4
	b.ne	.Lprobe_bad
	cmp	x3, x7
	b.ne	.Lprobe_bad
	add	x1, x1, #1
	cmp	x1, #32
	b.lo	.Lprobe_vectors
	cbnz	x6, .Lprobe_finish
	mov	x6, #1
	str	x6, [sp, #1064]
	b	.Lprobe_pass1
.Lprobe_bad:
	str	xzr, [sp, #1080]
.Lprobe_finish:
	ldr	x1, [sp, #1040]
	msr	FPCR, x1
	ldr	x1, [sp, #1048]
	msr	FPSR, x1
	ldp	q8, q9, [sp, #912]
	ldp	q10, q11, [sp, #944]
	ldp	q12, q13, [sp, #976]
	ldp	q14, q15, [sp, #1008]
	add	x1, sp, #800
	ldp	x18, x19, [x1]
	ldp	x20, x21, [x1, #16]
	ldp	x22, x23, [x1, #32]
	ldp	x24, x25, [x1, #48]
	ldp	x26, x27, [x1, #64]
	ldp	x28, x29, [x1, #80]
	ldr	x30, [sp, #896]
	ldr	x0, [sp, #1080]
	add	sp, sp, #1104
	ret
	.p2align	3, 0x0
.Ltmp79:
	.xword	72340172838076673
	// SAFETY: Design 0023. CPU0/BUSY/peer-OFF, exact admitted controls and
	// retained roots/context. Only fixed reserved kernel storage is accessed while
	// the process root is active. Every normal trap restores before returning.
	.arch	armv8.1-a
	.section	.text.process,"ax",@progbits
	.p2align	11
	.globl	arm_process_vectors
arm_process_vectors:
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_sync
	.zero	124
	b	arm_process_irq
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124
	b	arm_process_kernel_fatal
	.zero	124

	.globl	arm_process_slice
	.type	arm_process_slice,@function
arm_process_slice:
	ldr	x16, .Ltmp80
	sub	x16, x16, #2048
	str	x18, [x16, #1184]
	str	x19, [x16, #1192]
	str	x20, [x16, #1200]
	str	x21, [x16, #1208]
	str	x22, [x16, #1216]
	str	x23, [x16, #1224]
	str	x24, [x16, #1232]
	str	x25, [x16, #1240]
	str	x26, [x16, #1248]
	str	x27, [x16, #1256]
	str	x28, [x16, #1264]
	str	x29, [x16, #1272]
	str	x30, [x16, #1280]
	str	q8, [x16, #1296]
	str	q9, [x16, #1312]
	str	q10, [x16, #1328]
	str	q11, [x16, #1344]
	str	q12, [x16, #1360]
	str	q13, [x16, #1376]
	str	q14, [x16, #1392]
	str	q15, [x16, #1408]
	mrs	x17, TTBR0_EL1
	str	x17, [x16, #1024]
	mrs	x17, TTBR1_EL1
	str	x17, [x16, #1032]
	mrs	x17, PAR_EL1
	str	x17, [x16, #1040]
	mrs	x17, VBAR_EL1
	str	x17, [x16, #1048]
	mrs	x17, SP_EL0
	str	x17, [x16, #1056]
	mrs	x17, DAIF
	str	x17, [x16, #1064]
	mrs	x17, ELR_EL1
	str	x17, [x16, #1072]
	mrs	x17, SPSR_EL1
	str	x17, [x16, #1080]
	mrs	x17, ESR_EL1
	str	x17, [x16, #1088]
	mrs	x17, FAR_EL1
	str	x17, [x16, #1096]
	mrs	x17, CNTKCTL_EL1
	str	x17, [x16, #1104]
	mrs	x17, CPACR_EL1
	str	x17, [x16, #1112]
	mrs	x17, TPIDR_EL0
	str	x17, [x16, #1120]
	mrs	x17, TPIDRRO_EL0
	str	x17, [x16, #1128]
	mrs	x17, CNTP_CVAL_EL0
	str	x17, [x16, #1136]
	mrs	x17, CNTP_CTL_EL0
	and	x17, x17, #0x3
	str	x17, [x16, #1144]
	mov	x17, sp
	str	x17, [x16, #1152]
	str	x1, [x16, #1160]
	mrs	x17, FPCR
	str	x17, [x16, #1424]
	mrs	x17, FPSR
	str	x17, [x16, #1432]
	mrs	x17, TCR_EL1
	str	x17, [x16, #1544]
	mrs	x17, MAIR_EL1
	str	x17, [x16, #1552]
	str	x2, [x16, #1440]
	str	x0, [x16, #1560]
	// Admission restricts DIT to0/1 and SSBS to0/2. Never access absent fields.
	mov	x3, #0
	str	xzr, [x16, #1576]
	str	xzr, [x16, #1584]
	mrs	x17, ID_AA64PFR0_EL1
	ubfx	x17, x17, #48, #4
	cbz	x17, .Lprocess_no_dit_save
	mrs	x17, S3_3_C4_C2_5
	str	x17, [x16, #1576]
	orr	x3, x3, #0x1
.Lprocess_no_dit_save:
	mrs	x17, ID_AA64PFR1_EL1
	ubfx	x17, x17, #4, #4
	cbz	x17, .Lprocess_no_ssbs_save
	mrs	x17, S3_3_C4_C2_6
	str	x17, [x16, #1584]
	orr	x3, x3, #0x2
.Lprocess_no_ssbs_save:
	str	x3, [x16, #1568]
	mov	x17, #1
	str	x17, [x16, #1448]
	mov	x3, #0
.Lprocess_copy_in:
	ldr	x4, [x1, x3]
	str	x4, [x16, x3]
	add	x3, x3, #8
	cmp	x3, #848
	b.lo	.Lprocess_copy_in
	str	xzr, [x16, #808]
	str	xzr, [x16, #816]
	str	xzr, [x16, #824]
	str	xzr, [x16, #832]
	str	xzr, [x16, #840]
	mov	x5, #134217728
	mov	x6, #134283264
	ldr	w7, [x5]
	str	x7, [x16, #1464]
	ldr	w7, [x6]
	str	x7, [x16, #1472]
	ldr	w7, [x6, #4]
	str	x7, [x16, #1480]
	ldr	w7, [x6, #8]
	str	x7, [x16, #1488]
	ldr	w7, [x5, #128]
	str	x7, [x16, #1496]
	ldr	w7, [x5, #3076]
	str	x7, [x16, #1504]
	ldr	w7, [x5, #1052]
	str	x7, [x16, #1512]
	ldr	w7, [x5, #256]
	str	x7, [x16, #1520]
	ldr	w7, [x5, #128]
	and	w7, w7, #0xbfffffff
	str	w7, [x5, #128]
	dsb	sy
	ldr	w8, [x5, #128]
	cmp	w8, w7
	b.ne	arm_process_kernel_fatal
	ldr	w7, [x5, #3076]
	and	w7, w7, #0xdfffffff
	str	w7, [x5, #3076]
	dsb	sy
	ldr	w8, [x5, #3076]
	cmp	w8, w7
	b.ne	arm_process_kernel_fatal
	ldr	w7, [x5, #1052]
	mov	w8, #128
	bfi	w7, w8, #16, #8
	str	w7, [x5, #1052]
	dsb	sy
	ldr	w8, [x5, #1052]
	cmp	w8, w7
	b.ne	arm_process_kernel_fatal
	mov	w7, #255
	str	w7, [x6, #4]
	dsb	sy
	ldr	w8, [x6, #4]
	cmp	w8, w7
	b.ne	arm_process_kernel_fatal
	str	wzr, [x6, #8]
	dsb	sy
	ldr	w8, [x6, #8]
	cbnz	w8, arm_process_kernel_fatal
	mov	w7, #1
	str	w7, [x6]
	str	w7, [x5]
	dsb	sy
	ldr	w8, [x6]
	cmp	w8, #1
	b.ne	arm_process_kernel_fatal
	ldr	w8, [x5]
	cmp	w8, #1
	b.ne	arm_process_kernel_fatal
	mov	w7, #1073741824
	str	w7, [x5, #256]
	dsb	sy
	ldr	w8, [x5, #256]
	tbz	w8, #30, arm_process_kernel_fatal
	ldr	x7, [x16, #1440]
	msr	CNTP_CVAL_EL0, x7
	isb
	mrs	x8, CNTP_CVAL_EL0
	cmp	x8, x7
	b.ne	arm_process_kernel_fatal
	dsb	sy
	isb
	ldr	x7, .Ltmp81
	msr	VBAR_EL1, x7
	isb
	mov	sp, x16
	msr	CNTKCTL_EL1, xzr
	mov	x7, #3145728
	msr	CPACR_EL1, x7
	isb
	ldr	x7, [sp, #248]
	msr	SP_EL0, x7
	ldr	x7, [sp, #1560]
	dsb	sy
	tlbi	vmalle1
	dsb	sy
	isb
	msr	TTBR0_EL1, x7
	isb
	tlbi	vmalle1
	dsb	sy
	isb
	ldr	x7, [sp, #256]
	msr	ELR_EL1, x7
	ldr	x7, [sp, #264]
	and	x7, x7, #0xf0000000
	ldr	x8, .Ltmp82
	orr	x7, x7, x8
	msr	SPSR_EL1, x7
	ldr	x7, [sp, #784]
	msr	FPCR, x7
	ldr	x7, [sp, #792]
	msr	FPSR, x7
	ldr	x7, [sp, #800]
	msr	TPIDR_EL0, x7
	msr	TPIDRRO_EL0, xzr
	mov	x7, #1
	msr	CNTP_CTL_EL0, x7
	dsb	sy
	isb
	ldr	q0, [sp, #272]
	ldr	q1, [sp, #288]
	ldr	q2, [sp, #304]
	ldr	q3, [sp, #320]
	ldr	q4, [sp, #336]
	ldr	q5, [sp, #352]
	ldr	q6, [sp, #368]
	ldr	q7, [sp, #384]
	ldr	q8, [sp, #400]
	ldr	q9, [sp, #416]
	ldr	q10, [sp, #432]
	ldr	q11, [sp, #448]
	ldr	q12, [sp, #464]
	ldr	q13, [sp, #480]
	ldr	q14, [sp, #496]
	ldr	q15, [sp, #512]
	ldr	q16, [sp, #528]
	ldr	q17, [sp, #544]
	ldr	q18, [sp, #560]
	ldr	q19, [sp, #576]
	ldr	q20, [sp, #592]
	ldr	q21, [sp, #608]
	ldr	q22, [sp, #624]
	ldr	q23, [sp, #640]
	ldr	q24, [sp, #656]
	ldr	q25, [sp, #672]
	ldr	q26, [sp, #688]
	ldr	q27, [sp, #704]
	ldr	q28, [sp, #720]
	ldr	q29, [sp, #736]
	ldr	q30, [sp, #752]
	ldr	q31, [sp, #768]
	ldr	x0, [sp]
	ldr	x1, [sp, #8]
	ldr	x2, [sp, #16]
	ldr	x3, [sp, #24]
	ldr	x4, [sp, #32]
	ldr	x5, [sp, #40]
	ldr	x6, [sp, #48]
	ldr	x7, [sp, #56]
	ldr	x8, [sp, #64]
	ldr	x9, [sp, #72]
	ldr	x10, [sp, #80]
	ldr	x11, [sp, #88]
	ldr	x12, [sp, #96]
	ldr	x13, [sp, #104]
	ldr	x14, [sp, #112]
	ldr	x15, [sp, #120]
	ldr	x16, [sp, #128]
	ldr	x17, [sp, #136]
	ldr	x18, [sp, #144]
	ldr	x19, [sp, #152]
	ldr	x20, [sp, #160]
	ldr	x21, [sp, #168]
	ldr	x22, [sp, #176]
	ldr	x23, [sp, #184]
	ldr	x24, [sp, #192]
	ldr	x25, [sp, #200]
	ldr	x26, [sp, #208]
	ldr	x27, [sp, #216]
	ldr	x28, [sp, #224]
	ldr	x29, [sp, #232]
	ldr	x30, [sp, #240]
	eret
.Ltmp83:
	.size	arm_process_slice, .Ltmp83-arm_process_slice

arm_process_sync:
	str	x0, [sp]
	str	x1, [sp, #8]
	str	x2, [sp, #16]
	str	x3, [sp, #24]
	str	x4, [sp, #32]
	str	x5, [sp, #40]
	str	x6, [sp, #48]
	str	x7, [sp, #56]
	str	x8, [sp, #64]
	str	x9, [sp, #72]
	str	x10, [sp, #80]
	str	x11, [sp, #88]
	str	x12, [sp, #96]
	str	x13, [sp, #104]
	str	x14, [sp, #112]
	str	x15, [sp, #120]
	str	x16, [sp, #128]
	str	x17, [sp, #136]
	str	x18, [sp, #144]
	str	x19, [sp, #152]
	str	x20, [sp, #160]
	str	x21, [sp, #168]
	str	x22, [sp, #176]
	str	x23, [sp, #184]
	str	x24, [sp, #192]
	str	x25, [sp, #200]
	str	x26, [sp, #208]
	str	x27, [sp, #216]
	str	x28, [sp, #224]
	str	x29, [sp, #232]
	str	x30, [sp, #240]
	mov	x0, #1
	str	x0, [sp, #824]
	b	.Lprocess_trap

arm_process_irq:
	str	x0, [sp]
	str	x1, [sp, #8]
	str	x2, [sp, #16]
	str	x3, [sp, #24]
	str	x4, [sp, #32]
	str	x5, [sp, #40]
	str	x6, [sp, #48]
	str	x7, [sp, #56]
	str	x8, [sp, #64]
	str	x9, [sp, #72]
	str	x10, [sp, #80]
	str	x11, [sp, #88]
	str	x12, [sp, #96]
	str	x13, [sp, #104]
	str	x14, [sp, #112]
	str	x15, [sp, #120]
	str	x16, [sp, #128]
	str	x17, [sp, #136]
	str	x18, [sp, #144]
	str	x19, [sp, #152]
	str	x20, [sp, #160]
	str	x21, [sp, #168]
	str	x22, [sp, #176]
	str	x23, [sp, #184]
	str	x24, [sp, #192]
	str	x25, [sp, #200]
	str	x26, [sp, #208]
	str	x27, [sp, #216]
	str	x28, [sp, #224]
	str	x29, [sp, #232]
	str	x30, [sp, #240]
	mov	x0, #3
	str	x0, [sp, #824]
	b	.Lprocess_trap
.Lprocess_trap:
	msr	DAIFSet, #15
	ldr	x0, [sp, #1448]
	cmp	x0, #1
	b.ne	arm_process_kernel_fatal
	mrs	x0, SP_EL0
	str	x0, [sp, #248]
	mrs	x0, ELR_EL1
	str	x0, [sp, #256]
	mrs	x0, SPSR_EL1
	str	x0, [sp, #264]
	and	x1, x0, #0x1f
	cbnz	x1, arm_process_kernel_fatal
	str	q0, [sp, #272]
	str	q1, [sp, #288]
	str	q2, [sp, #304]
	str	q3, [sp, #320]
	str	q4, [sp, #336]
	str	q5, [sp, #352]
	str	q6, [sp, #368]
	str	q7, [sp, #384]
	str	q8, [sp, #400]
	str	q9, [sp, #416]
	str	q10, [sp, #432]
	str	q11, [sp, #448]
	str	q12, [sp, #464]
	str	q13, [sp, #480]
	str	q14, [sp, #496]
	str	q15, [sp, #512]
	str	q16, [sp, #528]
	str	q17, [sp, #544]
	str	q18, [sp, #560]
	str	q19, [sp, #576]
	str	q20, [sp, #592]
	str	q21, [sp, #608]
	str	q22, [sp, #624]
	str	q23, [sp, #640]
	str	q24, [sp, #656]
	str	q25, [sp, #672]
	str	q26, [sp, #688]
	str	q27, [sp, #704]
	str	q28, [sp, #720]
	str	q29, [sp, #736]
	str	q30, [sp, #752]
	str	q31, [sp, #768]
	mrs	x0, FPCR
	str	x0, [sp, #784]
	mrs	x0, FPSR
	str	x0, [sp, #792]
	mrs	x0, TPIDR_EL0
	str	x0, [sp, #800]
	ldr	x0, [sp, #824]
	cmp	x0, #3
	b.eq	.Lprocess_irq_capture
	mrs	x0, ESR_EL1
	str	x0, [sp, #808]
	lsr	x1, x0, #26
	cmp	x1, #21
	b.ne	.Lprocess_fault
	tbz	w0, #25, .Lprocess_fault
	and	x2, x0, #0xffff
	cbnz	x2, .Lprocess_fault
	b	.Lprocess_quiesce
.Lprocess_fault:
	mov	x2, #2
	str	x2, [sp, #824]
	cmp	x1, #32
	b.eq	.Lprocess_far
	cmp	x1, #36
	b.ne	.Lprocess_quiesce
.Lprocess_far:
	tbnz	w0, #10, .Lprocess_quiesce
	mrs	x2, FAR_EL1
	str	x2, [sp, #816]
	mov	x2, #1
	str	x2, [sp, #840]
	b	.Lprocess_quiesce
.Lprocess_irq_capture:
	mov	x0, #134283264
	ldr	w1, [x0, #12]
	str	x1, [sp, #832]
	and	w2, w1, #0x3ff
	cmp	w2, #30
	b.eq	.Lprocess_timer_irq
	cmp	w2, #1020
	b.lo	arm_process_kernel_fatal
	mov	x2, #4
	str	x2, [sp, #824]
	b	.Lprocess_quiesce
.Lprocess_timer_irq:
	mrs	x2, CNTP_CTL_EL0
	str	x2, [sp, #1528]
	tbz	w2, #2, arm_process_kernel_fatal
	isb
	mrs	x2, CNTPCT_EL0
	str	x2, [sp, #1536]
	ldr	x3, [sp, #1440]
	cmp	x2, x3
	b.lo	arm_process_kernel_fatal
.Lprocess_quiesce:
	ldr	x0, [sp, #824]
	str	x0, [sp, #1456]
	mov	x0, #2
	msr	CNTP_CTL_EL0, x0
	isb
	mov	x5, #134217728
	mov	x6, #134283264
	mov	w7, #1073741824
	str	w7, [x5, #384]
	dsb	sy
	ldr	x0, [sp, #824]
	cmp	x0, #3
	b.ne	.Lprocess_no_eoi
	ldr	w0, [sp, #832]
	str	w0, [x6, #16]
	dsb	sy
.Lprocess_no_eoi:
	str	w7, [x5, #640]
	dsb	sy
	ldr	w0, [x5, #256]
	tbnz	w0, #30, arm_process_kernel_fatal
	ldr	w0, [x5, #512]
	tbnz	w0, #30, arm_process_kernel_fatal
	ldr	w0, [x5, #768]
	tbnz	w0, #30, arm_process_kernel_fatal
	str	wzr, [x6]
	str	wzr, [x5]
	dsb	sy
	ldr	x7, [sp, #1496]
	str	w7, [x5, #128]
	dsb	sy
	ldr	w8, [x5, #128]
	cmp	w8, w7
	b.ne	arm_process_kernel_fatal
	ldr	x7, [sp, #1504]
	str	w7, [x5, #3076]
	dsb	sy
	ldr	w8, [x5, #3076]
	cmp	w8, w7
	b.ne	arm_process_kernel_fatal
	ldr	x7, [sp, #1512]
	str	w7, [x5, #1052]
	dsb	sy
	ldr	w8, [x5, #1052]
	cmp	w8, w7
	b.ne	arm_process_kernel_fatal
	ldr	x7, [sp, #1480]
	str	w7, [x6, #4]
	dsb	sy
	ldr	w8, [x6, #4]
	cmp	w8, w7
	b.ne	arm_process_kernel_fatal
	ldr	x7, [sp, #1488]
	str	w7, [x6, #8]
	dsb	sy
	ldr	w8, [x6, #8]
	cmp	w8, w7
	b.ne	arm_process_kernel_fatal
	ldr	x7, [sp, #1472]
	str	w7, [x6]
	dsb	sy
	ldr	w8, [x6]
	cmp	w8, w7
	b.ne	arm_process_kernel_fatal
	ldr	x7, [sp, #1464]
	str	w7, [x5]
	dsb	sy
	ldr	w8, [x5]
	cmp	w8, w7
	b.ne	arm_process_kernel_fatal
	ldr	w7, [x5, #256]
	ldr	w8, [sp, #1520]
	cmp	w7, w8
	b.ne	arm_process_kernel_fatal
	ldr	x7, [sp, #1136]
	msr	CNTP_CVAL_EL0, x7
	ldr	x7, [sp, #1144]
	msr	CNTP_CTL_EL0, x7
	isb
	mrs	x8, CNTP_CTL_EL0
	and	x8, x8, #0x3
	cmp	x8, x7
	b.ne	arm_process_kernel_fatal
	ldr	x7, [sp, #1136]
	mrs	x8, CNTP_CVAL_EL0
	cmp	x8, x7
	b.ne	arm_process_kernel_fatal
	ldr	x7, [sp, #1024]
	dsb	sy
	tlbi	vmalle1
	dsb	sy
	isb
	msr	TTBR0_EL1, x7
	isb
	tlbi	vmalle1
	dsb	sy
	isb
	// Context destination may name the omitted owned arena: copy only now.
	ldr	x1, [sp, #1160]
	mov	x2, #0
	mov	x16, sp
.Lprocess_copy_out:
	ldr	x3, [x16, x2]
	str	x3, [x1, x2]
	add	x2, x2, #8
	cmp	x2, #848
	b.lo	.Lprocess_copy_out
	str	xzr, [x16, #1448]
	ldr	x3, [x16, #1568]
	tbz	w3, #0, .Lprocess_no_dit_restore
	ldr	x17, [x16, #1576]
	msr	S3_3_C4_C2_5, x17
.Lprocess_no_dit_restore:
	tbz	w3, #1, .Lprocess_no_ssbs_restore
	ldr	x17, [x16, #1584]
	msr	S3_3_C4_C2_6, x17
.Lprocess_no_ssbs_restore:
	isb
	ldr	x17, [x16, #1040]
	msr	PAR_EL1, x17
	ldr	x17, [x16, #1056]
	msr	SP_EL0, x17
	ldr	x17, [x16, #1064]
	msr	DAIF, x17
	ldr	x17, [x16, #1072]
	msr	ELR_EL1, x17
	ldr	x17, [x16, #1080]
	msr	SPSR_EL1, x17
	ldr	x17, [x16, #1088]
	msr	ESR_EL1, x17
	ldr	x17, [x16, #1096]
	msr	FAR_EL1, x17
	ldr	x17, [x16, #1104]
	msr	CNTKCTL_EL1, x17
	ldr	x17, [x16, #1112]
	msr	CPACR_EL1, x17
	ldr	x17, [x16, #1120]
	msr	TPIDR_EL0, x17
	ldr	x17, [x16, #1128]
	msr	TPIDRRO_EL0, x17
	ldr	x17, [x16, #1424]
	msr	FPCR, x17
	ldr	x17, [x16, #1432]
	msr	FPSR, x17
	isb
	ldr	q8, [x16, #1296]
	ldr	q9, [x16, #1312]
	ldr	q10, [x16, #1328]
	ldr	q11, [x16, #1344]
	ldr	q12, [x16, #1360]
	ldr	q13, [x16, #1376]
	ldr	q14, [x16, #1392]
	ldr	q15, [x16, #1408]
	ldr	x18, [x16, #1184]
	ldr	x19, [x16, #1192]
	ldr	x20, [x16, #1200]
	ldr	x21, [x16, #1208]
	ldr	x22, [x16, #1216]
	ldr	x23, [x16, #1224]
	ldr	x24, [x16, #1232]
	ldr	x25, [x16, #1240]
	ldr	x26, [x16, #1248]
	ldr	x27, [x16, #1256]
	ldr	x28, [x16, #1264]
	ldr	x29, [x16, #1272]
	ldr	x30, [x16, #1280]
	ldr	x0, [x16, #1456]
	ldr	x17, [x16, #1152]
	mov	sp, x17
	ldr	x17, [x16, #1048]
	msr	VBAR_EL1, x17
	isb
	ret

	.globl	arm_process_kernel_fatal
arm_process_kernel_fatal:
	msr	DAIFSet, #15
	ldr	x0, .Ltmp84
	mov	x1, #150994944
.Lprocess_fatal_char:
	ldrb	w2, [x0], #1
	cbz	w2, .Lprocess_fatal_exit
	mov	x3, #65535
.Lprocess_fatal_poll:
	ldr	w4, [x1, #24]
	tbz	w4, #5, .Lprocess_fatal_send
	subs	x3, x3, #1
	b.ne	.Lprocess_fatal_poll
	b	.Lprocess_fatal_exit
.Lprocess_fatal_send:
	str	w2, [x1]
	b	.Lprocess_fatal_char
.Lprocess_fatal_exit:
	ldr	x1, .Ltmp85
	mov	x0, #32
	hlt	#0xf000
.Lprocess_terminal:
	wfe
	b	.Lprocess_terminal
	.p2align	3, 0x0
.Ltmp80:
	.xword	__exception_stack_top
	.p2align	3, 0x0
.Ltmp81:
	.xword	arm_process_vectors
	.p2align	3, 0x0
.Ltmp82:
	.xword	4195136
	.p2align	3, 0x0
.Ltmp84:
	.xword	.Lprocess_fatal_message
	.p2align	3, 0x0
.Ltmp85:
	.xword	.Lprocess_failure_block
	.section	.rodata.process,"a",@progbits
.Lprocess_fatal_message:
	.ascii	"HMPROC KERNEL FAILURE\n"
	.byte	0
	.p2align	3, 0x0
.Lprocess_failure_block:
	.xword	131110
	.xword	1
	// SAFETY: Reviewed design0010. Private records and guarded stacks remain owned
	// through each ordinary AAPCS64 switch; no live Rust frame is abandoned.
	.arch	armv8.1-a
	.section	.text.threads,"ax",@progbits
	.globl	arm_context_switch
	.globl	arm_thread_start
	.globl	arm_thread_context_probe
arm_context_switch:
	stp	x18, x19, [x0]
	stp	x20, x21, [x0, #16]
	stp	x22, x23, [x0, #32]
	stp	x24, x25, [x0, #48]
	stp	x26, x27, [x0, #64]
	stp	x28, x29, [x0, #80]
	str	x30, [x0, #96]
	mov	x2, sp
	str	x2, [x0, #104]
	stp	q8, q9, [x0, #112]
	stp	q10, q11, [x0, #144]
	stp	q12, q13, [x0, #176]
	stp	q14, q15, [x0, #208]
	mrs	x2, FPCR
	str	x2, [x0, #240]
	mrs	x2, FPSR
	str	x2, [x0, #248]
	ldr	x2, [x1, #240]
	msr	FPCR, x2
	ldr	x2, [x1, #248]
	msr	FPSR, x2
	ldp	q8, q9, [x1, #112]
	ldp	q10, q11, [x1, #144]
	ldp	q12, q13, [x1, #176]
	ldp	q14, q15, [x1, #208]
	ldp	x18, x19, [x1]
	ldp	x20, x21, [x1, #16]
	ldp	x22, x23, [x1, #32]
	ldp	x24, x25, [x1, #48]
	ldp	x26, x27, [x1, #64]
	ldp	x28, x29, [x1, #80]
	ldr	x30, [x1, #96]
	ldr	x2, [x1, #104]
	mov	sp, x2
	ret

arm_thread_start:
	mov	x0, x21
	mov	x1, x22
	bl	_RNvNtCsel89eI7eLYd_8hematite7threads14callback_entry
	// Rust callback and adapter have both returned normally. Only assembly
	// frames remain; marking Done cannot strand callback-owned Rust locals.
	str	x0, [x19, #256]
	mov	x0, #2
	str	x0, [x19, #264]
	mov	x0, x19
	mov	x1, x20
	b	arm_context_switch

arm_thread_context_probe:
	sub	sp, sp, #208
	str	x19, [sp]
	str	x20, [sp, #8]
	str	x21, [sp, #16]
	str	x22, [sp, #24]
	str	x23, [sp, #32]
	str	x24, [sp, #40]
	str	x25, [sp, #48]
	str	x26, [sp, #56]
	str	x27, [sp, #64]
	str	x28, [sp, #72]
	str	x29, [sp, #80]
	str	x30, [sp, #88]
	str	d8, [sp, #96]
	str	d9, [sp, #104]
	str	d10, [sp, #112]
	str	d11, [sp, #120]
	str	d12, [sp, #128]
	str	d13, [sp, #136]
	str	d14, [sp, #144]
	str	d15, [sp, #152]
	mrs	x9, FPCR
	str	x9, [sp, #160]
	mrs	x9, FPSR
	str	x9, [sp, #168]
	str	x0, [sp, #176]
	str	x1, [sp, #200]
	mov	x9, sp
	str	x9, [sp, #192]
	mov	x9, #256
	add	x9, x9, x1, lsl #8
	str	x9, [sp, #184]
	add	x19, x9, #19
	add	x20, x9, #20
	add	x21, x9, #21
	add	x22, x9, #22
	add	x23, x9, #23
	add	x24, x9, #24
	add	x25, x9, #25
	add	x26, x9, #26
	add	x27, x9, #27
	add	x28, x9, #28
	add	x29, x9, #29
	add	x10, x9, #8
	fmov	d8, x10
	add	x10, x9, #9
	fmov	d9, x10
	add	x10, x9, #10
	fmov	d10, x10
	add	x10, x9, #11
	fmov	d11, x10
	add	x10, x9, #12
	fmov	d12, x10
	add	x10, x9, #13
	fmov	d13, x10
	add	x10, x9, #14
	fmov	d14, x10
	add	x10, x9, #15
	fmov	d15, x10
	and	x10, x1, #0x1
	lsl	x11, x10, #22
	msr	FPCR, x11
	lsl	x11, x10, #27
	msr	FPSR, x11
	ldr	x0, [sp, #176]
	bl	_RNvNtCsel89eI7eLYd_8hematite7threads11probe_yield
	mov	x9, sp
	ldr	x10, [sp, #192]
	cmp	x9, x10
	b.ne	.Lthread_probe_fail
	ldr	x9, [sp, #184]
	add	x10, x9, #19
	cmp	x19, x10
	b.ne	.Lthread_probe_fail
	add	x10, x9, #20
	cmp	x20, x10
	b.ne	.Lthread_probe_fail
	add	x10, x9, #21
	cmp	x21, x10
	b.ne	.Lthread_probe_fail
	add	x10, x9, #22
	cmp	x22, x10
	b.ne	.Lthread_probe_fail
	add	x10, x9, #23
	cmp	x23, x10
	b.ne	.Lthread_probe_fail
	add	x10, x9, #24
	cmp	x24, x10
	b.ne	.Lthread_probe_fail
	add	x10, x9, #25
	cmp	x25, x10
	b.ne	.Lthread_probe_fail
	add	x10, x9, #26
	cmp	x26, x10
	b.ne	.Lthread_probe_fail
	add	x10, x9, #27
	cmp	x27, x10
	b.ne	.Lthread_probe_fail
	add	x10, x9, #28
	cmp	x28, x10
	b.ne	.Lthread_probe_fail
	add	x10, x9, #29
	cmp	x29, x10
	b.ne	.Lthread_probe_fail
	add	x10, x9, #8
	fmov	x11, d8
	cmp	x10, x11
	b.ne	.Lthread_probe_fail
	add	x10, x9, #9
	fmov	x11, d9
	cmp	x10, x11
	b.ne	.Lthread_probe_fail
	add	x10, x9, #10
	fmov	x11, d10
	cmp	x10, x11
	b.ne	.Lthread_probe_fail
	add	x10, x9, #11
	fmov	x11, d11
	cmp	x10, x11
	b.ne	.Lthread_probe_fail
	add	x10, x9, #12
	fmov	x11, d12
	cmp	x10, x11
	b.ne	.Lthread_probe_fail
	add	x10, x9, #13
	fmov	x11, d13
	cmp	x10, x11
	b.ne	.Lthread_probe_fail
	add	x10, x9, #14
	fmov	x11, d14
	cmp	x10, x11
	b.ne	.Lthread_probe_fail
	add	x10, x9, #15
	fmov	x11, d15
	cmp	x10, x11
	b.ne	.Lthread_probe_fail
	ldr	x9, [sp, #200]
	and	x9, x9, #0x1
	lsl	x10, x9, #22
	mrs	x11, FPCR
	cmp	x10, x11
	b.ne	.Lthread_probe_fail
	lsl	x10, x9, #27
	mrs	x11, FPSR
	cmp	x10, x11
	b.ne	.Lthread_probe_fail
	mov	x0, #1
	b	.Lthread_probe_restore
.Lthread_probe_fail:
	mov	x0, #0
.Lthread_probe_restore:
	ldr	x9, [sp, #160]
	msr	FPCR, x9
	ldr	x9, [sp, #168]
	msr	FPSR, x9
	ldr	d8, [sp, #96]
	ldr	d9, [sp, #104]
	ldr	d10, [sp, #112]
	ldr	d11, [sp, #120]
	ldr	d12, [sp, #128]
	ldr	d13, [sp, #136]
	ldr	d14, [sp, #144]
	ldr	d15, [sp, #152]
	ldr	x19, [sp]
	ldr	x20, [sp, #8]
	ldr	x21, [sp, #16]
	ldr	x22, [sp, #24]
	ldr	x23, [sp, #32]
	ldr	x24, [sp, #40]
	ldr	x25, [sp, #48]
	ldr	x26, [sp, #56]
	ldr	x27, [sp, #64]
	ldr	x28, [sp, #72]
	ldr	x29, [sp, #80]
	ldr	x30, [sp, #88]
	add	sp, sp, #208
	ret
	.section	.bss.cpu_local,"aw",@nobits
	.p2align	6, 0x0
	.globl	arm_cpu_records
arm_cpu_records:
	.zero	256
	// SAFETY: Dedicated CPU1 lifecycle entry; design 0018. No mutable shared loads
	// until coherent mappings are active. All peer exceptions are terminal.
	.arch	armv8.1-a
	.section	.text.secondary,"ax",@progbits
	.globl	arm_secondary_start
arm_secondary_start:
	msr	DAIFSet, #15
	mov	x19, x0
	mrs	x0, CurrentEL
	cmp	x0, #4
	b.ne	arm_secondary_failure
	mrs	x0, MPIDR_EL1
	ldr	x1, .Ltmp86
	and	x0, x0, x1
	cmp	x0, #1
	b.ne	arm_secondary_failure
	cbz	x19, arm_secondary_failure
	mrs	x0, SCTLR_EL1
	mov	x1, #4101
	tst	x0, x1
	b.ne	arm_secondary_failure
	msr	SPSel, #1
	ldr	x0, .Ltmp87
	mov	sp, x0
	ldr	x0, .Ltmp88
	msr	SP_EL0, x0
	ldr	x0, .Ltmp89
	msr	VBAR_EL1, x0
	isb
	mov	x0, #255
	msr	MAIR_EL1, x0
	ldr	x0, .Ltmp90
	msr	TCR_EL1, x0
	ldr	x0, .Ltmp91
	msr	TTBR0_EL1, x0
	msr	TTBR1_EL1, xzr
	isb
	tlbi	vmalle1
	dsb	sy
	isb
	ic	iallu
	dsb	sy
	isb
	ldr	x0, .Ltmp92
	msr	SCTLR_EL1, x0
	isb
	msr	PAN, #1
	mov	x0, #3145728
	msr	CPACR_EL1, x0
	isb
	msr	FPCR, xzr
	msr	FPSR, xzr
	ldr	x0, .Ltmp93
	add	x0, x0, #128
	msr	TPIDR_EL1, x0
	isb
	bl	arm_secondary_quiet
	// Reserve a real assembly caller frame so observed SP is inside usable RAM.
	stp	x29, x30, [sp, #-16]!
	mov	x0, x19
	bl	_RNvNtCsel89eI7eLYd_8hematite9secondary7adapter
	ldp	x29, x30, [sp], #16
	// Every Rust frame has returned. Teardown and publication are assembly-only.
	bl	arm_secondary_quiet
	ldr	x1, .Ltmp94
	ldar	x0, [x1]
	cmp	x0, #3
	b.ne	arm_secondary_failure
	mov	x0, #4
	stlr	x0, [x1]
	dsb	sy
	ldr	x0, .Ltmp95
	mov	x1, #0
	mov	x2, #0
	mov	x3, #0
	hvc	#0
	b	arm_secondary_failure

	// Only this CPU's timer/PPI/GICC; never changes shared distributor forwarding.
	.globl	arm_secondary_quiet
arm_secondary_quiet:
	mov	x0, #2
	msr	CNTP_CTL_EL0, x0
	isb
	mov	x0, #134283264
	str	wzr, [x0]
	mov	x1, #134217728
	mov	w2, #1073741824
	str	w2, [x1, #384]
	dsb	sy
	str	w2, [x1, #640]
	dsb	sy
	mrs	x2, CNTP_CTL_EL0
	and	x2, x2, #0x3
	cmp	x2, #2
	b.ne	arm_secondary_failure
	ldr	w2, [x0]
	cbnz	w2, arm_secondary_failure
	ldr	w2, [x1, #256]
	tbnz	w2, #30, arm_secondary_failure
	ldr	w2, [x1, #512]
	tbnz	w2, #30, arm_secondary_failure
	ldr	w2, [x1, #768]
	tbnz	w2, #30, arm_secondary_failure
	ret

	.globl	arm_secondary_failure
	.globl	arm_secondary_stale
arm_secondary_failure:
	ldr	x1, .Ltmp96
	b	.Lsecondary_exit
arm_secondary_stale:
	ldr	x1, .Ltmp97
	b	.Lsecondary_exit
arm_secondary_off_return:
	ldr	x1, .Ltmp98
.Lsecondary_exit:
	mov	x0, #32
	hlt	#0xf000
.Lsecondary_halt:
	wfi
	b	.Lsecondary_halt
	.p2align	3, 0x0
.Ltmp86:
	.xword	1095233437695
	.p2align	3, 0x0
.Ltmp87:
	.xword	__secondary_stack_top
	.p2align	3, 0x0
.Ltmp88:
	.xword	__secondary_exception_stack_top
	.p2align	3, 0x0
.Ltmp89:
	.xword	arm_secondary_vectors
	.p2align	3, 0x0
.Ltmp90:
	.xword	2157524249
	.p2align	3, 0x0
.Ltmp91:
	.xword	arm_secondary_root
	.p2align	3, 0x0
.Ltmp92:
	.xword	811079693
	.p2align	3, 0x0
.Ltmp93:
	.xword	arm_cpu_records
	.p2align	3, 0x0
.Ltmp94:
	.xword	_RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX
	.p2align	3, 0x0
.Ltmp95:
	.xword	2214592514
	.p2align	3, 0x0
.Ltmp96:
	.xword	.Lsecondary_failed
	.p2align	3, 0x0
.Ltmp97:
	.xword	.Lsecondary_stale
	.p2align	3, 0x0
.Ltmp98:
	.xword	.Lsecondary_off_return

	.p2align	11
arm_secondary_vectors:
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_timer_irq
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7
	b	arm_secondary_failure
	.p2align	7

	// Terminal-only negative: no stack access or register restoration on a guard.

	.section	.rodata.secondary,"a",@progbits
	.p2align	3, 0x0
.Lsecondary_failed:
	.xword	131110
	.xword	2
.Lsecondary_stale:
	.xword	131110
	.xword	3
.Lsecondary_off_return:
	.xword	131110
	.xword	4

.Lsecondary_overflow:
	.xword	131110
	.xword	5

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI0_0:
	.xword	131110
	.xword	1
	.section	.text._RINvCsjStpv0Kdcdo_9hm_kernel13report_memoryNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBJ_,"ax",@progbits
	.p2align	2
	.type	_RINvCsjStpv0Kdcdo_9hm_kernel13report_memoryNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBJ_,@function
_RINvCsjStpv0Kdcdo_9hm_kernel13report_memoryNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBJ_:
.Lfunc_begin0:
	.cfi_startproc
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x30, [sp, #32]
	stp	x20, x19, [sp, #48]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -32
	.cfi_remember_state
	mov	x8, x0
	ldr	x0, [x0, #2504]
	mov	w19, #24
	mov	w9, #34464
	movk	w19, #2304, lsl #16
	movk	w9, #1, lsl #16
.LBB0_1:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_3
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_1
	b	.LBB0_54
.LBB0_3:
	mov	w9, #150994944
	mov	w10, #66
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_4:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_6
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_4
	b	.LBB0_54
.LBB0_6:
	mov	w9, #150994944
	mov	w10, #111
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_7:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_9
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_7
	b	.LBB0_54
.LBB0_9:
	mov	w9, #150994944
	mov	w10, #111
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_10:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_12
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_10
	b	.LBB0_54
.LBB0_12:
	mov	w9, #150994944
	mov	w10, #116
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_13:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_15
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_13
	b	.LBB0_54
.LBB0_15:
	mov	w9, #150994944
	mov	w10, #32
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_16:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_18
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_16
	b	.LBB0_54
.LBB0_18:
	mov	w9, #150994944
	mov	w10, #82
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_19:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_21
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_19
	b	.LBB0_54
.LBB0_21:
	mov	w9, #150994944
	mov	w10, #65
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_22:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_24
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_22
	b	.LBB0_54
.LBB0_24:
	mov	w9, #150994944
	mov	w10, #77
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_25:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_27
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_25
	b	.LBB0_54
.LBB0_27:
	mov	w9, #150994944
	mov	w10, #32
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_28:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_30
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_28
	b	.LBB0_54
.LBB0_30:
	mov	w9, #150994944
	mov	w10, #98
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_31:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_33
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_31
	b	.LBB0_54
.LBB0_33:
	mov	w9, #150994944
	mov	w10, #121
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_34:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_36
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_34
	b	.LBB0_54
.LBB0_36:
	mov	w9, #150994944
	mov	w10, #116
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_37:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_39
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_37
	b	.LBB0_54
.LBB0_39:
	mov	w9, #150994944
	mov	w10, #101
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_40:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_42
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_40
	b	.LBB0_54
.LBB0_42:
	mov	w9, #150994944
	mov	w10, #115
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_43:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_45
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_43
	b	.LBB0_54
.LBB0_45:
	mov	w9, #150994944
	mov	w10, #58
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_46:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_48
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_46
	b	.LBB0_54
.LBB0_48:
	mov	w9, #150994944
	mov	w10, #32
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_49:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_51
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_49
	b	.LBB0_54
.LBB0_51:
	mov	w9, #150994944
	mov	w10, #48
	str	w10, [x9]
	mov	w9, #34464
	movk	w9, #1, lsl #16
.LBB0_52:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB0_56
	isb
	subs	w9, w9, #1
	b.ne	.LBB0_52
.LBB0_54:
	adrp	x8, .LCPI0_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI0_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB0_55:
	//APP
	wfi
	//NO_APP
	b	.LBB0_55
.LBB0_56:
	mov	w9, #34464
	str	x8, [sp, #40]
	mov	w20, #150994944
	movk	w9, #1, lsl #16
	mov	w8, #120
	str	w9, [sp, #12]
	str	w8, [x20]
	bl	_RINvCsjStpv0Kdcdo_9hm_kernel9write_hexNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBE_
	mov	x8, xzr
	adrp	x9, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.1
	add	x9, x9, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.1
	mov	w10, #13
.LBB0_57:
	mov	w11, #34464
	cmp	x8, #17
	movk	w11, #1, lsl #16
	b.ne	.LBB0_60
.LBB0_58:
	ldr	w12, [x19]
	tbz	w12, #5, .LBB0_63
	isb
	subs	w11, w11, #1
	b.ne	.LBB0_58
	b	.LBB0_75
.LBB0_60:
	ldrb	w11, [x9, x8]
	mov	w12, #34464
	movk	w12, #1, lsl #16
.LBB0_61:
	ldr	w13, [x19]
	tbz	w13, #5, .LBB0_67
	isb
	subs	w12, w12, #1
	b.ne	.LBB0_61
	b	.LBB0_77
.LBB0_63:
	mov	w11, #34464
	str	w10, [x20]
	movk	w11, #1, lsl #16
.LBB0_64:
	ldr	w12, [x19]
	tbz	w12, #5, .LBB0_66
	isb
	subs	w11, w11, #1
	b.ne	.LBB0_64
	b	.LBB0_79
.LBB0_66:
	mov	w11, #10
.LBB0_67:
	add	x8, x8, #1
	str	w11, [x20]
	cmp	x8, #18
	b.ne	.LBB0_57
	ldr	x8, [sp, #40]
	ldr	x8, [x8]
	cbz	x8, .LBB0_156
	//APP
	mrs	x8, DAIF
	msr	DAIFSet, #2
	//NO_APP
	mov	w10, #1
	ldr	x9, [sp, #40]
	add	x9, x9, #528
.LBB0_70:
	ldaxrb	w11, [x9]
	cbnz	w11, .LBB0_132
	stxrb	w11, w10, [x9]
	cbnz	w11, .LBB0_70
.LBB0_72:
	ldr	x9, [sp, #40]
	add	x10, x9, #528
	stlrb	wzr, [x10]
	//APP
	msr	DAIF, x8
	//NO_APP
	mov	w8, #34464
	ldr	x0, [x9, #1064]
	movk	w8, #1, lsl #16
.LBB0_73:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_81
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_73
	b	.LBB0_142
.LBB0_75:
	adrp	x8, .LCPI0_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI0_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB0_76:
	//APP
	wfi
	//NO_APP
	b	.LBB0_76
.LBB0_77:
	adrp	x8, .LCPI0_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI0_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB0_78:
	//APP
	wfi
	//NO_APP
	b	.LBB0_78
.LBB0_79:
	adrp	x8, .LCPI0_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI0_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB0_80:
	//APP
	wfi
	//NO_APP
	b	.LBB0_80
.LBB0_81:
	mov	w8, #150994944
	mov	w9, #70
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_82:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_84
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_82
	b	.LBB0_142
.LBB0_84:
	mov	w8, #150994944
	mov	w9, #114
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_85:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_87
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_85
	b	.LBB0_142
.LBB0_87:
	mov	w8, #150994944
	mov	w9, #97
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_88:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_90
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_88
	b	.LBB0_142
.LBB0_90:
	mov	w8, #150994944
	mov	w9, #109
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_91:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_93
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_91
	b	.LBB0_142
.LBB0_93:
	mov	w8, #150994944
	mov	w9, #101
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_94:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_96
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_94
	b	.LBB0_142
.LBB0_96:
	mov	w8, #150994944
	mov	w9, #32
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_97:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_99
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_97
	b	.LBB0_142
.LBB0_99:
	mov	w8, #150994944
	mov	w9, #112
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_100:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_102
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_100
	b	.LBB0_142
.LBB0_102:
	mov	w8, #150994944
	mov	w9, #111
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_103:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_105
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_103
	b	.LBB0_142
.LBB0_105:
	mov	w8, #150994944
	mov	w9, #111
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_106:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_108
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_106
	b	.LBB0_142
.LBB0_108:
	mov	w8, #150994944
	mov	w9, #108
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_109:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_111
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_109
	b	.LBB0_142
.LBB0_111:
	mov	w8, #150994944
	mov	w9, #32
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_112:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_114
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_112
	b	.LBB0_142
.LBB0_114:
	mov	w8, #150994944
	mov	w9, #112
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_115:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_117
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_115
	b	.LBB0_142
.LBB0_117:
	mov	w8, #150994944
	mov	w9, #97
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_118:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_120
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_118
	b	.LBB0_142
.LBB0_120:
	mov	w8, #150994944
	mov	w9, #103
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_121:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_123
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_121
	b	.LBB0_142
.LBB0_123:
	mov	w8, #150994944
	mov	w9, #101
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_124:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_126
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_124
	b	.LBB0_142
.LBB0_126:
	mov	w8, #150994944
	mov	w9, #115
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_127:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_129
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_127
	b	.LBB0_142
.LBB0_129:
	mov	w8, #150994944
	mov	w9, #58
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_130:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_136
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_130
	b	.LBB0_142
.LBB0_132:
	mov	w10, #1
.LBB0_133:
	clrex
	isb
.LBB0_134:
	ldaxrb	w11, [x9]
	cbnz	w11, .LBB0_133
	stxrb	w11, w10, [x9]
	cbz	w11, .LBB0_72
	b	.LBB0_134
.LBB0_136:
	mov	w8, #150994944
	mov	w9, #32
	str	w9, [x8]
	mov	w8, #34464
	movk	w8, #1, lsl #16
.LBB0_137:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB0_139
	isb
	subs	w8, w8, #1
	b.ne	.LBB0_137
	b	.LBB0_142
.LBB0_139:
	mov	w8, #150994944
	mov	w9, #48
	str	w9, [x8]
.LBB0_140:
	ldr	w8, [x19]
	tbz	w8, #5, .LBB0_144
	isb
	ldr	w8, [sp, #12]
	subs	w8, w8, #1
	str	w8, [sp, #12]
	b.ne	.LBB0_140
.LBB0_142:
	adrp	x8, .LCPI0_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI0_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB0_143:
	//APP
	wfi
	//NO_APP
	b	.LBB0_143
.LBB0_144:
	mov	w20, #150994944
	mov	w8, #120
	str	w8, [x20]
	bl	_RINvCsjStpv0Kdcdo_9hm_kernel9write_hexNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBE_
	mov	x8, xzr
	adrp	x9, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.3
	add	x9, x9, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.3
	mov	w10, #13
.LBB0_145:
	mov	w11, #34464
	cmp	x8, #41
	movk	w11, #1, lsl #16
	b.ne	.LBB0_148
.LBB0_146:
	ldr	w12, [x19]
	tbz	w12, #5, .LBB0_151
	isb
	subs	w11, w11, #1
	b.ne	.LBB0_146
	b	.LBB0_157
.LBB0_148:
	ldrb	w11, [x9, x8]
	mov	w12, #34464
	movk	w12, #1, lsl #16
.LBB0_149:
	ldr	w13, [x19]
	tbz	w13, #5, .LBB0_155
	isb
	subs	w12, w12, #1
	b.ne	.LBB0_149
	b	.LBB0_159
.LBB0_151:
	mov	w11, #34464
	str	w10, [x20]
	movk	w11, #1, lsl #16
.LBB0_152:
	ldr	w12, [x19]
	tbz	w12, #5, .LBB0_154
	isb
	subs	w11, w11, #1
	b.ne	.LBB0_152
	b	.LBB0_161
.LBB0_154:
	mov	w11, #10
.LBB0_155:
	add	x8, x8, #1
	str	w11, [x20]
	cmp	x8, #42
	b.ne	.LBB0_145
.LBB0_156:
	ldp	x20, x19, [sp, #48]
	ldr	x30, [sp, #32]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	ret
.LBB0_157:
	.cfi_restore_state
	adrp	x8, .LCPI0_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI0_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB0_158:
	//APP
	wfi
	//NO_APP
	b	.LBB0_158
.LBB0_159:
	adrp	x8, .LCPI0_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI0_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB0_160:
	//APP
	wfi
	//NO_APP
	b	.LBB0_160
.LBB0_161:
	adrp	x8, .LCPI0_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI0_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB0_162:
	//APP
	wfi
	//NO_APP
	b	.LBB0_162
.Lfunc_end0:
	.size	_RINvCsjStpv0Kdcdo_9hm_kernel13report_memoryNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBJ_, .Lfunc_end0-_RINvCsjStpv0Kdcdo_9hm_kernel13report_memoryNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBJ_
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI1_0:
	.xword	131110
	.xword	1
	.section	.text._RINvCsjStpv0Kdcdo_9hm_kernel9write_hexNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBE_,"ax",@progbits
	.p2align	2
	.type	_RINvCsjStpv0Kdcdo_9hm_kernel9write_hexNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBE_,@function
_RINvCsjStpv0Kdcdo_9hm_kernel9write_hexNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBE_:
.Lfunc_begin1:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	.cfi_remember_state
	lsr	x11, x0, #60
	adrp	x10, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.4
	add	x10, x10, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.4
	ubfx	x12, x0, #56, #4
	ubfx	x13, x0, #52, #4
	ubfx	x14, x0, #48, #4
	ldrb	w11, [x10, x11]
	mov	x8, sp
	mov	x9, xzr
	ldrb	w12, [x10, x12]
	ldrb	w13, [x10, x13]
	ldrb	w14, [x10, x14]
	strb	w11, [sp]
	ubfx	x11, x0, #44, #4
	strb	w12, [sp, #1]
	ubfx	x12, x0, #40, #4
	strb	w13, [sp, #2]
	ldrb	w11, [x10, x11]
	ubfx	x13, x0, #36, #4
	strb	w14, [sp, #3]
	ldrb	w12, [x10, x12]
	ubfx	x14, x0, #32, #4
	strb	w11, [sp, #4]
	ldrb	w11, [x10, x13]
	lsr	w13, w0, #28
	strb	w12, [sp, #5]
	ldrb	w12, [x10, x14]
	ubfx	x14, x0, #24, #4
	strb	w11, [sp, #6]
	ldrb	w11, [x10, x13]
	ubfx	x13, x0, #20, #4
	strb	w12, [sp, #7]
	ldrb	w12, [x10, x14]
	ubfx	x14, x0, #16, #4
	strb	w11, [sp, #8]
	ldrb	w11, [x10, x13]
	ubfx	x13, x0, #12, #4
	strb	w12, [sp, #9]
	ldrb	w12, [x10, x14]
	ubfx	x14, x0, #8, #4
	strb	w11, [sp, #10]
	ldrb	w11, [x10, x13]
	ubfx	x13, x0, #4, #4
	strb	w12, [sp, #11]
	ldrb	w12, [x10, x14]
	strb	w11, [sp, #12]
	ldrb	w11, [x10, x13]
	and	x13, x0, #0xf
	ldrb	w10, [x10, x13]
	strb	w12, [sp, #13]
	add	x12, x8, #4
	strb	w11, [sp, #14]
	adrp	x11, .Lanon.4379416e6c146e9fcb6d8c8e621434d6.197
	add	x11, x11, :lo12:.Lanon.4379416e6c146e9fcb6d8c8e621434d6.197
	strb	w10, [sp, #15]
	and	x10, x12, #0xfffffffffffffff8
	sub	x10, x10, x8
.LBB1_1:
	add	x12, x8, x9
	ldrsb	w13, [x12]
	tbnz	w13, #31, .LBB1_8
	sub	w12, w10, w9
	tst	x12, #0x7
	b.ne	.LBB1_38
	cbnz	x9, .LBB1_6
	ldp	x9, x12, [sp]
	orr	x9, x12, x9
	tst	x9, #0x8080808080808080
	b.eq	.LBB1_40
	mov	x9, xzr
.LBB1_6:
	ldrsb	w12, [x8, x9]
	tbnz	w12, #31, .LBB1_39
	add	x9, x9, #1
	cmp	x9, #16
	b.ne	.LBB1_6
	b	.LBB1_40
.LBB1_8:
	and	x14, x13, #0xff
	and	w13, w13, #0xff
	ldrb	w14, [x11, x14]
	cmp	w14, #4
	b.eq	.LBB1_17
	cmp	w14, #3
	b.eq	.LBB1_13
	cmp	w14, #2
	b.ne	.LBB1_51
	cmp	x9, #15
	b.eq	.LBB1_51
	add	x9, x9, #1
	b	.LBB1_37
.LBB1_13:
	cmp	x9, #15
	b.eq	.LBB1_51
	ldrb	w12, [x12, #1]
	cmp	w13, #224
	b.eq	.LBB1_22
	sxtb	w12, w12
	cmp	w13, #237
	b.ne	.LBB1_24
	cmn	w12, #97
	b.le	.LBB1_35
	b	.LBB1_51
.LBB1_17:
	cmp	x9, #15
	b.eq	.LBB1_51
	ldrb	w14, [x12, #1]
	cmp	w13, #240
	b.eq	.LBB1_23
	cmp	w13, #244
	b.ne	.LBB1_27
	sxtb	w13, w14
	cmn	w13, #113
	b.gt	.LBB1_51
	cmp	x9, #13
	b.ls	.LBB1_30
	b	.LBB1_51
.LBB1_22:
	and	w12, w12, #0xe0
	cmp	w12, #160
	b.eq	.LBB1_35
	b	.LBB1_51
.LBB1_23:
	sub	w13, w14, #144
	cmp	w13, #47
	b.ls	.LBB1_29
	b	.LBB1_51
.LBB1_24:
	sub	w14, w13, #225
	cmp	w14, #12
	b.hs	.LBB1_33
	cmn	w12, #65
	b.gt	.LBB1_51
	cmp	x9, #13
	b.ls	.LBB1_36
	b	.LBB1_51
.LBB1_27:
	sub	w13, w13, #241
	cmp	w13, #2
	b.hi	.LBB1_51
	sxtb	w13, w14
	cmn	w13, #65
	b.gt	.LBB1_51
.LBB1_29:
	cmp	x9, #14
	b.hs	.LBB1_51
.LBB1_30:
	ldrsb	w12, [x12, #2]
	cmn	w12, #65
	b.gt	.LBB1_51
	cmp	x9, #13
	b.eq	.LBB1_51
	add	x9, x9, #3
	b	.LBB1_37
.LBB1_33:
	and	w13, w13, #0xfe
	cmp	w13, #238
	b.ne	.LBB1_51
	cmn	w12, #65
	b.gt	.LBB1_51
.LBB1_35:
	cmp	x9, #14
	b.hs	.LBB1_51
.LBB1_36:
	add	x9, x9, #2
.LBB1_37:
	ldrsb	w12, [x8, x9]
	cmn	w12, #65
	b.gt	.LBB1_51
.LBB1_38:
	add	x9, x9, #1
.LBB1_39:
	cmp	x9, #16
	b.lo	.LBB1_1
.LBB1_40:
	mov	w9, #24
	mov	x8, xzr
	mov	x10, sp
	movk	w9, #2304, lsl #16
	mov	w11, #150994944
	mov	w12, #13
.LBB1_41:
	ldrb	w13, [x10, x8]
	mov	w14, #34464
	mov	w15, #34464
	movk	w14, #1, lsl #16
	movk	w15, #1, lsl #16
	cmp	w13, #10
	b.ne	.LBB1_44
.LBB1_42:
	ldr	w13, [x9]
	tbz	w13, #5, .LBB1_46
	isb
	subs	w15, w15, #1
	b.ne	.LBB1_42
	b	.LBB1_52
.LBB1_44:
	ldr	w15, [x9]
	tbz	w15, #5, .LBB1_50
	isb
	subs	w14, w14, #1
	b.ne	.LBB1_44
	b	.LBB1_54
.LBB1_46:
	mov	w13, #34464
	str	w12, [x11]
	movk	w13, #1, lsl #16
.LBB1_47:
	ldr	w14, [x9]
	tbz	w14, #5, .LBB1_49
	isb
	subs	w13, w13, #1
	b.ne	.LBB1_47
	b	.LBB1_56
.LBB1_49:
	mov	w13, #10
.LBB1_50:
	add	x8, x8, #1
	str	w13, [x11]
	cmp	x8, #16
	b.ne	.LBB1_41
.LBB1_51:
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.LBB1_52:
	.cfi_restore_state
	adrp	x8, .LCPI1_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI1_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB1_53:
	//APP
	wfi
	//NO_APP
	b	.LBB1_53
.LBB1_54:
	adrp	x8, .LCPI1_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI1_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB1_55:
	//APP
	wfi
	//NO_APP
	b	.LBB1_55
.LBB1_56:
	adrp	x8, .LCPI1_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI1_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB1_57:
	//APP
	wfi
	//NO_APP
	b	.LBB1_57
.Lfunc_end1:
	.size	_RINvCsjStpv0Kdcdo_9hm_kernel9write_hexNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBE_, .Lfunc_end1-_RINvCsjStpv0Kdcdo_9hm_kernel9write_hexNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBE_
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI2_0:
	.xword	131110
	.xword	1
	.section	.text._RNvCsdtSMxSA38aw_7___rustc17rust_begin_unwind,"ax",@progbits
	.p2align	2
	.type	_RNvCsdtSMxSA38aw_7___rustc17rust_begin_unwind,@function
_RNvCsdtSMxSA38aw_7___rustc17rust_begin_unwind:
.Lfunc_begin2:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	adrp	x8, .LCPI2_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI2_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB2_1:
	//APP
	wfi
	//NO_APP
	b	.LBB2_1
.Lfunc_end2:
	.size	_RNvCsdtSMxSA38aw_7___rustc17rust_begin_unwind, .Lfunc_end2-_RNvCsdtSMxSA38aw_7___rustc17rust_begin_unwind
	.cfi_endproc

	.section	.text._RNvCsel89eI7eLYd_8hematite9boot_main,"ax",@progbits
	.p2align	2
	.type	_RNvCsel89eI7eLYd_8hematite9boot_main,@function
_RNvCsel89eI7eLYd_8hematite9boot_main:
.Lfunc_begin3:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	sp, sp, #2528
	.cfi_def_cfa_offset 2544
	ldr	xzr, [sp]
	add	x0, sp, #8
	bl	_RNvNtCsel89eI7eLYd_8hematite4arch4init
	adrp	x0, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.5
	add	x0, x0, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.5
	mov	w1, #43
	bl	_RNvXNtCsel89eI7eLYd_8hematite4archNtB2_12BootPlatformNtCsjStpv0Kdcdo_9hm_kernel8Platform5write
	add	x0, sp, #8
	bl	_RINvCsjStpv0Kdcdo_9hm_kernel13report_memoryNtNtCsel89eI7eLYd_8hematite4arch12BootPlatformEBJ_
	add	x0, sp, #8
	bl	_RNvNtCsel89eI7eLYd_8hematite4arch9smp_tests
	bl	_RNvCsdtSMxSA38aw_7___rustc17rust_begin_unwind
.Lfunc_end3:
	.size	_RNvCsel89eI7eLYd_8hematite9boot_main, .Lfunc_end3-_RNvCsel89eI7eLYd_8hematite9boot_main
	.cfi_endproc

	.section	.text._RNvMs_NtCsel89eI7eLYd_8hematite7threadsNtB4_6Runner9from_boot,"ax",@progbits
	.p2align	2
	.type	_RNvMs_NtCsel89eI7eLYd_8hematite7threadsNtB4_6Runner9from_boot,@function
_RNvMs_NtCsel89eI7eLYd_8hematite7threadsNtB4_6Runner9from_boot:
.Lfunc_begin4:
	.cfi_startproc
	//APP
	mrs	x8, DAIF
	msr	DAIFSet, #2
	isb
	mrs	x10, TPIDR_EL1
	mrs	x9, MPIDR_EL1
	//NO_APP
	and	x9, x9, #0xffffffffff
	and	x9, x9, #0xffffffff00ffffff
	cmp	x9, #1
	b.ls	.LBB4_2
	cmp	x9, #0
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	csel	w0, wzr, wzr, ne
	ret
.LBB4_2:
	adrp	x11, arm_cpu_records
	add	x11, x11, :lo12:arm_cpu_records
	add	x11, x11, x9, lsl #7
	cmp	x10, x11
	b.ne	.LBB4_4
	ldr	x10, [x10, #96]
	cmp	x10, x9
	cset	w10, eq
	cmp	x9, #0
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	csel	w0, wzr, w10, ne
	ret
.LBB4_4:
	cmp	x9, #0
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	csel	w0, wzr, wzr, ne
	ret
.Lfunc_end4:
	.size	_RNvMs_NtCsel89eI7eLYd_8hematite7threadsNtB4_6Runner9from_boot, .Lfunc_end4-_RNvMs_NtCsel89eI7eLYd_8hematite7threadsNtB4_6Runner9from_boot
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI5_0:
	.xword	1
	.xword	2
.LCPI5_1:
	.xword	131110
	.xword	1
	.section	.text._RNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer,@function
_RNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer:
.Lfunc_begin5:
	.cfi_startproc
	stp	d15, d14, [sp, #-160]!
	.cfi_def_cfa_offset 160
	stp	d13, d12, [sp, #16]
	stp	d11, d10, [sp, #32]
	stp	d9, d8, [sp, #48]
	stp	x29, x30, [sp, #64]
	stp	x28, x27, [sp, #80]
	stp	x26, x25, [sp, #96]
	stp	x24, x23, [sp, #112]
	stp	x22, x21, [sp, #128]
	stp	x20, x19, [sp, #144]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
	sub	sp, sp, #1152
	.cfi_def_cfa_offset 1312
	adrp	x8, .L_MergedGlobals+8
	add	x8, x8, :lo12:.L_MergedGlobals+8
	ldr	xzr, [sp]
	str	xzr, [x8]
	adrp	x9, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.6+32
	add	x9, x9, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.6+32
	str	xzr, [x8, #16]
	mov	w10, #1
	str	xzr, [x8, #24]
	str	xzr, [x8, #32]
	str	xzr, [x8, #40]
	str	xzr, [x8, #48]
	str	xzr, [x8, #56]
	str	xzr, [x8, #64]
	str	xzr, [x8, #72]
	adrp	x8, _RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer11coordinator
	add	x8, x8, :lo12:_RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer11coordinator
	stp	x8, xzr, [sp, #56]
	stp	x8, x10, [sp, #72]
	ldp	x11, x8, [x9]
	stp	x11, x8, [sp, #88]
	ldp	x10, x8, [x9, #16]
	stp	x10, x8, [sp, #104]
	adrp	x8, _RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer4peer
	add	x8, x8, :lo12:_RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer4peer
	mov	w10, #4
	stp	x8, x10, [sp, #120]
	mov	w10, #5
	stp	x8, x10, [sp, #136]
	ldp	x11, x8, [x9, #80]
	adrp	x10, .LCPI5_0
	ldr	q0, [x10, :lo12:.LCPI5_0]
	stp	x11, x8, [sp, #168]
	ldp	x9, x8, [x9, #64]
	str	q0, [sp, #32]
	stp	x9, x8, [sp, #152]
	ldp	x9, x8, [sp, #32]
	stp	x9, x8, [sp, #184]
	mov	w9, #2
	str	x9, [sp, #200]
	//APP
	mrs	x8, DAIF
	//NO_APP
	cmp	x8, #960
	b.ne	.LBB5_21
	//APP
	mrs	x8, DAIF
	msr	DAIFSet, #2
	isb
	mrs	x10, TPIDR_EL1
	mrs	x9, MPIDR_EL1
	//NO_APP
	and	x9, x9, #0xffffffffff
	and	x9, x9, #0xffffffff00ffffff
	cmp	x9, #1
	b.hi	.LBB5_20
	adrp	x11, arm_cpu_records
	add	x11, x11, :lo12:arm_cpu_records
	add	x11, x11, x9, lsl #7
	cmp	x10, x11
	b.ne	.LBB5_20
	ldr	x10, [x10, #96]
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	orr	x8, x10, x9
	cbnz	x8, .LBB5_21
	adrp	x20, .L_MergedGlobals+4
	add	x20, x20, :lo12:.L_MergedGlobals+4
	mov	w8, #1
.LBB5_5:
	ldaxrb	w9, [x20]
	cbnz	w9, .LBB5_63
	stlxrb	w9, w8, [x20]
	cbnz	w9, .LBB5_5
	mov	w0, #4
	mov	w1, #1
	mov	x2, xzr
	movk	w0, #50176, lsl #16
	mov	x3, xzr
	//APP
	hvc	#0
	//NO_APP
	cmp	x0, #1
	b.ne	.LBB5_62
	adrp	x21, _RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX
	add	x21, x21, :lo12:_RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX
	ldar	x8, [x21]
	cbnz	x8, .LBB5_62
	adrp	x8, _RNvNtCsel89eI7eLYd_8hematite9secondary15NEXT_GENERATION.0
	ldr	x19, [x8, :lo12:_RNvNtCsel89eI7eLYd_8hematite9secondary15NEXT_GENERATION.0]
	cmn	x19, #1
	b.eq	.LBB5_61
	add	x9, x19, #1
	str	x9, [x8, :lo12:_RNvNtCsel89eI7eLYd_8hematite9secondary15NEXT_GENERATION.0]
	ldr	x23, [sp, #184]
	cmp	x23, #1
	b.ne	.LBB5_13
	bl	arm_gic_session_start
	cmp	x0, #1
	b.ne	.LBB5_61
	adrp	x8, .L_MergedGlobals+16
	str	xzr, [x8, :lo12:.L_MergedGlobals+16]
.LBB5_13:
	add	x0, x21, #16
	mov	w1, wzr
	mov	w2, #776
	bl	memset
	add	x0, x21, #792
	add	x1, sp, #56
	mov	w2, #152
	bl	memcpy
	adrp	x22, arm_cpu_records+128
	add	x22, x22, :lo12:arm_cpu_records+128
	mov	w8, #1
	str	xzr, [x22]
	mov	w0, #3
	adrp	x2, arm_secondary_start
	add	x2, x2, :lo12:arm_secondary_start
	str	xzr, [x22, #8]
	movk	w0, #50176, lsl #16
	str	xzr, [x22, #16]
	mov	w1, #1
	mov	x3, x19
	str	xzr, [x22, #24]
	str	xzr, [x22, #32]
	str	xzr, [x22, #40]
	str	xzr, [x22, #48]
	str	xzr, [x22, #56]
	str	xzr, [x22, #64]
	str	xzr, [x22, #72]
	str	xzr, [x22, #80]
	str	xzr, [x22, #88]
	str	xzr, [x22, #96]
	str	xzr, [x22, #104]
	str	xzr, [x22, #112]
	str	xzr, [x22, #120]
	str	x8, [x22, #96]
	str	x19, [x21, #8]
	stlr	x8, [x21]
	//APP
	dsb	sy
	//NO_APP
	//APP
	hvc	#0
	//NO_APP
	cbnz	x0, .LBB5_62
	ldar	x8, [x21]
	cmp	x8, #2
	b.eq	.LBB5_17
.LBB5_15:
	cmp	x8, #1
	b.ne	.LBB5_62
	isb
	ldar	x8, [x21]
	cmp	x8, #2
	b.ne	.LBB5_15
.LBB5_17:
	mov	w8, #3
	cmp	x23, #1
	stlr	x8, [x21]
	b.ne	.LBB5_23
	ldr	x2, [sp, #192]
	cmp	x2, #5
	b.hs	.LBB5_62
	add	x0, sp, #208
	add	x1, sp, #56
	mov	x3, xzr
	bl	_RNvNtCsel89eI7eLYd_8hematite9secondary9local_run
	ldr	x26, [sp, #944]
	b	.LBB5_26
.LBB5_20:
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
.LBB5_21:
	adrp	x8, .LCPI5_1
	add	x1, sp, #208
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI5_1]
	str	q0, [sp, #208]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB5_22:
	//APP
	wfi
	//NO_APP
	b	.LBB5_22
.LBB5_23:
	movi	v0.2d, #0000000000000000
	add	x8, sp, #208
	mov	w1, wzr
	add	x0, x8, #208
	mov	w2, #512
	str	q0, [sp, #1072]
	str	q0, [sp, #1056]
	bl	memset
	movi	v0.2d, #0000000000000000
	add	x0, sp, #208
	add	x1, sp, #960
	mov	w2, #192
	str	q0, [sp, #1088]
	str	q0, [sp, #1104]
	str	q0, [sp, #1120]
	str	q0, [sp, #1136]
	stp	q0, q0, [sp, #960]
	stp	q0, q0, [sp, #992]
	str	q0, [sp, #1024]
	str	q0, [sp, #1040]
	bl	memcpy
	mov	x26, xzr
	stp	xzr, xzr, [sp, #400]
	str	xzr, [sp, #928]
	strb	wzr, [sp, #936]
	str	xzr, [sp, #944]
	b	.LBB5_26
.LBB5_24:
	cmp	x8, #3
	b.ne	.LBB5_62
	isb
.LBB5_26:
	ldar	x8, [x21]
	cmp	x8, #4
	b.ne	.LBB5_24
	b	.LBB5_28
.LBB5_27:
	isb
.LBB5_28:
	mov	w0, #4
	mov	w1, #1
	mov	x2, xzr
	movk	w0, #50176, lsl #16
	mov	x3, xzr
	//APP
	hvc	#0
	//NO_APP
	cmp	x0, #0
	ccmp	x0, #2, #4, ne
	b.eq	.LBB5_27
	cmp	x0, #1
	b.ne	.LBB5_62
	adrp	x8, _RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX+16
	add	x8, x8, :lo12:_RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX+16
	cmp	x23, #1
	ldp	x10, x27, [x8, #96]
	ldr	x25, [x8]
	ldp	x11, x9, [x8, #112]
	ldr	x24, [x8, #24]
	ldp	x28, x19, [x8, #160]
	ldr	x29, [x8, #224]
	ldr	x23, [x8, #768]
	stp	x11, x10, [sp, #16]
	str	x9, [sp, #8]
	b.ne	.LBB5_32
	bl	arm_gic_session_stop
	cmp	x0, #1
	b.ne	.LBB5_64
.LBB5_32:
	adrp	x8, __secondary_stack_guard
	add	x8, x8, :lo12:__secondary_stack_guard
	adrp	x9, __secondary_stack_top
	add	x9, x9, :lo12:__secondary_stack_top
	add	x0, x8, #1, lsl #12
	mov	w1, wzr
	sub	x9, x9, x8
	sub	x2, x9, #1, lsl #12
	bl	memset
	adrp	x8, __secondary_exception_stack_guard
	add	x8, x8, :lo12:__secondary_exception_stack_guard
	adrp	x9, __secondary_exception_stack_top
	add	x9, x9, :lo12:__secondary_exception_stack_top
	add	x0, x8, #1, lsl #12
	mov	w1, wzr
	sub	x9, x9, x8
	sub	x2, x9, #1, lsl #12
	bl	memset
	mov	x8, #61455
	movk	x8, #38505, lsl #16
	movk	x8, #49980, lsl #32
	movk	x8, #42330, lsl #48
	str	x8, [x22]
	str	x8, [x22, #8]
	str	x8, [x22, #16]
	str	x8, [x22, #24]
	str	x8, [x22, #32]
	str	x8, [x22, #40]
	str	x8, [x22, #48]
	str	x8, [x22, #56]
	str	x8, [x22, #64]
	str	x8, [x22, #72]
	str	x8, [x22, #80]
	str	x8, [x22, #88]
	str	x8, [x22, #96]
	str	x8, [x22, #104]
	str	x8, [x22, #112]
	str	x8, [x22, #120]
	stlr	xzr, [x21]
	stlrb	wzr, [x20]
	ldrb	w8, [sp, #936]
	cmp	w8, #2
	b.eq	.LBB5_21
	cmp	x25, #1
	b.ne	.LBB5_21
	cmp	x24, #255
	b.ne	.LBB5_21
	ldp	x9, x8, [sp, #336]
	ldr	x10, [sp, #400]
	cmp	x8, #1
	ccmp	x9, #1, #0, eq
	ccmp	x10, #2, #0, eq
	b.ne	.LBB5_21
	ldp	x8, x9, [sp, #272]
	adds	x8, x9, x8
	b.hs	.LBB5_21
	ldr	x9, [sp, #288]
	adds	x8, x9, x8
	b.hs	.LBB5_21
	ldr	x9, [sp, #296]
	add	x9, x9, x8
	cmp	x26, x9
	ccmp	x9, x8, #0, eq
	b.lo	.LBB5_21
	adrp	x8, .L_MergedGlobals+24
	add	x8, x8, :lo12:.L_MergedGlobals+24
	adrp	x10, __thread0_guard
	add	x10, x10, :lo12:__thread0_guard
	ldar	x9, [x8]
	add	x11, x10, #1, lsl #12
	cmp	x9, x11
	mov	x11, #-4097
	ccmp	x10, x11, #2, hs
	b.hi	.LBB5_21
	tst	x9, #0xf
	adrp	x10, __thread0_top
	add	x10, x10, :lo12:__thread0_top
	ccmp	x9, x10, #2, eq
	b.hs	.LBB5_21
	adrp	x9, .L_MergedGlobals+32
	add	x9, x9, :lo12:.L_MergedGlobals+32
	adrp	x11, __thread1_guard
	add	x11, x11, :lo12:__thread1_guard
	ldar	x10, [x9]
	add	x12, x11, #1, lsl #12
	cmp	x10, x12
	mov	x12, #-4097
	ccmp	x11, x12, #2, hs
	b.hi	.LBB5_21
	tst	x10, #0xf
	adrp	x11, __thread1_top
	add	x11, x11, :lo12:__thread1_top
	ccmp	x10, x11, #2, eq
	b.hs	.LBB5_21
	ldar	x11, [x8]
	cmp	x11, x10
	b.eq	.LBB5_21
	cmp	x19, #1
	ccmp	x28, #1, #0, eq
	ccmp	x29, #2, #0, eq
	b.ne	.LBB5_21
	ldr	x10, [sp, #24]
	adds	x10, x27, x10
	b.hs	.LBB5_21
	ldr	x11, [sp, #16]
	adds	x10, x11, x10
	b.hs	.LBB5_21
	ldr	x11, [sp, #8]
	add	x11, x11, x10
	cmp	x23, x11
	ccmp	x11, x10, #0, eq
	b.lo	.LBB5_21
	adrp	x10, .L_MergedGlobals+56
	add	x10, x10, :lo12:.L_MergedGlobals+56
	adrp	x11, __secondary_thread0_guard
	add	x11, x11, :lo12:__secondary_thread0_guard
	ldar	x13, [x10]
	add	x12, x11, #1, lsl #12
	cmp	x13, x12
	mov	x12, #-4097
	ccmp	x11, x12, #2, hs
	b.hi	.LBB5_21
	tst	x13, #0xf
	adrp	x11, __secondary_thread0_top
	add	x11, x11, :lo12:__secondary_thread0_top
	ccmp	x13, x11, #2, eq
	b.hs	.LBB5_21
	ldar	x11, [x8]
	cmp	x11, x13
	b.eq	.LBB5_21
	ldar	x11, [x9]
	cmp	x11, x13
	b.eq	.LBB5_21
	adrp	x11, .L_MergedGlobals+40
	add	x11, x11, :lo12:.L_MergedGlobals+40
	ldar	x12, [x11]
	cmp	x12, x13
	b.eq	.LBB5_21
	adrp	x12, .L_MergedGlobals+48
	add	x12, x12, :lo12:.L_MergedGlobals+48
	ldar	x14, [x12]
	cmp	x14, x13
	b.eq	.LBB5_21
	adrp	x13, .L_MergedGlobals+64
	add	x13, x13, :lo12:.L_MergedGlobals+64
	adrp	x14, __secondary_thread1_guard
	add	x14, x14, :lo12:__secondary_thread1_guard
	ldar	x13, [x13]
	add	x15, x14, #1, lsl #12
	cmp	x13, x15
	mov	x15, #-4097
	ccmp	x14, x15, #2, hs
	b.hi	.LBB5_21
	tst	x13, #0xf
	adrp	x14, __secondary_thread1_top
	add	x14, x14, :lo12:__secondary_thread1_top
	ccmp	x13, x14, #2, eq
	b.hs	.LBB5_21
	ldar	x8, [x8]
	cmp	x8, x13
	b.eq	.LBB5_21
	ldar	x8, [x9]
	cmp	x8, x13
	b.eq	.LBB5_21
	ldar	x8, [x11]
	cmp	x8, x13
	b.eq	.LBB5_21
	ldar	x8, [x12]
	cmp	x8, x13
	b.eq	.LBB5_21
	ldar	xzr, [x10]
	b	.LBB5_21
.LBB5_61:
	stlrb	wzr, [x20]
	b	.LBB5_21
.LBB5_62:
	bl	_RNvNtCsel89eI7eLYd_8hematite9secondary4fail
.LBB5_63:
	clrex
	b	.LBB5_21
.LBB5_64:
	bl	arm_exception_fail
.Lfunc_end5:
	.size	_RNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer, .Lfunc_end5-_RNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer
	.cfi_endproc

	.section	.text._RNvNtCsel89eI7eLYd_8hematite10smp_checks6record,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsel89eI7eLYd_8hematite10smp_checks6record,@function
_RNvNtCsel89eI7eLYd_8hematite10smp_checks6record:
.Lfunc_begin6:
	.cfi_startproc
	cmp	x3, #7
	b.hi	.LBB6_11
	stp	x30, x23, [sp, #-48]!
	.cfi_def_cfa_offset 48
	stp	x22, x21, [sp, #16]
	stp	x20, x19, [sp, #32]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w30, -48
	.cfi_remember_state
	mov	x10, #1099511627775
	//APP
	mrs	x8, DAIF
	msr	DAIFSet, #2
	isb
	mov	x20, sp
	//NO_APP
	movk	x10, #255, lsl #16
	//APP
	mrs	x9, DAIF
	msr	DAIFSet, #2
	isb
	mrs	x11, TPIDR_EL1
	mrs	x12, MPIDR_EL1
	//NO_APP
	and	x21, x12, x10
	cmp	x21, #1
	b.hi	.LBB6_12
	adrp	x12, arm_cpu_records
	add	x12, x12, :lo12:arm_cpu_records
	add	x13, x12, x21, lsl #7
	cmp	x11, x13
	b.ne	.LBB6_12
	ldr	x11, [x11, #96]
	tst	x8, #0x80
	//APP
	msr	DAIF, x9
	isb
	//NO_APP
	ccmp	x11, x21, #0, eq
	b.ne	.LBB6_13
	//APP
	mrs	x9, DAIF
	msr	DAIFSet, #2
	isb
	mrs	x11, TPIDR_EL1
	mrs	x13, MPIDR_EL1
	//NO_APP
	and	x10, x13, x10
	cmp	x10, #1
	b.hi	.LBB6_14
	add	x12, x12, x10, lsl #7
	cmp	x11, x12
	b.ne	.LBB6_14
	ldr	x12, [x11, #96]
	cmp	x12, x10
	b.ne	.LBB6_14
	ldr	x10, [x11, #56]
	cmp	x10, #1
	b.ne	.LBB6_14
	ldr	x10, [x11, #48]
	//APP
	msr	DAIF, x9
	isb
	//NO_APP
	cbz	x10, .LBB6_13
	cbz	x21, .LBB6_15
	adrp	x9, __secondary_thread3_top
	add	x9, x9, :lo12:__secondary_thread3_top
	adrp	x10, __secondary_thread2_top
	add	x10, x10, :lo12:__secondary_thread2_top
	adrp	x12, __secondary_thread1_top
	add	x12, x12, :lo12:__secondary_thread1_top
	adrp	x13, __secondary_thread0_top
	add	x13, x13, :lo12:__secondary_thread0_top
	adrp	x11, __secondary_thread3_guard
	add	x11, x11, :lo12:__secondary_thread3_guard
	adrp	x16, __secondary_thread0_guard
	add	x16, x16, :lo12:__secondary_thread0_guard
	adrp	x15, __secondary_thread1_guard
	add	x15, x15, :lo12:__secondary_thread1_guard
	adrp	x14, __secondary_thread2_guard
	add	x14, x14, :lo12:__secondary_thread2_guard
	b	.LBB6_16
.LBB6_11:
	.cfi_def_cfa wsp, 0
	.cfi_same_value w19
	.cfi_same_value w20
	.cfi_same_value w21
	.cfi_same_value w22
	.cfi_same_value w23
	.cfi_same_value w30
	mov	w0, wzr
	ret
.LBB6_12:
	.cfi_restore_state
	.cfi_remember_state
	//APP
	msr	DAIF, x9
	isb
	//NO_APP
.LBB6_13:
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	mov	w0, wzr
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldp	x30, x23, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	ret
.LBB6_14:
	.cfi_restore_state
	.cfi_remember_state
	//APP
	msr	DAIF, x9
	isb
	//NO_APP
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	mov	w0, wzr
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldp	x30, x23, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	ret
.LBB6_15:
	.cfi_restore_state
	.cfi_remember_state
	adrp	x9, __thread3_top
	add	x9, x9, :lo12:__thread3_top
	adrp	x10, __thread2_top
	add	x10, x10, :lo12:__thread2_top
	adrp	x12, __thread1_top
	add	x12, x12, :lo12:__thread1_top
	adrp	x13, __thread0_top
	add	x13, x13, :lo12:__thread0_top
	adrp	x11, __thread3_guard
	add	x11, x11, :lo12:__thread3_guard
	adrp	x16, __thread0_guard
	add	x16, x16, :lo12:__thread0_guard
	adrp	x15, __thread1_guard
	add	x15, x15, :lo12:__thread1_guard
	adrp	x14, __thread2_guard
	add	x14, x14, :lo12:__thread2_guard
.LBB6_16:
	add	x16, x16, #1, lsl #12
	cmp	x20, x13
	ccmp	x20, x16, #0, lo
	b.hs	.LBB6_20
	add	x13, x15, #1, lsl #12
	cmp	x20, x12
	ccmp	x20, x13, #0, lo
	b.hs	.LBB6_20
	add	x12, x14, #1, lsl #12
	cmp	x20, x10
	ccmp	x20, x12, #0, lo
	b.hs	.LBB6_20
	add	x10, x11, #1, lsl #12
	cmp	x20, x9
	ccmp	x20, x10, #0, lo
	b.lo	.LBB6_13
.LBB6_20:
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	cmp	x21, x3, lsr #2
	b.ne	.LBB6_24
	mov	x23, x1
	mov	x22, x3
	mov	x19, x0
	blr	x2
	cmp	x0, x21
	b.ne	.LBB6_24
	mov	x0, x19
	blr	x23
	and	x8, x22, #0x3
	cmp	x0, x8
	b.ne	.LBB6_24
	adrp	x8, .L_MergedGlobals
	add	x8, x8, :lo12:.L_MergedGlobals
	mov	w0, #1
	add	x8, x8, x22, lsl #3
	add	x8, x8, #24
	stlr	x20, [x8]
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldp	x30, x23, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	ret
.LBB6_24:
	.cfi_restore_state
	mov	w0, wzr
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldp	x30, x23, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	ret
.Lfunc_end6:
	.size	_RNvNtCsel89eI7eLYd_8hematite10smp_checks6record, .Lfunc_end6-_RNvNtCsel89eI7eLYd_8hematite10smp_checks6record
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI7_0:
	.xword	1073741824
	.xword	1075838976
.LCPI7_1:
	.xword	1073741824
	.xword	4096
.LCPI7_2:
	.xword	131110
	.xword	1
	.section	.text._RNvNtCsel89eI7eLYd_8hematite4arch4init,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsel89eI7eLYd_8hematite4arch4init,@function
_RNvNtCsel89eI7eLYd_8hematite4arch4init:
.Lfunc_begin7:
	.cfi_startproc
	stp	x29, x30, [sp, #-96]!
	.cfi_def_cfa_offset 96
	stp	x28, x27, [sp, #16]
	stp	x26, x25, [sp, #32]
	stp	x24, x23, [sp, #48]
	stp	x22, x21, [sp, #64]
	stp	x20, x19, [sp, #80]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	sub	sp, sp, #1, lsl #12
	.cfi_def_cfa_offset 4192
	ldr	xzr, [sp]
	sub	sp, sp, #1, lsl #12
	.cfi_def_cfa_offset 8288
	ldr	xzr, [sp]
	sub	sp, sp, #1520
	.cfi_def_cfa_offset 9808
	.cfi_remember_state
	mov	w25, #1073741824
	ldr	xzr, [sp]
	mov	w22, #65497
	ldr	w8, [x25, #4]
	movk	w22, #31, lsl #16
	rev	w20, w8
	sub	w8, w20, #40
	cmp	w8, w22
	b.hs	.LBB7_24
	mov	w8, #1073741824
	mov	w23, #3536
	ldr	w8, [x8]
	movk	w23, #60926, lsl #16
	cmp	w8, w23
	b.ne	.LBB7_24
	ldr	w8, [x25, #4]
	rev	w21, w8
	sub	w8, w21, #40
	cmp	w8, w22
	b.hs	.LBB7_24
	ldr	w8, [x25, #20]
	mov	w9, #285212672
	cmp	w8, w9
	b.ne	.LBB7_24
	ldr	w8, [x25, #24]
	mov	w9, #268435456
	cmp	w8, w9
	b.ne	.LBB7_24
	cmp	w20, w21
	b.lo	.LBB7_24
	ldp	w9, w10, [x25, #8]
	ldr	w8, [x25, #36]
	rev	w29, w9
	rev	w26, w8
	rev	w24, w10
	add	x8, x26, x29
	cmp	x8, x24
	b.hi	.LBB7_24
	ldr	w9, [x25, #16]
	rev	w27, w9
	cmp	w27, w29
	b.hs	.LBB7_24
	cmp	w27, #40
	b.lo	.LBB7_24
	orr	w9, w26, w29
	ubfiz	x10, x27, #32, #3
	ubfiz	x9, x9, #32, #2
	orr	x9, x9, x10
	cbnz	x9, .LBB7_24
	cmp	x8, x21
	b.hi	.LBB7_24
	ldr	w9, [x25, #32]
	rev	w28, w9
	add	x8, x28, x24
	cmp	x8, x21
	b.hi	.LBB7_24
	str	x0, [sp, #32]
	add	x0, sp, #1952
	mov	w1, wzr
	mov	w2, #792
	str	w9, [sp, #40]
	sub	x19, x29, x27
	bl	memset
	cmp	x19, #16
	str	x21, [sp, #2744]
	b.lo	.LBB7_24
	mov	x0, xzr
	mov	x10, xzr
	add	x21, x25, x29
	add	x29, x25, x24
	add	x8, x25, x27
	mov	w9, #16
.LBB7_14:
	add	x10, x8, x10
	ldrb	w11, [x10, #1]
	ldrb	w12, [x10]
	ldrb	w14, [x10, #2]
	mov	x17, x10
	ldrb	w13, [x10, #3]
	ldrb	w15, [x10, #5]
	orr	x11, x12, x11, lsl #8
	lsl	x12, x14, #16
	ldrb	w16, [x10, #9]
	ldrb	w14, [x17, #8]!
	ldrb	w18, [x10, #13]
	ldrb	w1, [x10, #4]!
	ldrb	w2, [x10, #2]
	ldrb	w3, [x17, #3]
	ldrb	w4, [x17, #2]
	orr	x12, x12, x13, lsl #24
	ldrb	w5, [x17, #4]!
	ldrb	w6, [x17, #2]
	ldrb	w10, [x10, #3]
	lsl	w13, w2, #16
	lsl	x2, x4, #16
	ldrb	w17, [x17, #3]
	lsl	w4, w6, #16
	orr	w15, w1, w15, lsl #8
	orr	w10, w13, w10, lsl #24
	orr	x13, x14, x16, lsl #8
	orr	x14, x2, x3, lsl #24
	orr	w16, w5, w18, lsl #8
	orr	w17, w4, w17, lsl #24
	orr	x11, x12, x11
	orr	w10, w10, w15
	orr	x12, x14, x13
	orr	w13, w17, w16
	orr	x10, x11, x10, lsl #32
	orr	x13, x12, x13, lsl #32
	rev	x11, x10
	rev	x12, x13
	orr	x14, x12, x11
	cbz	x14, .LBB7_63
	cbz	x13, .LBB7_24
	mov	x10, x9
	adds	x9, x12, x11
	b.hs	.LBB7_24
	cmp	x0, #33
	b.hs	.LBB7_252
	lsl	x13, x0, #4
	add	x14, sp, #1952
	add	x12, x14, x13
.LBB7_19:
	cbz	x13, .LBB7_22
	mov	x15, x14
	ldr	x14, [x14]
	sub	x13, x13, #16
	cmp	x14, x9
	add	x14, x15, #16
	b.hs	.LBB7_19
	ldr	x15, [x15, #8]
	cmp	x11, x15
	b.hs	.LBB7_19
	b	.LBB7_24
.LBB7_22:
	cmp	x0, #32
	b.eq	.LBB7_24
	stp	x11, x9, [x12]
	orr	x13, x10, #0xf
	ldr	x9, [sp, #2728]
	cmp	x13, x19
	add	x0, x9, #1
	add	x9, x10, #16
	str	x0, [sp, #2728]
	b.lo	.LBB7_14
.LBB7_24:
	mov	w8, #24
	mov	w9, #34464
	mov	w10, #34464
	movk	w8, #2304, lsl #16
	movk	w9, #1, lsl #16
	movk	w10, #1, lsl #16
.LBB7_25:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_27
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_25
	b	.LBB7_171
.LBB7_27:
	mov	w10, #150994944
	mov	w11, #66
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_28:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_30
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_28
	b	.LBB7_171
.LBB7_30:
	mov	w10, #150994944
	mov	w11, #111
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_31:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_33
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_31
	b	.LBB7_171
.LBB7_33:
	mov	w10, #150994944
	mov	w11, #111
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_34:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_36
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_34
	b	.LBB7_171
.LBB7_36:
	mov	w10, #150994944
	mov	w11, #116
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_37:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_39
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_37
	b	.LBB7_171
.LBB7_39:
	mov	w10, #150994944
	mov	w11, #32
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_40:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_42
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_40
	b	.LBB7_171
.LBB7_42:
	mov	w10, #150994944
	mov	w11, #109
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_43:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_45
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_43
	b	.LBB7_171
.LBB7_45:
	mov	w10, #150994944
	mov	w11, #101
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_46:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_48
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_46
	b	.LBB7_171
.LBB7_48:
	mov	w10, #150994944
	mov	w11, #109
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_49:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_51
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_49
	b	.LBB7_171
.LBB7_51:
	mov	w10, #150994944
	mov	w11, #111
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_52:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_54
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_52
	b	.LBB7_171
.LBB7_54:
	mov	w10, #150994944
	mov	w11, #114
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_55:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_57
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_55
	b	.LBB7_171
.LBB7_57:
	mov	w10, #150994944
	mov	w11, #121
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_58:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_60
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_58
	b	.LBB7_171
.LBB7_60:
	mov	w10, #150994944
	mov	w11, #32
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_61:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_114
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_61
	b	.LBB7_171
.LBB7_63:
	mov	w8, #1024
	cmp	w26, #4
	str	x21, [sp, #2760]
	str	x26, [sp, #2768]
	str	xzr, [sp, #2776]
	str	xzr, [sp, #2792]
	str	xzr, [sp, #2784]
	str	x8, [sp, #2800]
	str	xzr, [sp, #2808]
	str	xzr, [sp, #2816]
	str	x8, [sp, #2824]
	str	xzr, [sp, #2832]
	str	xzr, [sp, #2840]
	str	x8, [sp, #2848]
	str	xzr, [sp, #2856]
	str	xzr, [sp, #2864]
	str	x8, [sp, #2872]
	str	xzr, [sp, #2880]
	str	xzr, [sp, #2888]
	str	x8, [sp, #2896]
	str	xzr, [sp, #2904]
	str	xzr, [sp, #2912]
	str	x8, [sp, #2920]
	str	xzr, [sp, #2936]
	str	xzr, [sp, #2928]
	str	x8, [sp, #2968]
	str	xzr, [sp, #2960]
	str	x8, [sp, #2944]
	str	xzr, [sp, #2952]
	str	xzr, [sp, #2984]
	str	xzr, [sp, #2976]
	str	x8, [sp, #3016]
	str	xzr, [sp, #3008]
	str	x8, [sp, #2992]
	str	xzr, [sp, #3000]
	str	xzr, [sp, #3032]
	str	xzr, [sp, #3024]
	str	x8, [sp, #3040]
	str	xzr, [sp, #3048]
	str	xzr, [sp, #3056]
	str	x8, [sp, #3064]
	str	xzr, [sp, #3080]
	str	xzr, [sp, #3072]
	str	x8, [sp, #3112]
	str	xzr, [sp, #3104]
	str	x8, [sp, #3088]
	str	xzr, [sp, #3096]
	str	xzr, [sp, #3128]
	str	xzr, [sp, #3120]
	str	x8, [sp, #3160]
	str	xzr, [sp, #3152]
	str	x8, [sp, #3136]
	str	xzr, [sp, #3144]
	str	xzr, [sp, #3176]
	str	xzr, [sp, #3168]
	str	x8, [sp, #3208]
	str	xzr, [sp, #3200]
	str	x8, [sp, #3184]
	str	xzr, [sp, #3192]
	str	xzr, [sp, #3224]
	str	xzr, [sp, #3216]
	str	x8, [sp, #3256]
	str	xzr, [sp, #3248]
	str	x8, [sp, #3232]
	str	xzr, [sp, #3240]
	str	xzr, [sp, #3272]
	str	xzr, [sp, #3264]
	str	x8, [sp, #3304]
	str	xzr, [sp, #3296]
	str	x8, [sp, #3280]
	str	xzr, [sp, #3288]
	str	x8, [sp, #3328]
	str	xzr, [sp, #3320]
	str	xzr, [sp, #3312]
	str	x8, [sp, #3352]
	str	xzr, [sp, #3344]
	str	xzr, [sp, #3336]
	str	x8, [sp, #3376]
	str	xzr, [sp, #3368]
	str	xzr, [sp, #3360]
	str	x8, [sp, #3400]
	str	xzr, [sp, #3392]
	str	xzr, [sp, #3384]
	str	x8, [sp, #3424]
	str	xzr, [sp, #3416]
	str	xzr, [sp, #3408]
	str	x8, [sp, #3448]
	str	xzr, [sp, #3440]
	str	xzr, [sp, #3432]
	str	x8, [sp, #3472]
	str	xzr, [sp, #3464]
	str	xzr, [sp, #3456]
	str	x8, [sp, #3496]
	str	xzr, [sp, #3488]
	str	xzr, [sp, #3480]
	str	x8, [sp, #3520]
	str	xzr, [sp, #3512]
	str	xzr, [sp, #3504]
	str	x8, [sp, #3544]
	str	xzr, [sp, #3536]
	str	xzr, [sp, #3528]
	b.lo	.LBB7_24
	mov	x19, xzr
	mov	x24, xzr
	mov	w27, wzr
	mov	w25, #4
	mov	x14, x26
	str	wzr, [sp, #24]
.LBB7_65:
	add	x8, x21, x19
	str	x25, [sp, #2776]
	ldrb	w9, [x8, #2]
	ldrb	w10, [x8, #1]
	ldrb	w11, [x8]
	ldrb	w8, [x8, #3]
	lsl	w9, w9, #16
	orr	w10, w11, w10, lsl #8
	orr	w8, w9, w8, lsl #24
	orr	w8, w8, w10
	rev	w8, w8
	cmp	w8, #2
	b.le	.LBB7_69
	cmp	w8, #3
	b.eq	.LBB7_73
	cmp	w8, #4
	b.ne	.LBB7_132
	mov	x19, x25
	b	.LBB7_112
.LBB7_69:
	cmp	w8, #1
	b.eq	.LBB7_82
	cmp	w8, #2
	b.ne	.LBB7_24
	sub	x24, x24, #1
	cmp	x24, #32
	b.hs	.LBB7_24
	mov	w8, #24
	add	x9, sp, #2784
	add	x1, sp, #1952
	madd	x0, x24, x8, x9
	mov	x19, x14
	bl	_RNvMs1_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_4Node6finish
	mov	w8, #255
	mov	x14, x19
	mov	x19, x25
	bics	wzr, w8, w0
	b.eq	.LBB7_112
	b	.LBB7_24
.LBB7_73:
	cmn	x25, #5
	b.hi	.LBB7_24
	add	x9, x25, #4
	cmp	x9, x14
	b.hi	.LBB7_24
	cmn	x9, #5
	str	x9, [sp, #2776]
	b.hi	.LBB7_24
	add	x8, x25, #8
	cmp	x8, x14
	b.hi	.LBB7_24
	add	x9, x21, x9
	ldrb	w10, [x9, #2]
	ldrb	w11, [x9, #1]
	ldrb	w12, [x9]
	ldrb	w9, [x9, #3]
	lsl	w10, w10, #16
	orr	w11, w12, w11, lsl #8
	orr	w9, w10, w9, lsl #24
	orr	w10, w9, w11
	rev	w9, w10
	cmp	w9, w28
	b.hi	.LBB7_24
	ldr	w11, [sp, #40]
	cmp	w10, w11
	b.eq	.LBB7_24
	add	x10, x21, x25
	mov	x2, xzr
	add	x1, x29, x9
	ldrb	w11, [x10, #2]
	ldrb	w12, [x10, #1]
	ldrb	w13, [x10]
	ldrb	w10, [x10, #3]
	sub	x9, x28, x9
	lsl	w11, w11, #16
	orr	w12, w13, w12, lsl #8
	orr	w10, w11, w10, lsl #24
	orr	w10, w10, w12
	rev	w4, w10
.LBB7_80:
	ldrb	w10, [x1, x2]
	cbz	w10, .LBB7_99
	add	x2, x2, #1
	cmp	x9, x2
	b.ne	.LBB7_80
	b	.LBB7_24
.LBB7_82:
	add	x0, sp, #3552
	add	x1, sp, #2760
	bl	_RNvMs0_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_6Cursor4name
	ldr	x1, [sp, #3552]
	cbz	x1, .LBB7_24
	ldr	x21, [sp, #2760]
	ldr	x8, [sp, #3560]
	cbz	x24, .LBB7_90
	cbz	x8, .LBB7_24
	cmp	x24, #33
	b.hs	.LBB7_24
	mov	w9, #24
	add	x10, sp, #2784
	mov	w11, #1
	madd	x10, x24, x9, x10
	ldurb	w9, [x10, #-7]
	sturb	w11, [x10, #-6]
	cmp	w9, #1
	b.le	.LBB7_92
	cmp	w9, #2
	b.eq	.LBB7_98
	cmp	w9, #4
	b.ne	.LBB7_24
.LBB7_89:
	mov	w8, #4
	b	.LBB7_110
.LBB7_90:
	cmp	x8, #0
	cset	w8, ne
	orr	w8, w27, w8
	tbnz	w8, #0, .LBB7_24
	mov	w8, wzr
	mov	w27, #1
	b	.LBB7_111
.LBB7_92:
	cbnz	w9, .LBB7_24
	cmp	x8, #6
	b.eq	.LBB7_106
	cmp	x8, #15
	b.ne	.LBB7_107
	ldrb	w10, [x1, #2]
	ldrb	w8, [x1, #1]
	mov	x12, x1
	ldrb	w9, [x1]
	ldrb	w11, [x1, #3]
	mov	x13, x1
	lsl	x10, x10, #16
	ldrb	w14, [x12, #4]!
	ldrb	w16, [x13, #8]!
	ldrb	w17, [x12, #3]
	orr	x8, x9, x8, lsl #8
	orr	x9, x10, x11, lsl #24
	ldrb	w10, [x12, #2]
	ldrb	w12, [x13, #2]
	ldrb	w15, [x1, #5]
	ldrb	w11, [x13, #3]
	ldrb	w18, [x1, #13]
	ldrb	w0, [x13, #4]!
	lsl	w10, w10, #16
	ldrb	w2, [x1, #9]
	lsl	x12, x12, #16
	orr	w14, w14, w15, lsl #8
	orr	w15, w0, w18, lsl #8
	ldrb	w13, [x13, #2]
	orr	w10, w10, w17, lsl #24
	orr	x16, x16, x2, lsl #8
	orr	x11, x12, x11, lsl #24
	orr	w12, w15, w13, lsl #16
	orr	x8, x9, x8
	orr	w9, w10, w14
	orr	x10, x11, x16
	orr	x8, x8, x9, lsl #32
	orr	x9, x10, x12, lsl #32
	mov	x10, #25970
	movk	x10, #25971, lsl #16
	movk	x10, #30322, lsl #32
	movk	x10, #25701, lsl #48
	eor	x8, x8, x10
	mov	x10, #27949
	movk	x10, #28005, lsl #16
	movk	x10, #29295, lsl #32
	movk	x10, #121, lsl #48
	eor	x9, x9, x10
	orr	x8, x8, x9
	cbnz	x8, .LBB7_108
	ldr	w8, [sp, #24]
	tbnz	w8, #0, .LBB7_24
	mov	w9, #1
	mov	w8, #2
	str	w9, [sp, #24]
	b	.LBB7_110
.LBB7_98:
	mov	w8, #3
	b	.LBB7_110
.LBB7_99:
	cbz	x2, .LBB7_24
	adds	x9, x8, x4
	b.hs	.LBB7_24
	cmp	x9, x14
	b.hi	.LBB7_24
	neg	w10, w9
	and	x10, x10, #0x3
	adds	x19, x10, x9
	b.hs	.LBB7_24
	cmp	x19, x14
	b.hi	.LBB7_24
	sub	x9, x24, #1
	str	x19, [sp, #2776]
	cmp	x9, #31
	b.hi	.LBB7_24
	mov	w9, #24
	add	x10, sp, #2784
	add	x3, x21, x8
	madd	x9, x24, x9, x10
	mov	x25, x14
	sub	x0, x9, #24
	bl	_RNvMs1_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_4Node8property
	mov	w8, #255
	mov	x14, x25
	bics	wzr, w8, w0
	b.eq	.LBB7_112
	b	.LBB7_24
.LBB7_106:
	ldrb	w8, [x1, #2]
	ldrb	w9, [x1, #1]
	ldrb	w10, [x1]
	ldrb	w11, [x1, #3]
	ldrb	w12, [x1, #5]
	ldrb	w13, [x1, #4]
	lsl	x8, x8, #16
	orr	x9, x10, x9, lsl #8
	orr	w10, w13, w12, lsl #8
	orr	x8, x8, x11, lsl #24
	orr	x8, x8, x9
	mov	x9, #25965
	orr	x8, x8, x10, lsl #32
	movk	x9, #28525, lsl #16
	movk	x9, #31090, lsl #32
	cmp	x8, x9
	b.ne	.LBB7_89
	b	.LBB7_109
.LBB7_107:
	cmp	x8, #7
	b.lo	.LBB7_89
.LBB7_108:
	adrp	x0, .Lanon.9c45514b0a68c977cf2a682a7d2de827.67
	add	x0, x0, :lo12:.Lanon.9c45514b0a68c977cf2a682a7d2de827.67
	mov	w2, #7
	bl	memcmp
	cbnz	w0, .LBB7_89
.LBB7_109:
	mov	w8, #1
.LBB7_110:
	cmp	x24, #32
	b.eq	.LBB7_24
.LBB7_111:
	mov	w9, #24
	add	x10, sp, #2784
	ldr	x14, [sp, #2768]
	madd	x9, x24, x9, x10
	ldr	x19, [sp, #2776]
	add	x24, x24, #1
	str	xzr, [x9]
	strb	wzr, [x9, #16]
	strb	w8, [x9, #17]
	strb	wzr, [x9, #18]
.LBB7_112:
	cmn	x19, #5
	b.hi	.LBB7_24
	add	x25, x19, #4
	cmp	x25, x14
	b.hi	.LBB7_24
	b	.LBB7_65
.LBB7_114:
	mov	w10, #150994944
	mov	w11, #114
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_115:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_117
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_115
	b	.LBB7_171
.LBB7_117:
	mov	w10, #150994944
	mov	w11, #101
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_118:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_120
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_118
	b	.LBB7_171
.LBB7_120:
	mov	w10, #150994944
	mov	w11, #106
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_121:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_123
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_121
	b	.LBB7_171
.LBB7_123:
	mov	w10, #150994944
	mov	w11, #101
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_124:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_126
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_124
	b	.LBB7_171
.LBB7_126:
	mov	w10, #150994944
	mov	w11, #99
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_127:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_129
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_127
	b	.LBB7_171
.LBB7_129:
	mov	w10, #150994944
	mov	w11, #116
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_130:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_143
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_130
	b	.LBB7_171
.LBB7_132:
	cmp	w8, #9
	b.ne	.LBB7_24
	cmp	x24, #0
	cset	w8, eq
	tst	w8, w27
	b.eq	.LBB7_24
	cmp	x25, x26
	b.ne	.LBB7_24
	ldr	x8, [sp, #2720]
	cbz	x8, .LBB7_24
	add	x19, sp, #3568
	add	x1, sp, #1952
	mov	w2, #800
	add	x0, x19, #6
	bl	memcpy
	add	x0, sp, #1152
	add	x1, x19, #6
	mov	w2, #800
	bl	memcpy
	cmp	w20, #40
	b.lo	.LBB7_149
	mov	w8, #1073741824
	ldr	w8, [x8]
	cmp	w8, w23
	b.ne	.LBB7_149
	mov	w8, #1073741824
	ldr	w8, [x8, #4]
	rev	w8, w8
	sub	w9, w8, #40
	cmp	w9, w22
	b.hs	.LBB7_149
	mov	w9, #1073741824
	mov	w10, #285212672
	ldr	w9, [x9, #20]
	cmp	w9, w10
	b.ne	.LBB7_149
	mov	w9, #1073741824
	mov	w10, #268435456
	ldr	w9, [x9, #24]
	cmp	w9, w10
	b.ne	.LBB7_149
	mov	w9, #1073741824
	ldr	w9, [x9, #28]
	cbz	w9, .LBB7_175
	mov	w20, #255
	mov	w21, #3
	b	.LBB7_150
.LBB7_143:
	mov	w10, #150994944
	mov	w11, #101
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_144:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_146
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_144
	b	.LBB7_171
.LBB7_146:
	mov	w10, #150994944
	mov	w11, #100
	str	w11, [x10]
	mov	w10, #34464
	movk	w10, #1, lsl #16
.LBB7_147:
	ldr	w11, [x8]
	tbz	w11, #5, .LBB7_168
	isb
	subs	w10, w10, #1
	b.ne	.LBB7_147
	b	.LBB7_171
.LBB7_149:
	mov	x21, xzr
	mov	w20, #255
.LBB7_150:
.LBB7_151:
	add	x8, sp, #3568
	mov	x23, #1795
	add	x1, sp, #1152
	add	x0, x8, #1720
	mov	w2, #800
	movk	x23, #96, lsl #48
	bl	memcpy
	mov	w8, #1
	mov	w12, #1
	str	x21, [sp, #5256]
	str	x8, [sp, #5264]
	add	x8, sp, #3568
	movk	w12, #16640, lsl #16
	strb	w20, [x8, #1712]
	mov	w8, #2
	adrp	x20, __kernel_end
	add	x20, x20, :lo12:__kernel_end
	str	x27, [sp, #5272]
	adrp	x27, __secondary_thread2_guard
	add	x27, x27, :lo12:__secondary_thread2_guard
	str	xzr, [sp, #3568]
	cmp	x20, x12
	str	xzr, [sp, #4640]
	adrp	x28, __secondary_thread3_guard
	add	x28, x28, :lo12:__secondary_thread3_guard
	str	x8, [sp, #5168]
	adrp	x26, arm_ram_l3
	add	x26, x26, :lo12:arm_ram_l3
	str	wzr, [sp, #5184]
	adrp	x22, __text_start
	add	x22, x22, :lo12:__text_start
	str	w8, [sp, #5192]
	adrp	x29, __stack_guard
	add	x29, x29, :lo12:__stack_guard
	str	xzr, [sp, #5248]
	//APP
	mrs	x24, CurrentEL
	//NO_APP
	//APP
	mrs	x21, SCTLR_EL1
	//NO_APP
	//APP
	mrs	x8, TCR_EL1
	//NO_APP
	//APP
	mrs	x10, MAIR_EL1
	//NO_APP
	//APP
	mrs	x9, TTBR0_EL1
	//NO_APP
	//APP
	mrs	x11, S3_0_C4_C2_3
	//NO_APP
	str	x11, [sp, #40]
	adrp	x25, arm_ram_l2
	add	x25, x25, :lo12:arm_ram_l2
	and	x11, x20, #0xffffffffc0000000
	adrp	x19, arm_device_l2
	add	x19, x19, :lo12:arm_device_l2
	ccmp	x11, #0, #4, lo
	//APP
	mrs	x11, SP_EL0
	//NO_APP
	str	x11, [sp, #24]
	b.eq	.LBB7_201
	adrp	x13, __secondary_stack_top
	add	x13, x13, :lo12:__secondary_stack_top
	adrp	x14, __secondary_exception_stack_guard
	add	x14, x14, :lo12:__secondary_exception_stack_guard
	str	x13, [sp, #1976]
	adrp	x13, __secondary_exception_stack_top
	add	x13, x13, :lo12:__secondary_exception_stack_top
	adrp	x12, __secondary_stack_guard
	add	x12, x12, :lo12:__secondary_stack_guard
	str	x14, [sp, #1984]
	adrp	x14, __secondary_thread1_guard
	add	x14, x14, :lo12:__secondary_thread1_guard
	str	x13, [sp, #1992]
	adrp	x13, __secondary_thread0_top
	add	x13, x13, :lo12:__secondary_thread0_top
	str	x12, [sp, #1968]
	adrp	x12, __secondary_thread0_guard
	add	x12, x12, :lo12:__secondary_thread0_guard
	str	x13, [sp, #2008]
	adrp	x13, __secondary_thread1_top
	add	x13, x13, :lo12:__secondary_thread1_top
	str	x14, [sp, #2016]
	adrp	x14, __secondary_thread3_top
	add	x14, x14, :lo12:__secondary_thread3_top
	str	x12, [sp, #2000]
	add	x12, sp, #1952
	mov	x17, #-61440
	str	x13, [sp, #2024]
	adrp	x13, __secondary_thread2_top
	add	x13, x13, :lo12:__secondary_thread2_top
	str	x14, [sp, #2056]
	mov	w14, #4096
	mov	x11, xzr
	add	x12, x12, #16
	str	x27, [sp, #2032]
	movk	w14, #1, lsl #16
	str	x13, [sp, #2040]
	adrp	x13, __thread3_top
	add	x13, x13, :lo12:__thread3_top
	str	x28, [sp, #2048]
	mov	w15, #20480
	mov	x16, #-1073741824
	str	xzr, [sp, #2064]
	movk	x17, #49152, lsl #16
.LBB7_153:
	add	x18, x12, x11, lsl #4
	cmp	x11, #1
	lsr	x2, x13, #30
	csel	x0, x15, x14, eq
	ldp	x1, x18, [x18]
	cmp	x1, x13
	orr	w1, w18, w13
	ccmp	x2, #0, #4, eq
	and	x1, x1, #0xfff
	ccmp	x18, x20, #2, ne
	ccmp	x1, #0, #0, ls
	b.ne	.LBB7_201
	subs	x1, x18, x13
	b.lo	.LBB7_201
	cmp	x1, x0
	b.ne	.LBB7_201
	add	x0, x13, x16
	lsr	x1, x0, #24
	cbnz	x1, .LBB7_201
	lsr	x0, x0, #12
	ldr	x0, [x26, x0, lsl #3]
	cbnz	x0, .LBB7_201
	add	x0, x13, #1, lsl #12
	add	x11, x11, #1
	subs	x0, x18, x0
	csel	x0, xzr, x0, lo
	lsr	x1, x0, #12
	tst	x0, #0xfff
	cinc	x0, x1, ne
	mvn	x0, x0
	b	.LBB7_160
.LBB7_159:
	lsr	x1, x1, #12
	ldr	x1, [x26, x1, lsl #3]
	add	x13, x13, #1, lsl #12
	orr	x2, x13, x23
	cmp	x1, x2
	b.ne	.LBB7_201
.LBB7_160:
	adds	x0, x0, #1
	b.hs	.LBB7_163
	add	x1, x13, x17
	lsr	x2, x1, #24
	cbz	x2, .LBB7_159
	mov	x1, #-1
	add	x13, x13, #1, lsl #12
	orr	x2, x13, x23
	cmp	x1, x2
	b.eq	.LBB7_160
	b	.LBB7_201
.LBB7_163:
	cmp	x11, #6
	mov	x13, x18
	b.ne	.LBB7_153
	cmp	x18, x20
	b.ne	.LBB7_201
	adrp	x11, arm_secondary_root
	add	x11, x11, :lo12:arm_secondary_root
	tst	x11, #0xff8
	ccmp	x11, x22, #0, eq
	b.lo	.LBB7_201
	add	x12, x11, #1, lsl #12
	cmp	x12, x29
	ccmp	x12, x11, #0, ls
	b.lo	.LBB7_201
	mov	x12, xzr
	b	.LBB7_179
.LBB7_168:
	mov	w10, #150994944
	mov	w11, #13
	str	w11, [x10]
.LBB7_169:
	ldr	w10, [x8]
	tbz	w10, #5, .LBB7_173
	isb
	subs	w9, w9, #1
	b.ne	.LBB7_169
.LBB7_171:
	adrp	x8, .LCPI7_2
	add	x1, sp, #3568
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI7_2]
	str	q0, [sp, #3568]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB7_172:
	//APP
	wfi
	//NO_APP
	b	.LBB7_172
.LBB7_173:
	adrp	x8, .LCPI7_2
	mov	w9, #150994944
	mov	w10, #10
	ldr	q0, [x8, :lo12:.LCPI7_2]
	str	w10, [x9]
	add	x1, sp, #3568
	mov	w0, #32
	str	q0, [sp, #3568]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB7_174:
	//APP
	wfi
	//NO_APP
	b	.LBB7_174
.LBB7_175:
	cmp	w20, w8
	b.hs	.LBB7_183
.LBB7_176:
	mov	w20, #255
	mov	w21, #1
	b	.LBB7_150
.LBB7_177:
	mov	x13, xzr
.LBB7_178:
	ldr	x15, [x11, x12, lsl #3]
	mov	w14, wzr
	add	x12, x12, #1
	cmp	x15, x13
	b.ne	.LBB7_202
.LBB7_179:
	cmp	x12, #512
	b.eq	.LBB7_190
	orr	x13, x19, #0x3
	cbz	x12, .LBB7_178
	cmp	x12, #1
	b.ne	.LBB7_177
	orr	x13, x25, #0x3
	b	.LBB7_178
.LBB7_183:
	mov	w9, #1073741824
	mov	x21, xzr
	mov	w20, #255
	ldr	w10, [x9, #8]
	ldr	w11, [x9, #16]
	rev	w9, w10
	rev	w10, w11
	cmp	w10, w9
	b.hs	.LBB7_150
	cmp	w10, #40
	b.lo	.LBB7_150
	mov	w11, #1073741824
	ubfiz	x12, x10, #32, #3
	ldr	w11, [x11, #36]
	rev	w28, w11
	orr	w11, w28, w9
	ubfiz	x11, x11, #32, #2
	orr	x11, x11, x12
	cbnz	x11, .LBB7_150
	mov	w11, #1073741824
	ldr	w11, [x11, #12]
	rev	w29, w11
	add	x11, x28, x9
	cmp	x11, x29
	b.hi	.LBB7_151
	cmp	x11, x8
	b.hi	.LBB7_189
	mov	w11, #1073741824
	ldr	w11, [x11, #32]
	rev	w19, w11
	add	x11, x19, x29
	cmp	x11, x8
	b.ls	.LBB7_193
.LBB7_189:
	mov	w21, #1
	b	.LBB7_150
.LBB7_190:
	lsr	x12, x11, #30
	cbz	x12, .LBB7_201
	mov	x12, #-1073741824
	add	x12, x11, x12
	lsr	x13, x12, #24
	cbz	x13, .LBB7_197
	mov	x12, #-1
	b	.LBB7_198
.LBB7_193:
	mov	w11, #1073741824
	sub	x8, x9, x10
	mov	w21, #2
	add	x26, x11, x9
	add	x9, x10, x11
	mov	w10, #15
	add	x9, x9, #8
.LBB7_194:
	cmp	x10, x8
	b.hs	.LBB7_176
	mov	x12, x9
	ldurb	w11, [x9, #-7]
	mov	x2, x9
	ldrb	w14, [x12, #-8]!
	ldrb	w15, [x12, #2]
	ldrb	w16, [x12, #3]
	ldrb	w17, [x12, #4]!
	ldrb	w0, [x12, #2]
	lsl	x15, x15, #16
	ldrb	w1, [x9, #2]
	orr	x11, x14, x11, lsl #8
	ldurb	w13, [x9, #-3]
	ldrb	w18, [x9, #1]
	lsl	w14, w0, #16
	orr	x15, x15, x16, lsl #24
	ldrb	w12, [x12, #3]
	ldrb	w16, [x2, #4]!
	ldrb	w0, [x2, #2]
	ldrb	w3, [x9]
	ldrb	w4, [x9, #3]
	lsl	x1, x1, #16
	ldrb	w5, [x9, #5]
	ldrb	w2, [x2, #3]
	lsl	w0, w0, #16
	orr	w13, w17, w13, lsl #8
	orr	w12, w14, w12, lsl #24
	orr	x14, x3, x18, lsl #8
	orr	x17, x1, x4, lsl #24
	orr	w16, w16, w5, lsl #8
	orr	w18, w0, w2, lsl #24
	orr	x11, x15, x11
	orr	w12, w12, w13
	orr	x13, x17, x14
	orr	w14, w18, w16
	orr	x11, x11, x12, lsl #32
	orr	x12, x13, x14, lsl #32
	rev	x11, x11
	rev	x12, x12
	orr	x13, x12, x11
	cbz	x13, .LBB7_281
	neg	x12, x12
	add	x9, x9, #16
	add	x10, x10, #16
	cmp	x11, x12
	b.hs	.LBB7_151
	b	.LBB7_194
.LBB7_197:
	lsr	x12, x12, #12
	ldr	x12, [x26, x12, lsl #3]
.LBB7_198:
	cmp	x10, #255
	mov	w10, #13593
	orr	x11, x11, x23
	movk	w10, #32921, lsl #16
	ccmp	x8, x10, #0, eq
	adrp	x8, arm_root
	add	x8, x8, :lo12:arm_root
	ccmp	x9, x8, #0, eq
	ccmp	x12, x11, #0, eq
	b.ne	.LBB7_201
	add	x0, sp, #1952
	mov	w1, wzr
	mov	w2, #512
	bl	memset
	adrp	x8, arm_owned_l2
	ldr	x9, [x8, :lo12:arm_owned_l2]
	adrp	x8, arm_owned_l3
	add	x8, x8, :lo12:arm_owned_l3
	orr	x10, x8, #0x3
	cmp	x9, x10
	b.ne	.LBB7_201
	adrp	x9, arm_owned_l3
	ldr	x9, [x9, :lo12:arm_owned_l3]
	cbz	x9, .LBB7_274
.LBB7_201:
	mov	w14, wzr
.LBB7_202:
	adrp	x10, arm_root
	orr	x9, x19, #0x3
	adrp	x11, arm_device_l3
	add	x11, x11, :lo12:arm_device_l3
	ldr	x8, [x10, :lo12:arm_root]
	ldr	x15, [x19]
	mov	x13, #1031
	adrp	x12, arm_gic_l3
	add	x12, x12, :lo12:arm_gic_l3
	ldr	x16, [x11]
	cmp	x8, x9
	movk	x13, #2304, lsl #16
	mov	x18, #1031
	movk	x13, #96, lsl #48
	adrp	x8, arm_ram_l2
	ccmp	x15, #0, #0, eq
	ldr	x15, [x12]
	movk	x18, #2048, lsl #16
	csel	w14, wzr, w14, ne
	cmp	x16, x13
	movk	x18, #96, lsl #48
	ldr	x8, [x8, :lo12:arm_ram_l2]
	csel	w14, wzr, w14, ne
	cmp	x15, x18
	adrp	x15, arm_ram_l3+3
	add	x15, x15, :lo12:arm_ram_l3+3
	csel	w16, wzr, w14, ne
	cmp	x8, x15
	add	x14, x15, #1, lsl #12
	mov	w17, #1
	csel	w8, wzr, w16, ne
	adrp	x15, arm_device_l2
	adrp	x16, arm_root
	add	x16, x16, :lo12:arm_root
	add	x18, x18, #16, lsl #12
	adrp	x0, arm_owned_l2
	add	x0, x0, :lo12:arm_owned_l2
	b	.LBB7_205
.LBB7_203:
	ldr	x1, [x10, :lo12:arm_root]
	ldr	x2, [x15, :lo12:arm_device_l2]
	cmp	x1, x9
	ccmp	x2, #0, #0, eq
	mov	x2, x13
	cset	w1, eq
.LBB7_204:
	ldr	x3, [x11, x17, lsl #3]
	and	w8, w8, w1
	ldr	x1, [x12, x17, lsl #3]
	cmp	x3, x2
	csel	w8, wzr, w8, ne
	cmp	x17, #16
	csel	x2, x18, xzr, eq
	cmp	x1, x2
	ldr	x1, [x25, x17, lsl #3]
	csel	w8, wzr, w8, ne
	cmp	x17, #8
	add	x17, x17, #1
	csel	x2, x14, xzr, lo
	add	x14, x14, #1, lsl #12
	cmp	x1, x2
	csel	w8, wzr, w8, ne
	cmp	x17, #512
	b.eq	.LBB7_217
.LBB7_205:
	cbz	x17, .LBB7_203
	cmp	x17, #1
	b.eq	.LBB7_209
	cmp	x17, #2
	b.ne	.LBB7_212
	mov	x1, x0
	b	.LBB7_210
.LBB7_209:
	mov	x1, x25
.LBB7_210:
	ldr	x2, [x16, x17, lsl #3]
	orr	x1, x1, #0x3
	mov	x3, xzr
	cmp	x2, x1
	cset	w1, eq
.LBB7_211:
	ldr	x4, [x19, x17, lsl #3]
	mov	x2, xzr
	cmp	x4, x3
	csel	w1, wzr, w1, ne
	b	.LBB7_204
.LBB7_212:
	ldr	x1, [x16, x17, lsl #3]
	cmp	x1, #0
	cset	w1, eq
	cmp	x17, #64
	b.eq	.LBB7_215
	cmp	x17, #72
	b.ne	.LBB7_216
	orr	x3, x11, #0x3
	b	.LBB7_211
.LBB7_215:
	orr	x3, x12, #0x3
	b	.LBB7_211
.LBB7_216:
	mov	x3, xzr
	b	.LBB7_211
.LBB7_217:
	adrp	x11, __thread0_guard
	add	x11, x11, :lo12:__thread0_guard
	adrp	x12, __secondary_stack_guard
	add	x12, x12, :lo12:__secondary_stack_guard
	fmov	d0, x11
	adrp	x11, __thread1_guard
	add	x11, x11, :lo12:__thread1_guard
	fmov	d2, x12
	adrp	x12, __secondary_thread0_guard
	add	x12, x12, :lo12:__secondary_thread0_guard
	mov	x15, #1923
	mov	x10, xzr
	mov	v0.d[1], x11
	adrp	x11, __thread2_guard
	add	x11, x11, :lo12:__thread2_guard
	fmov	d1, x11
	adrp	x11, __thread3_guard
	add	x11, x11, :lo12:__thread3_guard
	fmov	d3, x12
	adrp	x9, __exception_stack_guard
	add	x9, x9, :lo12:__exception_stack_guard
	mov	w12, #1073741824
	adrp	x13, __rodata_start
	add	x13, x13, :lo12:__rodata_start
	mov	v1.d[1], x11
	adrp	x11, __secondary_exception_stack_guard
	add	x11, x11, :lo12:__secondary_exception_stack_guard
	mov	v2.d[1], x11
	adrp	x11, __secondary_thread1_guard
	add	x11, x11, :lo12:__secondary_thread1_guard
	mov	v3.d[1], x11
	adrp	x11, __text_end
	add	x11, x11, :lo12:__text_end
	adrp	x14, __rodata_end
	add	x14, x14, :lo12:__rodata_end
	movk	x15, #64, lsl #48
	b	.LBB7_220
.LBB7_218:
	mov	x16, xzr
.LBB7_219:
	ldr	x17, [x26, x10]
	add	x10, x10, #8
	add	x12, x12, #1, lsl #12
	cmp	x17, x16
	csel	w8, w8, wzr, eq
	cmp	x10, #8, lsl #12
	b.eq	.LBB7_223
.LBB7_220:
	cmp	x9, x12
	ccmp	x29, x12, #4, ne
	b.eq	.LBB7_218
	dup	v4.2d, x12
	cmeq	v5.2d, v4.2d, v3.2d
	cmeq	v6.2d, v4.2d, v2.2d
	cmeq	v7.2d, v4.2d, v1.2d
	cmeq	v4.2d, v4.2d, v0.2d
	uzp1	v5.4s, v6.4s, v5.4s
	uzp1	v4.4s, v4.4s, v7.4s
	uzp1	v4.8h, v4.8h, v5.8h
	xtn	v4.8b, v4.8h
	fmov	x16, d4
	cmp	x16, #0
	ccmp	x28, x12, #4, eq
	ccmp	x27, x12, #4, ne
	b.eq	.LBB7_218
	cmp	x12, x14
	add	x16, x23, #128
	ccmp	x12, x13, #0, lo
	csel	x16, x16, x23, hs
	cmp	x12, x11
	ccmp	x12, x22, #0, lo
	csel	x16, x15, x16, hs
	add	x16, x16, x12
	b	.LBB7_219
.LBB7_223:
	mov	x11, #-1073741824
	cmp	x24, #4
	mov	w10, wzr
	add	x11, x29, x11
	lsr	x12, x11, #24
	cset	w11, eq
	and	w11, w11, w21
	cbnz	x12, .LBB7_231
	cbz	w11, .LBB7_231
	tbz	w8, #0, .LBB7_231
	mov	x10, #-1073741824
	add	x12, x29, x10
	add	x10, x9, x10
	lsr	x12, x12, #12
	lsr	x13, x10, #24
	mov	w10, wzr
	ldr	x12, [x26, x12, lsl #3]
	cbnz	x13, .LBB7_231
	cbnz	x12, .LBB7_231
	mov	x10, #-1073741824
	add	x9, x9, x10
	lsr	x9, x9, #12
	ldr	x9, [x26, x9, lsl #3]
	cbz	x9, .LBB7_230
	mov	w10, wzr
	b	.LBB7_231
.LBB7_230:
	ldr	x10, [sp, #24]
	adrp	x9, __exception_stack_top
	add	x9, x9, :lo12:__exception_stack_top
	cmp	x10, x9
	cset	w10, eq
.LBB7_231:
	tst	x21, #0x800000
	ubfx	x9, x21, #19, #1
	and	x12, x8, #0xff
	ccmp	x24, #4, #0, eq
	ldr	x8, [sp, #40]
	cset	w13, eq
	cmp	w11, #0
	ubfx	x14, x8, #22, #1
	csel	x8, x12, xzr, ne
	tst	w11, w9
	mov	x11, #-65536
	csel	x9, x12, xzr, ne
	mov	w12, #16777216
	movk	x11, #49120, lsl #16
	tst	w13, w14
	add	x13, x20, x11
	csel	x11, x12, xzr, ne
	cmp	x13, #3584, lsl #12
	b.hi	.LBB7_24
	bfi	x11, x9, #32, #1
	orr	x11, x11, x8, lsl #16
	orr	x9, x11, x9, lsl #8
	orr	x9, x9, x10, lsl #40
	orr	x8, x9, x8
	mov	x9, #72340172838076673
	and	x9, x9, #0xffffffffffff00
	cmp	x9, x8, lsl #8
	b.ne	.LBB7_24
	ldr	x19, [sp, #6056]
	cmp	x19, #17
	b.hs	.LBB7_272
	cbz	x19, .LBB7_24
	add	x8, sp, #3568
	lsl	x21, x19, #4
	add	x22, x8, #2232
	add	x8, x8, #2240
	add	x23, x22, x21
	mov	x9, x21
	b	.LBB7_237
.LBB7_236:
	subs	x9, x9, #16
	add	x8, x8, #16
	b.eq	.LBB7_24
.LBB7_237:
	ldur	x11, [x8, #-8]
	mov	w10, #1073741824
	add	x10, x10, #1
	cmp	x11, x10
	b.hs	.LBB7_236
	ldr	x10, [x8]
	cmp	x10, x20
	b.lo	.LBB7_236
	add	x24, sp, #1952
	mov	w1, wzr
	mov	w2, #512
	add	x0, x24, #32
	bl	memset
	adrp	x8, .LCPI7_0
	ldr	x0, [sp, #6064]
	str	x20, [sp, #1976]
	ldr	q0, [x8, :lo12:.LCPI7_0]
	mov	w8, #1075838976
	cmp	x0, #33
	str	x8, [sp, #1968]
	str	q0, [sp, #1952]
	b.hs	.LBB7_252
	lsl	x20, x0, #4
	add	x8, sp, #3568
	add	x0, x24, #32
	add	x1, x8, #1720
	mov	x2, x20
	bl	memcpy
	mov	x8, xzr
	mov	x9, xzr
	add	x10, x19, #1
	mov	x11, x22
.LBB7_241:
	ldp	x12, x13, [x11], #16
	cmp	x12, x13
	b.hs	.LBB7_24
	cmp	x9, x10
	b.eq	.LBB7_273
	add	x9, x9, #1
	mov	x14, x8
	mov	x16, x22
.LBB7_244:
	cbz	x14, .LBB7_247
	mov	x15, x16
	ldr	x16, [x16, #8]
	sub	x14, x14, #16
	cmp	x12, x16
	add	x16, x15, #16
	b.hs	.LBB7_244
	ldr	x15, [x15]
	cmp	x15, x13
	b.hs	.LBB7_244
	b	.LBB7_24
.LBB7_247:
	cmp	x11, x23
	add	x8, x8, #16
	b.ne	.LBB7_241
	add	x8, sp, #1952
	add	x9, x8, x20
	add	x9, x9, #32
.LBB7_249:
	ldp	x10, x11, [x8], #16
	cmp	x10, x11
	b.hs	.LBB7_24
	cmp	x8, x9
	b.ne	.LBB7_249
	add	x0, sp, #2784
	mov	w1, wzr
	mov	w2, #512
	add	x19, sp, #2784
	bl	memset
	adrp	x9, .LCPI7_1
	mov	x8, xzr
	mov	w11, #1
	ldr	q0, [x9, :lo12:.LCPI7_1]
	str	xzr, [sp, #3312]
	str	q0, [sp, #48]
	ldp	x10, x9, [sp, #48]
	str	x10, [sp, #3296]
	add	x10, sp, #3568
	str	x9, [sp, #3304]
	add	x9, x10, #2240
	add	x10, x20, #32
	b	.LBB7_255
.LBB7_252:
	mov	w1, #32
	bl	_RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail
.LBB7_253:
	lsr	x13, x12, #3
	lsl	x12, x11, x12
	and	x13, x13, #0x1ffffffffffffff8
	ldr	x14, [x19, x13]
	orr	x12, x14, x12
	str	x12, [x19, x13]
	ldr	x12, [sp, #3312]
	add	x12, x12, #1
	str	x12, [sp, #3312]
.LBB7_254:
	cmp	x8, #1, lsl #12
	b.eq	.LBB7_265
.LBB7_255:
	ldr	x13, [sp, #3296]
	adds	x13, x13, x8, lsl #12
	b.hs	.LBB7_24
	cmn	x13, #1, lsl #12
	b.hs	.LBB7_24
	mov	x12, x8
	add	x8, x8, #1
	add	x14, x13, #1, lsl #12
	mov	x15, x21
	mov	x16, x9
	b	.LBB7_259
.LBB7_258:
	subs	x15, x15, #16
	add	x16, x16, #16
	b.eq	.LBB7_254
.LBB7_259:
	ldur	x17, [x16, #-8]
	cmp	x17, x13
	b.hi	.LBB7_258
	ldr	x17, [x16]
	cmp	x14, x17
	b.hi	.LBB7_258
	add	x16, sp, #1952
	mov	x15, x10
.LBB7_262:
	cbz	x15, .LBB7_253
	mov	x17, x16
	ldr	x16, [x16, #8]
	sub	x15, x15, #16
	cmp	x13, x16
	add	x16, x17, #16
	b.hs	.LBB7_262
	ldr	x17, [x17]
	cmp	x17, x14
	b.hs	.LBB7_262
	b	.LBB7_254
.LBB7_265:
	add	x19, sp, #1152
	add	x1, sp, #2784
	mov	w2, #536
	add	x0, x19, #6
	bl	memcpy
	add	x0, sp, #72
	add	x1, x19, #6
	mov	w2, #536
	bl	memcpy
	adrp	x8, .L_MergedGlobals
	add	x8, x8, :lo12:.L_MergedGlobals
	mov	w9, #1
.LBB7_266:
	ldaxrb	w10, [x8]
	cbnz	w10, .LBB7_366
	stlxrb	w10, w9, [x8]
	cbnz	w10, .LBB7_266
	add	x8, sp, #608
	add	x1, sp, #72
	mov	w2, #536
	add	x0, x8, #7
	bl	memcpy
	add	x8, sp, #3568
	mov	w1, wzr
	mov	w2, #512
	add	x0, x8, #8
	bl	memset
	add	x9, sp, #3568
	add	x8, sp, #3568
	add	x1, sp, #608
	add	x0, x9, #529
	mov	w2, #543
	strh	wzr, [sp, #4088]
	strb	wzr, [x8, #528]
	bl	memcpy
	adrp	x8, .L_MergedGlobals+5
	add	x8, x8, :lo12:.L_MergedGlobals+5
	mov	w9, #1
.LBB7_269:
	ldaxrb	w10, [x8]
	cbnz	w10, .LBB7_366
	stlxrb	w10, w9, [x8]
	cbnz	w10, .LBB7_269
	add	x8, sp, #3568
	mov	w1, wzr
	mov	w2, #512
	add	x0, x8, #1080
	bl	memset
	mov	w19, #1
	add	x8, sp, #3568
	str	x19, [sp, #4640]
	strb	wzr, [x8, #1592]
	bl	_RNvMs_NtCsel89eI7eLYd_8hematite7threadsNtB4_6Runner9from_boot
	ldr	x20, [sp, #32]
	add	x8, sp, #3568
	str	x0, [sp, #5168]
	add	x1, x8, #8
	mov	w2, #2512
	str	xzr, [sp, #5176]
	add	x0, x20, #8
	bl	memcpy
	str	x19, [x20]
	add	sp, sp, #2, lsl #12
	.cfi_def_cfa_offset 1616
	add	sp, sp, #1520
	.cfi_def_cfa_offset 96
	ldp	x20, x19, [sp, #80]
	ldp	x22, x21, [sp, #64]
	ldp	x24, x23, [sp, #48]
	ldp	x26, x25, [sp, #32]
	ldp	x28, x27, [sp, #16]
	ldp	x29, x30, [sp], #96
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB7_272:
	.cfi_restore_state
	mov	x0, x19
	mov	w1, #16
	bl	_RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail
.LBB7_273:
	add	x0, x19, #1
	mov	x1, x19
	bl	_RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail
.LBB7_274:
	mov	w9, #1
	add	x10, sp, #1952
.LBB7_275:
	cmp	x9, #512
	b.eq	.LBB7_365
	adrp	x11, arm_owned_l2
	add	x11, x11, :lo12:arm_owned_l2
	cmp	x9, #63
	ldr	x11, [x11, x9, lsl #3]
	b.hi	.LBB7_278
	ldr	x12, [x10, x9, lsl #3]
	orr	x13, x12, x23
	cmp	x12, #0
	csel	x12, xzr, x13, eq
	b	.LBB7_279
.LBB7_278:
	mov	x12, xzr
.LBB7_279:
	cbnz	x11, .LBB7_201
	ldr	x11, [x8, x9, lsl #3]
	add	x9, x9, #1
	cmp	x11, x12
	b.eq	.LBB7_275
	b	.LBB7_201
.LBB7_281:
	adrp	x20, .Lanon.9c45514b0a68c977cf2a682a7d2de827.70
	add	x20, x20, :lo12:.Lanon.9c45514b0a68c977cf2a682a7d2de827.70
	add	x0, sp, #3568
	mov	x1, x20
	mov	w2, #192
	str	x26, [sp, #2784]
	str	x28, [sp, #2792]
	add	x22, sp, #3568
	str	xzr, [sp, #2800]
	bl	memcpy
	add	x0, x22, #192
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #384
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #576
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #768
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #960
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #1152
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #1344
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #1536
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #1728
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #1920
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #2112
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #2304
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #2496
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #2688
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #2880
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #3072
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #3264
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #3456
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #3648
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #3840
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	add	x0, x22, #4032
	mov	x1, x20
	mov	w2, #192
	bl	memcpy
	mov	w8, #4224
	mov	x1, x20
	mov	w2, #192
	add	x0, x22, x8
	bl	memcpy
	mov	w8, #4416
	mov	x1, x20
	mov	w2, #192
	add	x0, x22, x8
	bl	memcpy
	mov	w8, #4608
	mov	x1, x20
	mov	w2, #192
	add	x0, x22, x8
	bl	memcpy
	mov	w8, #4800
	mov	x1, x20
	mov	w2, #192
	add	x0, x22, x8
	bl	memcpy
	mov	w8, #4992
	mov	x1, x20
	mov	w2, #192
	add	x0, x22, x8
	bl	memcpy
	mov	w8, #5184
	mov	x1, x20
	mov	w2, #192
	add	x0, x22, x8
	bl	memcpy
	mov	w8, #5376
	mov	x1, x20
	mov	w2, #192
	add	x0, x22, x8
	bl	memcpy
	mov	w8, #5568
	mov	x1, x20
	mov	w2, #192
	add	x0, x22, x8
	bl	memcpy
	mov	w8, #5760
	mov	x1, x20
	mov	w2, #192
	add	x0, x22, x8
	bl	memcpy
	mov	w8, #5952
	mov	x1, x20
	mov	w2, #192
	add	x0, x22, x8
	bl	memcpy
	cmp	w28, #4
	strh	wzr, [sp, #3552]
	strh	wzr, [sp, #2760]
	b.lo	.LBB7_367
	mov	w8, #2
	mov	x25, xzr
	mov	x21, xzr
	str	w8, [sp, #24]
	mov	w8, #4
	mov	x23, x28
	stp	wzr, wzr, [sp, #16]
	str	wzr, [sp, #40]
.LBB7_283:
	add	x9, x26, x25
	str	x8, [sp, #2800]
	mov	w20, #255
	ldrb	w10, [x9, #2]
	ldrb	w11, [x9, #1]
	ldrb	w12, [x9]
	ldrb	w9, [x9, #3]
	mov	w0, #2
	lsl	w10, w10, #16
	orr	w11, w12, w11, lsl #8
	orr	w9, w10, w9, lsl #24
	orr	w9, w9, w11
	rev	w9, w9
	cmp	w9, #2
	b.le	.LBB7_287
	cmp	w9, #3
	b.eq	.LBB7_297
	cmp	w9, #4
	b.ne	.LBB7_368
	mov	x25, x8
	b	.LBB7_362
.LBB7_287:
	cmp	w9, #1
	b.eq	.LBB7_307
	cmp	w9, #2
	b.ne	.LBB7_364
	cbz	x21, .LBB7_379
	cmp	x21, #32
	b.hi	.LBB7_379
	sub	x9, x21, #1
	mov	w10, #192
	madd	x11, x9, x10, x22
	ldrb	w10, [x11, #190]
	cmp	w10, #3
	b.eq	.LBB7_320
	cmp	w10, #2
	b.eq	.LBB7_323
	cmp	w10, #1
	b.ne	.LBB7_322
	ldr	w10, [x11, #16]
	mov	w0, #3
	cbz	w10, .LBB7_376
	ldr	w10, [x11, #24]
	cbz	w10, .LBB7_376
	ldr	w10, [x11, #28]
	mov	x25, x8
	mov	x21, x9
	cbz	w10, .LBB7_362
	b	.LBB7_364
.LBB7_297:
	cmn	x8, #5
	mov	w0, #1
	b.hi	.LBB7_376
	add	x10, x8, #4
	cmp	x10, x23
	b.hi	.LBB7_364
	cmn	x10, #5
	mov	w0, #1
	str	x10, [sp, #2800]
	b.hi	.LBB7_376
	add	x9, x8, #8
	cmp	x9, x23
	b.hi	.LBB7_364
	add	x8, x26, x8
	mov	w0, #1
	ldrb	w11, [x8, #2]
	ldrb	w12, [x8, #1]
	ldrb	w13, [x8]
	ldrb	w8, [x8, #3]
	lsl	w11, w11, #16
	orr	w12, w13, w12, lsl #8
	orr	w8, w11, w8, lsl #24
	orr	w8, w8, w12
	rev	w5, w8
	adds	x8, x9, x5
	b.hs	.LBB7_376
	cmp	x8, x23
	b.hi	.LBB7_364
	neg	w11, w8
	mov	w0, #1
	and	x11, x11, #0x3
	adds	x25, x11, x8
	b.hs	.LBB7_376
	cmp	x25, x23
	b.hi	.LBB7_364
	add	x12, x26, x10
	sub	x13, x21, #1
	ldrb	w8, [x12, #1]
	ldrb	w10, [x12]
	ldrb	w11, [x12, #3]
	ldrb	w12, [x12, #2]
	cmp	x13, #31
	str	x25, [sp, #2800]
	b.hi	.LBB7_379
	lsl	w12, w12, #16
	mov	w13, #192
	orr	w8, w10, w8, lsl #8
	madd	x13, x21, x13, x22
	add	x4, x26, x9
	mov	x2, x19
	orr	w10, w12, w11, lsl #24
	orr	w8, w10, w8
	rev	w3, w8
	mov	w8, #1073741824
	sub	x0, x13, #192
	add	x1, x8, x29
	bl	_RNvMs0_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtB5_4Node8property
	bics	wzr, w20, w0
	b.eq	.LBB7_362
	b	.LBB7_376
.LBB7_307:
	add	x0, sp, #1952
	add	x1, sp, #2784
	bl	_RNvMs_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtB4_6Cursor4name
	ldr	x23, [sp, #1952]
	cbz	x23, .LBB7_377
	ldr	x26, [sp, #2784]
	ldr	x2, [sp, #1960]
	cbz	x21, .LBB7_318
	mov	w20, #255
	mov	w0, #2
	cbz	x2, .LBB7_376
	cmp	x21, #32
	b.hi	.LBB7_364
	mov	w8, #192
	mov	w10, #1
	madd	x9, x21, x8, x22
	ldurb	w8, [x9, #-2]
	sturb	w10, [x9, #-8]
	cmp	w8, #1
	b.gt	.LBB7_332
	cmp	x2, #4
	cbnz	w8, .LBB7_333
	b.ne	.LBB7_349
	ldrb	w8, [x23, #2]
	ldrb	w9, [x23, #1]
	ldrb	w10, [x23]
	ldrb	w11, [x23, #3]
	lsl	w8, w8, #16
	orr	w9, w10, w9, lsl #8
	orr	w8, w8, w11, lsl #24
	orr	w8, w8, w9
	mov	w9, #29552
	movk	w9, #26979, lsl #16
	cmp	w8, w9
	b.eq	.LBB7_335
	mov	w9, #28771
	movk	w9, #29557, lsl #16
	cmp	w8, w9
	b.ne	.LBB7_347
	ldr	w8, [sp, #20]
	tbnz	w8, #0, .LBB7_381
	mov	w8, #1
	mov	x23, xzr
	mov	w20, #1
	str	w8, [sp, #20]
	b	.LBB7_359
.LBB7_318:
	cmp	x2, #0
	ldr	w9, [sp, #40]
	cset	w8, ne
	orr	w8, w9, w8
	tbnz	w8, #0, .LBB7_378
	add	x0, sp, #1952
	adrp	x1, .Lanon.9c45514b0a68c977cf2a682a7d2de827.70+32
	add	x1, x1, :lo12:.Lanon.9c45514b0a68c977cf2a682a7d2de827.70+32
	mov	w2, #128
	bl	memcpy
	mov	x23, xzr
	mov	w20, wzr
	mov	w8, #1
	str	w8, [sp, #40]
	b	.LBB7_361
.LBB7_320:
	ldrb	w10, [x11, #188]
	ldrb	w12, [x11, #187]
	tst	w12, w10
	b.eq	.LBB7_384
	ldrb	w10, [x11, #189]
	str	w10, [sp, #24]
.LBB7_322:
	mov	x25, x8
	mov	x21, x9
	b	.LBB7_362
.LBB7_323:
	cbz	x9, .LBB7_379
	mov	w10, #192
	madd	x10, x21, x10, x22
	sub	x12, x10, #368
	ldr	w12, [x12]
	cbz	w12, .LBB7_384
	sub	x12, x10, #360
	ldr	w12, [x12]
	cbz	w12, .LBB7_384
	sub	x12, x10, #356
	mov	w0, #3
	ldr	w12, [x12]
	cbnz	w12, .LBB7_376
	ldrb	w12, [x11, #185]
	cbz	w12, .LBB7_364
	ldr	x13, [x11, #168]
	mov	w0, #2
	cbz	x13, .LBB7_376
	sub	x10, x10, #364
	ldr	x14, [x11, #176]
	ldr	w15, [x10]
	lsl	x10, x15, #2
	cmp	x14, x10
	b.ne	.LBB7_364
	ldp	x12, x10, [x11]
	cmp	w15, #1
	ldrb	w11, [x11, #186]
	b.ne	.LBB7_337
	ldrb	w14, [x13, #2]
	ldrb	w15, [x13, #1]
	ldrb	w16, [x13]
	ldrb	w13, [x13, #3]
	lsl	w14, w14, #16
	orr	w15, w16, w15, lsl #8
	orr	w13, w14, w13, lsl #24
	orr	w13, w13, w15
	rev	w13, w13
	b	.LBB7_339
.LBB7_332:
	cmp	w8, #4
	b.eq	.LBB7_345
	b	.LBB7_384
.LBB7_333:
	b.hs	.LBB7_344
	cmp	x2, #3
	b.ne	.LBB7_358
	b	.LBB7_357
.LBB7_335:
	ldr	w8, [sp, #16]
	tbnz	w8, #0, .LBB7_381
	mov	w8, #1
	mov	x23, xzr
	mov	w20, #3
	str	w8, [sp, #16]
	b	.LBB7_359
.LBB7_337:
	cmp	x14, #8
	b.lo	.LBB7_380
	ldrb	w14, [x13, #1]
	ldrb	w15, [x13]
	ldrb	w16, [x13, #3]
	ldrb	w17, [x13, #2]
	ldrb	w18, [x13, #5]
	ldrb	w0, [x13, #4]!
	orr	x14, x15, x14, lsl #8
	ldrb	w1, [x13, #2]
	lsl	x17, x17, #16
	ldrb	w13, [x13, #3]
	lsl	w1, w1, #16
	orr	x15, x17, x16, lsl #24
	orr	w16, w0, w18, lsl #8
	orr	w13, w1, w13, lsl #24
	orr	x14, x15, x14
	orr	w13, w13, w16
	orr	x13, x14, x13, lsl #32
	rev	x13, x13
.LBB7_339:
	tbz	w12, #0, .LBB7_384
	cmp	x10, x13
	mov	w0, #3
	b.ne	.LBB7_376
	cmp	x13, #1
	b.hi	.LBB7_364
	add	x12, sp, #3552
	ldrb	w12, [x12, x10]
	tbnz	w12, #0, .LBB7_381
	add	x13, sp, #3552
	mov	x25, x8
	add	x8, sp, #2760
	mov	w12, #1
	strb	w12, [x13, x10]
	mov	x21, x9
	strb	w11, [x8, x10]
	b	.LBB7_362
.LBB7_344:
	ldrb	w8, [x23, #2]
	ldrb	w9, [x23, #1]
	ldrb	w10, [x23]
	ldrb	w11, [x23, #3]
	lsl	w8, w8, #16
	orr	w9, w10, w9, lsl #8
	orr	w8, w8, w11, lsl #24
	orr	w8, w8, w9
	mov	w9, #28771
	movk	w9, #16501, lsl #16
	cmp	w8, w9
	b.eq	.LBB7_352
.LBB7_345:
	cmp	x2, #4
	b.ne	.LBB7_349
	ldrb	w8, [x23, #2]
	ldrb	w9, [x23, #1]
	ldrb	w10, [x23]
	ldrb	w11, [x23, #3]
	lsl	w8, w8, #16
	orr	w9, w10, w9, lsl #8
	orr	w8, w8, w11, lsl #24
	orr	w8, w8, w9
.LBB7_347:
	mov	w9, #29552
	mov	w0, #3
	movk	w9, #26979, lsl #16
	cmp	w8, w9
	b.eq	.LBB7_376
	mov	w9, #28771
	movk	w9, #29557, lsl #16
	cmp	w8, w9
	b.ne	.LBB7_356
	b	.LBB7_364
.LBB7_349:
	cmp	x2, #5
	b.hs	.LBB7_354
	cmp	x2, #3
	b.eq	.LBB7_357
	cmp	x2, #4
	b.eq	.LBB7_356
	b	.LBB7_358
.LBB7_352:
	add	x0, sp, #1952
	mov	x1, x23
	bl	_RNvNtCsjStpv0Kdcdo_9hm_kernel12cpu_topology12unit_address
	ldrb	w8, [sp, #1952]
	cbnz	w8, .LBB7_382
	ldr	x25, [sp, #1960]
	mov	w20, #2
	mov	w23, #1
	b	.LBB7_360
.LBB7_354:
	adrp	x0, .Lanon.9c45514b0a68c977cf2a682a7d2de827.71
	add	x0, x0, :lo12:.Lanon.9c45514b0a68c977cf2a682a7d2de827.71
	mov	x1, x23
	mov	w2, #5
	bl	memcmp
	cbz	w0, .LBB7_383
	adrp	x0, .Lanon.9c45514b0a68c977cf2a682a7d2de827.72
	add	x0, x0, :lo12:.Lanon.9c45514b0a68c977cf2a682a7d2de827.72
	mov	x1, x23
	mov	w2, #5
	bl	memcmp
	cbz	w0, .LBB7_383
.LBB7_356:
	ldrb	w8, [x23, #2]
	ldrb	w9, [x23, #1]
	ldrb	w10, [x23]
	ldrb	w11, [x23, #3]
	lsl	w8, w8, #16
	orr	w9, w10, w9, lsl #8
	orr	w8, w8, w11, lsl #24
	orr	w8, w8, w9
	mov	w9, #28771
	movk	w9, #16501, lsl #16
	cmp	w8, w9
	b.ne	.LBB7_358
	b	.LBB7_383
.LBB7_357:
	ldrb	w8, [x23, #1]
	ldrb	w9, [x23]
	orr	w8, w9, w8, lsl #8
	ldrb	w9, [x23, #2]
	orr	w8, w8, w9, lsl #16
	mov	w9, #28771
	movk	w9, #117, lsl #16
	cmp	w8, w9
	b.eq	.LBB7_384
.LBB7_358:
	mov	x23, xzr
	mov	w20, #4
.LBB7_359:
.LBB7_360:
	add	x0, sp, #1952
	adrp	x1, .Lanon.9c45514b0a68c977cf2a682a7d2de827.70+32
	add	x1, x1, :lo12:.Lanon.9c45514b0a68c977cf2a682a7d2de827.70+32
	mov	w2, #128
	bl	memcpy
	cmp	x21, #32
	b.eq	.LBB7_385
.LBB7_361:
	mov	w8, #192
	add	x1, sp, #1952
	mov	w2, #128
	madd	x24, x21, x8, x22
	add	x0, x24, #32
	stp	x23, x25, [x24]
	str	wzr, [x24, #16]
	str	wzr, [x24, #24]
	bl	memcpy
	ldr	x23, [sp, #2792]
	ldr	x25, [sp, #2800]
	add	x21, x21, #1
	stp	xzr, xzr, [x24, #160]
	str	wzr, [x24, #184]
	strh	wzr, [x24, #188]
	strb	w20, [x24, #190]
.LBB7_362:
	cmn	x25, #5
	mov	w20, #255
	mov	w0, #1
	b.hi	.LBB7_376
	add	x8, x25, #4
	cmp	x8, x23
	b.ls	.LBB7_283
.LBB7_364:
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_365:
	mov	w14, #1
	b	.LBB7_202
.LBB7_366:
	clrex
	b	.LBB7_24
.LBB7_367:
	mov	w0, #1
	mov	w20, #255
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_368:
	cmp	w9, #9
	b.ne	.LBB7_364
	ldr	w9, [sp, #40]
	mov	w0, #2
	tbz	w9, #0, .LBB7_376
	cbnz	x21, .LBB7_376
	cmp	x8, x28
	b.ne	.LBB7_364
	ldrb	w8, [sp, #3552]
	ldr	w9, [sp, #20]
	and	w8, w9, w8
	tbz	w8, #0, .LBB7_386
	ldrb	w8, [sp, #3553]
	tbz	w8, #0, .LBB7_387
	ldrh	w8, [sp, #2760]
	cmp	w8, #257
	ldr	w8, [sp, #24]
	ccmp	w8, #2, #4, eq
	b.eq	.LBB7_389
	mov	w0, wzr
	ldr	w20, [sp, #24]
	mov	w27, #2
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_376:
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_377:
	ldrb	w0, [sp, #1960]
	mov	w20, #255
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_378:
	mov	w0, #2
	mov	w20, #255
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_379:
	mov	w0, #2
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_380:
	mov	w0, #1
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_381:
	mov	w0, #4
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_382:
	ldrb	w0, [sp, #1953]
	mov	w20, #255
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_383:
	mov	w0, #3
	mov	w20, #255
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_384:
	mov	w0, #3
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_385:
	mov	w0, #5
	mov	w20, #255
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_386:
	mov	w0, #6
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_387:
	ldrb	w8, [sp, #2760]
	mov	w0, wzr
	mov	w27, #1
	cbz	w8, .LBB7_390
	ldr	w20, [sp, #24]
	cmp	w20, #2
	b.ne	.LBB7_364
.LBB7_389:
	mov	w0, #7
	mov	w20, #255
	and	x21, x0, #0xff
	b	.LBB7_151
.LBB7_390:
	ldr	w20, [sp, #24]
	and	x21, x0, #0xff
	b	.LBB7_151
.Lfunc_end7:
	.size	_RNvNtCsel89eI7eLYd_8hematite4arch4init, .Lfunc_end7-_RNvNtCsel89eI7eLYd_8hematite4arch4init
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI8_0:
	.xword	131110
	.xword	1
	.section	.text._RNvNtCsel89eI7eLYd_8hematite4arch9smp_tests,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsel89eI7eLYd_8hematite4arch9smp_tests,@function
_RNvNtCsel89eI7eLYd_8hematite4arch9smp_tests:
.Lfunc_begin8:
	.cfi_startproc
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	d15, d14, [sp, #16]
	stp	d13, d12, [sp, #32]
	stp	d11, d10, [sp, #48]
	stp	d9, d8, [sp, #64]
	str	x30, [sp, #80]
	stp	x20, x19, [sp, #96]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	.cfi_offset b10, -56
	.cfi_offset b11, -64
	.cfi_offset b12, -72
	.cfi_offset b13, -80
	.cfi_offset b14, -88
	.cfi_offset b15, -96
	.cfi_remember_state
	ldrb	w9, [x0, #1712]
	cmp	w9, #255
	b.ne	.LBB8_13
	mov	w10, #24
	mov	x8, xzr
	adrp	x9, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.9
	add	x9, x9, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9
	movk	w10, #2304, lsl #16
	mov	w11, #150994944
	mov	w12, #13
.LBB8_2:
	mov	w13, #34464
	cmp	x8, #23
	movk	w13, #1, lsl #16
	b.ne	.LBB8_5
.LBB8_3:
	ldr	w14, [x10]
	tbz	w14, #5, .LBB8_8
	isb
	subs	w13, w13, #1
	b.ne	.LBB8_3
	b	.LBB8_36
.LBB8_5:
	ldrb	w13, [x9, x8]
	mov	w14, #34464
	movk	w14, #1, lsl #16
.LBB8_6:
	ldr	w15, [x10]
	tbz	w15, #5, .LBB8_12
	isb
	subs	w14, w14, #1
	b.ne	.LBB8_6
	b	.LBB8_38
.LBB8_8:
	mov	w13, #34464
	str	w12, [x11]
	movk	w13, #1, lsl #16
.LBB8_9:
	ldr	w14, [x10]
	tbz	w14, #5, .LBB8_11
	isb
	subs	w13, w13, #1
	b.ne	.LBB8_9
	b	.LBB8_44
.LBB8_11:
	mov	w13, #10
.LBB8_12:
	add	x8, x8, #1
	str	w13, [x11]
	cmp	x8, #24
	b.ne	.LBB8_2
	b	.LBB8_61
.LBB8_13:
	ldr	x8, [x0, #1704]
	cmp	x8, #3
	b.hs	.LBB8_68
	cmp	x8, #2
	b.ne	.LBB8_24
	add	x8, x0, #1688
	ldp	x8, x10, [x8]
	cmp	x10, #1
	ccmp	x8, #0, #0, eq
	b.ne	.LBB8_24
	cmp	w9, #2
	b.eq	.LBB8_24
	//APP
	mrs	x8, DAIF
	//NO_APP
	cmp	x8, #960
	b.ne	.LBB8_49
	//APP
	mrs	x8, DAIF
	msr	DAIFSet, #2
	isb
	mrs	x10, TPIDR_EL1
	mrs	x9, MPIDR_EL1
	//NO_APP
	and	x9, x9, #0xffffffffff
	and	x9, x9, #0xffffffff00ffffff
	cmp	x9, #1
	b.hi	.LBB8_48
	adrp	x11, arm_cpu_records
	add	x11, x11, :lo12:arm_cpu_records
	add	x11, x11, x9, lsl #7
	cmp	x10, x11
	b.ne	.LBB8_48
	ldr	x10, [x10, #96]
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	orr	x8, x10, x9
	cbnz	x8, .LBB8_49
	mov	w0, #-2080374784
	mov	x1, xzr
	mov	x2, xzr
	mov	x3, xzr
	//APP
	hvc	#0
	//NO_APP
	and	x8, x0, #0xffff0000
	cmp	x8, #16, lsl #12
	b.ne	.LBB8_49
	mov	w0, #10
	mov	w1, #3
	mov	x2, xzr
	mov	x3, xzr
	movk	w0, #33792, lsl #16
	movk	w1, #50176, lsl #16
	//APP
	hvc	#0
	//NO_APP
	mov	x19, x0
	mov	w0, #10
	mov	w1, #2
	mov	x2, xzr
	movk	w0, #33792, lsl #16
	movk	w1, #33792, lsl #16
	mov	x3, xzr
	//APP
	hvc	#0
	//NO_APP
	mov	x20, x0
	mov	w0, #10
	mov	w1, #4
	mov	x2, xzr
	movk	w0, #33792, lsl #16
	movk	w1, #50176, lsl #16
	mov	x3, xzr
	//APP
	hvc	#0
	//NO_APP
	orr	w8, w20, w19
	orr	w8, w8, w0
	cbnz	w8, .LBB8_49
	adrp	x0, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.10
	add	x0, x0, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.10
	mov	w1, #29
	bl	_RNvXNtCsel89eI7eLYd_8hematite4archNtB2_12BootPlatformNtCsjStpv0Kdcdo_9hm_kernel8Platform5write
	bl	_RNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer
.LBB8_24:
	mov	w10, #24
	mov	x8, xzr
	adrp	x9, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.9
	add	x9, x9, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9
	movk	w10, #2304, lsl #16
	mov	w11, #150994944
	mov	w12, #13
.LBB8_25:
	mov	w13, #34464
	cmp	x8, #23
	movk	w13, #1, lsl #16
	b.ne	.LBB8_28
.LBB8_26:
	ldr	w14, [x10]
	tbz	w14, #5, .LBB8_31
	isb
	subs	w13, w13, #1
	b.ne	.LBB8_26
	b	.LBB8_40
.LBB8_28:
	ldrb	w13, [x9, x8]
	mov	w14, #34464
	movk	w14, #1, lsl #16
.LBB8_29:
	ldr	w15, [x10]
	tbz	w15, #5, .LBB8_35
	isb
	subs	w14, w14, #1
	b.ne	.LBB8_29
	b	.LBB8_42
.LBB8_31:
	mov	w13, #34464
	str	w12, [x11]
	movk	w13, #1, lsl #16
.LBB8_32:
	ldr	w14, [x10]
	tbz	w14, #5, .LBB8_34
	isb
	subs	w13, w13, #1
	b.ne	.LBB8_32
	b	.LBB8_46
.LBB8_34:
	mov	w13, #10
.LBB8_35:
	add	x8, x8, #1
	str	w13, [x11]
	cmp	x8, #24
	b.ne	.LBB8_25
	b	.LBB8_61
.LBB8_36:
	adrp	x8, .LCPI8_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI8_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB8_37:
	//APP
	wfi
	//NO_APP
	b	.LBB8_37
.LBB8_38:
	adrp	x8, .LCPI8_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI8_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB8_39:
	//APP
	wfi
	//NO_APP
	b	.LBB8_39
.LBB8_40:
	adrp	x8, .LCPI8_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI8_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB8_41:
	//APP
	wfi
	//NO_APP
	b	.LBB8_41
.LBB8_42:
	adrp	x8, .LCPI8_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI8_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB8_43:
	//APP
	wfi
	//NO_APP
	b	.LBB8_43
.LBB8_44:
	adrp	x8, .LCPI8_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI8_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB8_45:
	//APP
	wfi
	//NO_APP
	b	.LBB8_45
.LBB8_46:
	adrp	x8, .LCPI8_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI8_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB8_47:
	//APP
	wfi
	//NO_APP
	b	.LBB8_47
.LBB8_48:
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
.LBB8_49:
	mov	w10, #24
	mov	x8, xzr
	adrp	x9, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.11
	add	x9, x9, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.11
	movk	w10, #2304, lsl #16
	mov	w11, #150994944
	mov	w12, #13
.LBB8_50:
	mov	w13, #34464
	cmp	x8, #19
	movk	w13, #1, lsl #16
	b.ne	.LBB8_53
.LBB8_51:
	ldr	w14, [x10]
	tbz	w14, #5, .LBB8_56
	isb
	subs	w13, w13, #1
	b.ne	.LBB8_51
	b	.LBB8_62
.LBB8_53:
	ldrb	w13, [x9, x8]
	mov	w14, #34464
	movk	w14, #1, lsl #16
.LBB8_54:
	ldr	w15, [x10]
	tbz	w15, #5, .LBB8_60
	isb
	subs	w14, w14, #1
	b.ne	.LBB8_54
	b	.LBB8_64
.LBB8_56:
	mov	w13, #34464
	str	w12, [x11]
	movk	w13, #1, lsl #16
.LBB8_57:
	ldr	w14, [x10]
	tbz	w14, #5, .LBB8_59
	isb
	subs	w13, w13, #1
	b.ne	.LBB8_57
	b	.LBB8_66
.LBB8_59:
	mov	w13, #10
.LBB8_60:
	add	x8, x8, #1
	str	w13, [x11]
	cmp	x8, #20
	b.ne	.LBB8_50
.LBB8_61:
	ldp	x20, x19, [sp, #96]
	ldr	x30, [sp, #80]
	ldp	d9, d8, [sp, #64]
	ldp	d11, d10, [sp, #48]
	ldp	d13, d12, [sp, #32]
	ldp	d15, d14, [sp, #16]
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	.cfi_restore b12
	.cfi_restore b13
	.cfi_restore b14
	.cfi_restore b15
	ret
.LBB8_62:
	.cfi_restore_state
	adrp	x8, .LCPI8_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI8_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB8_63:
	//APP
	wfi
	//NO_APP
	b	.LBB8_63
.LBB8_64:
	adrp	x8, .LCPI8_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI8_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB8_65:
	//APP
	wfi
	//NO_APP
	b	.LBB8_65
.LBB8_66:
	adrp	x8, .LCPI8_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI8_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB8_67:
	//APP
	wfi
	//NO_APP
	b	.LBB8_67
.LBB8_68:
	mov	x0, x8
	mov	w1, #2
	bl	_RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail
.Lfunc_end8:
	.size	_RNvNtCsel89eI7eLYd_8hematite4arch9smp_tests, .Lfunc_end8-_RNvNtCsel89eI7eLYd_8hematite4arch9smp_tests
	.cfi_endproc

	.section	.text._RNvNtCsel89eI7eLYd_8hematite7preempt5empty,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty,@function
_RNvNtCsel89eI7eLYd_8hematite7preempt5empty:
.Lfunc_begin9:
	.cfi_startproc
	mov	x0, xzr
	ret
.Lfunc_end9:
	.size	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty, .Lfunc_end9-_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.cfi_endproc

	.section	.text._RNvNtCsel89eI7eLYd_8hematite7preempt5entry,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsel89eI7eLYd_8hematite7preempt5entry,@function
_RNvNtCsel89eI7eLYd_8hematite7preempt5entry:
.Lfunc_begin10:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x30, [sp, #32]
	.cfi_offset w30, -16
	.cfi_remember_state
	mov	w8, #1136
	adrp	x12, arm_cpu_records
	add	x12, x12, :lo12:arm_cpu_records
	madd	x9, x1, x8, x0
	ldr	x8, [x9, #1096]
	ldr	x2, [x9, #1104]
	//APP
	mrs	x10, DAIF
	msr	DAIFSet, #2
	isb
	mrs	x11, TPIDR_EL1
	mrs	x9, MPIDR_EL1
	//NO_APP
	and	x9, x9, #0xffffffffff
	and	x9, x9, #0xffffffff00ffffff
	add	x12, x12, x9, lsl #7
	cmp	x9, #1
	ccmp	x11, x12, #0, ls
	b.ne	.LBB10_3
	ldr	x11, [x11, #96]
	//APP
	msr	DAIF, x10
	isb
	//NO_APP
	cmp	x11, x9
	b.ne	.LBB10_4
	stp	x9, x0, [sp, #8]
	add	x0, sp, #8
	str	x1, [sp, #24]
	adrp	x1, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.12
	add	x1, x1, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.12
	blr	x8
	ldr	x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	ret
.LBB10_3:
	.cfi_restore_state
	//APP
	msr	DAIF, x10
	isb
	//NO_APP
.LBB10_4:
	bl	arm_exception_fail
.Lfunc_end10:
	.size	_RNvNtCsel89eI7eLYd_8hematite7preempt5entry, .Lfunc_end10-_RNvNtCsel89eI7eLYd_8hematite7preempt5entry
	.cfi_endproc

	.section	.text._RNvNtCsel89eI7eLYd_8hematite7preempt9run_local,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsel89eI7eLYd_8hematite7preempt9run_local,@function
_RNvNtCsel89eI7eLYd_8hematite7preempt9run_local:
.Lfunc_begin11:
	.cfi_startproc
	stp	x29, x30, [sp, #-96]!
	.cfi_def_cfa_offset 96
	stp	x28, x27, [sp, #16]
	stp	x26, x25, [sp, #32]
	stp	x24, x23, [sp, #48]
	stp	x22, x21, [sp, #64]
	stp	x20, x19, [sp, #80]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	sub	sp, sp, #1, lsl #12
	.cfi_def_cfa_offset 4192
	ldr	xzr, [sp]
	sub	sp, sp, #3872
	.cfi_def_cfa_offset 8064
	.cfi_remember_state
	ldr	xzr, [sp]
	//APP
	mrs	x8, DAIF
	//NO_APP
	//APP
	mrs	x9, DAIF
	msr	DAIFSet, #2
	isb
	mrs	x11, TPIDR_EL1
	mrs	x10, MPIDR_EL1
	//NO_APP
	and	x10, x10, #0xffffffffff
	mov	x23, x1
	mov	x20, x0
	and	x10, x10, #0xffffffff00ffffff
	cmp	x10, #1
	b.ls	.LBB11_2
	cmp	x10, x3
	//APP
	msr	DAIF, x9
	isb
	//NO_APP
	csel	w9, wzr, wzr, ne
	cmp	x8, #960
	csel	w8, wzr, w9, ne
	cbz	w8, .LBB11_4
	b	.LBB11_6
.LBB11_2:
	adrp	x12, arm_cpu_records
	add	x12, x12, :lo12:arm_cpu_records
	add	x12, x12, x10, lsl #7
	cmp	x11, x12
	b.ne	.LBB11_5
	ldr	x11, [x11, #96]
	cmp	x11, x10
	cset	w11, eq
	cmp	x10, x3
	//APP
	msr	DAIF, x9
	isb
	//NO_APP
	csel	w9, wzr, w11, ne
	cmp	x8, #960
	csel	w8, wzr, w9, ne
	cbnz	w8, .LBB11_6
.LBB11_4:
	mov	w8, #2
	strb	wzr, [x20]
	strb	w8, [x20, #728]
	b	.LBB11_53
.LBB11_5:
	cmp	x10, x3
	//APP
	msr	DAIF, x9
	isb
	//NO_APP
	csel	w9, wzr, wzr, ne
	cmp	x8, #960
	csel	w8, wzr, w9, ne
	cbz	w8, .LBB11_4
.LBB11_6:
	adrp	x8, __thread0_top
	add	x8, x8, :lo12:__thread0_top
	adrp	x9, __secondary_thread0_top
	add	x9, x9, :lo12:__secondary_thread0_top
	tst	w3, #0x1
	adrp	x10, __thread1_top
	add	x10, x10, :lo12:__thread1_top
	csel	x19, x9, x8, ne
	adrp	x8, __secondary_thread1_top
	add	x8, x8, :lo12:__secondary_thread1_top
	adrp	x9, __secondary_thread2_top
	add	x9, x9, :lo12:__secondary_thread2_top
	csel	x22, x8, x10, ne
	adrp	x8, __thread2_top
	add	x8, x8, :lo12:__thread2_top
	csel	x24, x9, x8, ne
	adrp	x8, __thread3_top
	add	x8, x8, :lo12:__thread3_top
	adrp	x9, __secondary_thread3_top
	add	x9, x9, :lo12:__secondary_thread3_top
	str	x2, [sp, #112]
	csel	x27, x9, x8, ne
	add	x0, sp, #176
	mov	w1, wzr
	mov	w2, #729
	mov	x25, x3
	stp	x19, x22, [sp, #144]
	stp	x24, x27, [sp, #160]
	add	x26, sp, #176
	bl	memset
	bl	arm_preempt_setup
	cbz	x0, .LBB11_10
	ldr	x21, [sp, #112]
	cbz	x21, .LBB11_12
	ldp	x28, x29, [x23]
	cmp	x21, #1
	stp	x22, x19, [sp, #48]
	stp	x27, x24, [sp, #32]
	stp	x20, x0, [sp, #16]
	str	x28, [sp, #128]
	b.ne	.LBB11_14
	add	x0, sp, #1, lsl #12
	mov	w1, wzr
	mov	w2, #1096
	add	x0, x0, #2768
	bl	memset
	mov	x23, xzr
	str	xzr, [sp, #6840]
	adrp	x19, _RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	add	x19, x19, :lo12:_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	str	xzr, [sp, #6848]
	mov	x21, x29
	str	xzr, [sp, #6856]
	b	.LBB11_16
.LBB11_10:
	bl	arm_preempt_stop
	cmp	x0, #1
	b.ne	.LBB11_54
	mov	w8, #3
	mov	w9, #2
	strb	w8, [x20]
	strb	w9, [x20, #728]
	b	.LBB11_53
.LBB11_12:
	bl	arm_preempt_stop
	cmp	x0, #1
	b.ne	.LBB11_54
	mov	x0, x20
	mov	w1, wzr
	mov	w2, #729
	bl	memset
	b	.LBB11_53
.LBB11_14:
	ldp	x24, x19, [x23, #16]
	add	x0, sp, #1, lsl #12
	add	x0, x0, #2768
	mov	w1, wzr
	mov	w2, #1096
	bl	memset
	cmp	x21, #2
	str	xzr, [sp, #6840]
	str	xzr, [sp, #6848]
	str	xzr, [sp, #6856]
	b.ne	.LBB11_17
	mov	x21, x29
	mov	x23, x19
	mov	x19, x24
.LBB11_16:
	add	x0, sp, #1, lsl #12
	mov	w1, wzr
	mov	w2, #1096
	add	x0, x0, #1648
	bl	memset
	adrp	x27, _RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	add	x27, x27, :lo12:_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	mov	x22, xzr
	mov	x28, xzr
	str	xzr, [sp, #5720]
	mov	x20, x27
	str	xzr, [sp, #5728]
	str	xzr, [sp, #5736]
	b	.LBB11_21
.LBB11_17:
	ldp	x27, x22, [x23, #32]
	add	x0, sp, #1, lsl #12
	add	x0, x0, #1648
	mov	w1, wzr
	mov	w2, #1096
	bl	memset
	cmp	x21, #4
	str	xzr, [sp, #5720]
	str	xzr, [sp, #5728]
	str	xzr, [sp, #5736]
	b.lo	.LBB11_19
	ldp	x20, x28, [x23, #48]
	b	.LBB11_20
.LBB11_19:
	mov	x28, xzr
	adrp	x20, _RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	add	x20, x20, :lo12:_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
.LBB11_20:
	mov	x21, x29
	mov	x23, x19
	mov	x19, x24
.LBB11_21:
	add	x9, x26, #96
	add	x8, x26, #208
	add	x24, sp, #912
	stp	x9, x8, [sp, #96]
	add	x9, x26, #128
	add	x8, x26, #64
	add	x0, x24, #3408
	mov	w1, wzr
	mov	w2, #1096
	stp	x8, x9, [sp, #80]
	bl	memset
	add	x0, sp, #912
	mov	w1, wzr
	mov	w2, #1096
	str	xzr, [sp, #5432]
	str	xzr, [sp, #5440]
	str	xzr, [sp, #5448]
	bl	memset
	add	x1, sp, #1, lsl #12
	add	x0, x24, #1136
	mov	w2, #1096
	add	x1, x1, #2768
	str	xzr, [sp, #2024]
	str	xzr, [sp, #2032]
	str	xzr, [sp, #2040]
	bl	memcpy
	ldr	x8, [sp, #6840]
	ldr	x9, [sp, #6848]
	add	x1, sp, #1, lsl #12
	ldr	x10, [sp, #6856]
	add	x0, x24, #2272
	add	x1, x1, #1648
	mov	w2, #1096
	str	x8, [sp, #3160]
	str	x9, [sp, #3168]
	str	x10, [sp, #3176]
	bl	memcpy
	ldr	x8, [sp, #5720]
	ldr	x9, [sp, #5728]
	mov	w1, wzr
	ldr	x10, [sp, #5736]
	mov	w2, #256
	str	x8, [sp, #4296]
	mov	w8, #4544
	add	x0, x24, x8
	str	x9, [sp, #4304]
	str	x10, [sp, #4312]
	str	x0, [sp, #136]
	bl	memset
	ldr	x8, [sp, #128]
	adrp	x9, __secondary_thread1_guard
	add	x9, x9, :lo12:__secondary_thread1_guard
	tst	w25, #0x1
	adrp	x10, __thread0_guard
	add	x10, x10, :lo12:__thread0_guard
	str	x8, [sp, #2008]
	adrp	x8, __thread1_guard
	add	x8, x8, :lo12:__thread1_guard
	adrp	x11, __secondary_thread0_guard
	add	x11, x11, :lo12:__secondary_thread0_guard
	csel	x8, x9, x8, ne
	str	x8, [sp, #128]
	csel	x8, x11, x10, ne
	adrp	x9, __secondary_thread2_guard
	add	x9, x9, :lo12:__secondary_thread2_guard
	str	x19, [sp, #3144]
	ldr	x26, [sp, #112]
	str	x22, [sp, #4288]
	ldp	x22, x19, [sp, #48]
	str	x8, [sp, #120]
	adrp	x8, __thread2_guard
	add	x8, x8, :lo12:__thread2_guard
	str	x20, [sp, #5416]
	csel	x10, x9, x8, ne
	adrp	x8, __thread3_guard
	add	x8, x8, :lo12:__thread3_guard
	str	x28, [sp, #5424]
	adrp	x9, __secondary_thread3_guard
	add	x9, x9, :lo12:__secondary_thread3_guard
	ldp	x20, x28, [sp, #32]
	mov	x29, xzr
	str	x27, [sp, #4280]
	csel	x11, x9, x8, ne
	add	x27, x24, #536
	add	x24, sp, #912
	str	x21, [sp, #2016]
	str	x25, [sp, #64]
	str	x23, [sp, #3152]
.LBB11_22:
	ldp	x9, x8, [sp, #120]
	mov	w1, wzr
	str	x10, [sp, #5760]
	mov	x25, x29
	mov	x23, x10
	str	x11, [sp, #5768]
	mov	x21, x11
	str	x9, [sp, #5744]
	add	x9, sp, #1, lsl #12
	str	x8, [sp, #5752]
	add	x8, sp, #1, lsl #12
	add	x9, x9, #2768
	str	x19, [sp, #6864]
	add	x8, x8, #1648
	str	x22, [sp, #6872]
	ldr	x8, [x8, x29, lsl #3]
	str	x28, [sp, #6880]
	str	x20, [sp, #6888]
	add	x0, x8, #1, lsl #12
	ldr	x9, [x9, x29, lsl #3]
	add	x29, x29, #1
	sub	x9, x9, x8
	sub	x2, x9, #1, lsl #12
	bl	memset
	add	x8, sp, #144
	adrp	x9, arm_preempt_start
	add	x9, x9, :lo12:arm_preempt_start
	ldr	x8, [x8, x25, lsl #3]
	str	x9, [x27, #520]
	mov	x11, x21
	mov	x10, x23
	cmp	x26, x29
	str	x8, [x27]
	//APP
	mrs	x8, S3_0_C4_C2_3
	//NO_APP
	ldr	x9, [sp, #136]
	stp	x24, x9, [x27, #-96]
	mov	w9, #837
	add	x24, x24, #1136
	orr	x8, x8, x9
	str	x8, [x27, #528]
	add	x8, sp, #912
	stp	x8, x25, [x27, #-80]
	add	x27, x27, #1136
	b.ne	.LBB11_22
	ldr	x9, [sp, #64]
	mov	w10, #1
	ldr	x22, [sp, #136]
	add	x11, sp, #176
	add	x15, sp, #912
	ldr	x19, [sp, #24]
	lsl	x27, x10, x9
	mov	x8, xzr
	mov	x28, xzr
	add	x9, x11, #160
	sub	x16, x15, #1136
	mov	w20, #1136
	adrp	x25, .L_MergedGlobals+16
	add	x25, x25, :lo12:.L_MergedGlobals+16
	mov	w17, #3
	mov	x14, x26
	sub	x29, x15, #1136
	str	x9, [sp, #72]
	b	.LBB11_26
.LBB11_24:
	mov	x28, x26
.LBB11_25:
	ldr	x8, [sp, #368]
	cmp	x8, x14
	b.hs	.LBB11_47
.LBB11_26:
	mov	x9, xzr
	mov	x10, xzr
.LBB11_27:
	cmp	x10, x14
	madd	x11, x10, x20, x16
	csel	x12, x10, x14, hi
.LBB11_28:
	cmp	x12, x10
	b.eq	.LBB11_34
	ldr	x13, [x11, #1400]
	add	x10, x10, #1
	add	x11, x11, #1136
	cmp	x13, #3
	b.ne	.LBB11_28
	ldr	x12, [x11, #1112]
	cbz	x12, .LBB11_54
	ldr	x13, [x11, #1120]
	ldar	x12, [x12]
	cmp	x12, x13
	b.eq	.LBB11_33
	add	x12, x11, #1112
	str	x17, [x11, #280]
	stp	xzr, xzr, [x12]
	str	xzr, [x11, #264]
	b	.LBB11_27
.LBB11_33:
	add	x9, x9, #1
	b	.LBB11_27
.LBB11_34:
	sub	x8, x14, x8
	cmp	x9, x8
	b.ne	.LBB11_37
.LBB11_35:
	ldaxr	x8, [x25]
	orr	x8, x8, x27
	stlxr	w9, x8, [x25]
	cbnz	w9, .LBB11_35
	isb
	b	.LBB11_25
.LBB11_37:
	ldaxr	x8, [x25]
	bic	x8, x8, x27
	stlxr	w9, x8, [x25]
	cbnz	w9, .LBB11_37
	add	x8, x28, #1
	madd	x24, x28, x20, x15
	udiv	x9, x8, x14
	msub	x26, x9, x14, x8
	ldr	x8, [x24, #264]
	cbnz	x8, .LBB11_24
	ldr	x8, [x24, #280]
	cmp	x8, #4
	b.hs	.LBB11_54
	ldr	x10, [sp, #376]
	ldr	x9, [sp, #896]
	adds	x10, x10, #1
	csinv	x10, x10, xzr, lo
	cmp	x9, #64
	str	x10, [sp, #376]
	b.hs	.LBB11_42
	ldr	x10, [sp, #104]
	str	x28, [x10, x9, lsl #3]
	add	x10, sp, #176
	strb	w8, [x10, x9]
	ldr	x8, [sp, #896]
	add	x8, x8, #1
	str	x8, [sp, #896]
	b	.LBB11_43
.LBB11_42:
	mov	w8, #1
	strb	w8, [sp, #904]
.LBB11_43:
	mov	x0, x22
	mov	x1, x24
	mov	x2, x19
	bl	arm_preempt_dispatch
	ldr	x8, [x24, #264]
	cmp	x8, #2
	b.ne	.LBB11_46
	ldr	x8, [x24, #1112]
	ldr	x14, [sp, #112]
	add	x15, sp, #912
	mov	w17, #3
	cbnz	x8, .LBB11_54
	ldr	x8, [sp, #368]
	ldr	x10, [sp, #88]
	mov	x16, x29
	ldr	x9, [x24, #256]
	add	x8, x8, #1
	str	x8, [sp, #368]
	ldr	x8, [x24, #272]
	str	x9, [x10, x28, lsl #3]
	ldr	x10, [sp, #72]
	ldr	x9, [x24, #1088]
	str	x8, [x10, x28, lsl #3]
	ldr	x8, [sp, #80]
	str	x9, [x8, x28, lsl #3]
	ldr	x9, [sp, #96]
	ldr	x8, [x24, #1128]
	str	x8, [x9, x28, lsl #3]
	b	.LBB11_24
.LBB11_46:
	ldr	x14, [sp, #112]
	mov	x28, x26
	add	x15, sp, #912
	mov	x16, x29
	mov	w17, #3
	b	.LBB11_25
.LBB11_47:
	bl	arm_preempt_stop
	cmp	x0, #1
	b.ne	.LBB11_54
	ldp	x22, x19, [sp, #48]
	mov	x26, xzr
	ldp	x20, x27, [sp, #32]
	ldr	x24, [sp, #112]
	ldp	x29, x28, [sp, #120]
.LBB11_49:
	add	x8, sp, #1, lsl #12
	add	x9, sp, #1, lsl #12
	str	x29, [sp, #5744]
	str	x28, [sp, #5752]
	add	x8, x8, #1648
	add	x9, x9, #2768
	str	x23, [sp, #5760]
	mov	w1, wzr
	str	x21, [sp, #5768]
	str	x19, [sp, #6864]
	ldr	x8, [x8, x26, lsl #3]
	str	x22, [sp, #6872]
	str	x27, [sp, #6880]
	add	x0, x8, #1, lsl #12
	str	x20, [sp, #6888]
	ldr	x9, [x9, x26, lsl #3]
	add	x26, x26, #1
	sub	x9, x9, x8
	sub	x2, x9, #1, lsl #12
	bl	memset
	cmp	x24, x26
	b.ne	.LBB11_49
	ldr	x9, [sp, #64]
	mov	w8, #1
	lsl	x8, x8, x9
.LBB11_51:
	ldaxr	x9, [x25]
	bic	x9, x9, x8
	stlxr	w10, x9, [x25]
	cbnz	w10, .LBB11_51
	ldr	x0, [sp, #16]
	add	x1, sp, #176
	mov	w2, #736
	bl	memcpy
.LBB11_53:
	add	sp, sp, #1, lsl #12
	.cfi_def_cfa_offset 3968
	add	sp, sp, #3872
	.cfi_def_cfa_offset 96
	ldp	x20, x19, [sp, #80]
	ldp	x22, x21, [sp, #64]
	ldp	x24, x23, [sp, #48]
	ldp	x26, x25, [sp, #32]
	ldp	x28, x27, [sp, #16]
	ldp	x29, x30, [sp], #96
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB11_54:
	.cfi_restore_state
	bl	arm_exception_fail
.Lfunc_end11:
	.size	_RNvNtCsel89eI7eLYd_8hematite7preempt9run_local, .Lfunc_end11-_RNvNtCsel89eI7eLYd_8hematite7preempt9run_local
	.cfi_endproc

	.section	.text._RNvNtCsel89eI7eLYd_8hematite7threads11probe_yield,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsel89eI7eLYd_8hematite7threads11probe_yield,@function
_RNvNtCsel89eI7eLYd_8hematite7threads11probe_yield:
.Lfunc_begin12:
	.cfi_startproc
	ldp	x0, x8, [x0]
	ldr	x1, [x8, #40]
	br	x1
.Lfunc_end12:
	.size	_RNvNtCsel89eI7eLYd_8hematite7threads11probe_yield, .Lfunc_end12-_RNvNtCsel89eI7eLYd_8hematite7threads11probe_yield
	.cfi_endproc

	.section	.text._RNvNtCsel89eI7eLYd_8hematite7threads14callback_entry,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsel89eI7eLYd_8hematite7threads14callback_entry,@function
_RNvNtCsel89eI7eLYd_8hematite7threads14callback_entry:
.Lfunc_begin13:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x1, x30, [sp, #8]
	.cfi_offset w30, -16
	mov	w8, #304
	str	x0, [sp]
	madd	x8, x1, x8, x0
	adrp	x1, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.13
	add	x1, x1, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.13
	mov	x0, sp
	ldp	x9, x2, [x8, #280]
	blr	x9
	ldr	x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	ret
.Lfunc_end13:
	.size	_RNvNtCsel89eI7eLYd_8hematite7threads14callback_entry, .Lfunc_end13-_RNvNtCsel89eI7eLYd_8hematite7threads14callback_entry
	.cfi_endproc

	.section	.text._RNvNtCsel89eI7eLYd_8hematite9secondary4fail,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsel89eI7eLYd_8hematite9secondary4fail,@function
_RNvNtCsel89eI7eLYd_8hematite9secondary4fail:
.Lfunc_begin14:
	.cfi_startproc
	str	x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -16
	bl	arm_secondary_failure
.Lfunc_end14:
	.size	_RNvNtCsel89eI7eLYd_8hematite9secondary4fail, .Lfunc_end14-_RNvNtCsel89eI7eLYd_8hematite9secondary4fail
	.cfi_endproc

	.section	.text._RNvNtCsel89eI7eLYd_8hematite9secondary7adapter,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsel89eI7eLYd_8hematite9secondary7adapter,@function
_RNvNtCsel89eI7eLYd_8hematite9secondary7adapter:
.Lfunc_begin15:
	.cfi_startproc
	str	x29, [sp, #-64]!
	.cfi_def_cfa_offset 64
	stp	x30, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w30, -48
	.cfi_offset w29, -64
	sub	sp, sp, #1088
	.cfi_def_cfa_offset 1152
	.cfi_remember_state
	adrp	x19, _RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX
	add	x19, x19, :lo12:_RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX
	ldr	xzr, [sp]
	ldar	x8, [x19]
	cmp	x8, #1
	b.ne	.LBB15_21
	adrp	x8, _RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX+8
	add	x8, x8, :lo12:_RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX+8
	ldar	x8, [x8]
	cmp	x8, x0
	b.ne	.LBB15_21
	adrp	x1, _RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX+792
	add	x1, x1, :lo12:_RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX+792
	mov	x0, sp
	mov	w2, #152
	bl	memcpy
	ldr	x8, [sp, #128]
	cmp	x8, #1
	b.hi	.LBB15_21
	ldr	x9, [sp, #136]
	cmp	x9, #4
	b.hi	.LBB15_21
	ldr	x9, [sp, #144]
	cmp	x9, #5
	b.hs	.LBB15_21
	mov	w9, #2
	stlr	x9, [x19]
	ldar	x9, [x19]
	cmp	x9, #3
	b.eq	.LBB15_8
.LBB15_6:
	cmp	x9, #2
	b.ne	.LBB15_21
	isb
	ldar	x9, [x19]
	cmp	x9, #3
	b.ne	.LBB15_6
.LBB15_8:
	cmp	x8, #1
	b.ne	.LBB15_11
	ldr	x2, [sp, #144]
	cmp	x2, #5
	b.hs	.LBB15_21
	mov	x8, sp
	add	x0, sp, #152
	mov	w3, #1
	add	x1, x8, #64
	bl	_RNvNtCsel89eI7eLYd_8hematite9secondary9local_run
	ldr	x21, [sp, #872]
	ldrb	w20, [sp, #880]
	ldr	x19, [sp, #888]
	b	.LBB15_12
.LBB15_11:
	movi	v0.2d, #0000000000000000
	add	x8, sp, #152
	mov	w1, wzr
	add	x0, x8, #208
	mov	w2, #512
	stp	q0, q0, [sp, #992]
	bl	memset
	movi	v0.2d, #0000000000000000
	add	x0, sp, #152
	add	x1, sp, #896
	mov	w2, #192
	str	q0, [sp, #1024]
	str	q0, [sp, #1040]
	str	q0, [sp, #1056]
	str	q0, [sp, #1072]
	stp	q0, q0, [sp, #896]
	stp	q0, q0, [sp, #928]
	stp	q0, q0, [sp, #960]
	bl	memcpy
	mov	x19, xzr
	mov	w20, wzr
	mov	x21, xzr
	stp	xzr, xzr, [sp, #344]
.LBB15_12:
	mov	x3, #1099511627775
	//APP
	mrs	x10, MPIDR_EL1
	mrs	x9, TTBR0_EL1
	mov	x8, sp
	mrs	x2, SP_EL0
	mrs	x0, S3_0_C4_C2_3
	mrs	x18, DAIF
	mrs	x12, SCTLR_EL1
	mrs	x11, TCR_EL1
	mrs	x13, MAIR_EL1
	mrs	x17, CurrentEL
	mrs	x15, CPACR_EL1
	mrs	x14, CNTP_CTL_EL0
	//NO_APP
	adrp	x16, arm_cpu_records
	add	x16, x16, :lo12:arm_cpu_records
	movk	x3, #255, lsl #16
	//APP
	mrs	x1, DAIF
	msr	DAIFSet, #2
	isb
	mrs	x4, TPIDR_EL1
	mrs	x5, MPIDR_EL1
	//NO_APP
	and	x10, x10, x3
	add	x6, x16, #128
	and	x3, x5, x3
	cmp	x10, #1
	cset	w16, eq
	cmp	x4, x6
	ccmp	x3, #1, #0, eq
	b.eq	.LBB15_14
	//APP
	msr	DAIF, x1
	isb
	//NO_APP
	b	.LBB15_15
.LBB15_14:
	adrp	x3, arm_cpu_records+224
	add	x3, x3, :lo12:arm_cpu_records+224
	ldr	x3, [x3]
	//APP
	msr	DAIF, x1
	isb
	//NO_APP
	orr	x1, x16, #0x2
	cmp	x3, #1
	csel	x16, x1, x16, eq
.LBB15_15:
	adrp	x1, arm_secondary_root
	add	x1, x1, :lo12:arm_secondary_root
	orr	x4, x16, #0x4
	cmp	x9, x1
	adrp	x1, __secondary_stack_guard
	add	x1, x1, :lo12:__secondary_stack_guard
	adrp	x5, __secondary_stack_top
	add	x5, x5, :lo12:__secondary_stack_top
	//APP
	at	s1e1r, x8
	isb
	mrs	x3, PAR_EL1
	//NO_APP
	csel	x16, x4, x16, eq
	add	x4, x1, #1, lsl #12
	cmp	x8, x5
	ccmp	x8, x4, #0, lo
	b.lo	.LBB15_18
	tst	x3, #0x1
	adrp	x5, __secondary_exception_stack_top
	add	x5, x5, :lo12:__secondary_exception_stack_top
	and	x4, x8, #0xf
	ccmp	x2, x5, #0, eq
	ccmp	x4, #0, #0, eq
	b.ne	.LBB15_18
	and	x2, x3, #0xfffffffff000
	and	x3, x8, #0xfffffffffffff000
	orr	x4, x16, #0x8
	cmp	x2, x3
	csel	x16, x4, x16, eq
.LBB15_18:
	mov	w3, #4109
	mvn	w2, w12
	and	x0, x0, #0x400000
	movk	w3, #8, lsl #16
	tst	x2, x3
	ccmp	x0, #0, #4, eq
	mov	w0, #960
	ccmp	x18, x0, #0, ne
	ccmp	x17, #4, #0, eq
	b.ne	.LBB15_20
	mvn	w15, w15
	and	x14, x14, #0x3
	and	x12, x12, #0x800000
	and	x15, x15, #0x300000
	cmp	x14, #2
	mov	w14, #255
	ccmp	x15, #0, #0, eq
	ccmp	x13, x14, #0, eq
	mov	w13, #13593
	movk	w13, #32921, lsl #16
	ccmp	x11, x13, #0, eq
	orr	x11, x16, #0x10
	ccmp	x12, #0, #0, eq
	csel	x16, x11, x16, eq
.LBB15_20:
	//APP
	at	s1e1r, x1
	isb
	mrs	x11, PAR_EL1
	//NO_APP
	mov	w12, #-2147483648
	mov	w14, #192
	//APP
	at	s1e1r, x12
	isb
	mrs	x13, PAR_EL1
	//NO_APP
	and	x11, x11, #0x7f
	orr	x12, x16, #0x20
	cmp	x11, #15
	and	x13, x13, #0x7f
	mov	w11, #128
	csel	x12, x12, x16, eq
	cmp	x13, #11
	adrp	x22, _RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX+16
	add	x22, x22, :lo12:_RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX+16
	add	x1, sp, #152
	mov	w2, #720
	stp	x10, x9, [x22]
	csel	x10, x14, x11, eq
	add	x0, x22, #32
	orr	x9, x10, x12
	add	x23, sp, #152
	stp	x8, x9, [x22, #16]
	bl	memcpy
	add	x0, x22, #761
	add	x1, x23, #729
	mov	w2, #7
	str	x21, [x22, #752]
	strb	w20, [x22, #760]
	bl	memcpy
	str	x19, [x22, #768]
	add	sp, sp, #1088
	.cfi_def_cfa_offset 64
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x30, x23, [sp, #16]
	ldr	x29, [sp], #64
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB15_21:
	.cfi_restore_state
	bl	_RNvNtCsel89eI7eLYd_8hematite9secondary4fail
.Lfunc_end15:
	.size	_RNvNtCsel89eI7eLYd_8hematite9secondary7adapter, .Lfunc_end15-_RNvNtCsel89eI7eLYd_8hematite9secondary7adapter
	.cfi_endproc

	.section	.text._RNvNtCsel89eI7eLYd_8hematite9secondary9local_run,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsel89eI7eLYd_8hematite9secondary9local_run,@function
_RNvNtCsel89eI7eLYd_8hematite9secondary9local_run:
.Lfunc_begin16:
	.cfi_startproc
	stp	x29, x30, [sp, #-96]!
	.cfi_def_cfa_offset 96
	stp	x28, x27, [sp, #16]
	stp	x26, x25, [sp, #32]
	stp	x24, x23, [sp, #48]
	stp	x22, x21, [sp, #64]
	stp	x20, x19, [sp, #80]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	sub	sp, sp, #1440
	.cfi_def_cfa_offset 1536
	.cfi_remember_state
	mov	x27, #1099511627775
	ldr	xzr, [sp]
	//APP
	mrs	x8, DAIF
	msr	DAIFSet, #2
	isb
	mrs	x9, TPIDR_EL1
	mrs	x10, MPIDR_EL1
	//NO_APP
	movk	x27, #255, lsl #16
	mov	x20, x3
	mov	x19, x0
	and	x10, x10, x27
	adrp	x26, arm_cpu_records
	add	x26, x26, :lo12:arm_cpu_records
	cmp	x10, #1
	b.hi	.LBB16_4
	add	x11, x26, x10, lsl #7
	cmp	x9, x11
	b.ne	.LBB16_4
	ldr	x11, [x9, #96]
	cmp	x11, x10
	b.ne	.LBB16_4
	ldr	x25, [x9, #72]
	b	.LBB16_5
.LBB16_4:
	mov	x25, xzr
.LBB16_5:
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	add	x0, sp, #704
	mov	x3, x20
	add	x28, sp, #704
	bl	_RNvNtCsel89eI7eLYd_8hematite7preempt9run_local
	ldrb	w8, [sp, #1432]
	cmp	w8, #2
	b.eq	.LBB16_31
	add	x0, sp, #640
	add	x1, sp, #704
	mov	w2, #64
	bl	memcpy
	ldr	x21, [sp, #768]
	ldr	x22, [sp, #776]
	mov	x0, sp
	ldr	x23, [sp, #784]
	ldr	x24, [sp, #792]
	add	x1, x28, #96
	mov	w2, #640
	bl	memcpy
	//APP
	mrs	x9, DAIF
	msr	DAIFSet, #2
	isb
	mrs	x10, TPIDR_EL1
	mrs	x8, MPIDR_EL1
	//NO_APP
	and	x8, x8, x27
	cmp	x8, #1
	b.hi	.LBB16_30
	add	x11, x26, x8, lsl #7
	cmp	x10, x11
	b.ne	.LBB16_30
	ldr	x10, [x10, #96]
	//APP
	msr	DAIF, x9
	isb
	//NO_APP
	cmp	x8, x20
	b.ne	.LBB16_31
	cmp	x10, x8
	b.ne	.LBB16_31
	adrp	x10, __exception_stack_top
	add	x10, x10, :lo12:__exception_stack_top
	adrp	x11, __secondary_exception_stack_top
	add	x11, x11, :lo12:__secondary_exception_stack_top
	tst	w20, #0x1
	//APP
	mrs	x12, DAIF
	mrs	x9, SP_EL0
	mrs	x8, CNTP_CTL_EL0
	//NO_APP
	csel	x10, x11, x10, ne
	cmp	x12, #960
	b.ne	.LBB16_31
	cmp	x9, x10
	b.ne	.LBB16_31
	and	x8, x8, #0x3
	cmp	x8, #2
	b.ne	.LBB16_31
	mov	w8, #134217728
	ldr	w8, [x8]
	cmp	w8, #1
	b.ne	.LBB16_31
	mov	w8, #134283264
	ldr	w8, [x8]
	cbnz	w8, .LBB16_31
	mov	w8, #256
	movk	w8, #2048, lsl #16
	ldr	w9, [x8]
	tbnz	w9, #30, .LBB16_31
	ldr	w9, [x8, #256]
	tbnz	w9, #30, .LBB16_31
	ldr	w8, [x8, #512]
	tbnz	w8, #30, .LBB16_31
	//APP
	mrs	x8, DAIF
	msr	DAIFSet, #2
	isb
	mrs	x9, TPIDR_EL1
	mrs	x10, MPIDR_EL1
	//NO_APP
	and	x10, x10, x27
	cmp	x10, #1
	b.ls	.LBB16_20
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	negs	x20, x25
	b.hs	.LBB16_25
	b	.LBB16_31
.LBB16_20:
	add	x11, x26, x10, lsl #7
	cmp	x9, x11
	b.ne	.LBB16_23
	ldr	x11, [x9, #96]
	cmp	x11, x10
	b.ne	.LBB16_24
	ldr	x9, [x9, #72]
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	subs	x20, x9, x25
	b.hs	.LBB16_25
	b	.LBB16_31
.LBB16_23:
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	negs	x20, x25
	b.hs	.LBB16_25
	b	.LBB16_31
.LBB16_24:
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	negs	x20, x25
	b.lo	.LBB16_31
.LBB16_25:
	adds	x8, x22, x21
	b.hs	.LBB16_31
	adds	x8, x23, x8
	b.hs	.LBB16_31
	add	x9, x24, x8
	cmp	x9, x8
	b.lo	.LBB16_31
	cmp	x9, x20
	b.ne	.LBB16_31
	add	x1, sp, #640
	mov	x0, x19
	mov	w2, #64
	bl	memcpy
	add	x0, x19, #96
	mov	x1, sp
	mov	w2, #640
	stp	x21, x22, [x19, #64]
	stp	x23, x24, [x19, #80]
	bl	memcpy
	str	x20, [x19, #736]
	add	sp, sp, #1440
	.cfi_def_cfa_offset 96
	ldp	x20, x19, [sp, #80]
	ldp	x22, x21, [sp, #64]
	ldp	x24, x23, [sp, #48]
	ldp	x26, x25, [sp, #32]
	ldp	x28, x27, [sp, #16]
	ldp	x29, x30, [sp], #96
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB16_30:
	.cfi_restore_state
	//APP
	msr	DAIF, x9
	isb
	//NO_APP
.LBB16_31:
	bl	_RNvNtCsel89eI7eLYd_8hematite9secondary4fail
.Lfunc_end16:
	.size	_RNvNtCsel89eI7eLYd_8hematite9secondary9local_run, .Lfunc_end16-_RNvNtCsel89eI7eLYd_8hematite9secondary9local_run
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI17_0:
	.xword	131110
	.xword	1
	.section	.text._RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer11coordinator,"ax",@progbits
	.p2align	2
	.type	_RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer11coordinator,@function
_RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer11coordinator:
.Lfunc_begin17:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	str	x30, [sp, #48]
	stp	x20, x19, [sp, #64]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -32
	.cfi_remember_state
	mov	x3, x2
	ldp	x19, x2, [x1, #24]
	mov	x20, x0
	mov	x1, x19
	bl	_RNvNtCsel89eI7eLYd_8hematite10smp_checks6record
	cbz	w0, .LBB17_11
	mov	x0, x20
	blr	x19
	adrp	x19, .L_MergedGlobals+8
	add	x19, x19, :lo12:.L_MergedGlobals+8
	cbz	x0, .LBB17_6
	ldar	x8, [x19]
	mov	w0, #1
	cmp	x8, #2
	b.eq	.LBB17_4
.LBB17_3:
	isb
	ldar	x8, [x19]
	cmp	x8, #2
	b.ne	.LBB17_3
.LBB17_4:
	ldp	x20, x19, [sp, #64]
	ldr	x30, [sp, #48]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	ret
.LBB17_5:
	.cfi_restore_state
	.cfi_remember_state
	isb
.LBB17_6:
	ldar	x8, [x19]
	cbz	x8, .LBB17_5
	adrp	x8, .L_MergedGlobals+56
	add	x8, x8, :lo12:.L_MergedGlobals+56
	add	x9, sp, #8
	ldar	x8, [x8]
	stp	x8, x9, [sp, #8]
	adrp	x8, _RNvXsd_NtNtNtCsboyoyqK6YBz_4core3fmt3num3impyNtB9_7Display3fmt
	add	x8, x8, :lo12:_RNvXsd_NtNtNtCsboyoyqK6YBz_4core3fmt3num3impyNtB9_7Display3fmt
	str	x8, [sp, #24]
	//APP
	mrs	x8, DAIF
	msr	DAIFSet, #2
	isb
	mrs	x10, TPIDR_EL1
	mrs	x9, MPIDR_EL1
	//NO_APP
	and	x9, x9, #0xffffffffff
	and	x9, x9, #0xffffffff00ffffff
	cmp	x9, #1
	b.hi	.LBB17_12
	adrp	x11, arm_cpu_records
	add	x11, x11, :lo12:arm_cpu_records
	add	x11, x11, x9, lsl #7
	cmp	x10, x11
	b.ne	.LBB17_12
	ldr	x10, [x10, #96]
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
	orr	x8, x10, x9
	cbnz	x8, .LBB17_13
	adrp	x1, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.8
	add	x1, x1, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.8
	add	x0, sp, #63
	add	x2, sp, #16
	bl	_RNvNtCsboyoyqK6YBz_4core3fmt5write
	ldar	x8, [x19]
	mov	w0, #1
	cmp	x8, #2
	b.ne	.LBB17_3
	b	.LBB17_4
.LBB17_11:
	mov	x0, xzr
	ldp	x20, x19, [sp, #64]
	ldr	x30, [sp, #48]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	ret
.LBB17_12:
	.cfi_restore_state
	//APP
	msr	DAIF, x8
	isb
	//NO_APP
.LBB17_13:
	adrp	x8, .LCPI17_0
	add	x1, sp, #32
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI17_0]
	str	q0, [sp, #32]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB17_14:
	//APP
	wfi
	//NO_APP
	b	.LBB17_14
.Lfunc_end17:
	.size	_RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer11coordinator, .Lfunc_end17-_RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer11coordinator
	.cfi_endproc

	.section	.text._RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer4peer,"ax",@progbits
	.p2align	2
	.type	_RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer4peer,@function
_RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer4peer:
.Lfunc_begin18:
	.cfi_startproc
	str	x30, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -32
	.cfi_remember_state
	mov	x3, x2
	ldp	x19, x2, [x1, #24]
	mov	x20, x0
	mov	x1, x19
	bl	_RNvNtCsel89eI7eLYd_8hematite10smp_checks6record
	cbz	w0, .LBB18_4
	mov	x0, x20
	blr	x19
	cbz	x0, .LBB18_5
	adrp	x8, .L_MergedGlobals+8
	add	x8, x8, :lo12:.L_MergedGlobals+8
	mov	w9, #2
	stlr	x9, [x8]
	mov	w0, #1
.LBB18_3:
	ldp	x20, x19, [sp, #16]
	ldr	x30, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	ret
.LBB18_4:
	.cfi_restore_state
	.cfi_remember_state
	mov	x0, xzr
	ldp	x20, x19, [sp, #16]
	ldr	x30, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	ret
.LBB18_5:
	.cfi_restore_state
	mov	w0, #1
	adrp	x8, .L_MergedGlobals+8
	add	x8, x8, :lo12:.L_MergedGlobals+8
	stlr	x0, [x8]
	ldar	x9, [x8]
	cmp	x9, #2
	b.eq	.LBB18_3
	mov	w0, #1
.LBB18_7:
	isb
	ldar	x9, [x8]
	cmp	x9, #2
	b.ne	.LBB18_7
	b	.LBB18_3
.Lfunc_end18:
	.size	_RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer4peer, .Lfunc_end18-_RNvNvNtCsel89eI7eLYd_8hematite10smp_checks13no_peer_timer4peer
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI19_0:
	.xword	131110
	.xword	1
	.section	.text._RNvXNtCsel89eI7eLYd_8hematite4archNtB2_12BootPlatformNtCsjStpv0Kdcdo_9hm_kernel8Platform5write,"ax",@progbits
	.p2align	2
	.type	_RNvXNtCsel89eI7eLYd_8hematite4archNtB2_12BootPlatformNtCsjStpv0Kdcdo_9hm_kernel8Platform5write,@function
_RNvXNtCsel89eI7eLYd_8hematite4archNtB2_12BootPlatformNtCsjStpv0Kdcdo_9hm_kernel8Platform5write:
.Lfunc_begin19:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	.cfi_remember_state
	mov	w8, #24
	add	x9, x0, x1
	mov	w10, #150994944
	movk	w8, #2304, lsl #16
	mov	w11, #13
.LBB19_1:
	ldrb	w12, [x0], #1
	mov	w13, #34464
	mov	w14, #34464
	movk	w13, #1, lsl #16
	cmp	w12, #10
	movk	w14, #1, lsl #16
	b.ne	.LBB19_4
.LBB19_2:
	ldr	w12, [x8]
	tbz	w12, #5, .LBB19_6
	isb
	subs	w14, w14, #1
	b.ne	.LBB19_2
	b	.LBB19_12
.LBB19_4:
	ldr	w14, [x8]
	tbz	w14, #5, .LBB19_10
	isb
	subs	w13, w13, #1
	b.ne	.LBB19_4
	b	.LBB19_14
.LBB19_6:
	mov	w12, #34464
	str	w11, [x10]
	movk	w12, #1, lsl #16
.LBB19_7:
	ldr	w13, [x8]
	tbz	w13, #5, .LBB19_9
	isb
	subs	w12, w12, #1
	b.ne	.LBB19_7
	b	.LBB19_16
.LBB19_9:
	mov	w12, #10
.LBB19_10:
	cmp	x0, x9
	str	w12, [x10]
	b.ne	.LBB19_1
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.LBB19_12:
	.cfi_restore_state
	adrp	x8, .LCPI19_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI19_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB19_13:
	//APP
	wfi
	//NO_APP
	b	.LBB19_13
.LBB19_14:
	adrp	x8, .LCPI19_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI19_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB19_15:
	//APP
	wfi
	//NO_APP
	b	.LBB19_15
.LBB19_16:
	adrp	x8, .LCPI19_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI19_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB19_17:
	//APP
	wfi
	//NO_APP
	b	.LBB19_17
.Lfunc_end19:
	.size	_RNvXNtCsel89eI7eLYd_8hematite4archNtB2_12BootPlatformNtCsjStpv0Kdcdo_9hm_kernel8Platform5write, .Lfunc_end19-_RNvXNtCsel89eI7eLYd_8hematite4archNtB2_12BootPlatformNtCsjStpv0Kdcdo_9hm_kernel8Platform5write
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI20_0:
	.xword	131110
	.xword	1
	.section	.text._RNvXNvNtCsel89eI7eLYd_8hematite4arch10smp_markerNtB2_6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write9write_str,"ax",@progbits
	.p2align	2
	.type	_RNvXNvNtCsel89eI7eLYd_8hematite4arch10smp_markerNtB2_6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write9write_str,@function
_RNvXNvNtCsel89eI7eLYd_8hematite4arch10smp_markerNtB2_6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write9write_str:
.Lfunc_begin20:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	.cfi_remember_state
	cbz	x2, .LBB20_12
	mov	w9, #24
	add	x8, x1, x2
	mov	w10, #150994944
	movk	w9, #2304, lsl #16
	mov	w11, #13
.LBB20_2:
	ldrb	w12, [x1], #1
	mov	w13, #34464
	mov	w14, #34464
	movk	w13, #1, lsl #16
	cmp	w12, #10
	movk	w14, #1, lsl #16
	b.ne	.LBB20_5
.LBB20_3:
	ldr	w12, [x9]
	tbz	w12, #5, .LBB20_7
	isb
	subs	w14, w14, #1
	b.ne	.LBB20_3
	b	.LBB20_13
.LBB20_5:
	ldr	w14, [x9]
	tbz	w14, #5, .LBB20_11
	isb
	subs	w13, w13, #1
	b.ne	.LBB20_5
	b	.LBB20_15
.LBB20_7:
	mov	w12, #34464
	str	w11, [x10]
	movk	w12, #1, lsl #16
.LBB20_8:
	ldr	w13, [x9]
	tbz	w13, #5, .LBB20_10
	isb
	subs	w12, w12, #1
	b.ne	.LBB20_8
	b	.LBB20_17
.LBB20_10:
	mov	w12, #10
.LBB20_11:
	cmp	x1, x8
	str	w12, [x10]
	b.ne	.LBB20_2
.LBB20_12:
	mov	w0, wzr
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.LBB20_13:
	.cfi_restore_state
	adrp	x8, .LCPI20_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI20_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB20_14:
	//APP
	wfi
	//NO_APP
	b	.LBB20_14
.LBB20_15:
	adrp	x8, .LCPI20_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI20_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB20_16:
	//APP
	wfi
	//NO_APP
	b	.LBB20_16
.LBB20_17:
	adrp	x8, .LCPI20_0
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI20_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB20_18:
	//APP
	wfi
	//NO_APP
	b	.LBB20_18
.Lfunc_end20:
	.size	_RNvXNvNtCsel89eI7eLYd_8hematite4arch10smp_markerNtB2_6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write9write_str, .Lfunc_end20-_RNvXNvNtCsel89eI7eLYd_8hematite4arch10smp_markerNtB2_6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write9write_str
	.cfi_endproc

	.section	.text._RNvXs0_NtCsel89eI7eLYd_8hematite7threadsNtB5_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext2id,"ax",@progbits
	.p2align	2
	.type	_RNvXs0_NtCsel89eI7eLYd_8hematite7threadsNtB5_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext2id,@function
_RNvXs0_NtCsel89eI7eLYd_8hematite7threadsNtB5_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext2id:
.Lfunc_begin21:
	.cfi_startproc
	ldr	x0, [x0, #8]
	ret
.Lfunc_end21:
	.size	_RNvXs0_NtCsel89eI7eLYd_8hematite7threadsNtB5_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext2id, .Lfunc_end21-_RNvXs0_NtCsel89eI7eLYd_8hematite7threadsNtB5_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext2id
	.cfi_endproc

	.section	.text._RNvXs0_NtCsel89eI7eLYd_8hematite7threadsNtB5_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext9yield_now,"ax",@progbits
	.p2align	2
	.type	_RNvXs0_NtCsel89eI7eLYd_8hematite7threadsNtB5_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext9yield_now,@function
_RNvXs0_NtCsel89eI7eLYd_8hematite7threadsNtB5_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext9yield_now:
.Lfunc_begin22:
	.cfi_startproc
	ldp	x10, x9, [x0]
	mov	w8, #304
	madd	x0, x9, x8, x10
	add	x1, x10, #1216
	ldr	x8, [x0, #272]
	adds	x8, x8, #1
	csinv	x8, x8, xzr, lo
	stp	xzr, x8, [x0, #264]
	b	arm_context_switch
.Lfunc_end22:
	.size	_RNvXs0_NtCsel89eI7eLYd_8hematite7threadsNtB5_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext9yield_now, .Lfunc_end22-_RNvXs0_NtCsel89eI7eLYd_8hematite7threadsNtB5_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext9yield_now
	.cfi_endproc

	.section	.text._RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext2id,"ax",@progbits
	.p2align	2
	.type	_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext2id,@function
_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext2id:
.Lfunc_begin23:
	.cfi_startproc
	ldr	x0, [x0, #16]
	ret
.Lfunc_end23:
	.size	_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext2id, .Lfunc_end23-_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext2id
	.cfi_endproc

	.section	.text._RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext4wait,"ax",@progbits
	.p2align	2
	.type	_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext4wait,@function
_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext4wait:
.Lfunc_begin24:
	.cfi_startproc
	str	x30, [sp, #-48]!
	.cfi_def_cfa_offset 48
	stp	x22, x21, [sp, #16]
	stp	x20, x19, [sp, #32]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -48
	.cfi_remember_state
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	bl	arm_preempt_wait_mask
	ldar	x9, [x20]
	ldr	x10, [x21]
	ldr	x8, [x21, #16]
	orr	x10, x8, x10
	cbnz	x10, .LBB24_6
	adrp	x10, _RNvNtCsel89eI7eLYd_8hematite7preempt9WAIT_RACE
	add	x10, x10, :lo12:_RNvNtCsel89eI7eLYd_8hematite7preempt9WAIT_RACE
	mov	w11, #2
.LBB24_2:
	ldaxr	x12, [x10]
	cmp	x12, #1
	b.ne	.LBB24_16
	stlxr	w12, x11, [x10]
	cbz	w12, .LBB24_5
	b	.LBB24_2
.LBB24_4:
	isb
.LBB24_5:
	ldar	x11, [x10]
	cmp	x11, #3
	b.ne	.LBB24_4
.LBB24_6:
	cmp	x9, x19
	b.ne	.LBB24_13
.LBB24_7:
	cmn	x19, #1
	b.eq	.LBB24_14
	mov	w10, #1136
	ldr	x9, [x21, #8]
	madd	x21, x8, x10, x9
	ldr	x8, [x21, #264]
	cmp	x8, #1
	b.ne	.LBB24_15
	ldr	x8, [x21, #1112]
	cbnz	x8, .LBB24_15
	ldr	x8, [x21, #1128]
	mov	x22, x0
	mov	w10, #3
	mov	x0, x21
	str	x20, [x21, #1112]
	adds	x8, x8, #1
	str	x19, [x21, #1120]
	csinv	x8, x8, xzr, lo
	str	x10, [x21, #280]
	str	x8, [x21, #1128]
	mov	w8, #4544
	add	x1, x9, x8
	str	x10, [x21, #264]
	bl	arm_preempt_park
	ldr	x8, [x21, #1112]
	cbnz	x8, .LBB24_15
	ldar	x8, [x20]
	cmp	x8, x19
	b.eq	.LBB24_15
	mov	x0, x22
.LBB24_13:
	mov	w8, #2
	//APP
	msr	DAIF, x0
	isb
	//NO_APP
	mov	w0, w8
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldr	x30, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	ret
.LBB24_14:
	.cfi_restore_state
	.cfi_remember_state
	mov	w8, #1
	//APP
	msr	DAIF, x0
	isb
	//NO_APP
	mov	w0, w8
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldr	x30, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	ret
.LBB24_15:
	.cfi_restore_state
	bl	arm_exception_fail
.LBB24_16:
	clrex
	cmp	x9, x19
	b.eq	.LBB24_7
	b	.LBB24_13
.Lfunc_end24:
	.size	_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext4wait, .Lfunc_end24-_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext4wait
	.cfi_endproc

	.section	.text._RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext6cpu_id,"ax",@progbits
	.p2align	2
	.type	_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext6cpu_id,@function
_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext6cpu_id:
.Lfunc_begin25:
	.cfi_startproc
	ldr	x0, [x0]
	ret
.Lfunc_end25:
	.size	_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext6cpu_id, .Lfunc_end25-_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext6cpu_id
	.cfi_endproc

	.section	.text._RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext9yield_now,"ax",@progbits
	.p2align	2
	.type	_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext9yield_now,@function
_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext9yield_now:
.Lfunc_begin26:
	.cfi_startproc
	ldp	x10, x8, [x0, #8]
	mov	w9, #1136
	madd	x0, x8, x9, x10
	mov	w8, #4544
	add	x1, x10, x8
	b	arm_preempt_yield
.Lfunc_end26:
	.size	_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext9yield_now, .Lfunc_end26-_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext9yield_now
	.cfi_endproc

	.section	.text._RNvYNtNtCsel89eI7eLYd_8hematite7threads5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext4waitB6_,"ax",@progbits
	.p2align	2
	.type	_RNvYNtNtCsel89eI7eLYd_8hematite7threads5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext4waitB6_,@function
_RNvYNtNtCsel89eI7eLYd_8hematite7threads5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext4waitB6_:
.Lfunc_begin27:
	.cfi_startproc
	mov	w0, wzr
	ret
.Lfunc_end27:
	.size	_RNvYNtNtCsel89eI7eLYd_8hematite7threads5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext4waitB6_, .Lfunc_end27-_RNvYNtNtCsel89eI7eLYd_8hematite7threads5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext4waitB6_
	.cfi_endproc

	.section	.text._RNvYNtNtCsel89eI7eLYd_8hematite7threads5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext6cpu_idB6_,"ax",@progbits
	.p2align	2
	.type	_RNvYNtNtCsel89eI7eLYd_8hematite7threads5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext6cpu_idB6_,@function
_RNvYNtNtCsel89eI7eLYd_8hematite7threads5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext6cpu_idB6_:
.Lfunc_begin28:
	.cfi_startproc
	mov	x0, xzr
	ret
.Lfunc_end28:
	.size	_RNvYNtNtCsel89eI7eLYd_8hematite7threads5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext6cpu_idB6_, .Lfunc_end28-_RNvYNtNtCsel89eI7eLYd_8hematite7threads5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext6cpu_idB6_
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI29_0:
	.xword	131110
	.xword	1
	.section	.text._RNvYNtNvNtCsel89eI7eLYd_8hematite4arch10smp_marker6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write10write_charB8_,"ax",@progbits
	.p2align	2
	.type	_RNvYNtNvNtCsel89eI7eLYd_8hematite4arch10smp_marker6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write10write_charB8_,@function
_RNvYNtNvNtCsel89eI7eLYd_8hematite4arch10smp_marker6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write10write_charB8_:
.Lfunc_begin29:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	.cfi_remember_state
	cmp	w1, #128
	add	x8, sp, #12
	str	wzr, [sp, #12]
	b.hs	.LBB29_2
	orr	x8, x8, #0x1
	strb	w1, [sp, #12]
	b	.LBB29_8
.LBB29_2:
	mov	w9, #-128
	cmp	w1, #2048
	mov	w11, #-128
	bfxil	w9, w1, #0, #6
	b.hs	.LBB29_4
	lsr	w10, w1, #6
	orr	x8, x8, #0x2
	strb	w9, [sp, #13]
	orr	w10, w10, #0xc0
	b	.LBB29_7
.LBB29_4:
	mov	w10, #-128
	lsr	w12, w1, #16
	bfxil	w10, w1, #6, #6
	cbnz	w12, .LBB29_6
	lsr	w11, w1, #12
	strb	w10, [sp, #13]
	orr	x8, x8, #0x3
	strb	w9, [sp, #14]
	orr	w10, w11, #0xe0
	b	.LBB29_7
.LBB29_6:
	lsr	w12, w1, #18
	bfxil	w11, w1, #12, #6
	strb	w10, [sp, #14]
	add	x8, x8, #4
	strb	w9, [sp, #15]
	orr	w10, w12, #0xfffffff0
	strb	w11, [sp, #13]
.LBB29_7:
	strb	w10, [sp, #12]
.LBB29_8:
	mov	w9, #24
	add	x10, sp, #12
	mov	w11, #150994944
	movk	w9, #2304, lsl #16
	mov	w12, #13
.LBB29_9:
	ldrb	w13, [x10], #1
	mov	w14, #34464
	mov	w15, #34464
	movk	w14, #1, lsl #16
	cmp	w13, #10
	movk	w15, #1, lsl #16
	b.ne	.LBB29_12
.LBB29_10:
	ldr	w13, [x9]
	tbz	w13, #5, .LBB29_14
	isb
	subs	w15, w15, #1
	b.ne	.LBB29_10
	b	.LBB29_20
.LBB29_12:
	ldr	w15, [x9]
	tbz	w15, #5, .LBB29_18
	isb
	subs	w14, w14, #1
	b.ne	.LBB29_12
	b	.LBB29_22
.LBB29_14:
	mov	w13, #34464
	str	w12, [x11]
	movk	w13, #1, lsl #16
.LBB29_15:
	ldr	w14, [x9]
	tbz	w14, #5, .LBB29_17
	isb
	subs	w13, w13, #1
	b.ne	.LBB29_15
	b	.LBB29_24
.LBB29_17:
	mov	w13, #10
.LBB29_18:
	cmp	x10, x8
	str	w13, [x11]
	b.ne	.LBB29_9
	mov	w0, wzr
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.LBB29_20:
	.cfi_restore_state
	adrp	x8, .LCPI29_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI29_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB29_21:
	//APP
	wfi
	//NO_APP
	b	.LBB29_21
.LBB29_22:
	adrp	x8, .LCPI29_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI29_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB29_23:
	//APP
	wfi
	//NO_APP
	b	.LBB29_23
.LBB29_24:
	adrp	x8, .LCPI29_0
	add	x1, sp, #16
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI29_0]
	str	q0, [sp, #16]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB29_25:
	//APP
	wfi
	//NO_APP
	b	.LBB29_25
.Lfunc_end29:
	.size	_RNvYNtNvNtCsel89eI7eLYd_8hematite4arch10smp_marker6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write10write_charB8_, .Lfunc_end29-_RNvYNtNvNtCsel89eI7eLYd_8hematite4arch10smp_marker6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write10write_charB8_
	.cfi_endproc

	.section	.text._RNvYNtNvNtCsel89eI7eLYd_8hematite4arch10smp_marker6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write9write_fmtB8_,"ax",@progbits
	.p2align	2
	.type	_RNvYNtNvNtCsel89eI7eLYd_8hematite4arch10smp_marker6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write9write_fmtB8_,@function
_RNvYNtNvNtCsel89eI7eLYd_8hematite4arch10smp_marker6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write9write_fmtB8_:
.Lfunc_begin30:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	b	_RNvNtCsboyoyqK6YBz_4core3fmt5write
.Lfunc_end30:
	.size	_RNvYNtNvNtCsel89eI7eLYd_8hematite4arch10smp_marker6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write9write_fmtB8_, .Lfunc_end30-_RNvYNtNvNtCsel89eI7eLYd_8hematite4arch10smp_marker6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write9write_fmtB8_
	.cfi_endproc

	.section	.text.unlikely._RNvNtCsboyoyqK6YBz_4core9panicking9panic_fmt,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsboyoyqK6YBz_4core9panicking9panic_fmt,@function
_RNvNtCsboyoyqK6YBz_4core9panicking9panic_fmt:
.Lfunc_begin31:
	.file	1 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/panicking.rs"
	.loc	1 60 0
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
.Ltmp105:
	.loc	1 80 14 prologue_end
	bl	_RNvCsdtSMxSA38aw_7___rustc17rust_begin_unwind
.Ltmp106:
.Lfunc_end31:
	.size	_RNvNtCsboyoyqK6YBz_4core9panicking9panic_fmt, .Lfunc_end31-_RNvNtCsboyoyqK6YBz_4core9panicking9panic_fmt
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI32_0:
	.xword	131110
	.xword	1
	.section	.text._RNvNtCsboyoyqK6YBz_4core3fmt5write,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsboyoyqK6YBz_4core3fmt5write,@function
_RNvNtCsboyoyqK6YBz_4core3fmt5write:
.Lfunc_begin32:
	.file	2 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/fmt/mod.rs"
	.loc	2 1631 0
	.cfi_startproc
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x29, x30, [sp, #32]
	str	x27, [sp, #48]
	stp	x26, x25, [sp, #64]
	stp	x24, x23, [sp, #80]
	stp	x22, x21, [sp, #96]
	stp	x20, x19, [sp, #112]
	add	x29, sp, #32
	.cfi_def_cfa w29, 96
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_remember_state
.Ltmp107:
	.loc	2 878 12 prologue_end
	tbnz	w2, #0, .LBB32_45
.Ltmp108:
	.file	3 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/ptr/mod.rs"
	.loc	3 1755 9
	ldrb	w8, [x1]
.Ltmp109:
	.loc	2 1653 12
	cbz	w8, .LBB32_57
.Ltmp110:
	.loc	2 0 12 is_stmt 0
	mov	w19, #24
	mov	w23, #32
	mov	x20, xzr
	movk	w19, #2304, lsl #16
	mov	w21, #150994944
	mov	w22, #13
	movk	w23, #24576, lsl #16
	adrp	x24, .Lanon.f00a327e9c5915a84331ee2e2076b7b8.7
	add	x24, x24, :lo12:.Lanon.f00a327e9c5915a84331ee2e2076b7b8.7
.LBB32_3:
.Ltmp111:
	.file	4 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/ptr/non_null.rs"
	.loc	4 627 28 is_stmt 1
	add	x25, x1, #1
.Ltmp112:
	.loc	2 1656 19
	tbnz	w8, #7, .LBB32_16
.Ltmp113:
	.loc	4 627 28
	add	x8, x25, w8, uxtw
.Ltmp114:
.LBB32_5:
	.loc	2 1665 20
	ldrb	w9, [x25], #1
	mov	w10, #34464
	mov	w11, #34464
	movk	w10, #1, lsl #16
	cmp	w9, #10
	movk	w11, #1, lsl #16
	b.ne	.LBB32_8
.LBB32_6:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB32_10
	isb
	subs	w11, w11, #1
	b.ne	.LBB32_6
	b	.LBB32_63
.LBB32_8:
	ldr	w11, [x19]
	tbz	w11, #5, .LBB32_14
	isb
	subs	w10, w10, #1
	b.ne	.LBB32_8
	b	.LBB32_65
.LBB32_10:
	.loc	2 0 20 is_stmt 0
	mov	w9, #34464
	.loc	2 1665 20
	str	w22, [x21]
	movk	w9, #1, lsl #16
.LBB32_11:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB32_13
	isb
	subs	w9, w9, #1
	b.ne	.LBB32_11
	b	.LBB32_69
.LBB32_13:
	.loc	2 0 20
	mov	w9, #10
.LBB32_14:
	.loc	2 1665 20 is_stmt 1
	cmp	x25, x8
	str	w9, [x21]
	b.ne	.LBB32_5
	.loc	2 0 20 is_stmt 0
	mov	x25, x8
	.loc	2 1665 20
	b	.LBB32_44
.Ltmp115:
.LBB32_16:
	.loc	2 1666 19 is_stmt 1
	cmp	w8, #128
	b.eq	.LBB32_19
	cmp	w8, #192
	b.ne	.LBB32_30
.Ltmp116:
	.loc	4 627 28
	add	x9, x2, x20, lsl #4
	mov	x27, x0
.Ltmp117:
	.loc	2 577 9
	str	x0, [sp]
.Ltmp118:
	.file	5 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/fmt/rt.rs"
	.loc	5 152 76
	mov	x1, sp
	mov	x26, x2
.Ltmp119:
	.loc	2 577 9
	stp	x24, x23, [sp, #8]
.Ltmp120:
	.loc	5 144 15
	ldp	x8, x9, [x9]
.Ltmp121:
	.loc	5 152 76
	mov	x0, x8
	blr	x9
.Ltmp122:
	.file	6 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/result.rs"
	.loc	6 2177 9
	tbz	w0, #0, .LBB32_43
	b	.LBB32_77
.Ltmp123:
.LBB32_19:
	.loc	3 1755 9
	ldrb	w8, [x1, #2]
	ldrb	w9, [x1, #1]
	orr	x9, x9, x8, lsl #8
.Ltmp124:
	.loc	4 627 28
	add	x8, x1, #3
.Ltmp125:
	.loc	4 627 28 is_stmt 0
	add	x25, x8, x9
.Ltmp126:
	.loc	2 1677 20 is_stmt 1
	cbz	x9, .LBB32_44
.LBB32_20:
	ldrb	w9, [x8], #1
	mov	w10, #34464
	mov	w11, #34464
	movk	w10, #1, lsl #16
	cmp	w9, #10
	movk	w11, #1, lsl #16
	b.ne	.LBB32_23
.LBB32_21:
	ldr	w9, [x19]
	tbz	w9, #5, .LBB32_25
	isb
	subs	w11, w11, #1
	b.ne	.LBB32_21
	b	.LBB32_73
.LBB32_23:
	ldr	w11, [x19]
	tbz	w11, #5, .LBB32_29
	isb
	subs	w10, w10, #1
	b.ne	.LBB32_23
	b	.LBB32_71
.LBB32_25:
	.loc	2 0 20 is_stmt 0
	mov	w9, #34464
	.loc	2 1677 20
	str	w22, [x21]
	movk	w9, #1, lsl #16
.LBB32_26:
	ldr	w10, [x19]
	tbz	w10, #5, .LBB32_28
	isb
	subs	w9, w9, #1
	b.ne	.LBB32_26
	b	.LBB32_75
.LBB32_28:
	.loc	2 0 20
	mov	w9, #10
.LBB32_29:
	.loc	2 1677 20 is_stmt 1
	cmp	x8, x25
	str	w9, [x21]
	b.ne	.LBB32_20
	b	.LBB32_44
.Ltmp127:
.LBB32_30:
	.loc	2 1700 20
	tbnz	w8, #0, .LBB32_36
	.loc	2 0 20 is_stmt 0
	mov	w9, #32
	movk	w9, #24576, lsl #16
	.loc	2 1704 20 is_stmt 1
	tbz	w8, #1, .LBB32_37
.LBB32_32:
.Ltmp128:
	.loc	3 1755 9
	ldrb	w10, [x25, #1]
	ldrb	w11, [x25], #2
	orr	x10, x11, x10, lsl #8
.Ltmp129:
	.loc	2 1708 20
	tbz	w8, #2, .LBB32_38
.LBB32_33:
.Ltmp130:
	.loc	3 1755 9
	ldrb	w11, [x25, #1]
	ldrb	w12, [x25], #2
	orr	x11, x12, x11, lsl #8
.Ltmp131:
	.loc	2 1712 20
	tbz	w8, #3, .LBB32_39
.LBB32_34:
.Ltmp132:
	.loc	3 1755 9
	ldrb	w12, [x25, #1]
	ldrb	w13, [x25], #2
	orr	x20, x13, x12, lsl #8
.Ltmp133:
	.loc	2 1717 16
	tbz	w8, #4, .LBB32_40
.LBB32_35:
.Ltmp134:
	.loc	4 627 28
	add	x10, x2, x10, lsl #4
.Ltmp135:
	.loc	5 161 33
	ldrh	w10, [x10, #8]
.Ltmp136:
	.loc	2 1724 16
	tbnz	w8, #5, .LBB32_41
	b	.LBB32_42
.LBB32_36:
.Ltmp137:
	.loc	3 1755 9
	ldrb	w9, [x1, #1]!
	ldrb	w10, [x1, #2]
	ldrb	w11, [x1, #1]
	ldrb	w12, [x1, #3]
.Ltmp138:
	.loc	4 627 28
	add	x25, x1, #4
.Ltmp139:
	.loc	3 1755 9
	lsl	w10, w10, #16
	orr	w9, w9, w11, lsl #8
	orr	w10, w10, w12, lsl #24
	orr	w9, w10, w9
.Ltmp140:
	.loc	2 1704 20
	tbnz	w8, #1, .LBB32_32
.LBB32_37:
	.loc	2 0 20 is_stmt 0
	mov	x10, xzr
	.loc	2 1708 20 is_stmt 1
	tbnz	w8, #2, .LBB32_33
.LBB32_38:
	.loc	2 0 20 is_stmt 0
	mov	x11, xzr
	.loc	2 1712 20 is_stmt 1
	tbnz	w8, #3, .LBB32_34
.LBB32_39:
	.loc	2 1717 16
	tbnz	w8, #4, .LBB32_35
.LBB32_40:
	.loc	2 1724 16
	tbz	w8, #5, .LBB32_42
.LBB32_41:
.Ltmp141:
	.loc	4 627 28
	add	x8, x2, x11, lsl #4
.Ltmp142:
	.loc	5 161 33
	ldrh	w11, [x8, #8]
.Ltmp143:
.LBB32_42:
	.loc	2 577 9
	str	w9, [sp, #16]
.Ltmp144:
	.loc	4 627 28
	add	x9, x2, x20, lsl #4
	mov	x27, x0
.Ltmp145:
	.loc	2 577 9
	stp	x0, x24, [sp]
.Ltmp146:
	.loc	5 152 76
	mov	x1, sp
	mov	x26, x2
.Ltmp147:
	.loc	5 144 15
	ldp	x8, x9, [x9]
.Ltmp148:
	.loc	2 577 9
	strh	w10, [sp, #20]
	strh	w11, [sp, #22]
.Ltmp149:
	.loc	5 152 76
	mov	x0, x8
	blr	x9
.Ltmp150:
	.loc	6 2177 9
	tbnz	w0, #0, .LBB32_77
.Ltmp151:
.LBB32_43:
	.loc	2 0 0 is_stmt 0
	add	x20, x20, #1
	mov	x2, x26
	mov	x0, x27
.Ltmp152:
.LBB32_44:
	.loc	3 1755 9 is_stmt 1
	ldrb	w8, [x25]
	mov	x1, x25
.Ltmp153:
	.loc	2 1653 12
	cbnz	w8, .LBB32_3
	b	.LBB32_57
.Ltmp154:
.LBB32_45:
	.loc	2 883 21
	lsr	x8, x2, #1
.Ltmp155:
	.loc	2 1633 23
	cbz	x8, .LBB32_57
	.loc	2 0 23 is_stmt 0
	mov	w9, #24
	add	x8, x1, x8
	mov	w10, #150994944
	movk	w9, #2304, lsl #16
	mov	w11, #13
.LBB32_47:
	.loc	2 1633 23 is_stmt 1
	ldrb	w12, [x1], #1
	mov	w13, #34464
	mov	w14, #34464
	movk	w13, #1, lsl #16
	cmp	w12, #10
	movk	w14, #1, lsl #16
	b.ne	.LBB32_50
.LBB32_48:
	ldr	w12, [x9]
	tbz	w12, #5, .LBB32_52
	isb
	subs	w14, w14, #1
	b.ne	.LBB32_48
	b	.LBB32_59
.LBB32_50:
	ldr	w14, [x9]
	tbz	w14, #5, .LBB32_56
	isb
	subs	w13, w13, #1
	b.ne	.LBB32_50
	b	.LBB32_61
.LBB32_52:
	.loc	2 0 23 is_stmt 0
	mov	w12, #34464
	.loc	2 1633 23
	str	w11, [x10]
	movk	w12, #1, lsl #16
.LBB32_53:
	ldr	w13, [x9]
	tbz	w13, #5, .LBB32_55
	isb
	subs	w12, w12, #1
	b.ne	.LBB32_53
	b	.LBB32_67
.LBB32_55:
	.loc	2 0 23
	mov	w12, #10
.LBB32_56:
	.loc	2 1633 23 is_stmt 1
	cmp	x1, x8
	str	w12, [x10]
	b.ne	.LBB32_47
.Ltmp156:
.LBB32_57:
	.loc	2 0 23 is_stmt 0
	mov	w0, wzr
.LBB32_58:
	.cfi_def_cfa wsp, 128
	.loc	2 1740 2 epilogue_begin is_stmt 1
	ldp	x20, x19, [sp, #112]
	ldr	x27, [sp, #48]
	ldp	x22, x21, [sp, #96]
	ldp	x24, x23, [sp, #80]
	ldp	x26, x25, [sp, #64]
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB32_59:
	.cfi_restore_state
	.loc	2 0 2 is_stmt 0
	adrp	x8, .LCPI32_0
.Ltmp157:
	.loc	2 1633 23 is_stmt 1
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI32_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB32_60:
	//APP
	wfi
	//NO_APP
	b	.LBB32_60
.LBB32_61:
	.loc	2 0 23 is_stmt 0
	adrp	x8, .LCPI32_0
	.loc	2 1633 23
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI32_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB32_62:
	//APP
	wfi
	//NO_APP
	b	.LBB32_62
.Ltmp158:
.LBB32_63:
	.loc	2 0 23
	adrp	x8, .LCPI32_0
.Ltmp159:
	.loc	2 1665 20 is_stmt 1
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI32_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB32_64:
	//APP
	wfi
	//NO_APP
	b	.LBB32_64
.LBB32_65:
	.loc	2 0 20 is_stmt 0
	adrp	x8, .LCPI32_0
	.loc	2 1665 20
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI32_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB32_66:
	//APP
	wfi
	//NO_APP
	b	.LBB32_66
.Ltmp160:
.LBB32_67:
	.loc	2 0 20
	adrp	x8, .LCPI32_0
.Ltmp161:
	.loc	2 1633 23 is_stmt 1
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI32_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB32_68:
	//APP
	wfi
	//NO_APP
	b	.LBB32_68
.Ltmp162:
.LBB32_69:
	.loc	2 0 23 is_stmt 0
	adrp	x8, .LCPI32_0
.Ltmp163:
	.loc	2 1665 20 is_stmt 1
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI32_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB32_70:
	//APP
	wfi
	//NO_APP
	b	.LBB32_70
.Ltmp164:
.LBB32_71:
	.loc	2 0 20 is_stmt 0
	adrp	x8, .LCPI32_0
.Ltmp165:
	.loc	2 1677 20 is_stmt 1
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI32_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB32_72:
	//APP
	wfi
	//NO_APP
	b	.LBB32_72
.LBB32_73:
	.loc	2 0 20 is_stmt 0
	adrp	x8, .LCPI32_0
	.loc	2 1677 20
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI32_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB32_74:
	//APP
	wfi
	//NO_APP
	b	.LBB32_74
.LBB32_75:
	.loc	2 0 20
	adrp	x8, .LCPI32_0
	.loc	2 1677 20
	mov	x1, sp
	mov	w0, #32
	ldr	q0, [x8, :lo12:.LCPI32_0]
	str	q0, [sp]
	//APP
	hlt	#0xf000
	//NO_APP
.LBB32_76:
	//APP
	wfi
	//NO_APP
	b	.LBB32_76
.Ltmp166:
.LBB32_77:
	.loc	2 0 20
	mov	w0, #1
.Ltmp167:
	.loc	6 2177 9 is_stmt 1
	b	.LBB32_58
.Ltmp168:
.Lfunc_end32:
	.size	_RNvNtCsboyoyqK6YBz_4core3fmt5write, .Lfunc_end32-_RNvNtCsboyoyqK6YBz_4core3fmt5write
	.cfi_endproc

	.section	.text._RNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB5_9Formatter12pad_integral,"ax",@progbits
	.p2align	2
	.type	_RNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB5_9Formatter12pad_integral,@function
_RNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB5_9Formatter12pad_integral:
.Lfunc_begin33:
	.loc	2 1826 0
	.cfi_startproc
	stp	x29, x30, [sp, #-96]!
	.cfi_def_cfa_offset 96
	stp	x28, x27, [sp, #16]
	stp	x26, x25, [sp, #32]
	stp	x24, x23, [sp, #48]
	stp	x22, x21, [sp, #64]
	stp	x20, x19, [sp, #80]
	mov	x29, sp
	.cfi_def_cfa w29, 96
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_remember_state
	ldr	w25, [x0, #16]
.Ltmp169:
	.loc	2 1855 19 prologue_end
	ldrh	w28, [x0, #20]
.Ltmp170:
	.loc	2 1833 19
	mov	w8, #43
	mov	x19, x2
	mov	x20, x1
.Ltmp171:
	.loc	2 2316 9
	and	x9, x25, #0x200000
.Ltmp172:
	.loc	2 2373 9
	ubfx	w21, w25, #23, #1
.Ltmp173:
	.loc	2 1833 19
	add	x27, x2, x9, lsr #21
	cmp	w9, #0
	csinv	w22, w8, wzr, ne
.Ltmp174:
	.loc	2 1856 12
	cmp	x27, x28
	b.hs	.LBB33_5
	.loc	2 1860 19
	tbnz	w25, #24, .LBB33_7
.Ltmp175:
	.loc	2 502 9
	ubfx	w8, w25, #29, #2
.Ltmp176:
	.loc	2 1873 45
	sub	w26, w28, w27
.Ltmp177:
	.loc	2 502 9
	cmp	w8, #1
	b.gt	.LBB33_11
	cbnz	w8, .LBB33_15
	.loc	2 0 9 is_stmt 0
	mov	w27, wzr
	.loc	2 502 9
	b	.LBB33_16
.Ltmp178:
.LBB33_5:
	.loc	2 1858 13 is_stmt 1
	ldp	x23, x24, [x0]
	mov	w2, w22
	mov	x3, x21
	mov	x0, x23
	mov	x1, x24
	bl	_RNvNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB7_9Formatter12pad_integral12write_prefix
.Ltmp179:
	.loc	6 2177 9
	tbnz	w0, #0, .LBB33_21
.Ltmp180:
	.loc	2 1859 13
	ldr	x3, [x24, #24]
	.loc	2 1859 22 is_stmt 0
	mov	x0, x23
	mov	x1, x20
	mov	x2, x19
	.cfi_def_cfa wsp, 96
	.loc	2 1859 22 epilogue_begin
	ldp	x20, x19, [sp, #80]
	ldp	x22, x21, [sp, #64]
	ldp	x24, x23, [sp, #48]
	ldp	x26, x25, [sp, #32]
	ldp	x28, x27, [sp, #16]
	ldp	x29, x30, [sp], #96
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	br	x3
.LBB33_7:
	.cfi_restore_state
	.cfi_remember_state
	.loc	2 1863 31 is_stmt 1
	ldp	x24, x25, [x0, #8]
.Ltmp181:
	.loc	2 403 22
	mov	w8, #-1612709888
.Ltmp182:
	.loc	2 1865 13
	ldr	x23, [x0]
	mov	x26, x0
	mov	w2, w22
	mov	x3, x21
.Ltmp183:
	.loc	2 403 22
	and	w8, w25, w8
.Ltmp184:
	.loc	2 1865 13
	mov	x1, x24
.Ltmp185:
	.loc	2 418 9
	orr	w8, w8, #0x30
	orr	w8, w8, #0x20000000
	str	w8, [x0, #16]
.Ltmp186:
	.loc	2 1865 13
	mov	x0, x23
	bl	_RNvNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB7_9Formatter12pad_integral12write_prefix
.Ltmp187:
	.loc	6 2177 9
	tbnz	w0, #0, .LBB33_21
.Ltmp188:
	.loc	6 0 9 is_stmt 0
	mov	w21, wzr
	.loc	2 1866 45 is_stmt 1
	sub	w22, w28, w27
.LBB33_9:
.Ltmp189:
	.file	7 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/cmp.rs"
	.loc	7 2144 50
	and	w8, w21, #0xffff
.Ltmp190:
	.file	8 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/iter/range.rs"
	.loc	8 1100 12
	cmp	w8, w22, uxth
	b.hs	.LBB33_13
.Ltmp191:
	.loc	2 1967 13
	ldr	x8, [x24, #32]
	.loc	2 1967 22 is_stmt 0
	mov	x0, x23
	mov	w1, #48
.Ltmp192:
	.file	9 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/num/uint_macros.rs"
	.loc	9 1013 17 is_stmt 1
	add	w21, w21, #1
.Ltmp193:
	.loc	2 1967 22
	blr	x8
.Ltmp194:
	.loc	6 2177 9
	tbz	w0, #0, .LBB33_9
	b	.LBB33_21
.Ltmp195:
.LBB33_11:
	.loc	2 502 9
	cmp	w8, #2
	mov	w27, w26
	b.ne	.LBB33_16
.Ltmp196:
	.loc	2 1963 34
	ubfx	w27, w26, #1, #15
	b	.LBB33_16
.Ltmp197:
.LBB33_13:
	.loc	2 1867 13
	ldr	x8, [x24, #24]
	.loc	2 1867 22 is_stmt 0
	mov	x0, x23
	mov	x1, x20
	mov	x2, x19
	blr	x8
.Ltmp198:
	.loc	6 2177 9 is_stmt 1
	tbnz	w0, #0, .LBB33_21
.Ltmp199:
	.loc	6 0 9 is_stmt 0
	mov	w0, wzr
	.loc	2 1869 13 is_stmt 1
	str	x25, [x26, #16]
.Ltmp200:
	.loc	2 1860 16
	b	.LBB33_22
.LBB33_15:
	.loc	2 0 16 is_stmt 0
	mov	w27, w26
.LBB33_16:
	ldp	x23, x24, [x0]
	mov	w28, wzr
.LBB33_17:
.Ltmp201:
	.loc	7 2144 50 is_stmt 1
	and	w8, w28, #0xffff
.Ltmp202:
	.loc	8 1100 12
	cmp	w8, w27, uxth
	b.hs	.LBB33_19
.Ltmp203:
	.loc	2 1967 13
	ldr	x8, [x24, #32]
.Ltmp204:
	.loc	2 497 43
	and	w1, w25, #0x1fffff
.Ltmp205:
	.loc	2 1967 22
	mov	x0, x23
.Ltmp206:
	.loc	9 1013 17
	add	w28, w28, #1
.Ltmp207:
	.loc	2 1967 22
	blr	x8
.Ltmp208:
	.loc	6 2177 9
	tbz	w0, #0, .LBB33_17
	b	.LBB33_21
.Ltmp209:
.LBB33_19:
	.loc	2 1874 13
	mov	x0, x23
	mov	x1, x24
	mov	w2, w22
	mov	x3, x21
	bl	_RNvNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB7_9Formatter12pad_integral12write_prefix
.Ltmp210:
	.loc	6 2177 9
	tbnz	w0, #0, .LBB33_21
.Ltmp211:
	.loc	2 1875 13
	ldr	x8, [x24, #24]
	.loc	2 1875 22 is_stmt 0
	mov	x0, x23
	mov	x1, x20
	mov	x2, x19
	blr	x8
.Ltmp212:
	.loc	6 2177 9 is_stmt 1
	tbz	w0, #0, .LBB33_23
.Ltmp213:
.LBB33_21:
	.loc	6 0 9 is_stmt 0
	mov	w0, #1
.LBB33_22:
	.cfi_def_cfa wsp, 96
	.loc	2 1878 6 epilogue_begin is_stmt 1
	ldp	x20, x19, [sp, #80]
	ldp	x22, x21, [sp, #64]
	ldp	x24, x23, [sp, #48]
	ldp	x26, x25, [sp, #32]
	ldp	x28, x27, [sp, #16]
	ldp	x29, x30, [sp], #96
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB33_23:
	.cfi_restore_state
	.loc	2 0 6 is_stmt 0
	mov	w19, wzr
	sub	w20, w26, w27
.LBB33_24:
.Ltmp214:
	.loc	7 2144 50 is_stmt 1
	and	w8, w19, #0xffff
.Ltmp215:
	.loc	8 1100 12
	cmp	w8, w20, uxth
	b.hs	.LBB33_26
.Ltmp216:
	.loc	2 1757 13
	ldr	x8, [x24, #32]
.Ltmp217:
	.loc	2 497 43
	and	w1, w25, #0x1fffff
.Ltmp218:
	.loc	2 1757 19
	mov	x0, x23
.Ltmp219:
	.loc	9 1013 17
	add	w19, w19, #1
.Ltmp220:
	.loc	2 1757 19
	blr	x8
	mov	w8, w0
	mov	w0, #1
.Ltmp221:
	.loc	6 2177 9
	tbz	w8, #0, .LBB33_24
	b	.LBB33_22
.Ltmp222:
.LBB33_26:
	.loc	6 0 9 is_stmt 0
	mov	w0, wzr
	b	.LBB33_22
.Lfunc_end33:
	.size	_RNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB5_9Formatter12pad_integral, .Lfunc_end33-_RNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB5_9Formatter12pad_integral
	.cfi_endproc

	.section	.text._RNvNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB7_9Formatter12pad_integral12write_prefix,"ax",@progbits
	.p2align	2
	.type	_RNvNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB7_9Formatter12pad_integral12write_prefix,@function
_RNvNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB7_9Formatter12pad_integral12write_prefix:
.Lfunc_begin34:
	.loc	2 1847 0 is_stmt 1
	.cfi_startproc
	stp	x29, x30, [sp, #-48]!
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]
	stp	x20, x19, [sp, #32]
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	mov	x19, x3
	mov	x20, x1
.Ltmp223:
	.loc	2 1848 20 prologue_end
	cmn	w2, #1
	mov	x21, x0
	b.eq	.LBB34_3
	.loc	2 1849 17
	ldr	x8, [x20, #32]
	.loc	2 1849 23 is_stmt 0
	mov	x0, x21
	mov	w1, w2
	blr	x8
.Ltmp224:
	.loc	6 2177 9 is_stmt 1
	tbz	w0, #0, .LBB34_3
.Ltmp225:
	.loc	6 0 9 is_stmt 0
	mov	w0, #1
	.cfi_def_cfa wsp, 48
	.loc	2 1852 10 epilogue_begin is_stmt 1
	ldp	x20, x19, [sp, #32]
	ldr	x21, [sp, #16]
	ldp	x29, x30, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB34_3:
	.cfi_restore_state
	.cfi_remember_state
.Ltmp226:
	.loc	2 1851 20
	cbz	x19, .LBB34_5
	.loc	2 1851 44 is_stmt 0
	ldr	x3, [x20, #24]
	.loc	2 1851 50
	mov	x0, x21
	mov	x1, x19
	mov	x2, xzr
	.cfi_def_cfa wsp, 48
	.loc	2 1851 50 epilogue_begin
	ldp	x20, x19, [sp, #32]
	ldr	x21, [sp, #16]
	ldp	x29, x30, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	br	x3
.Ltmp227:
.LBB34_5:
	.cfi_restore_state
	.loc	2 0 50
	mov	w0, wzr
	.cfi_def_cfa wsp, 48
	.loc	2 1852 10 epilogue_begin is_stmt 1
	ldp	x20, x19, [sp, #32]
	ldr	x21, [sp, #16]
	ldp	x29, x30, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.Ltmp228:
.Lfunc_end34:
	.size	_RNvNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB7_9Formatter12pad_integral12write_prefix, .Lfunc_end34-_RNvNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB7_9Formatter12pad_integral12write_prefix
	.cfi_endproc

	.section	.text.unlikely._RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail,"ax",@progbits
	.p2align	2
	.type	_RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail,@function
_RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail:
.Lfunc_begin35:
	.file	10 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/slice/index.rs"
	.loc	10 39 0
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
.Ltmp229:
	.file	11 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/panic.rs"
	.loc	11 177 9 prologue_end
	bl	_RNvNtCsboyoyqK6YBz_4core9panicking9panic_fmt
.Ltmp230:
.Lfunc_end35:
	.size	_RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail, .Lfunc_end35-_RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail
	.cfi_endproc

	.section	.text._RNvNtNtCsboyoyqK6YBz_4core5slice6memchr14memchr_aligned,"ax",@progbits
	.p2align	2
	.type	_RNvNtNtCsboyoyqK6YBz_4core5slice6memchr14memchr_aligned,@function
_RNvNtNtCsboyoyqK6YBz_4core5slice6memchr14memchr_aligned:
.Lfunc_begin36:
	.cfi_startproc
	.loc	3 2380 31 prologue_end
	add	x8, x0, #7
	and	x8, x8, #0xfffffffffffffff8
.Ltmp231:
	.file	12 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/slice/memchr.rs"
	.loc	12 73 16
	subs	x10, x8, x0
	b.ne	.LBB36_5
	.loc	12 0 16 is_stmt 0
	sub	x8, x1, #16
.LBB36_2:
	mov	x9, #2459565876494606882
	mov	x11, #72340172838076673
	mov	x12, #-9187201950435737472
	orr	x9, x9, #0xf0f0f0f0f0f0f0f
	movk	x11, #256
.LBB36_3:
.Ltmp232:
	.file	13 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/ptr/const_ptr.rs"
	.loc	13 871 18 is_stmt 1
	add	x13, x0, x10
.Ltmp233:
	.loc	12 87 29
	ldp	x14, x13, [x13]
.Ltmp234:
	.loc	12 91 49
	eor	x15, x14, x9
.Ltmp235:
	.loc	12 92 49
	eor	x13, x13, x9
.Ltmp236:
	.loc	12 19 5
	sub	x15, x11, x15
.Ltmp237:
	.loc	12 19 5 is_stmt 0
	sub	x16, x11, x13
.Ltmp238:
	.loc	12 19 5
	orr	x14, x15, x14
.Ltmp239:
	.loc	12 19 5
	orr	x13, x16, x13
.Ltmp240:
	.loc	12 93 24 is_stmt 1
	and	x13, x14, x13
	bics	xzr, x12, x13
	b.ne	.LBB36_9
.Ltmp241:
	.loc	12 97 17
	add	x10, x10, #16
	.loc	12 83 19
	cmp	x10, x8
	b.ls	.LBB36_3
	b	.LBB36_9
.Ltmp242:
.LBB36_5:
	.loc	12 0 19 is_stmt 0
	mov	x8, xzr
	mov	w9, #1
.LBB36_6:
.Ltmp243:
	.loc	12 42 12 is_stmt 1
	ldrb	w11, [x0, x8]
	cmp	w11, #47
	b.eq	.LBB36_14
	.loc	12 46 9
	add	x8, x8, #1
	.loc	12 41 11
	cmp	x10, x8
	b.ne	.LBB36_6
.Ltmp244:
	.loc	12 0 11 is_stmt 0
	sub	x8, x1, #16
.Ltmp245:
	.loc	12 83 19 is_stmt 1
	cmp	x10, x8
	b.ls	.LBB36_2
.LBB36_9:
.Ltmp246:
	.loc	12 41 11
	subs	x8, x1, x10
	b.eq	.LBB36_13
	.loc	12 0 11 is_stmt 0
	mov	x9, xzr
	add	x11, x0, x10
.LBB36_11:
	.loc	12 42 12 is_stmt 1
	ldrb	w12, [x11, x9]
	cmp	w12, #47
	b.eq	.LBB36_15
	.loc	12 46 9
	add	x9, x9, #1
	.loc	12 41 11
	cmp	x8, x9
	b.ne	.LBB36_11
.Ltmp247:
.LBB36_13:
	.loc	12 0 11 is_stmt 0
	mov	x9, xzr
.LBB36_14:
	.loc	12 109 2 is_stmt 1
	mov	x0, x9
	mov	x1, x8
	ret
.LBB36_15:
.Ltmp248:
	.loc	12 106 60
	add	x8, x9, x10
	mov	w9, #1
.Ltmp249:
	.loc	12 109 2
	mov	x0, x9
	mov	x1, x8
	ret
.Ltmp250:
.Lfunc_end36:
	.size	_RNvNtNtCsboyoyqK6YBz_4core5slice6memchr14memchr_aligned, .Lfunc_end36-_RNvNtNtCsboyoyqK6YBz_4core5slice6memchr14memchr_aligned
	.cfi_endproc
	.file	14 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/intrinsics/mod.rs"

	.section	.text._RNvXsd_NtNtNtCsboyoyqK6YBz_4core3fmt3num3impyNtB9_7Display3fmt,"ax",@progbits
	.p2align	2
	.type	_RNvXsd_NtNtNtCsboyoyqK6YBz_4core3fmt3num3impyNtB9_7Display3fmt,@function
_RNvXsd_NtNtNtCsboyoyqK6YBz_4core3fmt3num3impyNtB9_7Display3fmt:
.Lfunc_begin37:
	.file	15 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/fmt/num.rs"
	.loc	15 135 0
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
.Ltmp251:
	.loc	15 143 55 prologue_end
	ldr	x11, [x0]
	mov	x8, x1
	adrp	x10, .Lanon.4379416e6c146e9fcb6d8c8e621434d6.192
	add	x10, x10, :lo12:.Lanon.4379416e6c146e9fcb6d8c8e621434d6.192
.Ltmp252:
	.loc	15 198 48
	cmp	x11, #1000
	b.lo	.LBB37_9
	.loc	15 0 48 is_stmt 0
	mov	x13, #22859
	add	x12, sp, #12
	mov	w18, #38527
	movk	x13, #14470, lsl #16
	mov	w9, #20
	mov	w14, #10000
	movk	x13, #50646, lsl #32
	mov	w15, #5243
	.loc	15 198 48
	add	x16, x12, #19
	movk	x13, #13421, lsl #48
	mov	w17, #100
	movk	w18, #152, lsl #16
	mov	x0, x11
.LBB37_2:
.Ltmp253:
	.loc	15 210 21 is_stmt 1
	umulh	x12, x0, x13
.Ltmp254:
	.loc	15 205 21
	sub	x9, x9, #4
	.loc	15 198 48
	cmp	x0, x18
.Ltmp255:
	.loc	15 210 21
	lsr	x12, x12, #11
.Ltmp256:
	.loc	15 209 32
	msub	w1, w12, w14, w0
	mov	x0, x12
.Ltmp257:
	.loc	15 211 33
	ubfx	w2, w1, #2, #14
	mul	w2, w2, w15
	lsr	w2, w2, #17
.Ltmp258:
	.loc	15 212 33
	msub	w1, w2, w17, w1
.Ltmp259:
	.loc	15 213 43
	add	x2, x10, w2, uxtw #1
	ldrb	w3, [x2]
	.loc	15 214 43
	ldrb	w2, [x2, #1]
	.loc	15 215 43
	add	x1, x10, w1, uxth #1
.Ltmp260:
	.file	16 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/mem/maybe_uninit.rs"
	.loc	16 575 9
	sturb	w3, [x16, #-3]
.Ltmp261:
	.loc	15 215 43
	ldrb	w3, [x1]
	.loc	15 216 43
	ldrb	w1, [x1, #1]
.Ltmp262:
	.loc	16 575 9
	sturb	w2, [x16, #-2]
.Ltmp263:
	.loc	16 575 9 is_stmt 0
	sturb	w3, [x16, #-1]
.Ltmp264:
	.loc	16 575 9
	strb	w1, [x16], #-4
.Ltmp265:
	.loc	15 198 48 is_stmt 1
	b.hi	.LBB37_2
	.loc	15 220 20
	cmp	x12, #9
	b.ls	.LBB37_5
.LBB37_4:
.Ltmp266:
	.loc	15 230 21
	ubfx	w13, w12, #2, #14
	mov	w14, #5243
	add	x16, sp, #12
	mul	w13, w13, w14
	mov	w14, #100
	lsr	w13, w13, #17
.Ltmp267:
	.loc	15 229 32
	msub	w12, w13, w14, w12
	.loc	15 227 21
	sub	x14, x9, #2
.Ltmp268:
	.loc	15 232 21
	add	x9, x16, x9
	.loc	15 231 43
	add	x12, x10, w12, uxth #1
	ldrb	w15, [x12]
	.loc	15 232 43
	ldrb	w12, [x12, #1]
.Ltmp269:
	.loc	16 575 9
	strb	w15, [x16, x14]
.Ltmp270:
	.loc	16 575 9 is_stmt 0
	sturb	w12, [x9, #-1]
	mov	x12, x13
	mov	x9, x14
.Ltmp271:
.LBB37_5:
	.loc	15 236 20 is_stmt 1
	cbz	x11, .LBB37_7
	.loc	15 0 20 is_stmt 0
	cbz	x12, .LBB37_8
.LBB37_7:
.Ltmp272:
	.loc	15 248 39 is_stmt 1
	add	x10, x10, x12, lsl #1
.Ltmp273:
	.loc	15 243 21
	sub	x9, x9, #1
	add	x11, sp, #12
.Ltmp274:
	.loc	15 248 39
	ldrb	w10, [x10, #1]
.Ltmp275:
	.loc	16 575 9
	strb	w10, [x11, x9]
.Ltmp276:
.LBB37_8:
	.loc	10 380 27
	mov	w10, #20
.Ltmp277:
	.loc	15 143 32
	mov	x0, x8
.Ltmp278:
	.loc	10 380 27
	sub	x2, x10, x9
	add	x10, sp, #12
.Ltmp279:
	.loc	10 90 24
	add	x1, x10, x9
.Ltmp280:
	.loc	15 143 32
	bl	_RNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB5_9Formatter12pad_integral
.Ltmp281:
	.cfi_def_cfa wsp, 48
	.loc	15 151 14 epilogue_begin
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB37_9:
	.cfi_restore_state
	.loc	15 0 14 is_stmt 0
	mov	w9, #20
	mov	x12, x11
.Ltmp282:
	.loc	15 220 20 is_stmt 1
	cmp	x11, #9
	b.hi	.LBB37_4
	b	.LBB37_5
.Ltmp283:
.Lfunc_end37:
	.size	_RNvXsd_NtNtNtCsboyoyqK6YBz_4core3fmt3num3impyNtB9_7Display3fmt, .Lfunc_end37-_RNvXsd_NtNtNtCsboyoyqK6YBz_4core3fmt3num3impyNtB9_7Display3fmt
	.cfi_endproc
	.file	17 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/slice/mod.rs"

	.section	.text._RNvMs0_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_6Cursor4name,"ax",@progbits
	.p2align	2
	.type	_RNvMs0_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_6Cursor4name,@function
_RNvMs0_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_6Cursor4name:
.Lfunc_begin38:
	.cfi_startproc
	stp	x30, x21, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_remember_state
	ldp	x9, x10, [x1, #8]
	subs	x11, x9, x10
	b.hs	.LBB38_2
.LBB38_1:
	mov	w8, #1
	strb	w8, [x0, #8]
	str	xzr, [x0]
	ldp	x20, x19, [sp, #16]
	ldp	x30, x21, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	ret
.LBB38_2:
	.cfi_restore_state
	.cfi_remember_state
	b.eq	.LBB38_6
	ldr	x8, [x1]
	mov	x19, xzr
	add	x20, x8, x10
.LBB38_4:
	ldrb	w12, [x20, x19]
	cbz	w12, .LBB38_7
	add	x19, x19, #1
	cmp	x11, x19
	b.ne	.LBB38_4
.LBB38_6:
	mov	w8, #2
	strb	w8, [x0, #8]
	str	xzr, [x0]
	ldp	x20, x19, [sp, #16]
	ldp	x30, x21, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	ret
.LBB38_7:
	.cfi_restore_state
	.cfi_remember_state
	add	x11, x10, x19
	add	x11, x11, #1
	cmp	x11, x10
	b.lo	.LBB38_1
	cmp	x11, x9
	b.hi	.LBB38_1
	neg	w10, w11
	str	x11, [x1, #16]
	and	x10, x10, #0x3
	adds	x12, x10, x11
	cset	w13, hs
	cmp	x12, x9
	csinc	w9, w13, wzr, ls
	tbz	w9, #0, .LBB38_11
	mov	w8, #1
	strb	w8, [x0, #8]
	str	xzr, [x0]
	ldp	x20, x19, [sp, #16]
	ldp	x30, x21, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	ret
.LBB38_11:
	.cfi_restore_state
	.cfi_remember_state
	str	x12, [x1, #16]
	cbz	x10, .LBB38_14
	add	x8, x8, x11
	ldrb	w9, [x8]
	cbnz	w9, .LBB38_6
	cmp	x10, #1
	b.ne	.LBB38_21
.LBB38_14:
	cmp	x19, #15
	b.hi	.LBB38_19
	cbz	x19, .LBB38_20
	mov	x8, xzr
.LBB38_17:
	ldrb	w9, [x20, x8]
	cmp	w9, #47
	b.eq	.LBB38_6
	add	x8, x8, #1
	cmp	x19, x8
	b.ne	.LBB38_17
	b	.LBB38_20
.LBB38_19:
	mov	x21, x0
	mov	x0, x20
	mov	x1, x19
	bl	_RNvNtNtCsboyoyqK6YBz_4core5slice6memchr14memchr_aligned
	mov	x8, x0
	mov	x0, x21
	tbnz	w8, #0, .LBB38_6
.LBB38_20:
	stp	x20, x19, [x0]
	ldp	x20, x19, [sp, #16]
	ldp	x30, x21, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	ret
.LBB38_21:
	.cfi_restore_state
	ldrb	w9, [x8, #1]
	cbnz	w9, .LBB38_6
	cmp	x10, #2
	b.eq	.LBB38_14
	ldrb	w8, [x8, #2]
	cbnz	w8, .LBB38_6
	b	.LBB38_14
.Lfunc_end38:
	.size	_RNvMs0_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_6Cursor4name, .Lfunc_end38-_RNvMs0_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_6Cursor4name
	.cfi_endproc

	.section	.text._RNvMs1_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_4Node6finish,"ax",@progbits
	.p2align	2
	.type	_RNvMs1_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_4Node6finish,@function
_RNvMs1_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_4Node6finish:
.Lfunc_begin39:
	.cfi_startproc
	str	x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -16
	.cfi_remember_state
	ldrb	w9, [x0, #17]
	mov	x10, #59388
	movk	x10, #63480, lsl #16
	lsl	w8, w9, #3
	movk	x10, #255, lsl #32
	lsr	x8, x10, x8
	ldrb	w10, [x0, #16]
	and	w8, w8, #0xff
	orr	w8, w10, w8
	cmp	w8, #255
	b.ne	.LBB39_21
	ldr	x8, [x0]
	cbz	x8, .LBB39_19
	ldr	x10, [x0, #8]
	ands	x10, x10, #0xfffffffffffffff0
	b.eq	.LBB39_19
	cmp	w9, #1
	add	x9, x8, x10
	b.ne	.LBB39_15
	add	x10, x1, #512
.LBB39_5:
	mov	x11, x8
	ldrb	w17, [x8, #9]
	ldrb	w18, [x8, #13]
	ldrb	w12, [x11, #8]!
	ldrb	w13, [x11, #3]
	ldrb	w14, [x11, #2]
	ldrb	w15, [x11, #4]!
	ldrb	w16, [x11, #2]
	ldrb	w11, [x11, #3]
	orr	x12, x12, x17, lsl #8
	lsl	x14, x14, #16
	lsl	w16, w16, #16
	orr	x13, x14, x13, lsl #24
	orr	w14, w15, w18, lsl #8
	orr	w11, w16, w11, lsl #24
	orr	x12, x13, x12
	orr	w11, w11, w14
	orr	x11, x12, x11, lsl #32
	cbz	x11, .LBB39_23
	mov	x14, x8
	ldrb	w13, [x8, #2]
	ldrb	w12, [x8, #1]
	ldrb	w15, [x14, #4]!
	ldrb	w16, [x14, #2]
	ldrb	w17, [x8]
	ldrb	w18, [x8, #3]
	lsl	x13, x13, #16
	ldrb	w0, [x8, #5]
	ldrb	w14, [x14, #3]
	lsl	w16, w16, #16
	orr	x12, x17, x12, lsl #8
	orr	x13, x13, x18, lsl #24
	orr	w15, w15, w0, lsl #8
	orr	w14, w16, w14, lsl #24
	orr	x12, x13, x12
	orr	w13, w14, w15
	orr	x12, x12, x13, lsl #32
	rev	x13, x11
	rev	x12, x12
	adds	x11, x13, x12
	b.hs	.LBB39_23
	ldr	x0, [x1, #768]
	cmp	x0, #16
	b.hi	.LBB39_25
	lsl	x15, x0, #4
	add	x8, x8, #16
	add	x17, x1, #512
	add	x14, x10, x15
.LBB39_9:
	cbz	x15, .LBB39_12
	mov	x16, x17
	ldr	x17, [x17]
	sub	x15, x15, #16
	cmp	x17, x11
	add	x17, x16, #16
	b.hs	.LBB39_9
	ldr	x16, [x16, #8]
	cmp	x12, x16
	b.hs	.LBB39_9
	b	.LBB39_22
.LBB39_12:
	ldr	x15, [x1, #784]
	adds	x13, x15, x13
	b.hs	.LBB39_23
	cmp	x0, #16
	b.eq	.LBB39_24
	stp	x12, x11, [x14]
	cmp	x8, x9
	mov	w0, #255
	ldr	x12, [x1, #768]
	str	x13, [x1, #784]
	add	x11, x12, #1
	str	x11, [x1, #768]
	b.ne	.LBB39_5
	b	.LBB39_20
.LBB39_15:
	mov	x10, x8
	ldrb	w16, [x8, #9]
	ldrb	w17, [x8, #13]
	ldrb	w11, [x10, #8]!
	ldrb	w12, [x10, #3]
	ldrb	w13, [x10, #2]
	ldrb	w14, [x10, #4]!
	ldrb	w15, [x10, #2]
	ldrb	w10, [x10, #3]
	orr	x11, x11, x16, lsl #8
	lsl	x13, x13, #16
	lsl	w15, w15, #16
	orr	x12, x13, x12, lsl #24
	orr	w13, w14, w17, lsl #8
	orr	w10, w15, w10, lsl #24
	orr	x11, x12, x11
	orr	w10, w10, w13
	orr	x10, x11, x10, lsl #32
	cbz	x10, .LBB39_23
	mov	x13, x8
	ldrb	w12, [x8, #2]
	ldrb	w11, [x8, #1]
	ldrb	w14, [x13, #4]!
	ldrb	w15, [x13, #2]
	ldrb	w16, [x8]
	ldrb	w17, [x8, #3]
	lsl	x12, x12, #16
	ldrb	w18, [x8, #5]
	ldrb	w13, [x13, #3]
	lsl	w15, w15, #16
	orr	x11, x16, x11, lsl #8
	orr	x12, x12, x17, lsl #24
	rev	x10, x10
	orr	w14, w14, w18, lsl #8
	orr	w13, w15, w13, lsl #24
	orr	x11, x12, x11
	orr	w12, w13, w14
	orr	x11, x11, x12, lsl #32
	rev	x11, x11
	adds	x10, x10, x11
	b.hs	.LBB39_23
	ldr	x12, [x1, #776]
	cmp	x12, #32
	b.hs	.LBB39_24
	add	x12, x1, x12, lsl #4
	add	x8, x8, #16
	cmp	x8, x9
	stp	x11, x10, [x12]
	ldr	x10, [x1, #776]
	add	x10, x10, #1
	str	x10, [x1, #776]
	b.ne	.LBB39_15
.LBB39_19:
	mov	w0, #255
.LBB39_20:
	ldr	x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	ret
.LBB39_21:
	.cfi_restore_state
	.cfi_remember_state
	mov	w0, #2
	ldr	x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	ret
.LBB39_22:
	.cfi_restore_state
	.cfi_remember_state
	mov	w0, #7
	ldr	x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	ret
.LBB39_23:
	.cfi_restore_state
	.cfi_remember_state
	mov	w0, #6
	ldr	x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	ret
.LBB39_24:
	.cfi_restore_state
	.cfi_remember_state
	mov	w0, #5
	ldr	x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	ret
.LBB39_25:
	.cfi_restore_state
	mov	w1, #16
	bl	_RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail
.Lfunc_end39:
	.size	_RNvMs1_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_4Node6finish, .Lfunc_end39-_RNvMs1_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_4Node6finish
	.cfi_endproc

	.section	.text._RNvMs1_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_4Node8property,"ax",@progbits
	.p2align	2
	.type	_RNvMs1_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_4Node8property,@function
_RNvMs1_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_4Node8property:
.Lfunc_begin40:
	.cfi_startproc
	ldrb	w8, [x0, #18]
	tbz	w8, #0, .LBB40_2
	mov	w0, #2
	ret
.LBB40_2:
	cmp	x2, #11
	b.ne	.LBB40_10
	mov	x10, x1
	ldrb	w8, [x1, #1]
	ldrb	w9, [x1]
	ldrb	w11, [x1, #2]
	ldrb	w12, [x10, #4]!
	ldrb	w13, [x10, #2]
	orr	x8, x9, x8, lsl #8
	ldrb	w9, [x1, #3]
	lsl	x11, x11, #16
	ldrb	w14, [x1, #5]
	ldrb	w10, [x10, #3]
	lsl	w13, w13, #16
	mov	x15, x1
	ldrb	w16, [x1, #9]
	ldrb	w17, [x15, #8]!
	orr	x9, x11, x9, lsl #24
	orr	w11, w12, w14, lsl #8
	orr	w10, w13, w10, lsl #24
	ldrb	w13, [x15, #2]
	orr	x12, x17, x16, lsl #8
	orr	x8, x9, x8
	orr	w9, w10, w11
	mov	x10, #25956
	mov	w11, #28793
	movk	x10, #26998, lsl #16
	orr	x8, x8, x9, lsl #32
	orr	x9, x12, x13, lsl #16
	movk	x10, #25955, lsl #32
	movk	w11, #101, lsl #16
	movk	x10, #29791, lsl #48
	eor	x9, x9, x11
	eor	x8, x8, x10
	orr	x8, x8, x9
	cbnz	x8, .LBB40_10
	ldrb	w8, [x0, #16]
	tbnz	w8, #4, .LBB40_85
	ldrb	w9, [x0, #17]
	orr	w8, w8, #0x10
	strb	w8, [x0, #16]
	cmp	w9, #1
	b.ne	.LBB40_8
	cmp	x4, #7
	b.ne	.LBB40_117
	ldrb	w9, [x3, #2]
	mov	x10, x3
	ldrb	w11, [x3, #5]
	ldrb	w12, [x10, #4]!
	ldrb	w8, [x3, #1]
	ldrb	w13, [x3]
	ldrb	w14, [x3, #3]
	lsl	x9, x9, #16
	orr	w11, w12, w11, lsl #8
	ldrb	w10, [x10, #2]
	orr	x8, x13, x8, lsl #8
	orr	x9, x9, x14, lsl #24
	orr	w10, w11, w10, lsl #16
	orr	x8, x9, x8
	mov	x9, #25965
	orr	x8, x8, x10, lsl #32
	movk	x9, #28525, lsl #16
	movk	x9, #31090, lsl #32
	cmp	x8, x9
	b.eq	.LBB40_10
	b	.LBB40_117
.LBB40_8:
	cmp	x4, #7
	b.ne	.LBB40_10
	ldrb	w9, [x3, #2]
	mov	x10, x3
	ldrb	w11, [x3, #5]
	ldrb	w12, [x10, #4]!
	ldrb	w8, [x3, #1]
	ldrb	w13, [x3]
	ldrb	w14, [x3, #3]
	lsl	x9, x9, #16
	orr	w11, w12, w11, lsl #8
	ldrb	w10, [x10, #2]
	orr	x8, x13, x8, lsl #8
	orr	x9, x9, x14, lsl #24
	orr	w10, w11, w10, lsl #16
	orr	x8, x9, x8
	mov	x9, #25965
	orr	x8, x8, x10, lsl #32
	movk	x9, #28525, lsl #16
	movk	x9, #31090, lsl #32
	cmp	x8, x9
	b.eq	.LBB40_117
.LBB40_10:
	ldrb	w9, [x0, #17]
	cmp	w9, #1
	b.le	.LBB40_13
	cmp	w9, #2
	b.eq	.LBB40_14
	cmp	w9, #3
	b.eq	.LBB40_32
	b	.LBB40_115
.LBB40_13:
	cbnz	w9, .LBB40_32
.LBB40_14:
	cmp	x2, #6
	b.eq	.LBB40_54
	cmp	w2, #11
	b.eq	.LBB40_39
	cmp	w2, #14
	b.ne	.LBB40_68
	ldrb	w8, [x1]
	cmp	w8, #35
	b.ne	.LBB40_68
	ldrb	w8, [x1, #1]
	cmp	w8, #97
	b.ne	.LBB40_68
	ldrb	w8, [x1, #2]
	cmp	w8, #100
	b.ne	.LBB40_68
	ldrb	w8, [x1, #3]
	cmp	w8, #100
	b.ne	.LBB40_68
	ldrb	w8, [x1, #4]
	cmp	w8, #114
	b.ne	.LBB40_68
	ldrb	w8, [x1, #5]
	cmp	w8, #101
	b.ne	.LBB40_68
	ldrb	w8, [x1, #6]
	cmp	w8, #115
	b.ne	.LBB40_68
	ldrb	w8, [x1, #7]
	cmp	w8, #115
	b.ne	.LBB40_68
	ldrb	w8, [x1, #8]
	cmp	w8, #45
	b.ne	.LBB40_68
	ldrb	w8, [x1, #9]
	cmp	w8, #99
	b.ne	.LBB40_68
	ldrb	w8, [x1, #10]
	cmp	w8, #101
	b.ne	.LBB40_68
	ldrb	w8, [x1, #11]
	cmp	w8, #108
	b.ne	.LBB40_68
	ldrb	w8, [x1, #12]
	cmp	w8, #108
	b.ne	.LBB40_68
	ldrb	w8, [x1, #13]
	cmp	w8, #115
	b.ne	.LBB40_68
	ldrb	w11, [x1, #2]
	ldrb	w8, [x1, #1]
	mov	x13, x1
	ldrb	w10, [x1]
	ldrb	w12, [x1, #3]
	mov	x14, x1
	lsl	x11, x11, #16
	ldrb	w15, [x13, #4]!
	ldrb	w16, [x13, #2]
	ldrb	w17, [x14, #8]!
	ldrb	w18, [x14, #2]
	orr	x8, x10, x8, lsl #8
	orr	x10, x11, x12, lsl #24
	ldrb	w11, [x1, #5]
	ldrb	w12, [x13, #3]
	lsl	w13, w16, #16
	ldrb	w16, [x1, #9]
	ldrb	w5, [x14, #3]
	lsl	x18, x18, #16
	orr	w11, w15, w11, lsl #8
	ldrb	w15, [x14, #5]
	ldrb	w14, [x14, #4]
	orr	w12, w13, w12, lsl #24
	orr	x13, x17, x16, lsl #8
	orr	x16, x18, x5, lsl #24
	orr	w14, w14, w15, lsl #8
	orr	x8, x10, x8
	orr	w10, w12, w11
	orr	x11, x16, x13
	mov	x12, #25389
	orr	x8, x8, x10, lsl #32
	orr	x10, x11, x14, lsl #32
	mov	x11, #24867
	movk	x11, #25700, lsl #16
	movk	x12, #27749, lsl #16
	movk	x11, #25970, lsl #32
	movk	x12, #29548, lsl #32
	movk	x11, #29555, lsl #48
	eor	x10, x10, x12
	eor	x8, x8, x11
	orr	x8, x8, x10
	cmp	x8, #0
	mov	w8, #1
	cinc	w8, w8, ne
	b	.LBB40_51
.LBB40_32:
	cmp	x2, #3
	b.eq	.LBB40_34
	cmp	w2, #6
	b.eq	.LBB40_63
	b	.LBB40_68
.LBB40_34:
	ldrb	w8, [x1, #1]
	ldrb	w10, [x1]
	orr	w8, w10, w8, lsl #8
	ldrb	w10, [x1, #2]
	orr	w8, w8, w10, lsl #16
	sub	w8, w8, #1654, lsl #12
	cmp	w8, #1394
	b.ne	.LBB40_68
	ldrb	w8, [x0, #16]
	tbnz	w8, #3, .LBB40_85
	orr	w8, w8, #0x8
	strb	w8, [x0, #16]
	mov	w8, #2
	cbz	x4, .LBB40_118
	and	x10, x4, #0xf
	cbnz	x10, .LBB40_118
	stp	x3, x4, [x0]
	b	.LBB40_68
.LBB40_39:
	ldrb	w8, [x1]
	cmp	w8, #35
	b.ne	.LBB40_68
	ldrb	w8, [x1, #1]
	cmp	w8, #115
	b.ne	.LBB40_68
	ldrb	w8, [x1, #2]
	cmp	w8, #105
	b.ne	.LBB40_68
	ldrb	w8, [x1, #3]
	cmp	w8, #122
	b.ne	.LBB40_68
	ldrb	w8, [x1, #4]
	cmp	w8, #101
	b.ne	.LBB40_68
	ldrb	w8, [x1, #5]
	cmp	w8, #45
	b.ne	.LBB40_68
	ldrb	w8, [x1, #6]
	cmp	w8, #99
	b.ne	.LBB40_68
	ldrb	w8, [x1, #7]
	cmp	w8, #101
	b.ne	.LBB40_68
	ldrb	w8, [x1, #8]
	cmp	w8, #108
	b.ne	.LBB40_68
	ldrb	w8, [x1, #9]
	cmp	w8, #108
	b.ne	.LBB40_68
	ldrb	w8, [x1, #10]
	cmp	w8, #115
	b.ne	.LBB40_68
	mov	w8, #2
.LBB40_51:
	ldrb	w10, [x0, #16]
	tst	w10, w8
	b.ne	.LBB40_85
	orr	w8, w10, w8
	cmp	x4, #4
	strb	w8, [x0, #16]
	b.ne	.LBB40_117
	ldrb	w8, [x3, #2]
	ldrb	w10, [x3, #1]
	ldrb	w11, [x3]
	ldrb	w12, [x3, #3]
	lsl	w8, w8, #16
	orr	w10, w11, w10, lsl #8
	orr	w8, w8, w12, lsl #24
	orr	w8, w8, w10
	mov	w10, #33554432
	cmp	w8, w10
	b.eq	.LBB40_68
	b	.LBB40_117
.LBB40_54:
	ldrb	w8, [x1]
	cmp	w8, #114
	b.ne	.LBB40_63
	ldrb	w8, [x1, #1]
	cmp	w8, #97
	b.ne	.LBB40_63
	ldrb	w8, [x1, #2]
	cmp	w8, #110
	b.ne	.LBB40_63
	ldrb	w8, [x1, #3]
	cmp	w8, #103
	b.ne	.LBB40_63
	ldrb	w8, [x1, #4]
	cmp	w8, #101
	b.ne	.LBB40_63
	cmp	w9, #2
	b.ne	.LBB40_63
	ldrb	w8, [x1, #5]
	cmp	w8, #115
	b.ne	.LBB40_63
	ldrb	w8, [x0, #16]
	tbnz	w8, #2, .LBB40_85
	orr	w8, w8, #0x4
	strb	w8, [x0, #16]
	cbnz	x4, .LBB40_117
.LBB40_63:
	ldrb	w8, [x1, #2]
	ldrb	w10, [x1, #1]
	ldrb	w11, [x1]
	ldrb	w12, [x1, #3]
	ldrb	w13, [x1, #5]
	ldrb	w14, [x1, #4]
	lsl	x8, x8, #16
	orr	x10, x11, x10, lsl #8
	orr	w11, w14, w13, lsl #8
	orr	x8, x8, x12, lsl #24
	orr	x8, x8, x10
	mov	x10, #29811
	orr	x8, x8, x11, lsl #32
	movk	x10, #29793, lsl #16
	movk	x10, #29557, lsl #32
	cmp	x8, x10
	b.ne	.LBB40_68
	ldrb	w8, [x0, #16]
	tbnz	w8, #5, .LBB40_85
	orr	w8, w8, #0x20
	cmp	x4, #3
	strb	w8, [x0, #16]
	b.eq	.LBB40_116
	cmp	w4, #5
	b.ne	.LBB40_117
	ldrb	w8, [x3, #2]
	ldrb	w10, [x3, #1]
	ldrb	w11, [x3]
	ldrb	w12, [x3, #3]
	lsl	x8, x8, #16
	orr	x10, x11, x10, lsl #8
	ldrb	w11, [x3, #4]
	orr	x8, x8, x12, lsl #24
	orr	x8, x8, x10
	mov	w10, #27503
	orr	x8, x8, x11, lsl #32
	movk	w10, #31073, lsl #16
	cmp	x8, x10
	b.ne	.LBB40_117
.LBB40_68:
	and	w8, w9, #0x6
	cmp	w8, #2
	b.ne	.LBB40_115
	cmp	w2, #7
	mov	w8, #255
	b.le	.LBB40_86
	cmp	w2, #8
	b.eq	.LBB40_94
	cmp	w2, #9
	b.eq	.LBB40_102
	cmp	w2, #12
	b.ne	.LBB40_118
	ldrb	w8, [x1]
	cmp	w8, #97
	b.ne	.LBB40_115
	ldrb	w8, [x1, #1]
	cmp	w8, #108
	b.ne	.LBB40_115
	ldrb	w8, [x1, #2]
	cmp	w8, #108
	b.ne	.LBB40_115
	ldrb	w8, [x1, #3]
	cmp	w8, #111
	b.ne	.LBB40_115
	ldrb	w8, [x1, #4]
	cmp	w8, #99
	b.ne	.LBB40_115
	ldrb	w8, [x1, #5]
	cmp	w8, #45
	b.ne	.LBB40_115
	ldrb	w8, [x1, #6]
	cmp	w8, #114
	b.ne	.LBB40_115
	ldrb	w8, [x1, #7]
	cmp	w8, #97
	b.ne	.LBB40_115
	ldrb	w8, [x1, #8]
	cmp	w8, #110
	b.ne	.LBB40_115
	ldrb	w8, [x1, #9]
	cmp	w8, #103
	b.ne	.LBB40_115
	ldrb	w8, [x1, #10]
	cmp	w8, #101
	b.ne	.LBB40_115
	mov	w8, #115
	mov	w9, #11
	ldrb	w9, [x1, x9]
	cmp	w9, w8
	mov	w8, #3
	csinv	w0, w8, wzr, eq
	ret
.LBB40_85:
	mov	w0, #4
	ret
.LBB40_86:
	cmp	w2, #4
	b.eq	.LBB40_111
	cmp	w2, #6
	b.ne	.LBB40_118
	ldrb	w8, [x1]
	cmp	w8, #110
	b.ne	.LBB40_115
	ldrb	w8, [x1, #1]
	cmp	w8, #111
	b.ne	.LBB40_115
	ldrb	w8, [x1, #2]
	cmp	w8, #45
	b.ne	.LBB40_115
	ldrb	w8, [x1, #3]
	cmp	w8, #109
	b.ne	.LBB40_115
	ldrb	w8, [x1, #4]
	cmp	w8, #97
	b.ne	.LBB40_115
	mov	w8, #112
	mov	w9, #5
	ldrb	w9, [x1, x9]
	cmp	w9, w8
	mov	w8, #3
	csinv	w0, w8, wzr, eq
	ret
.LBB40_94:
	ldrb	w8, [x1]
	cmp	w8, #114
	b.ne	.LBB40_115
	ldrb	w8, [x1, #1]
	cmp	w8, #101
	b.ne	.LBB40_115
	ldrb	w8, [x1, #2]
	cmp	w8, #117
	b.ne	.LBB40_115
	ldrb	w8, [x1, #3]
	cmp	w8, #115
	b.ne	.LBB40_115
	ldrb	w8, [x1, #4]
	cmp	w8, #97
	b.ne	.LBB40_115
	ldrb	w8, [x1, #5]
	cmp	w8, #98
	b.ne	.LBB40_115
	ldrb	w8, [x1, #6]
	cmp	w8, #108
	b.ne	.LBB40_115
	mov	w8, #101
	mov	w9, #7
	ldrb	w9, [x1, x9]
	cmp	w9, w8
	mov	w8, #3
	csinv	w0, w8, wzr, eq
	ret
.LBB40_102:
	ldrb	w8, [x1]
	cmp	w8, #97
	b.ne	.LBB40_115
	ldrb	w8, [x1, #1]
	cmp	w8, #108
	b.ne	.LBB40_115
	ldrb	w8, [x1, #2]
	cmp	w8, #105
	b.ne	.LBB40_115
	ldrb	w8, [x1, #3]
	cmp	w8, #103
	b.ne	.LBB40_115
	ldrb	w8, [x1, #4]
	cmp	w8, #110
	b.ne	.LBB40_115
	ldrb	w8, [x1, #5]
	cmp	w8, #109
	b.ne	.LBB40_115
	ldrb	w8, [x1, #6]
	cmp	w8, #101
	b.ne	.LBB40_115
	ldrb	w8, [x1, #7]
	cmp	w8, #110
	b.ne	.LBB40_115
	mov	w8, #116
	mov	w9, #8
	ldrb	w9, [x1, x9]
	cmp	w9, w8
	mov	w8, #3
	csinv	w0, w8, wzr, eq
	ret
.LBB40_111:
	ldrb	w8, [x1]
	cmp	w8, #115
	b.ne	.LBB40_115
	ldrb	w8, [x1, #1]
	cmp	w8, #105
	b.ne	.LBB40_115
	ldrb	w8, [x1, #2]
	cmp	w8, #122
	b.ne	.LBB40_115
	mov	w8, #101
	mov	w9, #3
	ldrb	w9, [x1, x9]
	cmp	w9, w8
	mov	w8, #3
	csinv	w0, w8, wzr, eq
	ret
.LBB40_115:
	mov	w0, #255
	ret
.LBB40_116:
	ldrb	w8, [x3, #1]
	ldrb	w10, [x3]
	orr	w8, w10, w8, lsl #8
	ldrb	w10, [x3, #2]
	orr	w8, w8, w10, lsl #16
	mov	w10, #27503
	cmp	w8, w10
	b.eq	.LBB40_68
.LBB40_117:
	mov	w8, #3
.LBB40_118:
	mov	w0, w8
	ret
.Lfunc_end40:
	.size	_RNvMs1_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_4Node8property, .Lfunc_end40-_RNvMs1_NtCsjStpv0Kdcdo_9hm_kernel11boot_memoryNtB5_4Node8property
	.cfi_endproc

	.section	.text._RNvMs_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtB4_6Cursor4name,"ax",@progbits
	.p2align	2
	.type	_RNvMs_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtB4_6Cursor4name,@function
_RNvMs_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtB4_6Cursor4name:
.Lfunc_begin41:
	.cfi_startproc
	stp	x30, x21, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_remember_state
	ldp	x9, x10, [x1, #8]
	subs	x11, x9, x10
	b.hs	.LBB41_2
.LBB41_1:
	mov	w8, #1
	strb	w8, [x0, #8]
	str	xzr, [x0]
	ldp	x20, x19, [sp, #16]
	ldp	x30, x21, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	ret
.LBB41_2:
	.cfi_restore_state
	.cfi_remember_state
	b.eq	.LBB41_6
	ldr	x8, [x1]
	mov	x19, xzr
	add	x20, x8, x10
.LBB41_4:
	ldrb	w12, [x20, x19]
	cbz	w12, .LBB41_7
	add	x19, x19, #1
	cmp	x11, x19
	b.ne	.LBB41_4
.LBB41_6:
	mov	w8, #2
	strb	w8, [x0, #8]
	str	xzr, [x0]
	ldp	x20, x19, [sp, #16]
	ldp	x30, x21, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	ret
.LBB41_7:
	.cfi_restore_state
	.cfi_remember_state
	add	x11, x10, x19
	add	x11, x11, #1
	cmp	x11, x10
	b.lo	.LBB41_1
	cmp	x11, x9
	b.hi	.LBB41_1
	neg	w10, w11
	str	x11, [x1, #16]
	and	x10, x10, #0x3
	adds	x12, x10, x11
	cset	w13, hs
	cmp	x12, x9
	csinc	w9, w13, wzr, ls
	tbz	w9, #0, .LBB41_11
	mov	w8, #1
	strb	w8, [x0, #8]
	str	xzr, [x0]
	ldp	x20, x19, [sp, #16]
	ldp	x30, x21, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	ret
.LBB41_11:
	.cfi_restore_state
	.cfi_remember_state
	str	x12, [x1, #16]
	cbz	x10, .LBB41_14
	add	x8, x8, x11
	ldrb	w9, [x8]
	cbnz	w9, .LBB41_6
	cmp	x10, #1
	b.ne	.LBB41_21
.LBB41_14:
	cmp	x19, #15
	b.hi	.LBB41_19
	cbz	x19, .LBB41_20
	mov	x8, xzr
.LBB41_17:
	ldrb	w9, [x20, x8]
	cmp	w9, #47
	b.eq	.LBB41_6
	add	x8, x8, #1
	cmp	x19, x8
	b.ne	.LBB41_17
	b	.LBB41_20
.LBB41_19:
	mov	x21, x0
	mov	x0, x20
	mov	x1, x19
	bl	_RNvNtNtCsboyoyqK6YBz_4core5slice6memchr14memchr_aligned
	mov	x8, x0
	mov	x0, x21
	tbnz	w8, #0, .LBB41_6
.LBB41_20:
	stp	x20, x19, [x0]
	ldp	x20, x19, [sp, #16]
	ldp	x30, x21, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	ret
.LBB41_21:
	.cfi_restore_state
	ldrb	w9, [x8, #1]
	cbnz	w9, .LBB41_6
	cmp	x10, #2
	b.eq	.LBB41_14
	ldrb	w8, [x8, #2]
	cbnz	w8, .LBB41_6
	b	.LBB41_14
.Lfunc_end41:
	.size	_RNvMs_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtB4_6Cursor4name, .Lfunc_end41-_RNvMs_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtB4_6Cursor4name
	.cfi_endproc

	.section	.text._RNvNtCsjStpv0Kdcdo_9hm_kernel12cpu_topology12unit_address,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsjStpv0Kdcdo_9hm_kernel12cpu_topology12unit_address,@function
_RNvNtCsjStpv0Kdcdo_9hm_kernel12cpu_topology12unit_address:
.Lfunc_begin42:
	.cfi_startproc
	ldrb	w9, [x1, #2]
	ldrb	w10, [x1, #1]
	mov	w8, #28771
	ldrb	w11, [x1]
	ldrb	w12, [x1, #3]
	movk	w8, #16501, lsl #16
	lsl	w9, w9, #16
	orr	w10, w11, w10, lsl #8
	orr	w9, w9, w12, lsl #24
	orr	w9, w9, w10
	cmp	w9, w8
	b.eq	.LBB42_2
.LBB42_1:
	mov	w8, #3
	mov	w9, #1
	strb	w8, [x0, #1]
	strb	w9, [x0]
	ret
.LBB42_2:
	sub	x8, x2, #21
	cmn	x8, #16
	b.hs	.LBB42_4
.LBB42_3:
	mov	w8, #2
	mov	w9, #1
	strb	w8, [x0, #1]
	strb	w9, [x0]
	ret
.LBB42_4:
	mov	x8, xzr
	add	x9, x1, #4
	sub	x10, x2, #4
.LBB42_5:
	ldrb	w12, [x9], #1
	sub	w11, w12, #48
	cmp	w11, #10
	b.lo	.LBB42_8
	sub	w11, w12, #97
	cmp	w11, #5
	b.hi	.LBB42_3
	sub	w11, w12, #87
.LBB42_8:
	lsr	x12, x8, #60
	cbnz	x12, .LBB42_1
	lsl	x8, x8, #4
	subs	x10, x10, #1
	add	x8, x8, w11, uxtb
	b.ne	.LBB42_5
	str	x8, [x0, #8]
	strb	wzr, [x0]
	ret
.Lfunc_end42:
	.size	_RNvNtCsjStpv0Kdcdo_9hm_kernel12cpu_topology12unit_address, .Lfunc_end42-_RNvNtCsjStpv0Kdcdo_9hm_kernel12cpu_topology12unit_address
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtB5_4Node8property,"ax",@progbits
	.p2align	2
	.type	_RNvMs0_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtB5_4Node8property,@function
_RNvMs0_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtB5_4Node8property:
.Lfunc_begin43:
	.cfi_startproc
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x29, x30, [sp, #32]
	stp	x28, x27, [sp, #48]
	stp	x26, x25, [sp, #64]
	stp	x24, x23, [sp, #80]
	stp	x22, x21, [sp, #96]
	stp	x20, x19, [sp, #112]
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_remember_state
	ldrb	w8, [x0, #184]
	tbz	w8, #0, .LBB43_2
.LBB43_1:
	mov	w0, #2
	b	.LBB43_4
.LBB43_2:
	mov	w9, w3
	subs	x8, x2, x9
	b.hs	.LBB43_5
.LBB43_3:
	mov	w0, #1
.LBB43_4:
	ldp	x20, x19, [sp, #112]
	ldp	x22, x21, [sp, #96]
	ldp	x24, x23, [sp, #80]
	ldp	x26, x25, [sp, #64]
	ldp	x28, x27, [sp, #48]
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB43_5:
	.cfi_restore_state
	b.eq	.LBB43_1
	mov	x20, xzr
	add	x19, x1, x9
.LBB43_7:
	ldrb	w9, [x19, x20]
	cbz	w9, .LBB43_9
	add	x20, x20, #1
	cmp	x8, x20
	b.ne	.LBB43_7
	b	.LBB43_1
.LBB43_9:
	cbz	x20, .LBB43_1
	ldr	x21, [x0, #160]
	cmp	x21, #33
	b.hs	.LBB43_188
	add	x23, x0, #32
	add	x22, x23, x21, lsl #2
	cbz	x21, .LBB43_22
.LBB43_12:
	ldr	w8, [x23], #4
	cmp	x2, x8
	b.lo	.LBB43_3
	subs	x9, x2, x8
	b.eq	.LBB43_1
	mov	x24, x2
	mov	x10, x0
	mov	x11, xzr
	mov	x25, x1
	add	x8, x1, x8
.LBB43_15:
	ldrb	w12, [x8, x11]
	cbz	w12, .LBB43_17
	add	x11, x11, #1
	mov	w0, #2
	cmp	x9, x11
	b.ne	.LBB43_15
	b	.LBB43_4
.LBB43_17:
	cmp	x11, x20
	mov	x0, x10
	b.ne	.LBB43_19
	mov	x26, x0
	mov	x0, x8
	mov	x1, x19
	mov	x2, x20
	mov	x27, x4
	mov	x29, x5
	mov	w28, w3
	bl	memcmp
	mov	w3, w28
	mov	x5, x29
	mov	x4, x27
	mov	w8, w0
	mov	x0, x26
	cbz	w8, .LBB43_165
.LBB43_19:
	cmp	x23, x22
	mov	x2, x24
	mov	x1, x25
	b.ne	.LBB43_12
	cmp	x21, #32
	b.ne	.LBB43_22
	mov	w0, #5
	b	.LBB43_4
.LBB43_22:
	str	w3, [x22]
	cmp	x20, #10
	ldr	x8, [x0, #160]
	add	x8, x8, #1
	str	x8, [x0, #160]
	b.eq	.LBB43_29
	cmp	x20, #11
	b.ne	.LBB43_32
	mov	x10, x19
	ldrb	w8, [x19, #1]
	ldrb	w9, [x19]
	ldrb	w11, [x19, #2]
	ldrb	w12, [x10, #4]!
	ldrb	w13, [x10, #2]
	orr	x8, x9, x8, lsl #8
	ldrb	w9, [x19, #3]
	lsl	x11, x11, #16
	ldrb	w14, [x19, #5]
	ldrb	w10, [x10, #3]
	lsl	w13, w13, #16
	mov	x15, x19
	ldrb	w16, [x19, #9]
	ldrb	w17, [x15, #8]!
	orr	x9, x11, x9, lsl #24
	orr	w11, w12, w14, lsl #8
	orr	w10, w13, w10, lsl #24
	ldrb	w13, [x15, #2]
	orr	x12, x17, x16, lsl #8
	orr	x8, x9, x8
	orr	w9, w10, w11
	mov	x10, #25956
	mov	w11, #28793
	movk	x10, #26998, lsl #16
	orr	x8, x8, x9, lsl #32
	orr	x9, x12, x13, lsl #16
	movk	x10, #25955, lsl #32
	movk	w11, #101, lsl #16
	movk	x10, #29791, lsl #48
	eor	x9, x9, x11
	eor	x8, x8, x10
	orr	x8, x8, x9
	cbnz	x8, .LBB43_47
	cbz	x5, .LBB43_1
	mov	x8, x0
	mov	x9, xzr
	mov	w0, #2
.LBB43_27:
	ldrb	w10, [x4, x9]
	cbz	w10, .LBB43_41
	add	x9, x9, #1
	cmp	x5, x9
	b.ne	.LBB43_27
	b	.LBB43_4
.LBB43_29:
	mov	x10, x19
	ldrb	w9, [x19, #2]
	ldrb	w8, [x19, #1]
	ldrb	w11, [x10, #4]!
	ldrb	w12, [x10, #2]
	ldrb	w13, [x19]
	ldrb	w14, [x19, #3]
	lsl	x9, x9, #16
	ldrb	w15, [x19, #5]
	ldrb	w10, [x10, #3]
	lsl	w12, w12, #16
	orr	x8, x13, x8, lsl #8
	orr	x9, x9, x14, lsl #24
	ldrb	w13, [x19, #8]
	orr	w11, w11, w15, lsl #8
	orr	w10, w12, w10, lsl #24
	ldrb	w12, [x19, #9]
	orr	x8, x9, x8
	orr	w9, w10, w11
	mov	x10, #28515
	mov	w11, #25964
	movk	x10, #28781, lsl #16
	orr	x8, x8, x9, lsl #32
	orr	x9, x13, x12, lsl #8
	movk	x10, #29793, lsl #32
	movk	x10, #25193, lsl #48
	eor	x9, x9, x11
	eor	x8, x8, x10
	orr	x8, x8, x9
	cbnz	x8, .LBB43_47
	mov	x24, x0
	mov	x0, x4
	mov	x1, x5
	mov	x21, x4
	mov	x22, x5
	bl	_RNvNtCsjStpv0Kdcdo_9hm_kernel12cpu_topology10compatible
	and	w23, w0, #0xffff
	and	w8, w23, #0xff
	cmp	w8, #2
	b.ne	.LBB43_39
	lsr	w0, w23, #8
	b	.LBB43_4
.LBB43_32:
	ldrb	w8, [x0, #190]
	cmp	w8, #4
	ccmp	x20, #6, #0, ne
	b.ne	.LBB43_48
.LBB43_33:
	ldrb	w9, [x19, #2]
	ldrb	w10, [x19, #1]
	ldrb	w11, [x19]
	ldrb	w12, [x19, #3]
	ldrb	w13, [x19, #5]
	ldrb	w14, [x19, #4]
	lsl	x9, x9, #16
	orr	x10, x11, x10, lsl #8
	orr	w11, w14, w13, lsl #8
	orr	x9, x9, x12, lsl #24
	orr	x9, x9, x10
	mov	x10, #29811
	orr	x9, x9, x11, lsl #32
	movk	x10, #29793, lsl #16
	movk	x10, #29557, lsl #32
	cmp	x9, x10
	b.ne	.LBB43_38
	cbz	x5, .LBB43_1
	mov	x9, x0
	mov	x10, xzr
	mov	w0, #2
.LBB43_36:
	ldrb	w11, [x4, x10]
	cbz	w11, .LBB43_158
	add	x10, x10, #1
	cmp	x5, x10
	b.ne	.LBB43_36
	b	.LBB43_4
.LBB43_38:
	mov	w20, #6
	b	.LBB43_48
.LBB43_39:
	tbz	w23, #0, .LBB43_45
	ldrb	w8, [x24, #190]
	mov	x0, x24
	cmp	w8, #3
	b.ne	.LBB43_197
	b	.LBB43_46
.LBB43_41:
	add	x10, x9, #1
	cmp	x10, x5
	b.ne	.LBB43_1
	mov	x0, x8
	ldrb	w8, [x8, #190]
	cmp	x9, #3
	b.ne	.LBB43_182
	ldrb	w9, [x4, #1]
	ldrb	w10, [x4]
	cmp	w8, #2
	cset	w11, eq
	orr	w9, w10, w9, lsl #8
	ldrb	w10, [x4, #2]
	orr	w9, w9, w10, lsl #16
	mov	w10, #28771
	movk	w10, #117, lsl #16
	cmp	w9, w10
	cset	w12, eq
	eor	w11, w11, w12
	tbnz	w11, #0, .LBB43_197
	cmp	w9, w10
	cset	w9, eq
	b	.LBB43_184
.LBB43_45:
	add	x0, sp, #8
	stp	x21, x22, [sp, #8]
	strb	wzr, [sp, #24]
	bl	_RINvYINtNtNtCsboyoyqK6YBz_4core5slice4iter5SplithNCNvMs0_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_
	ldrb	w9, [x24, #190]
	mov	w8, w0
	mov	x0, x24
	cmp	w9, #3
	csel	w8, wzr, w8, eq
	tbnz	w8, #0, .LBB43_197
.LBB43_46:
	strh	w23, [x0, #188]
	mov	x4, x21
	mov	x5, x22
.LBB43_47:
	ldrb	w8, [x0, #190]
.LBB43_48:
	cmp	w8, #1
	b.eq	.LBB43_85
	cmp	w8, #2
	b.eq	.LBB43_66
	cmp	w8, #3
	b.ne	.LBB43_181
	cmp	x20, #6
	b.eq	.LBB43_147
	cmp	x20, #7
	b.eq	.LBB43_123
	cmp	x20, #11
	b.ne	.LBB43_181
	ldrb	w8, [x19]
	cmp	w8, #99
	b.ne	.LBB43_181
	ldrb	w8, [x19, #1]
	cmp	w8, #112
	b.ne	.LBB43_181
	ldrb	w8, [x19, #2]
	cmp	w8, #117
	b.ne	.LBB43_181
	ldrb	w8, [x19, #3]
	cmp	w8, #95
	b.ne	.LBB43_181
	ldrb	w8, [x19, #4]
	cmp	w8, #115
	b.ne	.LBB43_181
	ldrb	w8, [x19, #5]
	cmp	w8, #117
	b.ne	.LBB43_181
	ldrb	w8, [x19, #6]
	cmp	w8, #115
	b.ne	.LBB43_181
	ldrb	w8, [x19, #7]
	cmp	w8, #112
	b.ne	.LBB43_181
	ldrb	w8, [x19, #8]
	cmp	w8, #101
	b.ne	.LBB43_181
	ldrb	w8, [x19, #9]
	cmp	w8, #110
	b.ne	.LBB43_181
	ldrb	w8, [x19, #10]
	cmp	w8, #100
	b.ne	.LBB43_181
	mov	w8, #1
	movk	w8, #50176, lsl #16
	b	.LBB43_179
.LBB43_66:
	cmp	x20, #3
	b.eq	.LBB43_106
	cmp	x20, #13
	b.ne	.LBB43_181
	ldrb	w8, [x19]
	cmp	w8, #101
	b.ne	.LBB43_181
	ldrb	w8, [x19, #1]
	cmp	w8, #110
	b.ne	.LBB43_181
	ldrb	w8, [x19, #2]
	cmp	w8, #97
	b.ne	.LBB43_181
	ldrb	w9, [x19, #3]
	cmp	w9, #98
	b.ne	.LBB43_181
	ldrb	w9, [x19, #4]
	cmp	w9, #108
	b.ne	.LBB43_181
	ldrb	w9, [x19, #5]
	cmp	w9, #101
	b.ne	.LBB43_181
	ldrb	w9, [x19, #6]
	cmp	w9, #45
	b.ne	.LBB43_181
	ldrb	w9, [x19, #7]
	cmp	w9, #109
	b.ne	.LBB43_181
	ldrb	w9, [x19, #8]
	cmp	w9, #101
	b.ne	.LBB43_181
	ldrb	w9, [x19, #9]
	cmp	w9, #116
	b.ne	.LBB43_181
	ldrb	w9, [x19, #10]
	cmp	w9, #104
	b.ne	.LBB43_181
	ldrb	w9, [x19, #11]
	cmp	w9, #111
	b.ne	.LBB43_181
	ldrb	w9, [x19, #12]
	cmp	w9, #100
	b.ne	.LBB43_181
	cbz	x5, .LBB43_1
	mov	x8, x0
	mov	x9, xzr
	mov	x10, x4
	mov	w0, #2
.LBB43_83:
	ldrb	w10, [x10, x9]
	cbz	w10, .LBB43_193
	add	x9, x9, #1
	mov	x10, x4
	cmp	x5, x9
	b.ne	.LBB43_83
	b	.LBB43_4
.LBB43_85:
	cmp	x20, #11
	b.eq	.LBB43_132
	cmp	x20, #13
	b.eq	.LBB43_110
	cmp	x20, #14
	b.ne	.LBB43_181
	ldrb	w8, [x19]
	cmp	w8, #35
	b.ne	.LBB43_181
	ldrb	w8, [x19, #1]
	cmp	w8, #97
	b.ne	.LBB43_181
	ldrb	w8, [x19, #2]
	cmp	w8, #100
	b.ne	.LBB43_181
	ldrb	w9, [x19, #3]
	cmp	w9, #100
	b.ne	.LBB43_181
	ldrb	w9, [x19, #4]
	cmp	w9, #114
	b.ne	.LBB43_181
	ldrb	w9, [x19, #5]
	cmp	w9, #101
	b.ne	.LBB43_181
	ldrb	w9, [x19, #6]
	cmp	w9, #115
	b.ne	.LBB43_181
	ldrb	w9, [x19, #7]
	cmp	w9, #115
	b.ne	.LBB43_181
	ldrb	w9, [x19, #8]
	cmp	w9, #45
	b.ne	.LBB43_181
	ldrb	w9, [x19, #9]
	cmp	w9, #99
	b.ne	.LBB43_181
	ldrb	w9, [x19, #10]
	cmp	w9, #101
	b.ne	.LBB43_181
	ldrb	w9, [x19, #11]
	cmp	w9, #108
	b.ne	.LBB43_181
	ldrb	w9, [x19, #12]
	cmp	w9, #108
	b.ne	.LBB43_181
	ldrb	w9, [x19, #13]
	cmp	w9, #115
	b.ne	.LBB43_181
	cmp	x5, #4
	b.ne	.LBB43_1
	mov	x11, x19
	ldrb	w12, [x19, #2]
	mov	x8, x0
	ldrb	w13, [x11, #4]!
	ldrb	w14, [x11, #2]
	ldrb	w9, [x19, #1]
	ldrb	w10, [x19]
	ldrb	w15, [x19, #3]
	ldrb	w16, [x19, #5]
	ldrb	w11, [x11, #3]
	lsl	x12, x12, #16
	lsl	w14, w14, #16
	ldrb	w17, [x19, #9]
	orr	x9, x10, x9, lsl #8
	ldrb	w18, [x19, #8]!
	ldrb	w0, [x19, #2]
	orr	x10, x12, x15, lsl #24
	orr	w12, w13, w16, lsl #8
	orr	w11, w14, w11, lsl #24
	ldrb	w13, [x19, #3]
	lsl	x14, x0, #16
	ldrb	w15, [x19, #4]
	orr	x9, x10, x9
	ldrb	w10, [x19, #5]
	orr	w11, w11, w12
	orr	x12, x18, x17, lsl #8
	orr	x13, x14, x13, lsl #24
	ldrb	w14, [x4, #1]
	orr	w10, w15, w10, lsl #8
	orr	x9, x9, x11, lsl #32
	ldrb	w11, [x4, #2]
	orr	x12, x13, x12
	ldrb	w13, [x4]
	ldrb	w15, [x4, #3]
	orr	x10, x12, x10, lsl #32
	lsl	w11, w11, #16
	orr	w12, w13, w14, lsl #8
	mov	x13, #24867
	mov	x14, #25389
	movk	x13, #25700, lsl #16
	movk	x14, #27749, lsl #16
	orr	w11, w11, w15, lsl #24
	movk	x13, #25970, lsl #32
	movk	x14, #29548, lsl #32
	movk	x13, #29555, lsl #48
	eor	x10, x10, x14
	eor	x9, x9, x13
	orr	x10, x9, x10
	orr	w9, w11, w12
	cbnz	x10, .LBB43_145
	rev	w9, w9
	sub	w10, w9, #1
	cmp	w10, #1
	b.hi	.LBB43_197
	mov	w10, #1
	mov	w0, #255
	stp	w10, w9, [x8, #16]
	b	.LBB43_4
.LBB43_106:
	ldrb	w8, [x19]
	cmp	w8, #114
	b.ne	.LBB43_181
	ldrb	w8, [x19, #1]
	cmp	w8, #101
	b.ne	.LBB43_181
	ldrb	w8, [x19, #2]
	cmp	w8, #103
	b.ne	.LBB43_181
	mov	x8, x0
	str	x4, [x0, #168]
	mov	w0, #255
	str	x5, [x8, #176]
	b	.LBB43_4
.LBB43_110:
	ldrb	w8, [x19]
	cmp	w8, #101
	b.ne	.LBB43_181
	ldrb	w8, [x19, #1]
	cmp	w8, #110
	b.ne	.LBB43_181
	ldrb	w8, [x19, #2]
	cmp	w8, #97
	b.ne	.LBB43_181
	ldrb	w8, [x19, #3]
	cmp	w8, #98
	b.ne	.LBB43_181
	ldrb	w8, [x19, #4]
	cmp	w8, #108
	b.ne	.LBB43_181
	ldrb	w8, [x19, #5]
	cmp	w8, #101
	b.ne	.LBB43_181
	ldrb	w8, [x19, #6]
	cmp	w8, #45
	b.ne	.LBB43_181
	ldrb	w8, [x19, #7]
	cmp	w8, #109
	b.ne	.LBB43_181
	ldrb	w8, [x19, #8]
	cmp	w8, #101
	b.ne	.LBB43_181
	ldrb	w8, [x19, #9]
	cmp	w8, #116
	b.ne	.LBB43_181
	ldrb	w8, [x19, #10]
	cmp	w8, #104
	b.ne	.LBB43_181
	ldrb	w8, [x19, #11]
	cmp	w8, #111
	b.ne	.LBB43_181
	ldrb	w8, [x19, #12]
	cmp	w8, #100
	mov	w8, #3
	csinv	w0, w8, wzr, eq
	b	.LBB43_4
.LBB43_123:
	ldrb	w8, [x19]
	cmp	w8, #109
	b.eq	.LBB43_166
	cmp	w8, #99
	b.ne	.LBB43_181
	ldrb	w8, [x19, #1]
	cmp	w8, #112
	b.ne	.LBB43_181
	ldrb	w8, [x19, #2]
	cmp	w8, #117
	b.ne	.LBB43_181
	ldrb	w8, [x19, #3]
	cmp	w8, #95
	b.ne	.LBB43_181
	ldrb	w8, [x19, #4]
	cmp	w8, #111
	b.ne	.LBB43_181
	ldrb	w8, [x19, #5]
	cmp	w8, #102
	b.ne	.LBB43_181
	ldrb	w8, [x19, #6]
	cmp	w8, #102
	b.ne	.LBB43_181
	mov	w8, #2
	movk	w8, #33792, lsl #16
	b	.LBB43_179
.LBB43_132:
	ldrb	w8, [x19]
	cmp	w8, #35
	b.ne	.LBB43_181
	ldrb	w8, [x19, #1]
	cmp	w8, #115
	b.ne	.LBB43_181
	ldrb	w8, [x19, #2]
	cmp	w8, #105
	b.ne	.LBB43_181
	ldrb	w9, [x19, #3]
	cmp	w9, #122
	b.ne	.LBB43_181
	ldrb	w9, [x19, #4]
	cmp	w9, #101
	b.ne	.LBB43_181
	ldrb	w9, [x19, #5]
	cmp	w9, #45
	b.ne	.LBB43_181
	ldrb	w9, [x19, #6]
	cmp	w9, #99
	b.ne	.LBB43_181
	ldrb	w9, [x19, #7]
	cmp	w9, #101
	b.ne	.LBB43_181
	ldrb	w9, [x19, #8]
	cmp	w9, #108
	b.ne	.LBB43_181
	ldrb	w9, [x19, #9]
	cmp	w9, #108
	b.ne	.LBB43_181
	ldrb	w9, [x19, #10]
	cmp	w9, #115
	b.ne	.LBB43_181
	mov	x8, x0
	cmp	x5, #4
	b.ne	.LBB43_1
	ldrb	w9, [x4, #2]
	ldrb	w10, [x4, #1]
	ldrb	w11, [x4]
	ldrb	w12, [x4, #3]
	lsl	w9, w9, #16
	orr	w10, w11, w10, lsl #8
	orr	w9, w9, w12, lsl #24
	orr	w9, w9, w10
.LBB43_145:
	cbnz	w9, .LBB43_197
	mov	w9, #1
	mov	w0, #255
	str	x9, [x8, #24]
	b	.LBB43_4
.LBB43_147:
	ldrb	w8, [x19]
	cmp	w8, #99
	b.eq	.LBB43_173
	cmp	w8, #109
	b.ne	.LBB43_181
	ldrb	w8, [x19, #1]
	cmp	w8, #101
	b.ne	.LBB43_181
	ldrb	w9, [x19, #2]
	cmp	w9, #116
	b.ne	.LBB43_181
	ldrb	w9, [x19, #3]
	cmp	w9, #104
	b.ne	.LBB43_181
	ldrb	w9, [x19, #4]
	cmp	w9, #111
	b.ne	.LBB43_181
	ldrb	w9, [x19, #5]
	cmp	w9, #100
	b.ne	.LBB43_181
	cbz	x5, .LBB43_1
	mov	x8, x0
	mov	x9, xzr
	mov	x10, x4
	mov	w0, #2
.LBB43_156:
	ldrb	w11, [x10, x9]
	cbz	w11, .LBB43_189
	add	x9, x9, #1
	cmp	x5, x9
	b.ne	.LBB43_156
	b	.LBB43_4
.LBB43_158:
	add	x11, x10, #1
	cmp	x11, x5
	b.ne	.LBB43_1
	cmp	x10, #2
	b.eq	.LBB43_185
	cmp	x10, #4
	b.ne	.LBB43_197
	ldrb	w11, [x4]
	cmp	w11, #111
	b.ne	.LBB43_197
	ldrb	w11, [x4, #1]
	mov	x10, x4
	cmp	w11, #107
	b.ne	.LBB43_197
	ldrb	w11, [x10, #2]
	cmp	w11, #97
	b.ne	.LBB43_197
	ldrb	w11, [x10, #3]
	cmp	w11, #121
	b.ne	.LBB43_197
	b	.LBB43_187
.LBB43_165:
	mov	w0, #4
	b	.LBB43_4
.LBB43_166:
	ldrb	w8, [x19, #1]
	cmp	w8, #105
	b.ne	.LBB43_181
	ldrb	w8, [x19, #2]
	cmp	w8, #103
	b.ne	.LBB43_181
	ldrb	w8, [x19, #3]
	cmp	w8, #114
	b.ne	.LBB43_181
	ldrb	w8, [x19, #4]
	cmp	w8, #97
	b.ne	.LBB43_181
	ldrb	w8, [x19, #5]
	cmp	w8, #116
	b.ne	.LBB43_181
	ldrb	w8, [x19, #6]
	cmp	w8, #101
	b.ne	.LBB43_181
	mov	w8, #1
	movk	w8, #50176, lsl #16
	orr	w8, w8, #0x4
	b	.LBB43_179
.LBB43_173:
	ldrb	w8, [x19, #1]
	cmp	w8, #112
	b.ne	.LBB43_181
	ldrb	w8, [x19, #2]
	cmp	w8, #117
	b.ne	.LBB43_181
	ldrb	w8, [x19, #3]
	cmp	w8, #95
	b.ne	.LBB43_181
	ldrb	w8, [x19, #4]
	cmp	w8, #111
	b.ne	.LBB43_181
	ldrb	w8, [x19, #5]
	cmp	w8, #110
	b.ne	.LBB43_181
	mov	w8, #1
	movk	w8, #50176, lsl #16
	orr	w8, w8, #0x2
.LBB43_179:
	cmp	x5, #4
	b.ne	.LBB43_1
	ldrb	w9, [x4, #2]
	ldrb	w10, [x4, #1]
	ldrb	w11, [x4]
	ldrb	w12, [x4, #3]
	lsl	w9, w9, #16
	orr	w10, w11, w10, lsl #8
	orr	w9, w9, w12, lsl #24
	orr	w9, w9, w10
	rev	w9, w9
	cmp	w8, w9
	mov	w8, #3
	csinv	w0, w8, wzr, ne
	b	.LBB43_4
.LBB43_181:
	mov	w0, #255
	b	.LBB43_4
.LBB43_182:
	cmp	w8, #2
	b.eq	.LBB43_197
	mov	w9, wzr
.LBB43_184:
	strb	w9, [x0, #185]
	cmp	w8, #4
	ccmp	x20, #6, #0, ne
	b.eq	.LBB43_33
	b	.LBB43_48
.LBB43_185:
	ldrb	w11, [x4]
	cmp	w11, #111
	b.ne	.LBB43_197
	ldrb	w11, [x4, #1]
	mov	x10, x4
	cmp	w11, #107
	b.ne	.LBB43_197
.LBB43_187:
	mov	w20, #6
	mov	x4, x10
	mov	x0, x9
	b	.LBB43_48
.LBB43_188:
	mov	x0, x21
	mov	w1, #32
	bl	_RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail
.LBB43_189:
	add	x10, x9, #1
	cmp	x10, x5
	b.ne	.LBB43_1
	cmp	x9, #3
	b.ne	.LBB43_197
	ldrb	w9, [x4, #1]
	ldrb	w10, [x4]
	orr	w9, w10, w9, lsl #8
	ldrb	w10, [x4, #2]
	orr	w9, w9, w10, lsl #16
	sub	w9, w9, #1591, lsl #12
	cmp	w9, #1640
	b.ne	.LBB43_197
	mov	w9, #1
	mov	w0, #255
	strb	w9, [x8, #187]
	b	.LBB43_4
.LBB43_193:
	add	x10, x9, #1
	cmp	x10, x5
	b.ne	.LBB43_1
	cmp	x9, #4
	b.ne	.LBB43_197
	ldrb	w9, [x4, #2]
	ldrb	w10, [x4, #1]
	ldrb	w11, [x4]
	ldrb	w12, [x4, #3]
	lsl	w9, w9, #16
	orr	w10, w11, w10, lsl #8
	orr	w9, w9, w12, lsl #24
	orr	w9, w9, w10
	mov	w10, #29552
	movk	w10, #26979, lsl #16
	cmp	w9, w10
	b.ne	.LBB43_197
	mov	w9, #1
	mov	w0, #255
	strb	w9, [x8, #186]
	b	.LBB43_4
.LBB43_197:
	mov	w0, #3
	b	.LBB43_4
.Lfunc_end43:
	.size	_RNvMs0_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtB5_4Node8property, .Lfunc_end43-_RNvMs0_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtB5_4Node8property
	.cfi_endproc

	.section	.text._RNvNtCsjStpv0Kdcdo_9hm_kernel12cpu_topology10compatible,"ax",@progbits
	.p2align	2
	.type	_RNvNtCsjStpv0Kdcdo_9hm_kernel12cpu_topology10compatible,@function
_RNvNtCsjStpv0Kdcdo_9hm_kernel12cpu_topology10compatible:
.Lfunc_begin44:
	.cfi_startproc
	cbz	x1, .LBB44_2
	sub	x10, x1, #1
	mov	x8, x0
	ldrb	w9, [x0, x10]
	cbz	w9, .LBB44_3
.LBB44_2:
	mov	w9, #2
	mov	w0, #2
	bfi	w0, w9, #8, #24
	ret
.LBB44_3:
	str	x19, [sp, #-16]!
	.cfi_def_cfa_offset 16
	.cfi_offset w19, -16
	.cfi_remember_state
	mov	x12, #29281
	mov	w11, #12333
	mov	w13, #12589
	movk	x12, #11373, lsl #16
	mov	w0, wzr
	movk	w11, #12846, lsl #16
	movk	x12, #29552, lsl #32
	movk	w13, #12334, lsl #16
	movk	x12, #26979, lsl #48
	b	.LBB44_5
.LBB44_4:
	mov	x18, x8
	ldrb	w2, [x8, #2]
	ldrb	w16, [x8, #1]
	ldrb	w3, [x18, #4]!
	ldrb	w5, [x18, #2]
	ldrb	w17, [x8]
	ldrb	w1, [x8, #3]
	lsl	x2, x2, #16
	ldrb	w4, [x8, #5]
	ldrb	w6, [x8, #9]
	lsl	w5, w5, #16
	ldrb	w7, [x8, #8]!
	ldrb	w19, [x8, #2]
	ldrb	w18, [x18, #3]
	orr	x16, x17, x16, lsl #8
	ldrb	w8, [x8, #3]
	lsl	x17, x19, #16
	orr	x1, x2, x1, lsl #24
	orr	w2, w3, w4, lsl #8
	orr	w18, w5, w18, lsl #24
	orr	x3, x7, x6, lsl #8
	orr	x8, x17, x8, lsl #24
	orr	x16, x1, x16
	orr	w17, w18, w2
	orr	x16, x16, x17, lsl #32
	orr	x8, x8, x3
	cmp	x8, x11
	cset	w17, eq
	cmp	x16, x12
	cset	w18, eq
	cmp	x8, x13
	csinc	w17, w17, wzr, ne
	csel	w8, wzr, w18, ne
	cmp	x16, x12
	csel	w16, wzr, w17, ne
	orr	w0, w0, w16
	orr	w9, w9, w8
	mov	x8, x15
	cbnz	w14, .LBB44_13
.LBB44_5:
	cbz	x10, .LBB44_14
	mov	x16, xzr
.LBB44_7:
	ldrb	w14, [x8, x16]
	cbz	w14, .LBB44_10
	add	x16, x16, #1
	cmp	x10, x16
	b.ne	.LBB44_7
	mov	x15, x8
	mov	x16, x10
	cmp	x10, #12
	b.ne	.LBB44_11
	b	.LBB44_4
.LBB44_10:
	add	x15, x16, #1
	sub	x10, x10, x15
	add	x15, x8, x15
	cmp	x16, #12
	b.eq	.LBB44_4
.LBB44_11:
	cbz	x16, .LBB44_14
	orr	w9, w9, wzr
	mov	x8, x15
	cbz	w14, .LBB44_5
.LBB44_13:
	ldr	x19, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	bfi	w0, w9, #8, #24
	ret
.LBB44_14:
	.cfi_restore_state
	mov	w9, #2
	mov	w0, #2
	ldr	x19, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	bfi	w0, w9, #8, #24
	ret
.Lfunc_end44:
	.size	_RNvNtCsjStpv0Kdcdo_9hm_kernel12cpu_topology10compatible, .Lfunc_end44-_RNvNtCsjStpv0Kdcdo_9hm_kernel12cpu_topology10compatible
	.cfi_endproc

	.section	.text._RINvYINtNtNtCsboyoyqK6YBz_4core5slice4iter5SplithNCNvMs0_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_,"ax",@progbits
	.p2align	2
	.type	_RINvYINtNtNtCsboyoyqK6YBz_4core5slice4iter5SplithNCNvMs0_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_,@function
_RINvYINtNtNtCsboyoyqK6YBz_4core5slice4iter5SplithNCNvMs0_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_:
.Lfunc_begin45:
	.cfi_startproc
	ldrb	w8, [x0, #16]
	tbnz	w8, #0, .LBB45_11
	mov	x9, #29281
	ldp	x12, x10, [x0]
	movk	x9, #11373, lsl #16
	mov	w11, #1
	movk	x9, #29552, lsl #32
	movk	x9, #26979, lsl #48
.LBB45_2:
	cbz	x10, .LBB45_13
	mov	x8, x12
	mov	x13, xzr
.LBB45_4:
	ldrb	w12, [x8, x13]
	cbz	w12, .LBB45_6
	add	x13, x13, #1
	cmp	x10, x13
	b.ne	.LBB45_4
	b	.LBB45_9
.LBB45_6:
	add	x14, x13, #1
	cmp	x13, #8
	add	x12, x8, x14
	sub	x10, x10, x14
	stp	x12, x10, [x0]
	b.ne	.LBB45_2
	ldrb	w13, [x8, #1]
	ldrb	w14, [x8]
	ldrb	w15, [x8, #3]
	ldrb	w16, [x8, #2]
	ldrb	w17, [x8, #5]
	ldrb	w18, [x8, #4]!
	orr	x13, x14, x13, lsl #8
	ldrb	w1, [x8, #2]
	lsl	x16, x16, #16
	ldrb	w8, [x8, #3]
	lsl	w1, w1, #16
	orr	x14, x16, x15, lsl #24
	orr	w15, w18, w17, lsl #8
	orr	w8, w1, w8, lsl #24
	orr	x13, x14, x13
	orr	w8, w8, w15
	orr	x8, x13, x8, lsl #32
	cmp	x8, x9
	cset	w8, eq
	b.eq	.LBB45_12
	cbnz	w11, .LBB45_2
	b	.LBB45_12
.LBB45_9:
	mov	w11, #1
	cmp	x10, #8
	strb	w11, [x0, #16]
	b.ne	.LBB45_11
	ldrb	w10, [x8, #1]
	ldrb	w11, [x8]
	ldrb	w12, [x8, #3]
	ldrb	w13, [x8, #2]
	ldrb	w14, [x8, #5]
	ldrb	w15, [x8, #4]!
	orr	x10, x11, x10, lsl #8
	ldrb	w16, [x8, #2]
	lsl	x13, x13, #16
	ldrb	w8, [x8, #3]
	lsl	w16, w16, #16
	orr	x11, x13, x12, lsl #24
	orr	w12, w15, w14, lsl #8
	orr	w8, w16, w8, lsl #24
	orr	x10, x11, x10
	orr	w8, w8, w12
	orr	x8, x10, x8, lsl #32
	cmp	x8, x9
	cset	w0, eq
	ret
.LBB45_11:
	mov	w8, wzr
.LBB45_12:
	mov	w0, w8
	ret
.LBB45_13:
	mov	w9, #1
	strb	w9, [x0, #16]
	mov	w0, wzr
	ret
.Lfunc_end45:
	.size	_RINvYINtNtNtCsboyoyqK6YBz_4core5slice4iter5SplithNCNvMs0_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_, .Lfunc_end45-_RINvYINtNtNtCsboyoyqK6YBz_4core5slice4iter5SplithNCNvMs0_NtCsjStpv0Kdcdo_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_
	.cfi_endproc

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.1,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.1,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.1:
	.ascii	" (discovered RAM)\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.1, 18

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.3,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.3,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.3:
	.ascii	" (4 KiB each; boot reservations excluded)\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.3, 42

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.4,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.4:
	.ascii	"0123456789abcdef"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.4, 16

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.5,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.5,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.5:
	.ascii	"hematite: ARM64 Rust kernel entered at EL1\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.5, 43

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.6,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.6,"a",@progbits
	.p2align	3, 0x0
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.6:
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	32
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.6, 152

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.7,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.7,"a",@progbits
	.p2align	3, 0x0
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.7:
	.asciz	"\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000"
	.xword	_RNvXNvNtCsel89eI7eLYd_8hematite4arch10smp_markerNtB2_6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write9write_str
	.xword	_RNvYNtNvNtCsel89eI7eLYd_8hematite4arch10smp_marker6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write10write_charB8_
	.xword	_RNvYNtNvNtCsel89eI7eLYd_8hematite4arch10smp_marker6OutputNtNtCsboyoyqK6YBz_4core3fmt5Write9write_fmtB8_
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.7, 48

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.8,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.8:
	.asciz	"\031HMSCHED STARTED cpu=1 sp=\300\001\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.8, 30

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.9,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9:
	.ascii	"HMSCHED REJECT TOPOLOGY\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9, 24

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.10,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.10,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.10:
	.ascii	"HMSCHED EXPECT NO-PEER-TIMER\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.10, 29

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.11,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.11,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.11:
	.ascii	"HMSCHED REJECT PSCI\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.11, 20

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.12,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.12,"a",@progbits
	.p2align	3, 0x0
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.12:
	.asciz	"\000\000\000\000\000\000\000\000\030\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.xword	_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext2id
	.xword	_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext6cpu_id
	.xword	_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext9yield_now
	.xword	_RNvXs_NtCsel89eI7eLYd_8hematite7preemptNtB4_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext4wait
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.12, 56

	.type	_RNvNtCsel89eI7eLYd_8hematite7preempt9WAIT_RACE,@object
	.section	.bss._RNvNtCsel89eI7eLYd_8hematite7preempt9WAIT_RACE,"aw",@nobits
	.p2align	3, 0x0
_RNvNtCsel89eI7eLYd_8hematite7preempt9WAIT_RACE:
	.zero	8
	.size	_RNvNtCsel89eI7eLYd_8hematite7preempt9WAIT_RACE, 8

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.13,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.13,"a",@progbits
	.p2align	3, 0x0
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.13:
	.asciz	"\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.xword	_RNvXs0_NtCsel89eI7eLYd_8hematite7threadsNtB5_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext2id
	.xword	_RNvYNtNtCsel89eI7eLYd_8hematite7threads5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext6cpu_idB6_
	.xword	_RNvXs0_NtCsel89eI7eLYd_8hematite7threadsNtB5_5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext9yield_now
	.xword	_RNvYNtNtCsel89eI7eLYd_8hematite7threads5TokenNtNtCsjStpv0Kdcdo_9hm_kernel10thread_api13ThreadContext4waitB6_
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.13, 56

	.type	_RNvNtCsel89eI7eLYd_8hematite9secondary15NEXT_GENERATION.0,@object
	.section	.data._RNvNtCsel89eI7eLYd_8hematite9secondary15NEXT_GENERATION.0,"aw",@progbits
	.p2align	3, 0x0
_RNvNtCsel89eI7eLYd_8hematite9secondary15NEXT_GENERATION.0:
	.xword	1
	.size	_RNvNtCsel89eI7eLYd_8hematite9secondary15NEXT_GENERATION.0, 8

	.type	_RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX,@object
	.section	.data._RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX,"aw",@progbits
	.p2align	6, 0x0
_RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX:
	.zero	777
	.zero	7
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	8
	.xword	_RNvNtCsel89eI7eLYd_8hematite7preempt5empty
	.zero	32
	.zero	16
	.size	_RNvNtCsel89eI7eLYd_8hematite9secondary7MAILBOX, 960

	.type	.Lanon.4379416e6c146e9fcb6d8c8e621434d6.192,@object
	.section	.rodata..Lanon.4379416e6c146e9fcb6d8c8e621434d6.192,"a",@progbits
.Lanon.4379416e6c146e9fcb6d8c8e621434d6.192:
	.ascii	"00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
	.size	.Lanon.4379416e6c146e9fcb6d8c8e621434d6.192, 200

	.type	.Lanon.4379416e6c146e9fcb6d8c8e621434d6.197,@object
	.section	.rodata..Lanon.4379416e6c146e9fcb6d8c8e621434d6.197,"a",@progbits
.Lanon.4379416e6c146e9fcb6d8c8e621434d6.197:
	.asciz	"\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\003\003\003\003\003\003\003\003\003\003\003\003\003\003\003\003\004\004\004\004\004\000\000\000\000\000\000\000\000\000\000"
	.size	.Lanon.4379416e6c146e9fcb6d8c8e621434d6.197, 256

	.type	.Lanon.9c45514b0a68c977cf2a682a7d2de827.65,@object
	.section	.rodata..Lanon.9c45514b0a68c977cf2a682a7d2de827.65,"a",@progbits
	.p2align	3, 0x0
.Lanon.9c45514b0a68c977cf2a682a7d2de827.65:
	.zero	8
	.zero	8
	.asciz	"\000\004"
	.zero	5
	.size	.Lanon.9c45514b0a68c977cf2a682a7d2de827.65, 24

	.type	.Lanon.9c45514b0a68c977cf2a682a7d2de827.67,@object
	.section	.rodata..Lanon.9c45514b0a68c977cf2a682a7d2de827.67,"a",@progbits
.Lanon.9c45514b0a68c977cf2a682a7d2de827.67:
	.ascii	"memory@"
	.size	.Lanon.9c45514b0a68c977cf2a682a7d2de827.67, 7

	.type	.Lanon.9c45514b0a68c977cf2a682a7d2de827.69,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.9c45514b0a68c977cf2a682a7d2de827.69:
	.ascii	"cpu@"
	.size	.Lanon.9c45514b0a68c977cf2a682a7d2de827.69, 4

	.type	.Lanon.9c45514b0a68c977cf2a682a7d2de827.70,@object
	.section	.rodata..Lanon.9c45514b0a68c977cf2a682a7d2de827.70,"a",@progbits
	.p2align	3, 0x0
.Lanon.9c45514b0a68c977cf2a682a7d2de827.70:
	.zero	8
	.zero	8
	.zero	4
	.zero	4
	.zero	4
	.zero	4
	.zero	144
	.zero	8
	.ascii	"\000\000\000\000\000\000\004"
	.zero	1
	.size	.Lanon.9c45514b0a68c977cf2a682a7d2de827.70, 192

	.type	.Lanon.9c45514b0a68c977cf2a682a7d2de827.71,@object
	.section	.rodata..Lanon.9c45514b0a68c977cf2a682a7d2de827.71,"a",@progbits
.Lanon.9c45514b0a68c977cf2a682a7d2de827.71:
	.ascii	"cpus@"
	.size	.Lanon.9c45514b0a68c977cf2a682a7d2de827.71, 5

	.type	.Lanon.9c45514b0a68c977cf2a682a7d2de827.72,@object
	.section	.rodata..Lanon.9c45514b0a68c977cf2a682a7d2de827.72,"a",@progbits
.Lanon.9c45514b0a68c977cf2a682a7d2de827.72:
	.ascii	"psci@"
	.size	.Lanon.9c45514b0a68c977cf2a682a7d2de827.72, 5

	.type	.L_MergedGlobals,@object
	.section	.bss..L_MergedGlobals,"aw",@nobits
	.p2align	3, 0x0
.L_MergedGlobals:
	.zero	88
	.size	.L_MergedGlobals, 88

_RNvNtCsel89eI7eLYd_8hematite6frames7CLAIMED = .L_MergedGlobals
	.size	_RNvNtCsel89eI7eLYd_8hematite6frames7CLAIMED, 1
_RNvNtCsel89eI7eLYd_8hematite7threads4BUSY = .L_MergedGlobals+4
	.size	_RNvNtCsel89eI7eLYd_8hematite7threads4BUSY, 1
_RNvNtCsel89eI7eLYd_8hematite8mappings7CLAIMED = .L_MergedGlobals+5
	.size	_RNvNtCsel89eI7eLYd_8hematite8mappings7CLAIMED, 1
_RNvNtCsel89eI7eLYd_8hematite10smp_checks5PHASE.0 = .L_MergedGlobals+8
	.size	_RNvNtCsel89eI7eLYd_8hematite10smp_checks5PHASE.0, 8
_RNvNtCsel89eI7eLYd_8hematite7preempt11ALL_BLOCKED = .L_MergedGlobals+16
	.size	_RNvNtCsel89eI7eLYd_8hematite7preempt11ALL_BLOCKED, 8
_RNvNtCsel89eI7eLYd_8hematite10smp_checks6STACKS = .L_MergedGlobals+24
	.size	_RNvNtCsel89eI7eLYd_8hematite10smp_checks6STACKS, 64
	.section	.debug_abbrev,"",@progbits
	.byte	1
	.byte	17
	.byte	1
	.byte	37
	.byte	14
	.byte	19
	.byte	5
	.byte	3
	.byte	14
	.byte	16
	.byte	23
	.byte	27
	.byte	14
	.byte	17
	.byte	1
	.byte	85
	.byte	23
	.byte	0
	.byte	0
	.byte	2
	.byte	57
	.byte	1
	.byte	3
	.byte	14
	.byte	0
	.byte	0
	.byte	3
	.byte	46
	.byte	0
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	54
	.byte	11
	.byte	63
	.byte	25
	.ascii	"\207\001"
	.byte	25
	.byte	0
	.byte	0
	.byte	4
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	5
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	54
	.byte	11
	.byte	63
	.byte	25
	.byte	0
	.byte	0
	.byte	6
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	7
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	8
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.ascii	"\266B"
	.byte	11
	.byte	0
	.byte	0
	.byte	9
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	10
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	11
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	12
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.ascii	"\266B"
	.byte	11
	.byte	0
	.byte	0
	.byte	13
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.ascii	"\266B"
	.byte	11
	.byte	0
	.byte	0
	.byte	14
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	63
	.byte	25
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	15
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	54
	.byte	11
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	16
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	54
	.byte	11
	.byte	0
	.byte	0
	.byte	17
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	63
	.byte	25
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	18
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	63
	.byte	25
	.byte	0
	.byte	0
	.byte	19
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	20
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	21
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	54
	.byte	11
	.byte	63
	.byte	25
	.byte	0
	.byte	0
	.byte	22
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	23
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.word	.Ldebug_info_end0-.Ldebug_info_start0
.Ldebug_info_start0:
	.hword	4
	.word	.debug_abbrev
	.byte	8
	.byte	1
	.word	.Linfo_string0
	.hword	28
	.word	.Linfo_string1
	.word	.Lline_table_start0
	.word	.Linfo_string2
	.xword	0
	.word	.Ldebug_ranges22
	.byte	2
	.word	.Linfo_string3
	.byte	2
	.word	.Linfo_string4
	.byte	3
	.xword	.Lfunc_begin31
	.word	.Lfunc_end31-.Lfunc_begin31
	.byte	1
	.byte	109
	.word	.Linfo_string115
	.word	.Linfo_string116
	.byte	1
	.byte	60
	.byte	3


	.byte	0
	.byte	2
	.word	.Linfo_string5
	.byte	2
	.word	.Linfo_string6
	.byte	4
	.word	.Linfo_string7
	.word	.Linfo_string8
	.byte	2
	.hword	871
	.byte	1
	.byte	0
	.byte	2
	.word	.Linfo_string19
	.byte	4
	.word	.Linfo_string20
	.word	.Linfo_string21
	.byte	2
	.hword	576
	.byte	1
	.byte	4
	.word	.Linfo_string37
	.word	.Linfo_string38
	.byte	2
	.hword	2315
	.byte	1
	.byte	4
	.word	.Linfo_string39
	.word	.Linfo_string40
	.byte	2
	.hword	2372
	.byte	1
	.byte	4
	.word	.Linfo_string44
	.word	.Linfo_string45
	.byte	2
	.hword	1952
	.byte	1
	.byte	5
	.xword	.Lfunc_begin33
	.word	.Lfunc_end33-.Lfunc_begin33
	.byte	1
	.byte	109
	.word	.Linfo_string118
	.word	.Linfo_string76
	.byte	2
	.hword	1826
	.byte	3

	.byte	6
	.word	147
	.word	.Ldebug_ranges8
	.byte	2
	.hword	1873
	.byte	37
	.byte	7
	.word	1418
	.word	.Ldebug_ranges9
	.byte	2
	.hword	1957
	.byte	34
	.byte	8
	.word	2221
	.word	.Ldebug_ranges10
	.byte	2
	.hword	1966
	.byte	18
	.byte	2
	.byte	6
	.word	2189
	.word	.Ldebug_ranges10
	.byte	8
	.hword	1185
	.byte	14
	.byte	9
	.word	2145
	.xword	.Ltmp201
	.word	.Ltmp202-.Ltmp201
	.byte	8
	.hword	1100
	.byte	12
	.byte	10
	.word	2253
	.xword	.Ltmp206
	.word	.Ltmp207-.Ltmp206
	.byte	8
	.hword	1103
	.byte	35
	.byte	9
	.word	2292
	.xword	.Ltmp206
	.word	.Ltmp207-.Ltmp206
	.byte	8
	.hword	265
	.byte	28
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.word	2089
	.xword	.Ltmp208
	.word	.Ltmp209-.Ltmp208
	.byte	2
	.hword	1967
	.byte	13
	.byte	7
	.word	1457
	.word	.Ldebug_ranges11
	.byte	2
	.hword	1958
	.byte	33
	.byte	0
	.byte	9
	.word	2076
	.xword	.Ltmp179
	.word	.Ltmp180-.Ltmp179
	.byte	2
	.hword	1858
	.byte	13
	.byte	7
	.word	1431
	.word	.Ldebug_ranges12
	.byte	2
	.hword	1864
	.byte	26
	.byte	9
	.word	1444
	.xword	.Ltmp185
	.word	.Ltmp186-.Ltmp185
	.byte	2
	.hword	1864
	.byte	36
	.byte	9
	.word	2076
	.xword	.Ltmp187
	.word	.Ltmp188-.Ltmp187
	.byte	2
	.hword	1865
	.byte	13
	.byte	10
	.word	147
	.xword	.Ltmp189
	.word	.Ltmp195-.Ltmp189
	.byte	2
	.hword	1866
	.byte	37
	.byte	8
	.word	2221
	.word	.Ldebug_ranges13
	.byte	2
	.hword	1966
	.byte	18
	.byte	2
	.byte	6
	.word	2189
	.word	.Ldebug_ranges13
	.byte	8
	.hword	1185
	.byte	14
	.byte	9
	.word	2145
	.xword	.Ltmp189
	.word	.Ltmp190-.Ltmp189
	.byte	8
	.hword	1100
	.byte	12
	.byte	10
	.word	2253
	.xword	.Ltmp192
	.word	.Ltmp193-.Ltmp192
	.byte	8
	.hword	1103
	.byte	35
	.byte	9
	.word	2292
	.xword	.Ltmp192
	.word	.Ltmp193-.Ltmp192
	.byte	8
	.hword	265
	.byte	28
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.word	2089
	.xword	.Ltmp194
	.word	.Ltmp195-.Ltmp194
	.byte	2
	.hword	1967
	.byte	13
	.byte	0
	.byte	9
	.word	2076
	.xword	.Ltmp198
	.word	.Ltmp199-.Ltmp198
	.byte	2
	.hword	1867
	.byte	13
	.byte	9
	.word	2076
	.xword	.Ltmp210
	.word	.Ltmp211-.Ltmp210
	.byte	2
	.hword	1874
	.byte	13
	.byte	9
	.word	2076
	.xword	.Ltmp212
	.word	.Ltmp213-.Ltmp212
	.byte	2
	.hword	1875
	.byte	13
	.byte	6
	.word	1476
	.word	.Ldebug_ranges14
	.byte	2
	.hword	1876
	.byte	26
	.byte	8
	.word	2234
	.word	.Ldebug_ranges15
	.byte	2
	.hword	1756
	.byte	18
	.byte	2
	.byte	6
	.word	2202
	.word	.Ldebug_ranges15
	.byte	8
	.hword	1185
	.byte	14
	.byte	9
	.word	2158
	.xword	.Ltmp214
	.word	.Ltmp215-.Ltmp214
	.byte	8
	.hword	1100
	.byte	12
	.byte	10
	.word	2266
	.xword	.Ltmp219
	.word	.Ltmp220-.Ltmp219
	.byte	8
	.hword	1103
	.byte	35
	.byte	9
	.word	2305
	.xword	.Ltmp219
	.word	.Ltmp220-.Ltmp219
	.byte	8
	.hword	265
	.byte	28
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.word	2102
	.xword	.Ltmp221
	.word	.Ltmp222-.Ltmp221
	.byte	2
	.hword	1757
	.byte	13
	.byte	0
	.byte	9
	.word	121
	.xword	.Ltmp171
	.word	.Ltmp172-.Ltmp171
	.byte	2
	.hword	1833
	.byte	24
	.byte	9
	.word	134
	.xword	.Ltmp172
	.word	.Ltmp173-.Ltmp172
	.byte	2
	.hword	1838
	.byte	30
	.byte	0
	.byte	0
	.byte	2
	.word	.Linfo_string22
	.byte	2
	.word	.Linfo_string23
	.byte	11
	.word	.Linfo_string24
	.word	.Linfo_string5
	.byte	5
	.byte	143
	.byte	1
	.byte	11
	.word	.Linfo_string32
	.word	.Linfo_string33
	.byte	5
	.byte	159
	.byte	1
	.byte	0
	.byte	0
	.byte	5
	.xword	.Lfunc_begin32
	.word	.Lfunc_end32-.Lfunc_begin32
	.byte	1
	.byte	109
	.word	.Linfo_string117
	.word	.Linfo_string74
	.byte	2
	.hword	1631
	.byte	3

	.byte	7
	.word	89
	.word	.Ldebug_ranges0
	.byte	2
	.hword	1632
	.byte	26
	.byte	6
	.word	1908
	.word	.Ldebug_ranges1
	.byte	2
	.hword	1648
	.byte	30
	.byte	7
	.word	1885
	.word	.Ldebug_ranges1
	.byte	4
	.hword	935
	.byte	18
	.byte	0
	.byte	9
	.word	1921
	.xword	.Ltmp113
	.word	.Ltmp114-.Ltmp113
	.byte	2
	.hword	1662
	.byte	37
	.byte	9
	.word	1934
	.xword	.Ltmp116
	.word	.Ltmp117-.Ltmp116
	.byte	2
	.hword	1685
	.byte	22
	.byte	7
	.word	108
	.word	.Ldebug_ranges2
	.byte	2
	.hword	1687
	.byte	31
	.byte	7
	.word	798
	.word	.Ldebug_ranges3
	.byte	2
	.hword	1687
	.byte	22
	.byte	9
	.word	2063
	.xword	.Ltmp122
	.word	.Ltmp123-.Ltmp122
	.byte	2
	.hword	1685
	.byte	17
	.byte	10
	.word	1947
	.xword	.Ltmp123
	.word	.Ltmp124-.Ltmp123
	.byte	2
	.hword	1671
	.byte	80
	.byte	12
	.word	1975
	.xword	.Ltmp123
	.word	.Ltmp124-.Ltmp123
	.byte	4
	.hword	935
	.byte	18
	.byte	2
	.byte	0
	.byte	9
	.word	1921
	.xword	.Ltmp124
	.word	.Ltmp125-.Ltmp124
	.byte	2
	.hword	1672
	.byte	37
	.byte	9
	.word	1921
	.xword	.Ltmp125
	.word	.Ltmp126-.Ltmp125
	.byte	2
	.hword	1674
	.byte	37
	.byte	10
	.word	1947
	.xword	.Ltmp128
	.word	.Ltmp129-.Ltmp128
	.byte	2
	.hword	1705
	.byte	74
	.byte	12
	.word	1975
	.xword	.Ltmp128
	.word	.Ltmp129-.Ltmp128
	.byte	4
	.hword	935
	.byte	18
	.byte	6
	.byte	0
	.byte	10
	.word	1947
	.xword	.Ltmp130
	.word	.Ltmp131-.Ltmp130
	.byte	2
	.hword	1709
	.byte	78
	.byte	12
	.word	1975
	.xword	.Ltmp130
	.word	.Ltmp131-.Ltmp130
	.byte	4
	.hword	935
	.byte	18
	.byte	8
	.byte	0
	.byte	10
	.word	1947
	.xword	.Ltmp132
	.word	.Ltmp133-.Ltmp132
	.byte	2
	.hword	1713
	.byte	86
	.byte	12
	.word	1975
	.xword	.Ltmp132
	.word	.Ltmp133-.Ltmp132
	.byte	4
	.hword	935
	.byte	18
	.byte	10
	.byte	0
	.byte	9
	.word	1934
	.xword	.Ltmp134
	.word	.Ltmp135-.Ltmp134
	.byte	2
	.hword	1721
	.byte	38
	.byte	9
	.word	810
	.xword	.Ltmp135
	.word	.Ltmp136-.Ltmp135
	.byte	2
	.hword	1721
	.byte	71
	.byte	6
	.word	1960
	.word	.Ldebug_ranges4
	.byte	2
	.hword	1701
	.byte	74
	.byte	13
	.word	1988
	.word	.Ldebug_ranges4
	.byte	4
	.hword	935
	.byte	18
	.byte	4
	.byte	0
	.byte	9
	.word	1921
	.xword	.Ltmp138
	.word	.Ltmp139-.Ltmp138
	.byte	2
	.hword	1702
	.byte	41
	.byte	9
	.word	1934
	.xword	.Ltmp141
	.word	.Ltmp142-.Ltmp141
	.byte	2
	.hword	1729
	.byte	30
	.byte	9
	.word	810
	.xword	.Ltmp142
	.word	.Ltmp143-.Ltmp142
	.byte	2
	.hword	1729
	.byte	67
	.byte	7
	.word	108
	.word	.Ldebug_ranges5
	.byte	2
	.hword	1735
	.byte	55
	.byte	9
	.word	1934
	.xword	.Ltmp144
	.word	.Ltmp145-.Ltmp144
	.byte	2
	.hword	1735
	.byte	22
	.byte	7
	.word	798
	.word	.Ldebug_ranges6
	.byte	2
	.hword	1735
	.byte	46
	.byte	7
	.word	2063
	.word	.Ldebug_ranges7
	.byte	2
	.hword	1735
	.byte	17
	.byte	9
	.word	1921
	.xword	.Ltmp111
	.word	.Ltmp112-.Ltmp111
	.byte	2
	.hword	1649
	.byte	33
	.byte	0
	.byte	2
	.word	.Linfo_string41
	.byte	4
	.word	.Linfo_string42
	.word	.Linfo_string43
	.byte	2
	.hword	501
	.byte	1
	.byte	4
	.word	.Linfo_string46
	.word	.Linfo_string47
	.byte	2
	.hword	402
	.byte	1
	.byte	4
	.word	.Linfo_string48
	.word	.Linfo_string49
	.byte	2
	.hword	411
	.byte	1
	.byte	14
	.word	.Linfo_string70
	.word	.Linfo_string71
	.byte	2
	.hword	495

	.byte	1
	.byte	0
	.byte	2
	.word	.Linfo_string72
	.byte	15
	.word	.Linfo_string73
	.word	.Linfo_string74
	.byte	2
	.hword	1755
	.byte	3
	.byte	1
	.byte	0
	.byte	2
	.word	.Linfo_string75
	.byte	2
	.word	.Linfo_string76
	.byte	16
	.xword	.Lfunc_begin34
	.word	.Lfunc_end34-.Lfunc_begin34
	.byte	1
	.byte	109
	.word	.Linfo_string119
	.word	.Linfo_string120
	.byte	2
	.hword	1847
	.byte	3
	.byte	9
	.word	2115
	.xword	.Ltmp224
	.word	.Ltmp225-.Ltmp224
	.byte	2
	.hword	1849
	.byte	17
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.word	.Linfo_string63
	.byte	2
	.word	.Linfo_string93
	.byte	2
	.word	.Linfo_string94
	.byte	11
	.word	.Linfo_string95
	.word	.Linfo_string96
	.byte	15
	.byte	190
	.byte	1
	.byte	17
	.word	.Linfo_string97
	.word	.Linfo_string98
	.byte	15
	.byte	183

	.byte	1
	.byte	0
	.byte	2
	.word	.Linfo_string114
	.byte	18
	.xword	.Lfunc_begin37
	.word	.Lfunc_end37-.Lfunc_begin37
	.byte	1
	.byte	109
	.word	.Linfo_string124
	.word	.Linfo_string5
	.byte	15
	.byte	135

	.byte	19
	.word	1579
	.word	.Ldebug_ranges19
	.byte	15
	.byte	143
	.byte	60
	.byte	19
	.word	1567
	.word	.Ldebug_ranges20
	.byte	15
	.byte	185
	.byte	44
	.byte	20
	.word	2658
	.xword	.Ltmp260
	.word	.Ltmp261-.Ltmp260
	.byte	15
	.byte	213
	.byte	37
	.byte	20
	.word	2658
	.xword	.Ltmp262
	.word	.Ltmp263-.Ltmp262
	.byte	15
	.byte	214
	.byte	37
	.byte	20
	.word	2658
	.xword	.Ltmp263
	.word	.Ltmp264-.Ltmp263
	.byte	15
	.byte	215
	.byte	37
	.byte	20
	.word	2658
	.xword	.Ltmp264
	.word	.Ltmp265-.Ltmp264
	.byte	15
	.byte	216
	.byte	37
	.byte	20
	.word	2658
	.xword	.Ltmp269
	.word	.Ltmp270-.Ltmp269
	.byte	15
	.byte	231
	.byte	37
	.byte	20
	.word	2658
	.xword	.Ltmp270
	.word	.Ltmp271-.Ltmp270
	.byte	15
	.byte	232
	.byte	37
	.byte	20
	.word	2658
	.xword	.Ltmp275
	.word	.Ltmp276-.Ltmp275
	.byte	15
	.byte	248
	.byte	33
	.byte	0
	.byte	19
	.word	1866
	.word	.Ldebug_ranges21
	.byte	15
	.byte	187
	.byte	26
	.byte	19
	.word	2628
	.word	.Ldebug_ranges21
	.byte	15
	.byte	115
	.byte	32
	.byte	6
	.word	2380
	.word	.Ldebug_ranges21
	.byte	17
	.hword	647
	.byte	26
	.byte	6
	.word	2361
	.word	.Ldebug_ranges21
	.byte	10
	.hword	533
	.byte	44
	.byte	9
	.word	2394
	.xword	.Ltmp279
	.word	.Ltmp280-.Ltmp279
	.byte	10
	.hword	381
	.byte	13
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	11
	.word	.Linfo_string110
	.word	.Linfo_string111
	.byte	15
	.byte	113
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.word	.Linfo_string9
	.byte	4
	.word	.Linfo_string10
	.word	.Linfo_string11
	.byte	3
	.hword	1716
	.byte	1
	.byte	2
	.word	.Linfo_string12
	.byte	2
	.word	.Linfo_string13
	.byte	4
	.word	.Linfo_string14
	.word	.Linfo_string11
	.byte	4
	.hword	930
	.byte	1
	.byte	4
	.word	.Linfo_string15
	.word	.Linfo_string16
	.byte	4
	.hword	619
	.byte	1
	.byte	4
	.word	.Linfo_string17
	.word	.Linfo_string18
	.byte	4
	.hword	619
	.byte	1
	.byte	4
	.word	.Linfo_string31
	.word	.Linfo_string30
	.byte	4
	.hword	930
	.byte	1
	.byte	4
	.word	.Linfo_string36
	.word	.Linfo_string35
	.byte	4
	.hword	930
	.byte	1
	.byte	0
	.byte	0
	.byte	4
	.word	.Linfo_string29
	.word	.Linfo_string30
	.byte	3
	.hword	1716
	.byte	1
	.byte	4
	.word	.Linfo_string34
	.word	.Linfo_string35
	.byte	3
	.hword	1716
	.byte	1
	.byte	4
	.word	.Linfo_string79
	.word	.Linfo_string80
	.byte	3
	.hword	2288
	.byte	1
	.byte	2
	.word	.Linfo_string81
	.byte	2
	.word	.Linfo_string82
	.byte	4
	.word	.Linfo_string83
	.word	.Linfo_string80
	.byte	13
	.hword	1277
	.byte	1
	.byte	4
	.word	.Linfo_string88
	.word	.Linfo_string16
	.byte	13
	.hword	837
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.word	.Linfo_string25
	.byte	2
	.word	.Linfo_string26
	.byte	4
	.word	.Linfo_string27
	.word	.Linfo_string28
	.byte	6
	.hword	2176
	.byte	1
	.byte	4
	.word	.Linfo_string27
	.word	.Linfo_string28
	.byte	6
	.hword	2176
	.byte	1
	.byte	4
	.word	.Linfo_string27
	.word	.Linfo_string28
	.byte	6
	.hword	2176
	.byte	1
	.byte	4
	.word	.Linfo_string27
	.word	.Linfo_string28
	.byte	6
	.hword	2176
	.byte	1
	.byte	4
	.word	.Linfo_string27
	.word	.Linfo_string28
	.byte	6
	.hword	2176
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.word	.Linfo_string50
	.byte	2
	.word	.Linfo_string51
	.byte	2
	.word	.Linfo_string52
	.byte	4
	.word	.Linfo_string53
	.word	.Linfo_string54
	.byte	7
	.hword	2144
	.byte	1
	.byte	4
	.word	.Linfo_string53
	.word	.Linfo_string54
	.byte	7
	.hword	2144
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.word	.Linfo_string55
	.byte	2
	.word	.Linfo_string56
	.byte	2
	.word	.Linfo_string57
	.byte	4
	.word	.Linfo_string58
	.word	.Linfo_string59
	.byte	8
	.hword	1099
	.byte	1
	.byte	4
	.word	.Linfo_string58
	.word	.Linfo_string59
	.byte	8
	.hword	1099
	.byte	1
	.byte	0
	.byte	2
	.word	.Linfo_string60
	.byte	4
	.word	.Linfo_string61
	.word	.Linfo_string62
	.byte	8
	.hword	1184
	.byte	1
	.byte	4
	.word	.Linfo_string61
	.word	.Linfo_string62
	.byte	8
	.hword	1184
	.byte	1
	.byte	0
	.byte	2
	.word	.Linfo_string67
	.byte	4
	.word	.Linfo_string68
	.word	.Linfo_string69
	.byte	8
	.hword	263
	.byte	1
	.byte	4
	.word	.Linfo_string68
	.word	.Linfo_string69
	.byte	8
	.hword	263
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.word	.Linfo_string63
	.byte	2
	.word	.Linfo_string64
	.byte	4
	.word	.Linfo_string65
	.word	.Linfo_string66
	.byte	9
	.hword	1001
	.byte	1
	.byte	4
	.word	.Linfo_string65
	.word	.Linfo_string66
	.byte	9
	.hword	1001
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.word	.Linfo_string77
	.byte	2
	.word	.Linfo_string78
	.byte	3
	.xword	.Lfunc_begin35
	.word	.Lfunc_end35-.Lfunc_begin35
	.byte	1
	.byte	109
	.word	.Linfo_string121
	.word	.Linfo_string122
	.byte	10
	.byte	39
	.byte	3


	.byte	2
	.word	.Linfo_string104
	.byte	4
	.word	.Linfo_string105
	.word	.Linfo_string106
	.byte	10
	.hword	362
	.byte	1
	.byte	0
	.byte	2
	.word	.Linfo_string64
	.byte	4
	.word	.Linfo_string107
	.word	.Linfo_string106
	.byte	10
	.hword	531
	.byte	1
	.byte	0
	.byte	11
	.word	.Linfo_string112
	.word	.Linfo_string113
	.byte	10
	.byte	83
	.byte	1
	.byte	0
	.byte	2
	.word	.Linfo_string84
	.byte	2
	.word	.Linfo_string85
	.byte	4
	.word	.Linfo_string86
	.word	.Linfo_string87
	.byte	14
	.hword	2623
	.byte	1
	.byte	0
	.byte	11
	.word	.Linfo_string89
	.word	.Linfo_string90
	.byte	12
	.byte	18
	.byte	1
	.byte	11
	.word	.Linfo_string91
	.word	.Linfo_string92
	.byte	12
	.byte	37
	.byte	1
	.byte	21
	.xword	.Lfunc_begin36
	.word	.Lfunc_end36-.Lfunc_begin36
	.byte	1
	.byte	111
	.word	.Linfo_string123
	.word	.Linfo_string85
	.byte	12
	.byte	53
	.byte	3

	.byte	6
	.word	2417
	.word	.Ldebug_ranges16
	.byte	14
	.hword	2636
	.byte	9
	.byte	22
	.word	2024
	.xword	.Lfunc_begin36
	.word	.Ltmp231-.Lfunc_begin36
	.byte	12
	.byte	71
	.byte	34
	.byte	9
	.word	2001
	.xword	.Lfunc_begin36
	.word	.Ltmp231-.Lfunc_begin36
	.byte	13
	.hword	1286
	.byte	28
	.byte	0
	.byte	20
	.word	2037
	.xword	.Ltmp232
	.word	.Ltmp233-.Ltmp232
	.byte	12
	.byte	87
	.byte	35
	.byte	23
	.word	2431
	.word	.Ldebug_ranges17
	.byte	12
	.byte	92
	.byte	30
	.byte	23
	.word	2431
	.word	.Ldebug_ranges18
	.byte	12
	.byte	91
	.byte	30
	.byte	20
	.word	2443
	.xword	.Ltmp246
	.word	.Ltmp247-.Ltmp246
	.byte	12
	.byte	106
	.byte	30
	.byte	20
	.word	2443
	.xword	.Ltmp243
	.word	.Ltmp244-.Ltmp243
	.byte	12
	.byte	76
	.byte	38
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.word	.Linfo_string82
	.byte	4
	.word	.Linfo_string108
	.word	.Linfo_string109
	.byte	17
	.hword	640
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.word	.Linfo_string99
	.byte	2
	.word	.Linfo_string100
	.byte	2
	.word	.Linfo_string101
	.byte	4
	.word	.Linfo_string102
	.word	.Linfo_string103
	.byte	16
	.hword	574
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
.Ldebug_info_end0:
	.section	.text.unlikely._RNvNtCsboyoyqK6YBz_4core9panicking9panic_fmt,"ax",@progbits
.Lsec_end0:
	.section	.text._RNvNtCsboyoyqK6YBz_4core3fmt5write,"ax",@progbits
.Lsec_end1:
	.section	.text._RNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB5_9Formatter12pad_integral,"ax",@progbits
.Lsec_end2:
	.section	.text._RNvNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB7_9Formatter12pad_integral12write_prefix,"ax",@progbits
.Lsec_end3:
	.section	.text.unlikely._RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail,"ax",@progbits
.Lsec_end4:
	.section	.text._RNvNtNtCsboyoyqK6YBz_4core5slice6memchr14memchr_aligned,"ax",@progbits
.Lsec_end5:
	.section	.text._RNvXsd_NtNtNtCsboyoyqK6YBz_4core3fmt3num3impyNtB9_7Display3fmt,"ax",@progbits
.Lsec_end6:
	.section	.debug_aranges,"",@progbits
	.word	140
	.hword	2
	.word	.Lcu_begin0
	.byte	8
	.byte	0
	.zero	4,255
	.xword	.Lfunc_begin31
	.xword	.Lsec_end0-.Lfunc_begin31
	.xword	.Lfunc_begin32
	.xword	.Lsec_end1-.Lfunc_begin32
	.xword	.Lfunc_begin33
	.xword	.Lsec_end2-.Lfunc_begin33
	.xword	.Lfunc_begin34
	.xword	.Lsec_end3-.Lfunc_begin34
	.xword	.Lfunc_begin35
	.xword	.Lsec_end4-.Lfunc_begin35
	.xword	.Lfunc_begin36
	.xword	.Lsec_end5-.Lfunc_begin36
	.xword	.Lfunc_begin37
	.xword	.Lsec_end6-.Lfunc_begin37
	.xword	0
	.xword	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.xword	.Ltmp107
	.xword	.Ltmp108
	.xword	.Ltmp154
	.xword	.Ltmp155
	.xword	0
	.xword	0
.Ldebug_ranges1:
	.xword	.Ltmp108
	.xword	.Ltmp109
	.xword	.Ltmp152
	.xword	.Ltmp153
	.xword	0
	.xword	0
.Ldebug_ranges2:
	.xword	.Ltmp117
	.xword	.Ltmp118
	.xword	.Ltmp119
	.xword	.Ltmp120
	.xword	0
	.xword	0
.Ldebug_ranges3:
	.xword	.Ltmp118
	.xword	.Ltmp119
	.xword	.Ltmp120
	.xword	.Ltmp122
	.xword	0
	.xword	0
.Ldebug_ranges4:
	.xword	.Ltmp137
	.xword	.Ltmp138
	.xword	.Ltmp139
	.xword	.Ltmp140
	.xword	0
	.xword	0
.Ldebug_ranges5:
	.xword	.Ltmp143
	.xword	.Ltmp144
	.xword	.Ltmp145
	.xword	.Ltmp146
	.xword	.Ltmp148
	.xword	.Ltmp149
	.xword	0
	.xword	0
.Ldebug_ranges6:
	.xword	.Ltmp146
	.xword	.Ltmp148
	.xword	.Ltmp149
	.xword	.Ltmp150
	.xword	0
	.xword	0
.Ldebug_ranges7:
	.xword	.Ltmp150
	.xword	.Ltmp151
	.xword	.Ltmp167
	.xword	.Ltmp168
	.xword	0
	.xword	0
.Ldebug_ranges8:
	.xword	.Ltmp175
	.xword	.Ltmp176
	.xword	.Ltmp177
	.xword	.Ltmp178
	.xword	.Ltmp195
	.xword	.Ltmp197
	.xword	.Ltmp201
	.xword	.Ltmp209
	.xword	.Ltmp217
	.xword	.Ltmp218
	.xword	0
	.xword	0
.Ldebug_ranges9:
	.xword	.Ltmp175
	.xword	.Ltmp176
	.xword	.Ltmp177
	.xword	.Ltmp178
	.xword	.Ltmp195
	.xword	.Ltmp196
	.xword	0
	.xword	0
.Ldebug_ranges10:
	.xword	.Ltmp201
	.xword	.Ltmp203
	.xword	.Ltmp206
	.xword	.Ltmp207
	.xword	0
	.xword	0
.Ldebug_ranges11:
	.xword	.Ltmp204
	.xword	.Ltmp205
	.xword	.Ltmp217
	.xword	.Ltmp218
	.xword	0
	.xword	0
.Ldebug_ranges12:
	.xword	.Ltmp181
	.xword	.Ltmp182
	.xword	.Ltmp183
	.xword	.Ltmp184
	.xword	0
	.xword	0
.Ldebug_ranges13:
	.xword	.Ltmp189
	.xword	.Ltmp191
	.xword	.Ltmp192
	.xword	.Ltmp193
	.xword	0
	.xword	0
.Ldebug_ranges14:
	.xword	.Ltmp214
	.xword	.Ltmp217
	.xword	.Ltmp218
	.xword	.Ltmp222
	.xword	0
	.xword	0
.Ldebug_ranges15:
	.xword	.Ltmp214
	.xword	.Ltmp216
	.xword	.Ltmp219
	.xword	.Ltmp220
	.xword	0
	.xword	0
.Ldebug_ranges16:
	.xword	.Lfunc_begin36
	.xword	.Ltmp247
	.xword	.Ltmp248
	.xword	.Ltmp249
	.xword	0
	.xword	0
.Ldebug_ranges17:
	.xword	.Ltmp237
	.xword	.Ltmp238
	.xword	.Ltmp239
	.xword	.Ltmp240
	.xword	0
	.xword	0
.Ldebug_ranges18:
	.xword	.Ltmp236
	.xword	.Ltmp237
	.xword	.Ltmp238
	.xword	.Ltmp239
	.xword	0
	.xword	0
.Ldebug_ranges19:
	.xword	.Ltmp252
	.xword	.Ltmp277
	.xword	.Ltmp278
	.xword	.Ltmp280
	.xword	.Ltmp282
	.xword	.Ltmp283
	.xword	0
	.xword	0
.Ldebug_ranges20:
	.xword	.Ltmp252
	.xword	.Ltmp276
	.xword	.Ltmp282
	.xword	.Ltmp283
	.xword	0
	.xword	0
.Ldebug_ranges21:
	.xword	.Ltmp276
	.xword	.Ltmp277
	.xword	.Ltmp278
	.xword	.Ltmp280
	.xword	0
	.xword	0
.Ldebug_ranges22:
	.xword	.Lfunc_begin31
	.xword	.Lfunc_end31
	.xword	.Lfunc_begin32
	.xword	.Lfunc_end32
	.xword	.Lfunc_begin33
	.xword	.Lfunc_end33
	.xword	.Lfunc_begin34
	.xword	.Lfunc_end34
	.xword	.Lfunc_begin35
	.xword	.Lfunc_end35
	.xword	.Lfunc_begin36
	.xword	.Lfunc_end36
	.xword	.Lfunc_begin37
	.xword	.Lfunc_end37
	.xword	0
	.xword	0
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"clang LLVM (rustc version 1.99.0 (b940084d7 2026-09-28))"
.Linfo_string1:
	.asciz	"/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4/library/core/src/lib.rs/@/core.84bc9dbc121c31fb-cgu.0"
.Linfo_string2:
	.asciz	"/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4"
.Linfo_string3:
	.asciz	"core"
.Linfo_string4:
	.asciz	"panicking"
.Linfo_string5:
	.asciz	"fmt"
.Linfo_string6:
	.asciz	"Arguments"
.Linfo_string7:
	.asciz	"_RNvMs4_NtCsboyoyqK6YBz_4core3fmtNtB5_9Arguments6as_str"
.Linfo_string8:
	.asciz	"as_str"
.Linfo_string9:
	.asciz	"ptr"
.Linfo_string10:
	.asciz	"_RINvNtCsboyoyqK6YBz_4core3ptr4readhEB4_"
.Linfo_string11:
	.asciz	"read<u8>"
.Linfo_string12:
	.asciz	"non_null"
.Linfo_string13:
	.asciz	"NonNull"
.Linfo_string14:
	.asciz	"_RNvMs1_NtNtCsboyoyqK6YBz_4core3ptr8non_nullINtB5_7NonNullhE4readB9_"
.Linfo_string15:
	.asciz	"_RNvMs1_NtNtCsboyoyqK6YBz_4core3ptr8non_nullINtB5_7NonNullhE3addB9_"
.Linfo_string16:
	.asciz	"add<u8>"
.Linfo_string17:
	.asciz	"_RNvMs1_NtNtCsboyoyqK6YBz_4core3ptr8non_nullINtB5_7NonNullNtNtNtB9_3fmt2rt8ArgumentE3addB9_"
.Linfo_string18:
	.asciz	"add<core::fmt::rt::Argument>"
.Linfo_string19:
	.asciz	"Formatter"
.Linfo_string20:
	.asciz	"_RNvMs1_NtCsboyoyqK6YBz_4core3fmtNtB5_9Formatter3new"
.Linfo_string21:
	.asciz	"new"
.Linfo_string22:
	.asciz	"rt"
.Linfo_string23:
	.asciz	"Argument"
.Linfo_string24:
	.asciz	"_RNvMNtNtCsboyoyqK6YBz_4core3fmt2rtNtB2_8Argument3fmt"
.Linfo_string25:
	.asciz	"result"
.Linfo_string26:
	.asciz	"{impl#27}"
.Linfo_string27:
	.asciz	"_RNvXsp_NtCsboyoyqK6YBz_4core6resultINtB5_6ResultuNtNtB7_3fmt5ErrorENtNtNtB7_3ops9try_trait3Try6branchB7_"
.Linfo_string28:
	.asciz	"branch<(), core::fmt::Error>"
.Linfo_string29:
	.asciz	"_RINvNtCsboyoyqK6YBz_4core3ptr4readAhj2_EB4_"
.Linfo_string30:
	.asciz	"read<[u8; 2]>"
.Linfo_string31:
	.asciz	"_RNvMs1_NtNtCsboyoyqK6YBz_4core3ptr8non_nullINtB5_7NonNullAhj2_E4readB9_"
.Linfo_string32:
	.asciz	"_RNvMNtNtCsboyoyqK6YBz_4core3fmt2rtNtB2_8Argument6as_u16"
.Linfo_string33:
	.asciz	"as_u16"
.Linfo_string34:
	.asciz	"_RINvNtCsboyoyqK6YBz_4core3ptr4readAhj4_EB4_"
.Linfo_string35:
	.asciz	"read<[u8; 4]>"
.Linfo_string36:
	.asciz	"_RNvMs1_NtNtCsboyoyqK6YBz_4core3ptr8non_nullINtB5_7NonNullAhj4_E4readB9_"
.Linfo_string37:
	.asciz	"_RNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB5_9Formatter9sign_plus"
.Linfo_string38:
	.asciz	"sign_plus"
.Linfo_string39:
	.asciz	"_RNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB5_9Formatter9alternate"
.Linfo_string40:
	.asciz	"alternate"
.Linfo_string41:
	.asciz	"FormattingOptions"
.Linfo_string42:
	.asciz	"_RNvMs_NtCsboyoyqK6YBz_4core3fmtNtB4_17FormattingOptions9get_align"
.Linfo_string43:
	.asciz	"get_align"
.Linfo_string44:
	.asciz	"_RNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB5_9Formatter7padding"
.Linfo_string45:
	.asciz	"padding"
.Linfo_string46:
	.asciz	"_RNvMs_NtCsboyoyqK6YBz_4core3fmtNtB4_17FormattingOptions4fill"
.Linfo_string47:
	.asciz	"fill"
.Linfo_string48:
	.asciz	"_RNvMs_NtCsboyoyqK6YBz_4core3fmtNtB4_17FormattingOptions5align"
.Linfo_string49:
	.asciz	"align"
.Linfo_string50:
	.asciz	"cmp"
.Linfo_string51:
	.asciz	"impls"
.Linfo_string52:
	.asciz	"{impl#62}"
.Linfo_string53:
	.asciz	"_RNvXsY_NtNtCsboyoyqK6YBz_4core3cmp5implstNtB7_10PartialOrd2lt"
.Linfo_string54:
	.asciz	"lt"
.Linfo_string55:
	.asciz	"iter"
.Linfo_string56:
	.asciz	"range"
.Linfo_string57:
	.asciz	"{impl#5}"
.Linfo_string58:
	.asciz	"_RNvXs3_NtNtCsboyoyqK6YBz_4core4iter5rangeINtNtNtB9_3ops5range5RangetENtB5_17RangeIteratorImpl9spec_nextB9_"
.Linfo_string59:
	.asciz	"spec_next<u16>"
.Linfo_string60:
	.asciz	"{impl#6}"
.Linfo_string61:
	.asciz	"_RNvXs4_NtNtCsboyoyqK6YBz_4core4iter5rangeINtNtNtB9_3ops5range5RangetENtNtNtB7_6traits8iterator8Iterator4nextB9_"
.Linfo_string62:
	.asciz	"next<u16>"
.Linfo_string63:
	.asciz	"num"
.Linfo_string64:
	.asciz	"{impl#7}"
.Linfo_string65:
	.asciz	"_RNvMs5_NtCsboyoyqK6YBz_4core3numt13unchecked_add"
.Linfo_string66:
	.asciz	"unchecked_add"
.Linfo_string67:
	.asciz	"{impl#43}"
.Linfo_string68:
	.asciz	"_RNvXsF_NtNtCsboyoyqK6YBz_4core4iter5rangetNtB5_4Step17forward_unchecked"
.Linfo_string69:
	.asciz	"forward_unchecked"
.Linfo_string70:
	.asciz	"_RNvMs_NtCsboyoyqK6YBz_4core3fmtNtB4_17FormattingOptions8get_fill"
.Linfo_string71:
	.asciz	"get_fill"
.Linfo_string72:
	.asciz	"PostPadding"
.Linfo_string73:
	.asciz	"_RNvMs9_NtCsboyoyqK6YBz_4core3fmtNtB5_11PostPadding5write"
.Linfo_string74:
	.asciz	"write"
.Linfo_string75:
	.asciz	"{impl#12}"
.Linfo_string76:
	.asciz	"pad_integral"
.Linfo_string77:
	.asciz	"slice"
.Linfo_string78:
	.asciz	"index"
.Linfo_string79:
	.asciz	"_RINvNtCsboyoyqK6YBz_4core3ptr12align_offsethEB4_"
.Linfo_string80:
	.asciz	"align_offset<u8>"
.Linfo_string81:
	.asciz	"const_ptr"
.Linfo_string82:
	.asciz	"{impl#0}"
.Linfo_string83:
	.asciz	"_RNvMNtNtCsboyoyqK6YBz_4core3ptr9const_ptrPh12align_offsetB6_"
.Linfo_string84:
	.asciz	"memchr"
.Linfo_string85:
	.asciz	"memchr_aligned"
.Linfo_string86:
	.asciz	"_RNvNvNtNtCsboyoyqK6YBz_4core5slice6memchr14memchr_aligned7runtime"
.Linfo_string87:
	.asciz	"runtime"
.Linfo_string88:
	.asciz	"_RNvMNtNtCsboyoyqK6YBz_4core3ptr9const_ptrPh3addB6_"
.Linfo_string89:
	.asciz	"_RNvNtNtCsboyoyqK6YBz_4core5slice6memchr18contains_zero_byte"
.Linfo_string90:
	.asciz	"contains_zero_byte"
.Linfo_string91:
	.asciz	"_RNvNtNtCsboyoyqK6YBz_4core5slice6memchr12memchr_naive"
.Linfo_string92:
	.asciz	"memchr_naive"
.Linfo_string93:
	.asciz	"imp"
.Linfo_string94:
	.asciz	"{impl#17}"
.Linfo_string95:
	.asciz	"_RNvMsf_NtNtNtCsboyoyqK6YBz_4core3fmt3num3impy10__fmt_inner"
.Linfo_string96:
	.asciz	"_fmt_inner"
.Linfo_string97:
	.asciz	"_RNvMsf_NtNtNtCsboyoyqK6YBz_4core3fmt3num3impy4__fmt"
.Linfo_string98:
	.asciz	"_fmt"
.Linfo_string99:
	.asciz	"mem"
.Linfo_string100:
	.asciz	"maybe_uninit"
.Linfo_string101:
	.asciz	"MaybeUninit"
.Linfo_string102:
	.asciz	"_RNvMs1_NtNtCsboyoyqK6YBz_4core3mem12maybe_uninitINtB5_11MaybeUninithE5writeB9_"
.Linfo_string103:
	.asciz	"write<u8>"
.Linfo_string104:
	.asciz	"{impl#4}"
.Linfo_string105:
	.asciz	"_RNvXs2_NtNtCsboyoyqK6YBz_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninithEE13get_uncheckedB9_"
.Linfo_string106:
	.asciz	"get_unchecked<core::mem::maybe_uninit::MaybeUninit<u8>>"
.Linfo_string107:
	.asciz	"_RNvXs5_NtNtCsboyoyqK6YBz_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninithEE13get_uncheckedB9_"
.Linfo_string108:
	.asciz	"_RINvMNtCsboyoyqK6YBz_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninithE13get_uncheckedINtNtNtB5_3ops5range9RangeFromjEEB5_"
.Linfo_string109:
	.asciz	"get_unchecked<core::mem::maybe_uninit::MaybeUninit<u8>, core::ops::range::RangeFrom<usize>>"
.Linfo_string110:
	.asciz	"_RNvNtNtCsboyoyqK6YBz_4core3fmt3num19slice_buffer_to_str"
.Linfo_string111:
	.asciz	"slice_buffer_to_str"
.Linfo_string112:
	.asciz	"_RINvNtNtCsboyoyqK6YBz_4core5slice5index24get_offset_len_noubcheckINtNtNtB6_3mem12maybe_uninit11MaybeUninithEEB6_"
.Linfo_string113:
	.asciz	"get_offset_len_noubcheck<core::mem::maybe_uninit::MaybeUninit<u8>>"
.Linfo_string114:
	.asciz	"{impl#15}"
.Linfo_string115:
	.asciz	"_RNvNtCsboyoyqK6YBz_4core9panicking9panic_fmt"
.Linfo_string116:
	.asciz	"panic_fmt"
.Linfo_string117:
	.asciz	"_RNvNtCsboyoyqK6YBz_4core3fmt5write"
.Linfo_string118:
	.asciz	"_RNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB5_9Formatter12pad_integral"
.Linfo_string119:
	.asciz	"_RNvNvMsa_NtCsboyoyqK6YBz_4core3fmtNtB7_9Formatter12pad_integral12write_prefix"
.Linfo_string120:
	.asciz	"write_prefix"
.Linfo_string121:
	.asciz	"_RNvNtNtCsboyoyqK6YBz_4core5slice5index16slice_index_fail"
.Linfo_string122:
	.asciz	"slice_index_fail"
.Linfo_string123:
	.asciz	"_RNvNtNtCsboyoyqK6YBz_4core5slice6memchr14memchr_aligned"
.Linfo_string124:
	.asciz	"_RNvXsd_NtNtNtCsboyoyqK6YBz_4core3fmt3num3impyNtB9_7Display3fmt"
	.ident	"rustc version 1.99.0 (b940084d7 2026-09-28)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
