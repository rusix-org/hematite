	.att_syntax
	.file	"hematite.55e213b149fb9646-cgu.0"


	# SAFETY: This entire entry shim executes only under the PVH boot contract.
	# It owns linker-reserved BSS, tables and stack. No safe callers enter it.
	# See docs/design/0001-bootstrap.md and its independent review.
	.section	.note.Xen,"a",@note
	.p2align	2, 0x0
	.long	4
	.long	4
	.long	18
	.ascii	"Xen"
	.byte	0
	.p2align	2, 0x0
	.long	start32

	.section	.text.boot,"ax",@progbits
	.code32
	.globl	start32
start32:
	cli
	cld
	movl	%ebx, %esi	# Preserve PVH start-info address.
	movl	$__stack_top, %esp	# No stack use until BSS cleared.
	xorl	%eax, %eax
	movl	$__bss_start, %edi
	movl	$__bss_end, %ecx
	subl	%edi, %ecx
	shrl	$2, %ecx
	rep		stosl	%eax, %es:(%edi)

	xorl	%eax, %eax
	cpuid
	cmpl	$7, %eax
	jb	boot_fail
	movl	$1, %eax
	cpuid
	andl	$117440512, %edx	# FXSR, SSE, SSE2.
	cmpl	$117440512, %edx
	jne	boot_fail
	movl	$7, %eax
	xorl	%ecx, %ecx
	cpuid
	andl	$1048704, %ebx	# SMEP and SMAP.
	cmpl	$1048704, %ebx
	jne	boot_fail
	movl	$2147483648, %eax
	cpuid
	cmpl	$2147483649, %eax
	jb	boot_fail
	movl	$2147483649, %eax
	cpuid
	andl	$537919488, %edx	# Long mode and NX.
	cmpl	$537919488, %edx
	jne	boot_fail

	movl	$pdpt, %eax
	orl	$3, %eax
	movl	%eax, pml4
	movl	$page_directory, %eax
	orl	$3, %eax
	movl	%eax, pdpt
	movl	$page_directory, %edi
	movl	$page_tables, %eax
	orl	$3, %eax
	movl	$8, %ecx	# Eight PTs map 16 MiB in 4 KiB pages.
.Ltmp0:
	movl	%eax, (%edi)
	addl	$4096, %eax
	addl	$8, %edi
	loop	.Ltmp0

	movl	$page_tables, %edi
	xorl	%ecx, %ecx
.Ltmp1:
	movl	%ecx, %eax
	shll	$12, %eax
	testl	%eax, %eax
	je	.Ltmp2	# Null page stays absent.
	cmpl	$__stack_guard, %eax
	je	.Ltmp2
	movl	$2147483648, %edx	# NX high dword by default.
	cmpl	$__text_start, %eax
	jb	.Ltmp3
	cmpl	$__text_end, %eax
	jae	.Ltmp4
	xorl	%edx, %edx	# Text: RX, supervisor, no write.
	orl	$1, %eax
	jmp	.Ltmp5
.Ltmp4:
	cmpl	$__rodata_start, %eax
	jb	.Ltmp3
	cmpl	$__rodata_end, %eax
	jae	.Ltmp3
	orl	$1, %eax	# Rodata: R/NX.
	jmp	.Ltmp5
.Ltmp3:
	orl	$3, %eax	# Other RAM: RW/NX.
	jmp	.Ltmp5
.Ltmp2:
	xorl	%eax, %eax
	xorl	%edx, %edx
.Ltmp5:
	movl	%eax, (%edi)
	movl	%edx, 4(%edi)
	addl	$8, %edi
	incl	%ecx
	cmpl	$4096, %ecx
	jb	.Ltmp1

	lgdtl	gdt_pointer
	movl	$3147296, %eax	# PAE, OSFXSR, OSXMMEXCPT, SMEP, SMAP.
	movl	%eax, %cr4
	movl	$pml4, %eax
	movl	%eax, %cr3
	movl	$3221225600, %ecx
	rdmsr
	orl	$2304, %eax	# LME and NXE.
	wrmsr
	movl	%cr0, %eax
	andl	$4294967283, %eax	# Clear EM/TS.
	orl	$2147549219, %eax	# Paging, WP, PE, MP.
	movl	%eax, %cr0
	.byte	234
	.long	long_mode	# Far jump to 64-bit code selector.
	.short	8

boot_fail:
	movw	$244, %dx
	movl	$17, %eax
	outl	%eax, %dx
.Ltmp6:
	cli
	hlt
	jmp	.Ltmp6

	.code64
long_mode:
	movw	$16, %ax
	movw	%ax, %ds
	movw	%ax, %es
	movw	%ax, %ss
	xorl	%eax, %eax
	movw	%ax, %fs
	movw	%ax, %gs
	leaq	__stack_top(%rip), %rsp
	xorl	%ebp, %ebp
	clac
	fninit
	ldmxcsr	initial_mxcsr(%rip)
	movl	%esi, %edi
	callq	_RNvCs7n9xbH47f0w_8hematite9boot_main
	ud2

	.section	.rodata.boot,"a",@progbits
	.p2align	3, 0x0
gdt:
	.quad	0
	.quad	49428545226735615
	.quad	58426948388454399	# Accessed bit pre-set: no CPU write to RO GDT.
gdt_pointer:
	.short	23
	.long	gdt
initial_mxcsr:
	.long	8064

	.section	.bss.tables,"aw",@nobits
	.p2align	12, 0x0
	.globl	pml4
	.globl	pdpt
	.globl	page_directory
	.globl	page_tables
pml4:
	.zero	4096
pdpt:
	.zero	4096
page_directory:
	.zero	4096
page_tables:
	.zero	32768



	.section	.text._RINvCsjFdXuXHMTfk_9hm_kernel11run_monitorNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBH_,"ax",@progbits
	.prefalign	4, .Lfunc_end0, nop
	.type	_RINvCsjFdXuXHMTfk_9hm_kernel11run_monitorNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBH_,@function
_RINvCsjFdXuXHMTfk_9hm_kernel11run_monitorNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBH_:
.Lfunc_begin0:
	.cfi_sections .debug_frame
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$280, %rsp
	.cfi_def_cfa_offset 336
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	xorl	%esi, %esi
.LBB0_1:
	cmpq	$47, %rsi
	jne	.LBB0_5
	movl	$100000, %ecx
	.p2align	4
.LBB0_3:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_8
	pause
	decl	%ecx
	jne	.LBB0_3
	jmp	.LBB0_32
	.p2align	4
.LBB0_5:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.0(%rsi), %ecx
	movl	$100000, %edi
	.p2align	4
.LBB0_6:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_11
	pause
	decl	%edi
	jne	.LBB0_6
	jmp	.LBB0_30
	.p2align	4
.LBB0_8:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	.p2align	4
.LBB0_9:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_12
	pause
	decl	%ecx
	jne	.LBB0_9
	jmp	.LBB0_34
	.p2align	4
.LBB0_11:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rsi
	cmpq	$48, %rsi
	jne	.LBB0_1
	jmp	.LBB0_13
.LBB0_12:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rsi
	cmpq	$48, %rsi
	jne	.LBB0_1
.LBB0_13:
	xorl	%esi, %esi
.LBB0_14:
	cmpq	$74, %rsi
	jne	.LBB0_18
	movl	$100000, %ecx
	.p2align	4
.LBB0_16:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_21
	pause
	decl	%ecx
	jne	.LBB0_16
	jmp	.LBB0_38
.LBB0_18:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.1(%rsi), %ecx
	movl	$100000, %edi
	.p2align	4
.LBB0_19:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_24
	pause
	decl	%edi
	jne	.LBB0_19
	jmp	.LBB0_36
.LBB0_21:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_22:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_25
	pause
	decl	%ecx
	jne	.LBB0_22
	jmp	.LBB0_40
.LBB0_24:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_26
.LBB0_25:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_26:
	incq	%rsi
	cmpq	$75, %rsi
	jne	.LBB0_14
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB0_28:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_42
	pause
	decl	%ecx
	jne	.LBB0_28
	jmp	.LBB0_51
.LBB0_30:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB0_31:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_31
.LBB0_32:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB0_33:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_33
.LBB0_34:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB0_35:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_35
.LBB0_36:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB0_37:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_37
.LBB0_38:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB0_39:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_39
.LBB0_40:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB0_41:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_41
.LBB0_42:
	movw	$1016, %dx
	movb	$104, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB0_43:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_45
	pause
	decl	%ecx
	jne	.LBB0_43
	jmp	.LBB0_51
.LBB0_45:
	movw	$1016, %dx
	movb	$109, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB0_46:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_48
	pause
	decl	%ecx
	jne	.LBB0_46
	jmp	.LBB0_51
.LBB0_48:
	movw	$1016, %dx
	movb	$62, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB0_49:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_53
	pause
	decl	%ecx
	jne	.LBB0_49
.LBB0_51:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB0_52:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_52
.LBB0_53:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	leaq	20(%rsp), %rbx
	leaq	112(%rsp), %r13
	leaq	16(%rsp), %r14
	leaq	96(%rsp), %r15
	leaq	15(%rsp), %r12
	movabsq	$72057594037927935, %rbp
	jmp	.LBB0_55
.LBB0_54:
	pause
.LBB0_55:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$1, %al
	je	.LBB0_54
	movw	$1016, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	movzbl	%al, %esi
	movq	%r14, %rdi
	callq	_RNvMCsjFdXuXHMTfk_9hm_kernelNtB2_9InputLine4feed
	movzbl	%al, %eax
	jmpq	*.LJTI0_0(,%rax,8)
.LBB0_57:
	movb	%dl, 15(%rsp)
	movl	$1, %edx
	movq	%r15, %rdi
	movq	%r12, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core3str8converts9from_utf8
	cmpb	$0, 96(%rsp)
	jne	.LBB0_55
	movq	112(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB0_55
	movq	104(%rsp), %rdi
	addq	%rdi, %rsi
.LBB0_60:
	movzbl	(%rdi), %ecx
	cmpb	$10, %cl
	jne	.LBB0_64
	movl	$100000, %ecx
.LBB0_62:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_67
	pause
	decl	%ecx
	jne	.LBB0_62
	jmp	.LBB0_273
.LBB0_64:
	movl	$100000, %r8d
.LBB0_65:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_70
	pause
	decl	%r8d
	jne	.LBB0_65
	jmp	.LBB0_275
.LBB0_67:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_68:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_71
	pause
	decl	%ecx
	jne	.LBB0_68
	jmp	.LBB0_279
.LBB0_70:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_72
.LBB0_71:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_72:
	incq	%rdi
	cmpq	%rsi, %rdi
	jne	.LBB0_60
	jmp	.LBB0_55
.LBB0_73:
	movl	$100000, %ecx
.LBB0_74:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_79
	pause
	decl	%ecx
	jne	.LBB0_74
	jmp	.LBB0_267
.LBB0_76:
	movl	$100000, %ecx
.LBB0_77:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_82
	pause
	decl	%ecx
	jne	.LBB0_77
	jmp	.LBB0_269
.LBB0_79:
	movw	$1016, %dx
	movb	$8, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_80:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_85
	pause
	decl	%ecx
	jne	.LBB0_80
	jmp	.LBB0_267
.LBB0_82:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_83:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_88
	pause
	decl	%ecx
	jne	.LBB0_83
	jmp	.LBB0_271
.LBB0_85:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_86:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_103
	pause
	decl	%ecx
	jne	.LBB0_86
	jmp	.LBB0_267
.LBB0_88:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movq	80(%rsp), %rdx
	cmpq	$65, %rdx
	setae	%al
	orb	88(%rsp), %al
	je	.LBB0_104
	xorl	%esi, %esi
.LBB0_90:
	cmpq	$47, %rsi
	jne	.LBB0_94
	movl	$100000, %ecx
.LBB0_92:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_97
	pause
	decl	%ecx
	jne	.LBB0_92
	jmp	.LBB0_281
.LBB0_94:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.2(%rsi), %ecx
	movl	$100000, %edi
.LBB0_95:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_100
	pause
	decl	%edi
	jne	.LBB0_95
	jmp	.LBB0_283
.LBB0_97:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_98:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_101
	pause
	decl	%ecx
	jne	.LBB0_98
	jmp	.LBB0_285
.LBB0_100:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_102
.LBB0_101:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_102:
	incq	%rsi
	cmpq	$48, %rsi
	jne	.LBB0_90
	jmp	.LBB0_212
.LBB0_103:
	movw	$1016, %dx
	movb	$8, %al
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_55
.LBB0_104:
	cmpq	$6, %rdx
	ja	.LBB0_110
	jmpq	*.LJTI0_1(,%rdx,8)
.LBB0_106:
	cmpb	$114, 16(%rsp)
	jne	.LBB0_239
	cmpb	$117, 17(%rsp)
	jne	.LBB0_239
	cmpb	$110, 18(%rsp)
	jne	.LBB0_239
	movl	$1, %edi
	xorl	%esi, %esi
	jmp	.LBB0_211
.LBB0_110:
	cmpq	$4, %rdx
	jae	.LBB0_203
	jmp	.LBB0_239
.LBB0_111:
	movzbl	16(%rsp), %eax
	cmpl	$97, %eax
	je	.LBB0_204
	cmpl	$104, %eax
	jne	.LBB0_208
	cmpb	$101, 17(%rsp)
	jne	.LBB0_208
	cmpb	$108, 18(%rsp)
	jne	.LBB0_208
	cmpb	$112, 19(%rsp)
	jne	.LBB0_208
	xorl	%esi, %esi
.LBB0_117:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.3(%rsi), %ecx
	cmpb	$10, %cl
	jne	.LBB0_121
	movl	$100000, %ecx
.LBB0_119:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_124
	pause
	decl	%ecx
	jne	.LBB0_119
	jmp	.LBB0_299
.LBB0_121:
	movl	$100000, %edi
.LBB0_122:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_127
	pause
	decl	%edi
	jne	.LBB0_122
	jmp	.LBB0_301
.LBB0_124:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_125:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_128
	pause
	decl	%ecx
	jne	.LBB0_125
	jmp	.LBB0_309
.LBB0_127:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_129
.LBB0_128:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_129:
	incq	%rsi
	cmpq	$153, %rsi
	jne	.LBB0_117
	jmp	.LBB0_212
.LBB0_130:
	cmpb	$115, 16(%rsp)
	jne	.LBB0_203
	cmpb	$116, 17(%rsp)
	jne	.LBB0_203
	cmpb	$97, 18(%rsp)
	jne	.LBB0_203
	cmpb	$116, 19(%rsp)
	jne	.LBB0_203
	cmpb	$117, 20(%rsp)
	jne	.LBB0_203
	cmpb	$115, 21(%rsp)
	jne	.LBB0_203
	callq	_RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform6checks
	andq	%rbp, %rax
	movl	%eax, %ecx
	movq	%rax, %rdx
	movq	%rax, %rsi
	movq	%rax, %rdi
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.7, 112(%rsp)
	movq	$16, 120(%rsp)
	movb	%al, 128(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.8, 136(%rsp)
	movq	$2, 144(%rsp)
	movb	%ah, 152(%rsp)
	shrl	$16, %eax
	shrl	$24, %ecx
	shrq	$32, %rdx
	shrq	$40, %rsi
	shrq	$48, %rdi
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9, 160(%rsp)
	movq	$25, 168(%rsp)
	movb	%al, 176(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.10, 184(%rsp)
	movq	$22, 192(%rsp)
	movb	%cl, 200(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.11, 208(%rsp)
	movq	$12, 216(%rsp)
	movb	%dl, 224(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.12, 232(%rsp)
	movq	$11, 240(%rsp)
	movb	%sil, 248(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.13, 256(%rsp)
	movq	$10, 264(%rsp)
	movb	%dil, 272(%rsp)
	xorl	%esi, %esi
.LBB0_137:
	leaq	(%rsi,%rsi,2), %rax
	movzbl	16(%r13,%rax,8), %edi
	cmpb	$2, %dil
	je	.LBB0_188
	leaq	(,%rax,8), %rax
	addq	%r13, %rax
	movq	8(%rax), %r8
	testq	%r8, %r8
	je	.LBB0_153
	movq	(%rax), %r9
	addq	%r9, %r8
.LBB0_140:
	movzbl	(%r9), %ecx
	cmpb	$10, %cl
	jne	.LBB0_144
	movl	$100000, %ecx
.LBB0_142:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_147
	pause
	decl	%ecx
	jne	.LBB0_142
	jmp	.LBB0_293
.LBB0_144:
	movl	$100000, %r10d
.LBB0_145:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_150
	pause
	decl	%r10d
	jne	.LBB0_145
	jmp	.LBB0_295
.LBB0_147:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_148:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_151
	pause
	decl	%ecx
	jne	.LBB0_148
	jmp	.LBB0_303
.LBB0_150:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_152
.LBB0_151:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_152:
	incq	%r9
	cmpq	%r8, %r9
	jne	.LBB0_140
.LBB0_153:
	cmpb	$1, %dil
	jne	.LBB0_157
	movl	$100000, %ecx
.LBB0_155:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_171
	pause
	decl	%ecx
	jne	.LBB0_155
	jmp	.LBB0_297
.LBB0_157:
	xorl	%edi, %edi
.LBB0_158:
	cmpq	$8, %rdi
	jne	.LBB0_162
	movl	$100000, %ecx
.LBB0_160:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_165
	pause
	decl	%ecx
	jne	.LBB0_160
	jmp	.LBB0_305
.LBB0_162:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.15(%rdi), %ecx
	movl	$100000, %r8d
.LBB0_163:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_168
	pause
	decl	%r8d
	jne	.LBB0_163
	jmp	.LBB0_307
.LBB0_165:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_166:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_169
	pause
	decl	%ecx
	jne	.LBB0_166
	jmp	.LBB0_319
.LBB0_168:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_170
.LBB0_169:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_170:
	incq	%rdi
	cmpq	$9, %rdi
	jne	.LBB0_158
	jmp	.LBB0_187
.LBB0_171:
	movw	$1016, %dx
	movb	$58, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_172:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_174
	pause
	decl	%ecx
	jne	.LBB0_172
	jmp	.LBB0_297
.LBB0_174:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_175:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_177
	pause
	decl	%ecx
	jne	.LBB0_175
	jmp	.LBB0_297
.LBB0_177:
	movw	$1016, %dx
	movb	$79, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_178:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_180
	pause
	decl	%ecx
	jne	.LBB0_178
	jmp	.LBB0_297
.LBB0_180:
	movw	$1016, %dx
	movb	$75, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_181:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_183
	pause
	decl	%ecx
	jne	.LBB0_181
	jmp	.LBB0_331
.LBB0_183:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_184:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_186
	pause
	decl	%ecx
	jne	.LBB0_184
	jmp	.LBB0_333
.LBB0_186:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_187:
	incq	%rsi
	cmpq	$7, %rsi
	jne	.LBB0_137
.LBB0_188:
	xorl	%esi, %esi
.LBB0_189:
	cmpq	$25, %rsi
	jne	.LBB0_193
	movl	$100000, %ecx
.LBB0_191:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_196
	pause
	decl	%ecx
	jne	.LBB0_191
	jmp	.LBB0_325
.LBB0_193:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.14(%rsi), %ecx
	movl	$100000, %edi
.LBB0_194:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_199
	pause
	decl	%edi
	jne	.LBB0_194
	jmp	.LBB0_327
.LBB0_196:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_197:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_200
	pause
	decl	%ecx
	jne	.LBB0_197
	jmp	.LBB0_329
.LBB0_199:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_201
.LBB0_200:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_201:
	incq	%rsi
	cmpq	$26, %rsi
	jne	.LBB0_189
	callq	_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch13report_statusNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEB10_
	jmp	.LBB0_212
.LBB0_203:
	cmpl	$544109938, 16(%rsp)
	je	.LBB0_209
	jmp	.LBB0_239
.LBB0_204:
	cmpb	$112, 17(%rsp)
	jne	.LBB0_208
	cmpb	$112, 18(%rsp)
	jne	.LBB0_208
	cmpb	$115, 19(%rsp)
	jne	.LBB0_208
	callq	_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch9list_appsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBV_
	jmp	.LBB0_212
.LBB0_208:
	movl	16(%rsp), %ecx
	cmpl	$544109938, %ecx
	jne	.LBB0_224
.LBB0_209:
	addq	$-4, %rdx
	movq	%r15, %rdi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core3str8converts9from_utf8
	cmpl	$1, 96(%rsp)
	je	.LBB0_212
	movq	104(%rsp), %rdi
	movq	112(%rsp), %rsi
.LBB0_211:
	callq	_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch11run_commandNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBY_
.LBB0_212:
	movq	$0, 80(%rsp)
	movb	$0, 88(%rsp)
	movl	$100000, %ecx
.LBB0_213:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_215
	pause
	decl	%ecx
	jne	.LBB0_213
	jmp	.LBB0_277
.LBB0_215:
	movw	$1016, %dx
	movb	$104, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_216:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_218
	pause
	decl	%ecx
	jne	.LBB0_216
	jmp	.LBB0_277
.LBB0_218:
	movw	$1016, %dx
	movb	$109, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_219:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_221
	pause
	decl	%ecx
	jne	.LBB0_219
	jmp	.LBB0_277
.LBB0_221:
	movw	$1016, %dx
	movb	$62, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_222:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_253
	pause
	decl	%ecx
	jne	.LBB0_222
	jmp	.LBB0_277
.LBB0_224:
	cmpb	$116, %al
	sete	%al
	andl	$-256, %ecx
	cmpl	$1953719552, %ecx
	sete	%cl
	testb	%cl, %al
	je	.LBB0_239
	callq	_RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBE_
	xorl	%esi, %esi
	testb	%al, %al
	je	.LBB0_254
.LBB0_226:
	cmpq	$23, %rsi
	jne	.LBB0_230
	movl	$100000, %ecx
.LBB0_228:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_233
	pause
	decl	%ecx
	jne	.LBB0_228
	jmp	.LBB0_311
.LBB0_230:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.5(%rsi), %ecx
	movl	$100000, %edi
.LBB0_231:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_236
	pause
	decl	%edi
	jne	.LBB0_231
	jmp	.LBB0_313
.LBB0_233:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_234:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_237
	pause
	decl	%ecx
	jne	.LBB0_234
	jmp	.LBB0_321
.LBB0_236:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_238
.LBB0_237:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_238:
	incq	%rsi
	cmpq	$24, %rsi
	jne	.LBB0_226
	jmp	.LBB0_212
.LBB0_239:
	xorl	%esi, %esi
.LBB0_240:
	cmpq	$27, %rsi
	jne	.LBB0_244
	movl	$100000, %ecx
.LBB0_242:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_247
	pause
	decl	%ecx
	jne	.LBB0_242
	jmp	.LBB0_287
.LBB0_244:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.6(%rsi), %ecx
	movl	$100000, %edi
.LBB0_245:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_250
	pause
	decl	%edi
	jne	.LBB0_245
	jmp	.LBB0_289
.LBB0_247:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_248:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_251
	pause
	decl	%ecx
	jne	.LBB0_248
	jmp	.LBB0_291
.LBB0_250:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_252
.LBB0_251:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_252:
	incq	%rsi
	cmpq	$28, %rsi
	jne	.LBB0_240
	jmp	.LBB0_212
.LBB0_253:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_55
.LBB0_254:
	cmpq	$23, %rsi
	jne	.LBB0_258
	movl	$100000, %ecx
.LBB0_256:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_261
	pause
	decl	%ecx
	jne	.LBB0_256
	jmp	.LBB0_315
.LBB0_258:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.4(%rsi), %ecx
	movl	$100000, %edi
.LBB0_259:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_264
	pause
	decl	%edi
	jne	.LBB0_259
	jmp	.LBB0_317
.LBB0_261:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB0_262:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB0_265
	pause
	decl	%ecx
	jne	.LBB0_262
	jmp	.LBB0_323
.LBB0_264:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB0_266
.LBB0_265:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB0_266:
	incq	%rsi
	cmpq	$24, %rsi
	jne	.LBB0_254
	jmp	.LBB0_212
.LBB0_267:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_268:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_268
.LBB0_269:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_270:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_270
.LBB0_271:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_272:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_272
.LBB0_273:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_274:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_274
.LBB0_275:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_276:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_276
.LBB0_277:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_278:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_278
.LBB0_279:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_280:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_280
.LBB0_281:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_282:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_282
.LBB0_283:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_284:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_284
.LBB0_285:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_286:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_286
.LBB0_287:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_288:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_288
.LBB0_289:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_290:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_290
.LBB0_291:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_292:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_292
.LBB0_293:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_294:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_294
.LBB0_295:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_296:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_296
.LBB0_297:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_298:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_298
.LBB0_299:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_300:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_300
.LBB0_301:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_302:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_302
.LBB0_303:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_304:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_304
.LBB0_305:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_306:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_306
.LBB0_307:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_308:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_308
.LBB0_309:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_310:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_310
.LBB0_311:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_312:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_312
.LBB0_313:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_314:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_314
.LBB0_315:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_316:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_316
.LBB0_317:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_318:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_318
.LBB0_319:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_320:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_320
.LBB0_321:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_322:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_322
.LBB0_323:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_324:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_324
.LBB0_325:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_326:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_326
.LBB0_327:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_328:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_328
.LBB0_329:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_330:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_330
.LBB0_331:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_332:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_332
.LBB0_333:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB0_334:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB0_334
.Lfunc_end0:
	.size	_RINvCsjFdXuXHMTfk_9hm_kernel11run_monitorNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBH_, .Lfunc_end0-_RINvCsjFdXuXHMTfk_9hm_kernel11run_monitorNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBH_
	.cfi_endproc
	.section	.rodata._RINvCsjFdXuXHMTfk_9hm_kernel11run_monitorNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBH_,"a",@progbits
	.p2align	3, 0x0
.LJTI0_0:
	.quad	.LBB0_55
	.quad	.LBB0_57
	.quad	.LBB0_73
	.quad	.LBB0_76
.LJTI0_1:
	.quad	.LBB0_212
	.quad	.LBB0_110
	.quad	.LBB0_110
	.quad	.LBB0_106
	.quad	.LBB0_111
	.quad	.LBB0_110
	.quad	.LBB0_130

	.section	.text._RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBE_,"ax",@progbits
	.prefalign	4, .Lfunc_end1, nop
	.type	_RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBE_,@function
_RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBE_:
.Lfunc_begin1:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$824, %rsp
	.cfi_def_cfa_offset 29552
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	callq	_RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform6checks
	movabsq	$72057594037927935, %rcx
	andq	%rax, %rcx
	movb	%cl, 119(%rsp)
	movl	%ecx, %eax
	shrl	$8, %eax
	movl	%eax, 180(%rsp)
	movl	%ecx, %eax
	shrl	$16, %eax
	movl	%eax, 176(%rsp)
	movl	%ecx, %eax
	shrl	$24, %eax
	movl	%eax, 172(%rsp)
	movq	%rcx, %rax
	shrq	$32, %rax
	movq	%rax, 216(%rsp)
	movq	%rcx, %rax
	shrq	$40, %rax
	movq	%rax, 208(%rsp)
	shrq	$48, %rcx
	movq	%rcx, 224(%rsp)
	movw	$0, 352(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 280(%rsp)
	movl	$3, %eax
.LBB1_1:
	cmpb	$0, 352(%rsp)
	jne	.LBB1_7
	movb	$120, 277(%rsp,%rax)
	cmpb	$0, 352(%rsp)
	jne	.LBB1_7
	movb	$120, 278(%rsp,%rax)
	cmpb	$0, 352(%rsp)
	jne	.LBB1_7
	movb	$120, 279(%rsp,%rax)
	cmpb	$0, 352(%rsp)
	jne	.LBB1_7
	movb	$120, 280(%rsp,%rax)
	addq	$4, %rax
	cmpq	$67, %rax
	jne	.LBB1_1
	cmpb	$0, 352(%rsp)
	je	.LBB1_1756
.LBB1_7:
	movl	$0, 132(%rsp)
.LBB1_8:
	movl	$96, %eax
	.p2align	4
.LBB1_9:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB1_9
	xorl	%eax, %eax
	.p2align	4
.LBB1_11:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_11
	xorl	%eax, %eax
	.p2align	4
.LBB1_13:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_13
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %rbp
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%rbp
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%rbp
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%rbp
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%rbp
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_16
	.p2align	4
.LBB1_15:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB1_213
.LBB1_16:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB1_18
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB1_21
.LBB1_18:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_15
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_15
	incq	%rax
.LBB1_21:
	movl	$4680, %edx
	leaq	4888(%rsp), %rcx
	xorl	%r11d, %r11d
	jmp	.LBB1_23
	.p2align	4
.LBB1_22:
	addq	$2, %r11
	addq	$80, %rdx
	cmpq	$9800, %rdx
	je	.LBB1_213
.LBB1_23:
	cmpb	$2, 233(%rsp,%rdx)
	jne	.LBB1_25
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB1_28
.LBB1_25:
	cmpb	$2, 273(%rsp,%rdx)
	jne	.LBB1_22
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB1_22
	incq	%r11
.LBB1_28:
	movq	%rax, %rdx
	shlq	$5, %rdx
	movl	304(%rsp,%rdx), %esi
	movq	$1, 280(%rsp,%rdx)
	movq	$16, 288(%rsp,%rdx)
	movb	$0, 296(%rsp,%rdx)
	leaq	(%r11,%r11,4), %rdx
	movq	%rax, (%rcx,%rdx,8)
	movl	%esi, 8(%rcx,%rdx,8)
	movq	$1, 16(%rcx,%rdx,8)
	movw	$263, 24(%rcx,%rdx,8)
	movq	$16, 10032(%rsp)
	movl	32(%rcx,%rdx,8), %eax
	movl	%eax, 24(%rsp)
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_29:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_29
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_31:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_31
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_33:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_33
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB1_35:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_35
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_37:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_37
	movq	%r11, 32(%rsp)
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_39:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_39
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_41:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_41
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_43:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_43
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB1_45:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB1_45
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_47:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB1_47
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_49:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB1_49
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_51:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB1_51
	movl	$0, 20(%rsp)
	cmpq	%rax, %r9
	jne	.LBB1_212
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_214
	cmpq	%rdx, %r11
	jne	.LBB1_214
	cmpq	%rsi, %rbx
	jne	.LBB1_214
	cmpq	%rdi, %r14
	jne	.LBB1_214
	cmpq	%r8, %r15
	jne	.LBB1_214
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_213
	movl	$112, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_60:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB1_60
	movl	$4753, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_62:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r15, %rdx
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r15b
	addq	%rdx, %r15
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB1_62
	movl	$2192, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB1_64:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r12
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r12, %rdx
	xorl	%r12d, %r12d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r12b
	addq	%rdx, %r12
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB1_64
	movl	$120, %eax
	xorl	%r13d, %r13d
	.p2align	4
.LBB1_66:
	xorl	%ecx, %ecx
	cmpl	$0, 184(%rsp,%rax)
	sete	%cl
	cmpl	$1, 216(%rsp,%rax)
	movq	%r13, %rdx
	adcq	%rcx, %rdx
	xorl	%r13d, %r13d
	cmpl	$0, 248(%rsp,%rax)
	sete	%r13b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %r13
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB1_66
	movl	$4760, %eax
	xorl	%ebp, %ebp
	.p2align	4
.LBB1_68:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbp, %rdx
	adcq	%rcx, %rdx
	xorl	%ebp, %ebp
	cmpl	$0, 240(%rsp,%rax)
	sete	%bpl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %rbp
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB1_68
	movl	$2200, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_70:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbx, %rdx
	adcq	%rcx, %rdx
	xorl	%ebx, %ebx
	cmpl	$0, 240(%rsp,%rax)
	sete	%bl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %rbx
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB1_70
	leaq	280(%rsp), %rdi
	movl	$2, %esi
	movq	32(%rsp), %rdx
	movl	24(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	je	.LBB1_211
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_73:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_73
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_75:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_75
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_77:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_77
	movl	$120, %r8d
	movq	10032(%rsp), %rsi
	movq	%rsi, 40(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB1_79:
	xorl	%r9d, %r9d
	cmpl	$0, 184(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 216(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%r8)
	sete	%sil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2168, %r8
	jne	.LBB1_79
	movl	$4760, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_81:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$9880, %r9
	jne	.LBB1_81
	movl	$2200, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_83:
	xorl	%r11d, %r11d
	cmpl	$0, 160(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 200(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 240(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 280(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$4760, %r10
	jne	.LBB1_83
	movl	$0, 20(%rsp)
	cmpq	$16, 40(%rsp)
	jne	.LBB1_212
	cmpq	%r14, %rax
	jne	.LBB1_212
	cmpq	%r15, %rcx
	jne	.LBB1_212
	cmpq	%r12, %rdx
	jne	.LBB1_212
	cmpq	%r13, %rsi
	jne	.LBB1_212
	cmpq	%rbp, %r8
	jne	.LBB1_212
	cmpq	%rbx, %r9
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_214
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_213
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r15
	movq	%r15, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$2, %esi
	movq	%r15, %rdi
	movq	32(%rsp), %rbx
	movq	%rbx, %rdx
	movl	24(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$-1, %al
	je	.LBB1_213
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_213
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_213
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_213
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_213
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_213
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_213
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_213
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_213
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r15
	movq	%r15, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$1, (%rsp)
	leaq	12600(%rsp), %rdi
	movl	$2, %edx
	movl	$2, %r9d
	movq	%r15, %rsi
	movq	%rbx, %rcx
	movl	24(%rsp), %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$0, 12600(%rsp)
	je	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_211
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_211
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_211
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_211
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_211
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_211
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_211
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_211
	movl	$1, (%rsp)
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$1, %edx
	movl	$2, %r9d
	movq	32(%rsp), %rcx
	movl	24(%rsp), %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$1, 12600(%rsp)
	je	.LBB1_211
	movq	12608(%rsp), %r13
	movl	12616(%rsp), %r15d
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	12600(%rsp), %rdi
	movl	$2, %edx
	movq	%r12, %rsi
	movq	%r13, %rcx
	movl	%r15d, %r8d
	movl	$1, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$1, 12600(%rsp)
	jne	.LBB1_211
	cmpb	$4, 12601(%rsp)
	jne	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_211
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_211
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_211
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_211
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_211
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_211
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_211
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_211
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$1, (%rsp)
	leaq	12600(%rsp), %rdi
	movl	$2, %edx
	movl	$1, %r9d
	movq	%r12, %rsi
	movq	%r13, %rcx
	movl	%r15d, %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$0, 12600(%rsp)
	je	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_211
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_211
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_211
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_211
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_211
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_211
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_211
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_211
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$2, %esi
	movq	%r12, %rdi
	movq	%r13, %rdx
	movl	%r15d, %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$-1, %al
	je	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_211
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_211
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_211
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_211
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_211
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_211
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_211
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_211
	movl	$5, (%rsp)
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$1, %edx
	movl	$2, %r9d
	movq	32(%rsp), %rcx
	movl	24(%rsp), %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$1, 12600(%rsp)
	je	.LBB1_211
	movq	12608(%rsp), %rbx
	movl	12616(%rsp), %ebp
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$7, (%rsp)
	leaq	12600(%rsp), %rdi
	movl	$2, %edx
	movl	$1, %r9d
	movq	%r12, %rsi
	movq	%rbx, %rcx
	movl	%ebp, %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$0, 12600(%rsp)
	je	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_211
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_211
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_211
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_211
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_211
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_211
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_211
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_211
	movl	$1, (%rsp)
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$2, %edx
	movl	$1, %r9d
	movl	%ebp, %r8d
	movq	%rbx, %rcx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$1, 12600(%rsp)
	je	.LBB1_211
	movq	12608(%rsp), %r14
	movl	12616(%rsp), %eax
	movl	%eax, 40(%rsp)
	movl	$7, (%rsp)
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$1, %edx
	movl	$1, %r9d
	movq	32(%rsp), %rcx
	movl	24(%rsp), %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$1, 12600(%rsp)
	je	.LBB1_211
	movq	12608(%rsp), %rbx
	movl	12616(%rsp), %ebp
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$1, %esi
	movq	%r12, %rdi
	movq	%rbx, 56(%rsp)
	movq	%rbx, %rdx
	movl	%ebp, 72(%rsp)
	movl	%ebp, %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$4, %al
	jne	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_211
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_211
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_211
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_211
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_211
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_211
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_211
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_211
	movl	$0, (%rsp)
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$1, %edx
	movl	$2, %r9d
	movq	32(%rsp), %rcx
	movl	24(%rsp), %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$1, 12600(%rsp)
	je	.LBB1_211
	movq	12608(%rsp), %r12
	movl	12616(%rsp), %ebx
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rbp
	movq	%rbp, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	12600(%rsp), %rdi
	movl	$2, %edx
	movq	%rbp, %rsi
	movq	%r12, %rcx
	movl	%ebx, %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$0, 12600(%rsp)
	je	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_211
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_211
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_211
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_211
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_211
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_211
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_211
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$1, %edx
	movq	%r14, %rcx
	movl	40(%rsp), %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$1, 12600(%rsp)
	je	.LBB1_211
	movq	12608(%rsp), %rbx
	movl	12616(%rsp), %ebp
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$2, %esi
	movq	%r12, %rdi
	movq	%rbx, %rdx
	movl	%ebp, %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel
	cmpb	$-1, %al
	je	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_211
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_211
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_211
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_211
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_211
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_211
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_211
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_211
	leaq	280(%rsp), %rdi
	movq	%rbx, %rsi
	movl	%ebp, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	orb	%al, %dl
	testb	$1, %dl
	jne	.LBB1_211
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	32(%rsp), %rdx
	movl	24(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$-1, %al
	jne	.LBB1_211
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rbx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	12600(%rsp), %rdi
	movl	$2, %edx
	movq	%rbx, %rsi
	movq	%r13, %rcx
	movl	%r15d, %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$0, 12600(%rsp)
	je	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_211
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_211
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_211
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_211
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_211
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_211
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_211
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_211
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rbx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	12600(%rsp), %rdi
	movl	$1, %edx
	movq	%rbx, %rsi
	movq	56(%rsp), %rcx
	movl	72(%rsp), %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$0, 12600(%rsp)
	je	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_211
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_211
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_211
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_211
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_211
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_211
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_211
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_211
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rbx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	12600(%rsp), %rdi
	movl	$1, %edx
	movq	%rbx, %rsi
	movq	%r14, %rcx
	movl	40(%rsp), %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$0, 12600(%rsp)
	je	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_211
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_211
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_211
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_211
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_211
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_211
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_211
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12600(%rsp)
	jne	.LBB1_211
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12624(%rsp)
	je	.LBB1_1980
.LBB1_211:
	movl	$0, 20(%rsp)
.LBB1_212:
	movq	memcpy@GOTPCREL(%rip), %rbp
	jmp	.LBB1_214
.LBB1_213:
	movl	$0, 20(%rsp)
.LBB1_214:
	movl	$96, %eax
	.p2align	4
.LBB1_215:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB1_215
	xorl	%eax, %eax
	.p2align	4
.LBB1_217:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_217
	xorl	%eax, %eax
	.p2align	4
.LBB1_219:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_219
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%rbp
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%rbp
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%rbp
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%rbp
	movq	$8, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_222
	.p2align	4
.LBB1_221:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB1_266
.LBB1_222:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB1_224
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB1_227
.LBB1_224:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_221
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_221
	incq	%rax
.LBB1_227:
	movl	$4680, %edx
	leaq	4888(%rsp), %rcx
	xorl	%edi, %edi
	jmp	.LBB1_229
	.p2align	4
.LBB1_228:
	addq	$2, %rdi
	addq	$80, %rdx
	cmpq	$9800, %rdx
	je	.LBB1_266
.LBB1_229:
	cmpb	$2, 233(%rsp,%rdx)
	jne	.LBB1_231
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB1_234
.LBB1_231:
	cmpb	$2, 273(%rsp,%rdx)
	jne	.LBB1_228
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB1_228
	incq	%rdi
.LBB1_234:
	movq	%rax, %rdx
	shlq	$5, %rdx
	movl	304(%rsp,%rdx), %esi
	movq	$1, 280(%rsp,%rdx)
	movq	$8, 288(%rsp,%rdx)
	movb	$0, 296(%rsp,%rdx)
	movq	%rdi, 32(%rsp)
	leaq	(%rdi,%rdi,4), %rdx
	movq	%rax, (%rcx,%rdx,8)
	movl	%esi, 8(%rcx,%rdx,8)
	movq	$1, 16(%rcx,%rdx,8)
	movw	$263, 24(%rcx,%rdx,8)
	movq	$8, 10032(%rsp)
	movl	32(%rcx,%rdx,8), %eax
	movl	%eax, 40(%rsp)
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_235:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_235
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_237:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_237
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_239:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_239
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB1_241:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_241
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_243:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_243
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_245:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_245
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_247:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%r14d, %r14d
	cmpb	$2, 248(%rsp,%r10)
	setne	%r14b
	addq	%r11, %r14
	addq	%r9, %r14
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%r14, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_247
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_249:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%r11)
	setne	%r14b
	addq	%r14, %r10
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%r11)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r15b
	addq	%r14, %r15
	addq	%r10, %r15
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r15, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_249
	movl	$2192, %r14d
	xorl	%r11d, %r11d
	.p2align	4
.LBB1_251:
	xorl	%r15d, %r15d
	cmpb	$2, 160(%rsp,%r14)
	setne	%r15b
	addq	%r15, %r11
	xorl	%r15d, %r15d
	cmpb	$2, 200(%rsp,%r14)
	setne	%r15b
	xorl	%r12d, %r12d
	cmpb	$2, 240(%rsp,%r14)
	setne	%r12b
	addq	%r15, %r12
	addq	%r11, %r12
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%r14)
	setne	%r11b
	addq	%r12, %r11
	addq	$160, %r14
	cmpq	$4752, %r14
	jne	.LBB1_251
	movl	$120, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_253:
	xorl	%r12d, %r12d
	cmpl	$0, 184(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 216(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	subq	$-128, %r15
	cmpq	$2168, %r15
	jne	.LBB1_253
	movl	$4760, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_255:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$9880, %r12
	jne	.LBB1_255
	movq	%rax, 24(%rsp)
	movl	$2200, %r13d
	xorl	%r12d, %r12d
	.p2align	4
.LBB1_257:
	xorl	%ebp, %ebp
	cmpl	$0, 160(%rsp,%r13)
	sete	%bpl
	cmpl	$1, 200(%rsp,%r13)
	movq	%r12, %rbx
	adcq	%rbp, %rbx
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%r13)
	sete	%r12b
	cmpl	$1, 280(%rsp,%r13)
	adcq	%rbx, %r12
	addq	$160, %r13
	cmpq	$4760, %r13
	jne	.LBB1_257
	xorl	%eax, %eax
	cmpq	24(%rsp), %r9
	jne	.LBB1_679
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_267
	cmpq	%rdx, %r11
	jne	.LBB1_267
	cmpq	%rsi, %r14
	jne	.LBB1_267
	cmpq	%rdi, %r15
	jne	.LBB1_267
	cmpq	%r8, %r12
	jne	.LBB1_267
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_266
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	32(%rsp), %rdx
	movl	40(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB1_266
	movl	$64, %eax
	.p2align	4
.LBB1_543:
	addq	$-4, %rax
	jne	.LBB1_543
	movl	$128, %eax
	.p2align	4
.LBB1_545:
	addq	$-4, %rax
	jne	.LBB1_545
	movl	$64, %eax
	.p2align	4
.LBB1_547:
	addq	$-4, %rax
	jne	.LBB1_547
	movl	$64, %ecx
	movq	10032(%rsp), %rax
	.p2align	4
.LBB1_549:
	addq	$-4, %rcx
	jne	.LBB1_549
	movl	$128, %ecx
	.p2align	4
.LBB1_551:
	addq	$-4, %rcx
	jne	.LBB1_551
	movl	$64, %ecx
	.p2align	4
.LBB1_553:
	addq	$-4, %rcx
	jne	.LBB1_553
	testq	%rax, %rax
	je	.LBB1_555
.LBB1_266:
	xorl	%eax, %eax
.LBB1_267:
	movl	$96, %ecx
	.p2align	4
.LBB1_268:
	movq	$1, 9968(%rsp,%rcx)
	movq	$2, 9960(%rsp,%rcx)
	movq	$0, 9952(%rsp,%rcx)
	movq	$0, 9944(%rsp,%rcx)
	movq	$0, 9976(%rsp,%rcx)
	movq	$0, 9984(%rsp,%rcx)
	movq	$2, 9992(%rsp,%rcx)
	movq	$1, 10000(%rsp,%rcx)
	movq	$0, 10008(%rsp,%rcx)
	movq	$0, 10016(%rsp,%rcx)
	movq	$2, 10024(%rsp,%rcx)
	movq	$1, 10032(%rsp,%rcx)
	movq	$0, 10040(%rsp,%rcx)
	movq	$0, 10048(%rsp,%rcx)
	movq	$2, 10056(%rsp,%rcx)
	movq	$1, 10064(%rsp,%rcx)
	subq	$-128, %rcx
	cmpq	$2144, %rcx
	jne	.LBB1_268
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_270:
	movq	$1, 312(%rsp,%rcx)
	movq	$512, 304(%rsp,%rcx)
	movq	$0, 296(%rsp,%rcx)
	movq	$0, 288(%rsp,%rcx)
	movq	$0, 280(%rsp,%rcx)
	movq	$0, 320(%rsp,%rcx)
	movq	$0, 328(%rsp,%rcx)
	movq	$0, 336(%rsp,%rcx)
	movq	$512, 344(%rsp,%rcx)
	movq	$1, 352(%rsp,%rcx)
	movq	$0, 360(%rsp,%rcx)
	movq	$0, 368(%rsp,%rcx)
	movq	$0, 376(%rsp,%rcx)
	movq	$512, 384(%rsp,%rcx)
	movq	$1, 392(%rsp,%rcx)
	movq	$0, 400(%rsp,%rcx)
	movq	$0, 408(%rsp,%rcx)
	movq	$0, 416(%rsp,%rcx)
	movq	$512, 424(%rsp,%rcx)
	movq	$1, 432(%rsp,%rcx)
	addq	$160, %rcx
	cmpq	$5120, %rcx
	jne	.LBB1_270
	movl	%eax, 32(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB1_272:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_272
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%rbp
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%rbp
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%rbp
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%rbp
	movq	$-1, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_275
	.p2align	4
.LBB1_274:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB1_331
.LBB1_275:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB1_277
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB1_280
.LBB1_277:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_274
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_274
	incq	%rax
.LBB1_280:
	movl	$4680, %edx
	leaq	4888(%rsp), %rcx
	xorl	%edi, %edi
	jmp	.LBB1_282
	.p2align	4
.LBB1_281:
	addq	$2, %rdi
	addq	$80, %rdx
	cmpq	$9800, %rdx
	je	.LBB1_331
.LBB1_282:
	cmpb	$2, 233(%rsp,%rdx)
	jne	.LBB1_284
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB1_287
.LBB1_284:
	cmpb	$2, 273(%rsp,%rdx)
	jne	.LBB1_281
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB1_281
	incq	%rdi
.LBB1_287:
	movq	%rax, %rdx
	shlq	$5, %rdx
	movl	304(%rsp,%rdx), %esi
	movq	$1, 280(%rsp,%rdx)
	movq	$-1, 288(%rsp,%rdx)
	movb	$0, 296(%rsp,%rdx)
	movq	%rdi, 40(%rsp)
	leaq	(%rdi,%rdi,4), %rdx
	movq	%rax, (%rcx,%rdx,8)
	movl	%esi, 8(%rcx,%rdx,8)
	movq	$1, 16(%rcx,%rdx,8)
	movw	$263, 24(%rcx,%rdx,8)
	movq	$-1, 10032(%rsp)
	movl	32(%rcx,%rdx,8), %eax
	movl	%eax, 56(%rsp)
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_288:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_288
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_290:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_290
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_292:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_292
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB1_294:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_294
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_296:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_296
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_298:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_298
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_300:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%r14d, %r14d
	cmpb	$2, 248(%rsp,%r10)
	setne	%r14b
	addq	%r11, %r14
	addq	%r9, %r14
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%r14, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_300
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_302:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%r11)
	setne	%r14b
	addq	%r14, %r10
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%r11)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r15b
	addq	%r14, %r15
	addq	%r10, %r15
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r15, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_302
	movl	$2192, %r14d
	xorl	%r11d, %r11d
	.p2align	4
.LBB1_304:
	xorl	%r15d, %r15d
	cmpb	$2, 160(%rsp,%r14)
	setne	%r15b
	addq	%r15, %r11
	xorl	%r15d, %r15d
	cmpb	$2, 200(%rsp,%r14)
	setne	%r15b
	xorl	%r12d, %r12d
	cmpb	$2, 240(%rsp,%r14)
	setne	%r12b
	addq	%r15, %r12
	addq	%r11, %r12
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%r14)
	setne	%r11b
	addq	%r12, %r11
	addq	$160, %r14
	cmpq	$4752, %r14
	jne	.LBB1_304
	movl	$120, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_306:
	xorl	%r12d, %r12d
	cmpl	$0, 184(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 216(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	subq	$-128, %r15
	cmpq	$2168, %r15
	jne	.LBB1_306
	movl	$4760, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_308:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$9880, %r12
	jne	.LBB1_308
	movq	%rax, 24(%rsp)
	movl	$2200, %r13d
	xorl	%r12d, %r12d
	.p2align	4
.LBB1_310:
	xorl	%ebp, %ebp
	cmpl	$0, 160(%rsp,%r13)
	sete	%bpl
	cmpl	$1, 200(%rsp,%r13)
	movq	%r12, %rbx
	adcq	%rbp, %rbx
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%r13)
	sete	%r12b
	cmpl	$1, 280(%rsp,%r13)
	adcq	%rbx, %r12
	addq	$160, %r13
	cmpq	$4760, %r13
	jne	.LBB1_310
	xorl	%eax, %eax
	cmpq	24(%rsp), %r9
	jne	.LBB1_680
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_332
	cmpq	%rdx, %r11
	jne	.LBB1_332
	cmpq	%rsi, %r14
	jne	.LBB1_332
	cmpq	%rdi, %r15
	jne	.LBB1_332
	cmpq	%r8, %r12
	jne	.LBB1_332
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_331
	movl	$64, %eax
	.p2align	4
.LBB1_319:
	addq	$-4, %rax
	jne	.LBB1_319
	movl	$128, %eax
	.p2align	4
.LBB1_321:
	addq	$-4, %rax
	jne	.LBB1_321
	movl	$64, %eax
	.p2align	4
.LBB1_323:
	addq	$-4, %rax
	jne	.LBB1_323
	movl	$64, %eax
	.p2align	4
.LBB1_325:
	addq	$-4, %rax
	jne	.LBB1_325
	movl	$128, %eax
	.p2align	4
.LBB1_327:
	addq	$-4, %rax
	jne	.LBB1_327
	movl	$64, %eax
	.p2align	4
.LBB1_329:
	addq	$-4, %rax
	jne	.LBB1_329
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	40(%rsp), %rdx
	movl	56(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB1_331
	movl	$64, %eax
	.p2align	4
.LBB1_557:
	addq	$-4, %rax
	jne	.LBB1_557
	movl	$128, %eax
	.p2align	4
.LBB1_559:
	addq	$-4, %rax
	jne	.LBB1_559
	movl	$64, %eax
	.p2align	4
.LBB1_561:
	addq	$-4, %rax
	jne	.LBB1_561
	movl	$64, %ecx
	movq	10032(%rsp), %rax
	.p2align	4
.LBB1_563:
	addq	$-4, %rcx
	jne	.LBB1_563
	movl	$128, %ecx
	.p2align	4
.LBB1_565:
	addq	$-4, %rcx
	jne	.LBB1_565
	movl	$64, %ecx
	.p2align	4
.LBB1_567:
	addq	$-4, %rcx
	jne	.LBB1_567
	testq	%rax, %rax
	je	.LBB1_569
.LBB1_331:
	xorl	%eax, %eax
.LBB1_332:
	movl	$96, %ecx
	.p2align	4
.LBB1_333:
	movq	$1, 9968(%rsp,%rcx)
	movq	$2, 9960(%rsp,%rcx)
	movq	$0, 9952(%rsp,%rcx)
	movq	$0, 9944(%rsp,%rcx)
	movq	$0, 9976(%rsp,%rcx)
	movq	$0, 9984(%rsp,%rcx)
	movq	$2, 9992(%rsp,%rcx)
	movq	$1, 10000(%rsp,%rcx)
	movq	$0, 10008(%rsp,%rcx)
	movq	$0, 10016(%rsp,%rcx)
	movq	$2, 10024(%rsp,%rcx)
	movq	$1, 10032(%rsp,%rcx)
	movq	$0, 10040(%rsp,%rcx)
	movq	$0, 10048(%rsp,%rcx)
	movq	$2, 10056(%rsp,%rcx)
	movq	$1, 10064(%rsp,%rcx)
	subq	$-128, %rcx
	cmpq	$2144, %rcx
	jne	.LBB1_333
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_335:
	movq	$1, 312(%rsp,%rcx)
	movq	$512, 304(%rsp,%rcx)
	movq	$0, 296(%rsp,%rcx)
	movq	$0, 288(%rsp,%rcx)
	movq	$0, 280(%rsp,%rcx)
	movq	$0, 320(%rsp,%rcx)
	movq	$0, 328(%rsp,%rcx)
	movq	$0, 336(%rsp,%rcx)
	movq	$512, 344(%rsp,%rcx)
	movq	$1, 352(%rsp,%rcx)
	movq	$0, 360(%rsp,%rcx)
	movq	$0, 368(%rsp,%rcx)
	movq	$0, 376(%rsp,%rcx)
	movq	$512, 384(%rsp,%rcx)
	movq	$1, 392(%rsp,%rcx)
	movq	$0, 400(%rsp,%rcx)
	movq	$0, 408(%rsp,%rcx)
	movq	$0, 416(%rsp,%rcx)
	movq	$512, 424(%rsp,%rcx)
	movq	$1, 432(%rsp,%rcx)
	addq	$160, %rcx
	cmpq	$5120, %rcx
	jne	.LBB1_335
	movl	%eax, 40(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB1_337:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_337
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%rbp
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%rbp
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%rbp
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%rbp
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	xorl	%ebx, %ebx
.LBB1_339:
	cmpq	$64, %rbx
	je	.LBB1_355
	incq	%rbx
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_342
	.p2align	4
.LBB1_341:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB1_392
.LBB1_342:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB1_344
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB1_347
.LBB1_344:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_341
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_341
	incq	%rax
.LBB1_347:
	movl	$4680, %edx
	xorl	%ecx, %ecx
	jmp	.LBB1_349
	.p2align	4
.LBB1_348:
	addq	$2, %rcx
	addq	$80, %rdx
	cmpq	$9800, %rdx
	je	.LBB1_392
.LBB1_349:
	cmpb	$2, 233(%rsp,%rdx)
	jne	.LBB1_351
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB1_354
.LBB1_351:
	cmpb	$2, 273(%rsp,%rdx)
	jne	.LBB1_348
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB1_348
	incq	%rcx
.LBB1_354:
	movq	%rax, %rdx
	shlq	$5, %rdx
	movl	304(%rsp,%rdx), %esi
	movq	$1, 280(%rsp,%rdx)
	movq	$1, 288(%rsp,%rdx)
	movb	$0, 296(%rsp,%rdx)
	leaq	(%rcx,%rcx,4), %rcx
	leaq	280(%rsp), %rdi
	movq	%rax, 4608(%rdi,%rcx,8)
	movl	%esi, 4616(%rdi,%rcx,8)
	movq	$1, 4624(%rdi,%rcx,8)
	movw	$263, 4632(%rdi,%rcx,8)
	movq	%rbx, 10032(%rsp)
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	jne	.LBB1_339
	jmp	.LBB1_392
.LBB1_355:
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_356:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_356
	movl	$128, %ecx
	.p2align	4
.LBB1_358:
	addq	$-4, %rcx
	jne	.LBB1_358
	movl	$64, %ecx
	.p2align	4
.LBB1_360:
	addq	$-4, %rcx
	jne	.LBB1_360
	movl	$64, %ecx
	.p2align	4
.LBB1_362:
	addq	$-4, %rcx
	jne	.LBB1_362
	movl	$128, %ecx
	.p2align	4
.LBB1_364:
	addq	$-4, %rcx
	jne	.LBB1_364
	movl	$64, %ecx
	.p2align	4
.LBB1_366:
	addq	$-4, %rcx
	jne	.LBB1_366
	cmpq	$64, %rax
	jne	.LBB1_392
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_369:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_369
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_371:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_371
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_373:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_373
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB1_375:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_375
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_377:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_377
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_379:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_379
	movl	$56, %r9d
	jmp	.LBB1_382
	.p2align	4
.LBB1_381:
	addq	$64, %r9
	cmpq	$2104, %r9
	je	.LBB1_641
.LBB1_382:
	cmpb	$2, 240(%rsp,%r9)
	jne	.LBB1_384
	cmpl	$0, 248(%rsp,%r9)
	jne	.LBB1_386
.LBB1_384:
	cmpb	$2, 272(%rsp,%r9)
	jne	.LBB1_381
	cmpl	$0, 280(%rsp,%r9)
	je	.LBB1_381
.LBB1_386:
	xorl	%r9d, %r9d
	jmp	.LBB1_388
.LBB1_387:
	addq	$80, %r9
	cmpq	$5120, %r9
	je	.LBB1_641
.LBB1_388:
	cmpb	$2, 4913(%rsp,%r9)
	jne	.LBB1_390
	cmpl	$0, 4920(%rsp,%r9)
	jne	.LBB1_392
.LBB1_390:
	cmpb	$2, 4953(%rsp,%r9)
	jne	.LBB1_387
	cmpl	$0, 4960(%rsp,%r9)
	je	.LBB1_387
.LBB1_392:
	movl	$0, 24(%rsp)
.LBB1_393:
	movl	$96, %eax
	.p2align	4
.LBB1_394:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB1_394
	xorl	%eax, %eax
	.p2align	4
.LBB1_396:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_396
	xorl	%eax, %eax
	.p2align	4
.LBB1_398:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_398
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%rbp
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%rbp
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%rbp
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%rbp
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_401
	.p2align	4
.LBB1_400:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB1_430
.LBB1_401:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB1_403
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB1_406
.LBB1_403:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_400
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_400
	movq	%rbp, %r12
	incq	%rax
	jmp	.LBB1_407
.LBB1_406:
	movq	%rbp, %r12
.LBB1_407:
	movl	$4680, %ecx
	xorl	%r13d, %r13d
	jmp	.LBB1_409
	.p2align	4
.LBB1_408:
	addq	$2, %r13
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB1_431
.LBB1_409:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB1_411
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB1_414
.LBB1_411:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB1_408
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_408
	incq	%r13
.LBB1_414:
	movq	%rax, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %edx
	movq	$1, 280(%rsp,%rcx)
	movq	$1, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	leaq	(%r13,%r13,4), %rcx
	leaq	280(%rsp), %rsi
	leaq	4608(%rsi,%rcx,8), %r14
	movq	%rax, 4608(%rsi,%rcx,8)
	movl	%edx, 4616(%rsi,%rcx,8)
	movq	$1, 4624(%rsi,%rcx,8)
	movw	$263, 4632(%rsi,%rcx,8)
	movq	$1, 10032(%rsp)
	movl	4640(%rsi,%rcx,8), %eax
	movl	%eax, 56(%rsp)
	movl	$1, %r15d
	leaq	280(%rsp), %rbx
.LBB1_415:
	cmpl	$128, %r15d
	je	.LBB1_604
	cmpb	$2, 25(%r14)
	je	.LBB1_431
	xorl	%eax, %eax
	cmpq	$1, 16(%r14)
	jne	.LBB1_432
	movq	(%r14), %rdi
	cmpq	$63, %rdi
	ja	.LBB1_432
	movl	8(%r14), %ecx
	movq	%rdi, %rdx
	shlq	$5, %rdx
	cmpl	%ecx, 304(%rsp,%rdx)
	jne	.LBB1_431
	addq	%rsp, %rdx
	addq	$280, %rdx
	xorl	%eax, %eax
	cmpb	$0, 16(%rdx)
	jne	.LBB1_432
	movzbl	24(%r14), %edx
	andb	$5, %dl
	cmpb	$5, %dl
	jne	.LBB1_432
	movl	$4680, %esi
	xorl	%edx, %edx
	jmp	.LBB1_424
	.p2align	4
.LBB1_423:
	addq	$2, %rdx
	addq	$80, %rsi
	cmpq	$9800, %rsi
	je	.LBB1_431
.LBB1_424:
	cmpb	$2, 233(%rsp,%rsi)
	jne	.LBB1_426
	cmpl	$0, 240(%rsp,%rsi)
	jne	.LBB1_429
.LBB1_426:
	cmpb	$2, 273(%rsp,%rsi)
	jne	.LBB1_423
	cmpl	$0, 280(%rsp,%rsi)
	je	.LBB1_423
	incq	%rdx
.LBB1_429:
	leaq	(%rdx,%rdx,4), %rdx
	leaq	280(%rsp), %rsi
	movq	%rdi, 4608(%rsi,%rdx,8)
	movl	%ecx, 4616(%rsi,%rdx,8)
	movq	$2, 4624(%rsi,%rdx,8)
	movw	$1, 4632(%rsi,%rdx,8)
	incl	%r15d
	movq	%rbx, %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	jne	.LBB1_415
	jmp	.LBB1_431
.LBB1_430:
	movq	%rbp, %r12
.LBB1_431:
	xorl	%eax, %eax
.LBB1_432:
	movl	$96, %ecx
	.p2align	4
.LBB1_433:
	movq	$1, 9968(%rsp,%rcx)
	movq	$2, 9960(%rsp,%rcx)
	movq	$0, 9952(%rsp,%rcx)
	movq	$0, 9944(%rsp,%rcx)
	movq	$0, 9976(%rsp,%rcx)
	movq	$0, 9984(%rsp,%rcx)
	movq	$2, 9992(%rsp,%rcx)
	movq	$1, 10000(%rsp,%rcx)
	movq	$0, 10008(%rsp,%rcx)
	movq	$0, 10016(%rsp,%rcx)
	movq	$2, 10024(%rsp,%rcx)
	movq	$1, 10032(%rsp,%rcx)
	movq	$0, 10040(%rsp,%rcx)
	movq	$0, 10048(%rsp,%rcx)
	movq	$2, 10056(%rsp,%rcx)
	movq	$1, 10064(%rsp,%rcx)
	subq	$-128, %rcx
	cmpq	$2144, %rcx
	jne	.LBB1_433
	xorl	%ecx, %ecx
	movq	%r12, %rbp
	.p2align	4
.LBB1_435:
	movq	$1, 312(%rsp,%rcx)
	movq	$512, 304(%rsp,%rcx)
	movq	$0, 296(%rsp,%rcx)
	movq	$0, 288(%rsp,%rcx)
	movq	$0, 280(%rsp,%rcx)
	movq	$0, 320(%rsp,%rcx)
	movq	$0, 328(%rsp,%rcx)
	movq	$0, 336(%rsp,%rcx)
	movq	$512, 344(%rsp,%rcx)
	movq	$1, 352(%rsp,%rcx)
	movq	$0, 360(%rsp,%rcx)
	movq	$0, 368(%rsp,%rcx)
	movq	$0, 376(%rsp,%rcx)
	movq	$512, 384(%rsp,%rcx)
	movq	$1, 392(%rsp,%rcx)
	movq	$0, 400(%rsp,%rcx)
	movq	$0, 408(%rsp,%rcx)
	movq	$0, 416(%rsp,%rcx)
	movq	$512, 424(%rsp,%rcx)
	movq	$1, 432(%rsp,%rcx)
	addq	$160, %rcx
	cmpq	$5120, %rcx
	jne	.LBB1_435
	movl	%eax, 56(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB1_437:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_437
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%rbp
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%rbp
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%rbp
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%rbp
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %eax
	xorl	%r14d, %r14d
	jmp	.LBB1_440
	.p2align	4
.LBB1_439:
	addq	$2, %r14
	addq	$64, %rax
	cmpq	$2104, %rax
	je	.LBB1_467
.LBB1_440:
	cmpb	$2, 240(%rsp,%rax)
	jne	.LBB1_442
	cmpl	$0, 248(%rsp,%rax)
	jne	.LBB1_445
.LBB1_442:
	cmpb	$2, 272(%rsp,%rax)
	jne	.LBB1_439
	cmpl	$0, 280(%rsp,%rax)
	je	.LBB1_439
	incq	%r14
.LBB1_445:
	movl	$4680, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_447
	.p2align	4
.LBB1_446:
	addq	$2, %rax
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB1_467
.LBB1_447:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB1_449
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB1_452
.LBB1_449:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB1_446
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_446
	incq	%rax
.LBB1_452:
	movq	%r14, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %ebp
	movq	$1, 280(%rsp,%rcx)
	movq	$1, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	leaq	(%rax,%rax,4), %rax
	leaq	280(%rsp), %rcx
	movq	%r14, 4608(%rcx,%rax,8)
	movl	%ebp, 4616(%rcx,%rax,8)
	movq	$1, 4624(%rcx,%rax,8)
	movw	$263, 4632(%rcx,%rax,8)
	movq	$1, 10032(%rsp)
	xorl	%r15d, %r15d
	leaq	2328(%rsp), %r13
	leaq	280(%rsp), %rbx
.LBB1_453:
	cmpl	$64, %r15d
	je	.LBB1_570
	movl	$2192, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_455:
	xorl	%edx, %edx
	cmpb	$2, 160(%rsp,%rax)
	setne	%dl
	addq	%rdx, %rcx
	xorl	%edx, %edx
	cmpb	$2, 200(%rsp,%rax)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rcx, %rsi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rax)
	setne	%cl
	addq	%rsi, %rcx
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB1_455
	cmpq	$63, %rcx
	ja	.LBB1_465
	movl	$2120, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_459
	.p2align	4
.LBB1_458:
	addq	$2, %rax
	addq	$80, %rcx
	cmpq	$4680, %rcx
	je	.LBB1_465
.LBB1_459:
	cmpb	$2, 232(%rsp,%rcx)
	jne	.LBB1_461
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB1_464
.LBB1_461:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_458
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_458
	incq	%rax
.LBB1_464:
	leaq	(%rax,%rax,4), %rax
	movq	$1, (%r13,%rax,8)
	movq	%r14, 8(%r13,%rax,8)
	movl	%ebp, 16(%r13,%rax,8)
	movb	$0, 24(%r13,%rax,8)
	incl	%r15d
	movq	%rbx, %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	jne	.LBB1_453
.LBB1_465:
	xorl	%r12d, %r12d
.LBB1_466:
	movq	memcpy@GOTPCREL(%rip), %rbp
	jmp	.LBB1_468
.LBB1_570:
	movl	$64, %eax
	.p2align	4
.LBB1_571:
	addq	$-4, %rax
	jne	.LBB1_571
	movl	$128, %eax
	movq	memcpy@GOTPCREL(%rip), %rbp
	.p2align	4
.LBB1_573:
	addq	$-4, %rax
	jne	.LBB1_573
	movl	$2192, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_575:
	xorl	%edx, %edx
	cmpb	$2, 160(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 200(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	addq	$160, %rcx
	cmpq	$4752, %rcx
	jne	.LBB1_575
	movl	$64, %ecx
	.p2align	4
.LBB1_577:
	addq	$-4, %rcx
	jne	.LBB1_577
	movl	$128, %ecx
	.p2align	4
.LBB1_579:
	addq	$-4, %rcx
	jne	.LBB1_579
	movl	$64, %ecx
	.p2align	4
.LBB1_581:
	addq	$-4, %rcx
	jne	.LBB1_581
	cmpq	$64, %rax
	jne	.LBB1_467
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_584:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_584
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_586:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_586
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_588:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_588
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB1_590:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_590
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_592:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_592
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_594:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_594
	movl	$2192, %r9d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_596:
	xorl	%r11d, %r11d
	cmpb	$2, 160(%rsp,%r9)
	setne	%r11b
	addq	%r11, %r10
	xorl	%r11d, %r11d
	cmpb	$2, 200(%rsp,%r9)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 240(%rsp,%r9)
	setne	%bl
	addq	%r11, %rbx
	addq	%r10, %rbx
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r9)
	setne	%r10b
	addq	%rbx, %r10
	addq	$160, %r9
	cmpq	$4752, %r9
	jne	.LBB1_596
	cmpq	$63, %r10
	ja	.LBB1_660
	xorl	%r9d, %r9d
	jmp	.LBB1_600
.LBB1_599:
	addq	$80, %r9
	cmpq	$2560, %r9
	je	.LBB1_660
.LBB1_600:
	cmpb	$2, 2352(%rsp,%r9)
	jne	.LBB1_602
	cmpl	$0, 2360(%rsp,%r9)
	jne	.LBB1_467
.LBB1_602:
	cmpb	$2, 2392(%rsp,%r9)
	jne	.LBB1_599
	cmpl	$0, 2400(%rsp,%r9)
	je	.LBB1_599
.LBB1_467:
	xorl	%r12d, %r12d
.LBB1_468:
	movl	$96, %eax
	.p2align	4
.LBB1_469:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB1_469
	xorl	%eax, %eax
	.p2align	4
.LBB1_471:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_471
	xorl	%eax, %eax
	.p2align	4
.LBB1_473:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_473
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%rbp
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%rbp
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%rbp
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%rbp
	movq	$4096, 10008(%rsp)
	movq	$1, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_476
	.p2align	4
.LBB1_475:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB1_491
.LBB1_476:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB1_478
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB1_481
.LBB1_478:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_475
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_475
	incq	%rax
.LBB1_481:
	movl	$4680, %ecx
	xorl	%ebx, %ebx
	jmp	.LBB1_483
	.p2align	4
.LBB1_482:
	addq	$2, %rbx
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB1_491
.LBB1_483:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB1_485
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB1_488
.LBB1_485:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB1_482
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_482
	incq	%rbx
.LBB1_488:
	movq	%rax, %rdx
	shlq	$5, %rdx
	movl	304(%rsp,%rdx), %ecx
	movq	$1, 280(%rsp,%rdx)
	movq	$1, 288(%rsp,%rdx)
	movb	$0, 296(%rsp,%rdx)
	leaq	(%rbx,%rbx,4), %rdx
	leaq	280(%rsp), %rsi
	movq	%rax, 4608(%rsi,%rdx,8)
	movl	%ecx, 4616(%rsi,%rdx,8)
	movq	$1, 4624(%rsi,%rdx,8)
	movw	$263, 4632(%rsi,%rdx,8)
	movq	$1, 10032(%rsp)
	movl	4640(%rsi,%rdx,8), %r15d
	movl	$2192, %esi
	leaq	2328(%rsp), %rdx
	xorl	%edi, %edi
	.p2align	4
.LBB1_489:
	xorl	%r8d, %r8d
	cmpb	$2, 160(%rsp,%rsi)
	setne	%r8b
	addq	%r8, %rdi
	xorl	%r8d, %r8d
	cmpb	$2, 200(%rsp,%rsi)
	setne	%r8b
	xorl	%r9d, %r9d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r9b
	addq	%r8, %r9
	addq	%rdi, %r9
	xorl	%edi, %edi
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dil
	addq	%r9, %rdi
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_489
	testq	%rdi, %rdi
	je	.LBB1_492
.LBB1_491:
	xorl	%r13d, %r13d
.LBB1_714:
	movl	$96, %eax
	.p2align	4
.LBB1_715:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB1_715
	xorl	%eax, %eax
	.p2align	4
.LBB1_717:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_717
	xorl	%eax, %eax
	.p2align	4
.LBB1_719:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_719
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%rbp
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%rbp
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%rbp
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%rbp
	movq	$4096, 10008(%rsp)
	movq	$0, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_722
	.p2align	4
.LBB1_721:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB1_768
.LBB1_722:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB1_724
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB1_727
.LBB1_724:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_721
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_721
	incq	%rax
.LBB1_727:
	movl	$4680, %ecx
	xorl	%esi, %esi
	jmp	.LBB1_729
	.p2align	4
.LBB1_728:
	addq	$2, %rsi
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB1_768
.LBB1_729:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB1_731
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB1_734
.LBB1_731:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB1_728
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_728
	incq	%rsi
.LBB1_734:
	movq	%rax, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %edx
	movq	$1, 280(%rsp,%rcx)
	movq	$1, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	movq	%rsi, 96(%rsp)
	leaq	(%rsi,%rsi,4), %rcx
	leaq	280(%rsp), %rsi
	movq	%rax, 4608(%rsi,%rcx,8)
	movl	%edx, 4616(%rsi,%rcx,8)
	movq	$1, 4624(%rsi,%rcx,8)
	movw	$263, 4632(%rsi,%rcx,8)
	movq	$1, 10032(%rsp)
	movl	4640(%rsi,%rcx,8), %eax
	movl	%eax, 80(%rsp)
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_735:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_735
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_737:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_737
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_739:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_739
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB1_741:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_741
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_743:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_743
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_745:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_745
	movl	$64, %r9d
	.p2align	4
.LBB1_747:
	addq	$-4, %r9
	jne	.LBB1_747
	movl	%r12d, 72(%rsp)
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_749:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%r14d, %r14d
	cmpb	$2, 248(%rsp,%r10)
	setne	%r14b
	addq	%r11, %r14
	addq	%r9, %r14
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%r14, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_749
	movl	%r13d, 88(%rsp)
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_751:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%r11)
	setne	%r14b
	addq	%r14, %r10
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%r11)
	setne	%r14b
	xorl	%r12d, %r12d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r12b
	addq	%r14, %r12
	addq	%r10, %r12
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r12, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_751
	movl	$2192, %r14d
	xorl	%r11d, %r11d
	.p2align	4
.LBB1_753:
	xorl	%r12d, %r12d
	cmpb	$2, 160(%rsp,%r14)
	setne	%r12b
	addq	%r12, %r11
	xorl	%r12d, %r12d
	cmpb	$2, 200(%rsp,%r14)
	setne	%r12b
	xorl	%r13d, %r13d
	cmpb	$2, 240(%rsp,%r14)
	setne	%r13b
	addq	%r12, %r13
	addq	%r11, %r13
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%r14)
	setne	%r11b
	addq	%r13, %r11
	addq	$160, %r14
	cmpq	$4752, %r14
	jne	.LBB1_753
	movl	$120, %r12d
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_755:
	xorl	%r13d, %r13d
	cmpl	$0, 184(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 216(%rsp,%r12)
	movq	%r14, %rbp
	adcq	%r13, %rbp
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%r12)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r14
	subq	$-128, %r12
	cmpq	$2168, %r12
	jne	.LBB1_755
	movl	$4760, %r12d
	xorl	%r13d, %r13d
	.p2align	4
.LBB1_757:
	xorl	%ebp, %ebp
	cmpl	$0, 160(%rsp,%r12)
	sete	%bpl
	cmpl	$1, 200(%rsp,%r12)
	movq	%r13, %r15
	adcq	%rbp, %r15
	xorl	%r13d, %r13d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%r15, %r13
	addq	$160, %r12
	cmpq	$9880, %r12
	jne	.LBB1_757
	movl	$2200, %r12d
	xorl	%ebp, %ebp
	.p2align	4
.LBB1_759:
	xorl	%r15d, %r15d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 200(%rsp,%r12)
	movq	%rbp, %rbx
	adcq	%r15, %rbx
	xorl	%ebp, %ebp
	cmpl	$0, 240(%rsp,%r12)
	sete	%bpl
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbx, %rbp
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB1_759
	xorl	%ebx, %ebx
	cmpq	%rax, %r9
	jne	.LBB1_770
	cmpq	%rcx, %r10
	jne	.LBB1_770
	cmpq	%rdx, %r11
	jne	.LBB1_770
	cmpq	%rsi, %r14
	jne	.LBB1_770
	cmpq	%rdi, %r13
	jne	.LBB1_770
	cmpq	%r8, %rbp
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_771
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_768
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	96(%rsp), %rdx
	movl	80(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	je	.LBB1_769
.LBB1_768:
	xorl	%ebx, %ebx
.LBB1_771:
	movl	$96, %eax
	.p2align	4
.LBB1_772:
	movq	$1, 17648(%rsp,%rax)
	movq	$2, 17640(%rsp,%rax)
	movq	$0, 17632(%rsp,%rax)
	movq	$0, 17624(%rsp,%rax)
	movq	$0, 17656(%rsp,%rax)
	movq	$0, 17664(%rsp,%rax)
	movq	$2, 17672(%rsp,%rax)
	movq	$1, 17680(%rsp,%rax)
	movq	$0, 17688(%rsp,%rax)
	movq	$0, 17696(%rsp,%rax)
	movq	$2, 17704(%rsp,%rax)
	movq	$1, 17712(%rsp,%rax)
	movq	$0, 17720(%rsp,%rax)
	movq	$0, 17728(%rsp,%rax)
	movq	$2, 17736(%rsp,%rax)
	movq	$1, 17744(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB1_772
	xorl	%eax, %eax
	.p2align	4
.LBB1_774:
	movq	$1, 12632(%rsp,%rax)
	movq	$512, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$512, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$512, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$512, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_774
	movl	%ebx, 168(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB1_776:
	movq	$1, 10072(%rsp,%rax)
	movq	$2, 10064(%rsp,%rax)
	movq	$0, 10056(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10080(%rsp,%rax)
	movq	$0, 10088(%rsp,%rax)
	movq	$0, 10096(%rsp,%rax)
	movq	$2, 10104(%rsp,%rax)
	movq	$1, 10112(%rsp,%rax)
	movq	$0, 10120(%rsp,%rax)
	movq	$0, 10128(%rsp,%rax)
	movq	$0, 10136(%rsp,%rax)
	movq	$2, 10144(%rsp,%rax)
	movq	$1, 10152(%rsp,%rax)
	movq	$0, 10160(%rsp,%rax)
	movq	$0, 10168(%rsp,%rax)
	movq	$0, 10176(%rsp,%rax)
	movq	$2, 10184(%rsp,%rax)
	movq	$1, 10192(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_776
	leaq	19768(%rsp), %rbx
	leaq	17720(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%rbp
	leaq	24376(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$5120, %edx
	callq	*%rbp
	leaq	21816(%rsp), %rdi
	leaq	10040(%rsp), %rsi
	movl	$2560, %edx
	callq	*%rbp
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%rbp
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$112, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_778:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB1_778
	movl	$4753, %eax
	xorl	%r13d, %r13d
	.p2align	4
.LBB1_780:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r13
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r13, %rdx
	xorl	%r13d, %r13d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r13b
	addq	%rdx, %r13
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB1_780
	movl	$2192, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_782:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r15, %rdx
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r15b
	addq	%rdx, %r15
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB1_782
	movl	$120, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB1_784:
	xorl	%ecx, %ecx
	cmpl	$0, 184(%rsp,%rax)
	sete	%cl
	cmpl	$1, 216(%rsp,%rax)
	movq	%r12, %rdx
	adcq	%rcx, %rdx
	xorl	%r12d, %r12d
	cmpl	$0, 248(%rsp,%rax)
	sete	%r12b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %r12
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB1_784
	movl	$4760, %eax
	xorl	%ebp, %ebp
	.p2align	4
.LBB1_786:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbp, %rdx
	adcq	%rcx, %rdx
	xorl	%ebp, %ebp
	cmpl	$0, 240(%rsp,%rax)
	sete	%bpl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %rbp
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB1_786
	movl	$2200, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_788:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbx, %rdx
	adcq	%rcx, %rdx
	xorl	%ebx, %ebx
	cmpl	$0, 240(%rsp,%rax)
	sete	%bl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %rbx
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB1_788
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_791
	.p2align	4
.LBB1_790:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB1_846
.LBB1_791:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB1_793
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB1_796
.LBB1_793:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_790
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_790
	incq	%rax
.LBB1_796:
	movl	$4680, %ecx
	xorl	%edx, %edx
	jmp	.LBB1_798
	.p2align	4
.LBB1_797:
	addq	$2, %rdx
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB1_846
.LBB1_798:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB1_800
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB1_803
.LBB1_800:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB1_797
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_797
	incq	%rdx
.LBB1_803:
	movq	%rax, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %esi
	movq	$1, 280(%rsp,%rcx)
	movq	$8, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	leaq	(%rdx,%rdx,4), %rcx
	leaq	280(%rsp), %rdi
	movq	%rax, 4608(%rdi,%rcx,8)
	movl	%esi, 4616(%rdi,%rcx,8)
	movq	$1, 4624(%rdi,%rcx,8)
	movw	$263, 4632(%rdi,%rcx,8)
	movq	$8, 10032(%rsp)
	movl	4640(%rdi,%rcx,8), %ecx
	movl	$4680, %edi
	xorl	%r8d, %r8d
	jmp	.LBB1_805
	.p2align	4
.LBB1_804:
	addq	$2, %r8
	addq	$80, %rdi
	cmpq	$9800, %rdi
	je	.LBB1_846
.LBB1_805:
	cmpb	$2, 233(%rsp,%rdi)
	jne	.LBB1_807
	cmpl	$0, 240(%rsp,%rdi)
	jne	.LBB1_810
.LBB1_807:
	cmpb	$2, 273(%rsp,%rdi)
	jne	.LBB1_804
	cmpl	$0, 280(%rsp,%rdi)
	je	.LBB1_804
	incq	%r8
.LBB1_810:
	movq	%r8, 24(%rsp)
	leaq	(%r8,%r8,4), %rdi
	leaq	280(%rsp), %r8
	movq	%rax, 4608(%r8,%rdi,8)
	movl	%esi, 4616(%r8,%rdi,8)
	movq	$2, 4624(%r8,%rdi,8)
	movw	$1, 4632(%r8,%rdi,8)
	movl	4640(%r8,%rdi,8), %eax
	movl	%eax, 32(%rsp)
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_846
	movl	$64, %eax
	.p2align	4
.LBB1_813:
	addq	$-4, %rax
	jne	.LBB1_813
	movl	$128, %eax
	.p2align	4
.LBB1_815:
	addq	$-4, %rax
	jne	.LBB1_815
	movl	$64, %eax
	.p2align	4
.LBB1_817:
	addq	$-4, %rax
	jne	.LBB1_817
	movl	$64, %ecx
	movq	10032(%rsp), %rax
	.p2align	4
.LBB1_819:
	addq	$-4, %rcx
	jne	.LBB1_819
	movl	$128, %ecx
	.p2align	4
.LBB1_821:
	addq	$-4, %rcx
	jne	.LBB1_821
	movl	$64, %ecx
	.p2align	4
.LBB1_823:
	addq	$-4, %rcx
	jne	.LBB1_823
	cmpq	$8, %rax
	jne	.LBB1_846
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_826:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_826
	movl	$128, %ecx
	.p2align	4
.LBB1_828:
	addq	$-4, %rcx
	jne	.LBB1_828
	movl	$64, %ecx
	.p2align	4
.LBB1_830:
	addq	$-4, %rcx
	jne	.LBB1_830
	movl	$64, %ecx
	.p2align	4
.LBB1_832:
	addq	$-4, %rcx
	jne	.LBB1_832
	movl	$128, %ecx
	.p2align	4
.LBB1_834:
	addq	$-4, %rcx
	jne	.LBB1_834
	movl	$64, %ecx
	.p2align	4
.LBB1_836:
	addq	$-4, %rcx
	jne	.LBB1_836
	cmpq	$1, %rax
	jne	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	24(%rsp), %rcx
	cmpq	$1, 12608(%rsp)
	jne	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$2, %edx
	movl	32(%rsp), %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$1, 12600(%rsp)
	je	.LBB1_846
	movq	12608(%rsp), %rax
	movq	%rax, 40(%rsp)
	movl	12616(%rsp), %eax
	movl	%eax, 56(%rsp)
	leaq	280(%rsp), %rdi
	movl	$2, %esi
	movq	24(%rsp), %rdx
	movl	32(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$8, 12624(%rsp)
	jne	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12608(%rsp)
	jne	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$1, 12616(%rsp)
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	movq	40(%rsp), %rsi
	movl	56(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	orb	%al, %dl
	testb	$1, %dl
	je	.LBB1_1758
.LBB1_846:
	movl	$0, 16(%rsp)
.LBB1_847:
	movl	$96, %eax
	movq	memcpy@GOTPCREL(%rip), %rbp
	.p2align	4
.LBB1_848:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB1_848
	xorl	%eax, %eax
	.p2align	4
.LBB1_850:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_850
	xorl	%eax, %eax
	.p2align	4
.LBB1_852:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_852
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%rbp
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %r14
	movl	$5120, %edx
	movq	%r14, %rsi
	callq	*%rbp
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%rbp
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%rbp
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	xorl	%ebx, %ebx
	xorl	%r9d, %r9d
.LBB1_854:
	cmpl	$64, %ebx
	je	.LBB1_904
	cmpq	10008(%rsp), %r9
	jae	.LBB1_965
	incl	%ebx
	incq	%r9
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_858
	.p2align	4
.LBB1_857:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB1_965
.LBB1_858:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB1_860
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB1_863
.LBB1_860:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_857
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_857
	incq	%rax
.LBB1_863:
	movl	$4680, %ecx
	xorl	%r15d, %r15d
	jmp	.LBB1_865
	.p2align	4
.LBB1_864:
	addq	$2, %r15
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB1_965
.LBB1_865:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB1_867
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB1_870
.LBB1_867:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB1_864
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_864
	incq	%r15
.LBB1_870:
	movq	%rax, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %edx
	movq	$1, 280(%rsp,%rcx)
	movq	$1, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	leaq	(%r15,%r15,4), %rcx
	leaq	280(%rsp), %rsi
	movq	%rax, 4608(%rsi,%rcx,8)
	movl	%edx, 4616(%rsi,%rcx,8)
	movq	$1, 4624(%rsi,%rcx,8)
	movw	$263, 4632(%rsi,%rcx,8)
	movq	%r9, 10032(%rsp)
	movl	4640(%rsi,%rcx,8), %r12d
	movl	$1, %esi
	movq	%r14, %rdi
	movq	%r15, %rdx
	movl	%r12d, %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB1_965
	movq	%r15, %rdx
	movl	$112, %eax
	xorl	%r13d, %r13d
	.p2align	4
.LBB1_872:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r13
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rax)
	setne	%sil
	addq	%rcx, %rsi
	addq	%r13, %rsi
	xorl	%r13d, %r13d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r13b
	addq	%rsi, %r13
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB1_872
	movl	$4753, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_874:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rcx, %rsi
	addq	%r15, %rsi
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r15b
	addq	%rsi, %r15
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB1_874
	movl	$2192, %eax
	xorl	%ebp, %ebp
	.p2align	4
.LBB1_876:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbp
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rcx, %rsi
	addq	%rbp, %rsi
	xorl	%ebp, %ebp
	cmpb	$2, 280(%rsp,%rax)
	setne	%bpl
	addq	%rsi, %rbp
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB1_876
	movl	%r12d, %ecx
	movl	$120, %eax
	movq	10032(%rsp), %rsi
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_878:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rax)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rax)
	movq	%r14, %rdi
	adcq	%r8, %rdi
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%rax)
	sete	%r14b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdi, %r14
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB1_878
	movq	%rbx, 32(%rsp)
	movl	$4760, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB1_880:
	xorl	%r8d, %r8d
	cmpl	$0, 160(%rsp,%rax)
	sete	%r8b
	cmpl	$1, 200(%rsp,%rax)
	movq	%r12, %rdi
	adcq	%r8, %rdi
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r12b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdi, %r12
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB1_880
	movq	%rsi, 24(%rsp)
	movl	$2200, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_882:
	xorl	%edi, %edi
	cmpl	$0, 160(%rsp,%rax)
	sete	%dil
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbx, %rsi
	adcq	%rdi, %rsi
	xorl	%ebx, %ebx
	cmpl	$0, 240(%rsp,%rax)
	sete	%bl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %rbx
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB1_882
	movl	$1, %esi
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	je	.LBB1_963
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_885:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_885
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_887:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_887
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_889:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_889
	movl	$120, %r8d
	movq	10032(%rsp), %rsi
	movq	%rsi, 40(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB1_891:
	xorl	%r9d, %r9d
	cmpl	$0, 184(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 216(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%r8)
	sete	%sil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2168, %r8
	jne	.LBB1_891
	movl	$4760, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_893:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$9880, %r9
	jne	.LBB1_893
	movl	$2200, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_895:
	xorl	%r11d, %r11d
	cmpl	$0, 160(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 200(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 240(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 280(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$4760, %r10
	jne	.LBB1_895
	movq	40(%rsp), %rdi
	cmpq	24(%rsp), %rdi
	jne	.LBB1_964
	cmpq	%r13, %rax
	jne	.LBB1_964
	cmpq	%r15, %rcx
	jne	.LBB1_964
	cmpq	%rbp, %rdx
	jne	.LBB1_964
	cmpq	%r14, %rsi
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_965
	cmpq	%r12, %r8
	jne	.LBB1_965
	cmpq	%rbx, %r9
	movl	$0, %r12d
	jne	.LBB1_966
	leaq	280(%rsp), %r14
	movq	%r14, %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movq	24(%rsp), %r9
	testb	%al, %al
	movq	32(%rsp), %rbx
	jne	.LBB1_854
	jmp	.LBB1_965
.LBB1_492:
	movl	$2120, %esi
	xorl	%r13d, %r13d
	jmp	.LBB1_494
	.p2align	4
.LBB1_493:
	addq	$2, %r13
	addq	$80, %rsi
	cmpq	$4680, %rsi
	je	.LBB1_491
.LBB1_494:
	cmpb	$2, 232(%rsp,%rsi)
	jne	.LBB1_496
	cmpl	$0, 240(%rsp,%rsi)
	jne	.LBB1_499
.LBB1_496:
	cmpb	$2, 272(%rsp,%rsi)
	jne	.LBB1_493
	cmpl	$0, 280(%rsp,%rsi)
	je	.LBB1_493
	incq	%r13
.LBB1_499:
	leaq	(,%r13,4), %rsi
	addq	%r13, %rsi
	movq	$1, (%rdx,%rsi,8)
	movq	%rax, 8(%rdx,%rsi,8)
	movl	%ecx, 16(%rdx,%rsi,8)
	movb	$0, 24(%rdx,%rsi,8)
	movl	32(%rdx,%rsi,8), %eax
	movl	%eax, 96(%rsp)
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_500:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_500
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_502:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_502
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_504:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_504
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB1_506:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_506
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_508:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_508
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_510:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_510
	movl	$2192, %r9d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_512:
	xorl	%r11d, %r11d
	cmpb	$2, 160(%rsp,%r9)
	setne	%r11b
	addq	%r11, %r10
	xorl	%r11d, %r11d
	cmpb	$2, 200(%rsp,%r9)
	setne	%r11b
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r9)
	setne	%r14b
	addq	%r11, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r9)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r9
	cmpq	$4752, %r9
	jne	.LBB1_512
	testq	%r10, %r10
	je	.LBB1_536
.LBB1_514:
	movl	%r15d, 120(%rsp)
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_515:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%r14d, %r14d
	cmpb	$2, 248(%rsp,%r10)
	setne	%r14b
	addq	%r11, %r14
	addq	%r9, %r14
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%r14, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_515
	movl	%r12d, 72(%rsp)
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_517:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%r11)
	setne	%r14b
	addq	%r14, %r10
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%r11)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r15b
	addq	%r14, %r15
	addq	%r10, %r15
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r15, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_517
	movl	$2192, %r14d
	xorl	%r11d, %r11d
	.p2align	4
.LBB1_519:
	xorl	%r15d, %r15d
	cmpb	$2, 160(%rsp,%r14)
	setne	%r15b
	addq	%r15, %r11
	xorl	%r15d, %r15d
	cmpb	$2, 200(%rsp,%r14)
	setne	%r15b
	xorl	%r12d, %r12d
	cmpb	$2, 240(%rsp,%r14)
	setne	%r12b
	addq	%r15, %r12
	addq	%r11, %r12
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%r14)
	setne	%r11b
	addq	%r12, %r11
	addq	$160, %r14
	cmpq	$4752, %r14
	jne	.LBB1_519
	movq	%r13, 80(%rsp)
	movq	%rbx, 88(%rsp)
	movl	$120, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_521:
	xorl	%r12d, %r12d
	cmpl	$0, 184(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 216(%rsp,%r15)
	movq	%r14, %rbp
	adcq	%r12, %rbp
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%rbp, %r14
	subq	$-128, %r15
	cmpq	$2168, %r15
	jne	.LBB1_521
	movl	$4760, %ebp
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_523:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%rbp)
	sete	%r12b
	cmpl	$1, 200(%rsp,%rbp)
	movq	%r15, %r13
	adcq	%r12, %r13
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%rbp)
	sete	%r15b
	cmpl	$1, 280(%rsp,%rbp)
	adcq	%r13, %r15
	addq	$160, %rbp
	cmpq	$9880, %rbp
	jne	.LBB1_523
	movl	$2200, %r12d
	xorl	%ebp, %ebp
	.p2align	4
.LBB1_525:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%rbp, %rbx
	adcq	%r13, %rbx
	xorl	%ebp, %ebp
	cmpl	$0, 240(%rsp,%r12)
	sete	%bpl
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbx, %rbp
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB1_525
	xorl	%r13d, %r13d
	cmpq	%rax, %r9
	jne	.LBB1_712
	cmpq	%rcx, %r10
	movl	72(%rsp), %r12d
	jne	.LBB1_713
	cmpq	%rdx, %r11
	jne	.LBB1_713
	cmpq	%rsi, %r14
	jne	.LBB1_713
	cmpq	%rdi, %r15
	jne	.LBB1_713
	cmpq	%r8, %rbp
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_714
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_491
	leaq	280(%rsp), %rdi
	movq	80(%rsp), %rsi
	movl	96(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	jne	.LBB1_491
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	xorl	%r13d, %r13d
	movl	$1, %edx
	movq	88(%rsp), %rcx
	movl	120(%rsp), %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$0, 12600(%rsp)
	jne	.LBB1_714
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	%eax, %r13d
	jmp	.LBB1_714
.LBB1_770:
	movq	memcpy@GOTPCREL(%rip), %rbp
	jmp	.LBB1_771
.LBB1_536:
	xorl	%r9d, %r9d
	jmp	.LBB1_538
	.p2align	4
.LBB1_537:
	addq	$80, %r9
	cmpq	$2560, %r9
	je	.LBB1_514
.LBB1_538:
	cmpb	$2, 2352(%rsp,%r9)
	jne	.LBB1_540
	cmpl	$0, 2360(%rsp,%r9)
	jne	.LBB1_491
.LBB1_540:
	cmpb	$2, 2392(%rsp,%r9)
	jne	.LBB1_537
	cmpl	$0, 2400(%rsp,%r9)
	je	.LBB1_537
	jmp	.LBB1_491
.LBB1_769:
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	40(%rsp), %ecx
	andb	32(%rsp), %cl
	movl	24(%rsp), %edx
	andb	%cl, %dl
	andb	%al, %dl
	movl	72(%rsp), %eax
	andb	56(%rsp), %al
	movl	88(%rsp), %ebx
	andb	%al, %bl
	andb	%dl, %bl
	jmp	.LBB1_771
.LBB1_904:
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_905:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_905
	movl	$128, %ecx
	.p2align	4
.LBB1_907:
	addq	$-4, %rcx
	jne	.LBB1_907
	movl	$64, %ecx
	.p2align	4
.LBB1_909:
	addq	$-4, %rcx
	jne	.LBB1_909
	movl	$120, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_911:
	xorl	%esi, %esi
	cmpl	$0, 184(%rsp,%rdx)
	sete	%sil
	cmpl	$1, 216(%rsp,%rdx)
	movq	%rcx, %rdi
	adcq	%rsi, %rdi
	xorl	%ecx, %ecx
	cmpl	$0, 248(%rsp,%rdx)
	sete	%cl
	cmpl	$1, 280(%rsp,%rdx)
	adcq	%rdi, %rcx
	subq	$-128, %rdx
	cmpq	$2168, %rdx
	jne	.LBB1_911
	movl	$4760, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_913:
	xorl	%edi, %edi
	cmpl	$0, 160(%rsp,%rsi)
	sete	%dil
	cmpl	$1, 200(%rsp,%rsi)
	movq	%rdx, %r8
	adcq	%rdi, %r8
	xorl	%edx, %edx
	cmpl	$0, 240(%rsp,%rsi)
	sete	%dl
	cmpl	$1, 280(%rsp,%rsi)
	adcq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$9880, %rsi
	jne	.LBB1_913
	movl	$64, %esi
	.p2align	4
.LBB1_915:
	addq	$-4, %rsi
	jne	.LBB1_915
	xorl	%r12d, %r12d
	orq	%r9, %rax
	jne	.LBB1_966
	cmpq	$64, %rcx
	jne	.LBB1_966
	cmpq	$64, %rdx
	jne	.LBB1_966
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_920:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_920
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_922:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_922
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_924:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_924
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB1_926:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_926
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_928:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_928
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_930:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_930
	cmpq	$0, 10008(%rsp)
	je	.LBB1_944
	xorl	%r9d, %r9d
	jmp	.LBB1_934
.LBB1_933:
	addq	$64, %r9
	cmpq	$2048, %r9
	je	.LBB1_944
.LBB1_934:
	cmpb	$2, 296(%rsp,%r9)
	jne	.LBB1_936
	cmpl	$0, 304(%rsp,%r9)
	jne	.LBB1_938
.LBB1_936:
	cmpb	$2, 328(%rsp,%r9)
	jne	.LBB1_933
	cmpl	$0, 336(%rsp,%r9)
	je	.LBB1_933
.LBB1_938:
	xorl	%r9d, %r9d
	jmp	.LBB1_940
.LBB1_939:
	addq	$80, %r9
	cmpq	$5120, %r9
	je	.LBB1_944
.LBB1_940:
	cmpb	$2, 4913(%rsp,%r9)
	jne	.LBB1_942
	cmpl	$0, 4920(%rsp,%r9)
	jne	.LBB1_965
.LBB1_942:
	cmpb	$2, 4953(%rsp,%r9)
	jne	.LBB1_939
	cmpl	$0, 4960(%rsp,%r9)
	je	.LBB1_939
	jmp	.LBB1_965
.LBB1_604:
	movl	$64, %eax
	.p2align	4
.LBB1_605:
	addq	$-4, %rax
	jne	.LBB1_605
	movl	$4753, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_607:
	xorl	%edx, %edx
	cmpb	$2, 160(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 200(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	addq	$160, %rcx
	cmpq	$9873, %rcx
	jne	.LBB1_607
	movl	$64, %ecx
	.p2align	4
.LBB1_609:
	addq	$-4, %rcx
	jne	.LBB1_609
	movl	$64, %ecx
	.p2align	4
.LBB1_611:
	addq	$-4, %rcx
	jne	.LBB1_611
	movl	$128, %ecx
	.p2align	4
.LBB1_613:
	addq	$-4, %rcx
	jne	.LBB1_613
	movl	$64, %ecx
	.p2align	4
.LBB1_615:
	addq	$-4, %rcx
	jne	.LBB1_615
	cmpq	$128, %rax
	jne	.LBB1_431
	movl	$112, %ecx
	xorl	%ebp, %ebp
	.p2align	4
.LBB1_618:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rbp
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rbp, %rsi
	xorl	%ebp, %ebp
	cmpb	$2, 280(%rsp,%rcx)
	setne	%bpl
	addq	%rsi, %rbp
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_618
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_620:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_620
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_622:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_622
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB1_624:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_624
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_626:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_626
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_628:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_628
	movl	$56, %r9d
	jmp	.LBB1_631
.LBB1_630:
	addq	$64, %r9
	xorl	%eax, %eax
	cmpq	$2104, %r9
	je	.LBB1_432
.LBB1_631:
	cmpb	$2, 240(%rsp,%r9)
	jne	.LBB1_633
	cmpl	$0, 248(%rsp,%r9)
	jne	.LBB1_635
.LBB1_633:
	cmpb	$2, 272(%rsp,%r9)
	jne	.LBB1_630
	cmpl	$0, 280(%rsp,%r9)
	je	.LBB1_630
.LBB1_635:
	movl	$4680, %r9d
	jmp	.LBB1_637
.LBB1_636:
	addq	$80, %r9
	cmpq	$9800, %r9
	je	.LBB1_681
.LBB1_637:
	cmpb	$2, 233(%rsp,%r9)
	jne	.LBB1_639
	cmpl	$0, 240(%rsp,%r9)
	jne	.LBB1_431
.LBB1_639:
	cmpb	$2, 273(%rsp,%r9)
	jne	.LBB1_636
	cmpl	$0, 280(%rsp,%r9)
	je	.LBB1_636
	jmp	.LBB1_431
.LBB1_713:
	movq	memcpy@GOTPCREL(%rip), %rbp
	jmp	.LBB1_714
.LBB1_555:
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	jmp	.LBB1_267
.LBB1_569:
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	jmp	.LBB1_332
.LBB1_641:
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_642:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_642
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_644:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_644
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB1_646:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB1_646
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_648:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB1_648
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_650:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB1_650
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_652:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB1_652
	movl	$0, 24(%rsp)
	cmpq	%rax, %r9
	jne	.LBB1_1734
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_393
	cmpq	%rdx, %r11
	jne	.LBB1_393
	cmpq	%rsi, %rbx
	jne	.LBB1_393
	cmpq	%rdi, %r14
	jne	.LBB1_393
	cmpq	%r8, %r15
	jne	.LBB1_393
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	%eax, 24(%rsp)
	jmp	.LBB1_393
.LBB1_944:
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_945:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_945
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_947:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_947
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB1_949:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB1_949
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_951:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB1_951
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_953:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB1_953
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_955:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB1_955
	xorl	%r12d, %r12d
	cmpq	%rax, %r9
	jne	.LBB1_1736
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_966
	cmpq	%rdx, %r11
	jne	.LBB1_966
	cmpq	%rsi, %rbx
	jne	.LBB1_966
	cmpq	%rdi, %r14
	jne	.LBB1_966
	cmpq	%r8, %r15
	jne	.LBB1_966
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	%eax, %r12d
	jmp	.LBB1_966
.LBB1_660:
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_661:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_661
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_663:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_663
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB1_665:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB1_665
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_667:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB1_667
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_669:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB1_669
	movl	$2200, %r13d
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_671:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r13)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r13)
	movq	%r15, %rbp
	adcq	%r12, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r13)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r13)
	adcq	%rbp, %r15
	addq	$160, %r13
	cmpq	$4760, %r13
	jne	.LBB1_671
	xorl	%r12d, %r12d
	cmpq	%rax, %r9
	jne	.LBB1_466
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_468
	cmpq	%rdx, %r11
	jne	.LBB1_468
	cmpq	%rsi, %rbx
	jne	.LBB1_468
	cmpq	%rdi, %r14
	jne	.LBB1_468
	cmpq	%r8, %r15
	jne	.LBB1_468
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	%eax, %r12d
	jmp	.LBB1_468
.LBB1_963:
	xorl	%r12d, %r12d
	movq	memcpy@GOTPCREL(%rip), %rbp
	jmp	.LBB1_966
.LBB1_679:
	movq	memcpy@GOTPCREL(%rip), %rbp
	jmp	.LBB1_267
.LBB1_680:
	movq	memcpy@GOTPCREL(%rip), %rbp
	jmp	.LBB1_332
.LBB1_681:
	movl	$112, %r10d
	xorl	%eax, %eax
.LBB1_682:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %rax
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%rax, %rbx
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%r10)
	setne	%al
	addq	%rbx, %rax
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_682
	movl	$4753, %r11d
	xorl	%r10d, %r10d
.LBB1_684:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_684
	movl	$2192, %ebx
	xorl	%r11d, %r11d
.LBB1_686:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB1_686
	movq	%rax, 72(%rsp)
	movl	$120, %r14d
	xorl	%ebx, %ebx
.LBB1_688:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB1_688
	movl	$4760, %r15d
	xorl	%r14d, %r14d
.LBB1_690:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %rax
	adcq	%r12, %rax
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%rax, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB1_690
	movl	$2200, %r12d
	xorl	%r15d, %r15d
.LBB1_692:
	xorl	%eax, %eax
	cmpl	$0, 160(%rsp,%r12)
	sete	%al
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %r9
	adcq	%rax, %r9
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%r9, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB1_692
	cmpq	%rbp, 72(%rsp)
	jne	.LBB1_1757
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %r12
	jne	.LBB1_431
	cmpq	%rdx, %r11
	movl	$0, %eax
	jne	.LBB1_432
	cmpq	%rsi, %rbx
	jne	.LBB1_432
	cmpq	%rdi, %r14
	jne	.LBB1_432
	cmpq	%r8, %r15
	jne	.LBB1_432
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_431
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rbx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$1, (%rsp)
	leaq	12600(%rsp), %rdi
	movl	$1, %edx
	movl	$2, %r9d
	movq	%rbx, %rsi
	movq	%r13, %rcx
	movl	56(%rsp), %r8d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	cmpb	$0, 12600(%rsp)
	je	.LBB1_431
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_431
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_431
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_431
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_431
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_431
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_431
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_431
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_711
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	%r13, %rdx
	movl	56(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$-1, %al
	jne	.LBB1_711
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12624(%rsp)
	je	.LBB1_1842
.LBB1_711:
	xorl	%eax, %eax
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB1_432
.LBB1_712:
	movq	memcpy@GOTPCREL(%rip), %rbp
	movl	72(%rsp), %r12d
	jmp	.LBB1_714
.LBB1_964:
	movq	memcpy@GOTPCREL(%rip), %rbp
.LBB1_965:
	xorl	%r12d, %r12d
.LBB1_966:
	movl	$96, %eax
	.p2align	4
.LBB1_967:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB1_967
	xorl	%eax, %eax
	.p2align	4
.LBB1_969:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_969
	xorl	%eax, %eax
	.p2align	4
.LBB1_971:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_971
	leaq	19768(%rsp), %r15
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%r15, %rdi
	callq	*%rbp
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%rbp
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%rbp
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%r15, %rsi
	callq	*%rbp
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_974
	.p2align	4
.LBB1_973:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB1_1006
.LBB1_974:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB1_976
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB1_979
.LBB1_976:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_973
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_973
	incq	%rax
.LBB1_979:
	movl	$4680, %ecx
	xorl	%r15d, %r15d
	jmp	.LBB1_981
	.p2align	4
.LBB1_980:
	addq	$2, %r15
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB1_1006
.LBB1_981:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB1_983
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB1_986
.LBB1_983:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB1_980
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_980
	movl	%r12d, 32(%rsp)
	incq	%r15
	jmp	.LBB1_987
.LBB1_986:
	movl	%r12d, 32(%rsp)
.LBB1_987:
	movq	%rax, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %edx
	movq	$1, 280(%rsp,%rcx)
	movq	$1, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	leaq	(%r15,%r15,4), %rcx
	leaq	280(%rsp), %rsi
	leaq	4608(%rsi,%rcx,8), %r13
	movq	%rax, 4608(%rsi,%rcx,8)
	movl	%edx, 4616(%rsi,%rcx,8)
	movq	$1, 4624(%rsi,%rcx,8)
	movw	$263, 4632(%rsi,%rcx,8)
	movq	$1, 10032(%rsp)
	movl	4640(%rsi,%rcx,8), %eax
	movl	$1, %ebx
	leaq	280(%rsp), %r12
	movl	%eax, 24(%rsp)
.LBB1_988:
	cmpl	$128, %ebx
	je	.LBB1_1575
	cmpl	%eax, 32(%r13)
	jne	.LBB1_1006
	cmpb	$2, 25(%r13)
	je	.LBB1_1006
	xorl	%r14d, %r14d
	cmpq	$1, 16(%r13)
	jne	.LBB1_1007
	movq	(%r13), %rax
	cmpq	$63, %rax
	ja	.LBB1_1007
	movl	8(%r13), %ecx
	movq	%rax, %rdx
	shlq	$5, %rdx
	cmpl	%ecx, 304(%rsp,%rdx)
	jne	.LBB1_1006
	addq	%rsp, %rdx
	addq	$280, %rdx
	xorl	%r14d, %r14d
	cmpb	$0, 16(%rdx)
	jne	.LBB1_1007
	movzbl	24(%r13), %edx
	andb	$5, %dl
	cmpb	$5, %dl
	jne	.LBB1_1007
	incl	%ebx
	movl	$4680, %esi
	xorl	%edx, %edx
	jmp	.LBB1_998
	.p2align	4
.LBB1_997:
	addq	$2, %rdx
	addq	$80, %rsi
	cmpq	$9800, %rsi
	je	.LBB1_1006
.LBB1_998:
	cmpb	$2, 233(%rsp,%rsi)
	jne	.LBB1_1000
	cmpl	$0, 240(%rsp,%rsi)
	jne	.LBB1_1003
.LBB1_1000:
	cmpb	$2, 273(%rsp,%rsi)
	jne	.LBB1_997
	cmpl	$0, 280(%rsp,%rsi)
	je	.LBB1_997
	incq	%rdx
.LBB1_1003:
	leaq	(%rdx,%rdx,4), %rsi
	leaq	280(%rsp), %rdi
	movq	%rax, 4608(%rdi,%rsi,8)
	movl	%ecx, 4616(%rdi,%rsi,8)
	movq	$2, 4624(%rdi,%rsi,8)
	movw	$1, 4632(%rdi,%rsi,8)
	movl	4640(%rdi,%rsi,8), %ecx
	movl	$2, %esi
	movq	%r12, %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB1_1006
	movq	%r12, %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	xorl	%r14d, %r14d
	testb	%al, %al
	movl	24(%rsp), %eax
	jne	.LBB1_988
	jmp	.LBB1_1007
.LBB1_1575:
	movl	$64, %eax
	.p2align	4
.LBB1_1576:
	addq	$-4, %rax
	jne	.LBB1_1576
	movl	$128, %eax
	.p2align	4
.LBB1_1578:
	addq	$-4, %rax
	jne	.LBB1_1578
	movl	$64, %eax
	.p2align	4
.LBB1_1580:
	addq	$-4, %rax
	jne	.LBB1_1580
	movl	$64, %eax
	.p2align	4
.LBB1_1582:
	addq	$-4, %rax
	jne	.LBB1_1582
	movl	$4760, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_1584:
	xorl	%edx, %edx
	cmpl	$0, 160(%rsp,%rcx)
	sete	%dl
	cmpl	$1, 200(%rsp,%rcx)
	movq	%rax, %rsi
	adcq	%rdx, %rsi
	xorl	%eax, %eax
	cmpl	$0, 240(%rsp,%rcx)
	sete	%al
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %rax
	addq	$160, %rcx
	cmpq	$9880, %rcx
	jne	.LBB1_1584
	movl	$64, %ecx
	.p2align	4
.LBB1_1586:
	addq	$-4, %rcx
	jne	.LBB1_1586
	cmpq	$127, %rax
	jne	.LBB1_1006
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_1589:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_1589
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_1591:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_1591
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_1593:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_1593
	movl	$120, %edi
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_1595:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rbx, %r9
	adcq	%r8, %r9
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%rdi)
	sete	%bl
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rbx
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_1595
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_1597:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_1597
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_1599:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_1599
	movl	24(%rsp), %esi
	cmpl	%esi, 32(%r13)
	jne	.LBB1_1648
	cmpb	$2, 25(%r13)
	je	.LBB1_1648
	movq	(%r13), %r9
	cmpq	$1, 16(%r13)
	sete	%r10b
	cmpq	$64, %r9
	setb	%r11b
	andb	%r10b, %r11b
	cmpb	$1, %r11b
	jne	.LBB1_1648
	movl	8(%r13), %r10d
	shlq	$5, %r9
	cmpl	%r10d, 304(%rsp,%r9)
	jne	.LBB1_1648
	addq	%rsp, %r9
	addq	$280, %r9
	cmpb	$0, 16(%r9)
	jne	.LBB1_1648
	movzbl	24(%r13), %r9d
	andb	$5, %r9b
	cmpb	$5, %r9b
	jne	.LBB1_1648
	xorl	%r9d, %r9d
	jmp	.LBB1_1644
.LBB1_1643:
	addq	$80, %r9
	cmpq	$5120, %r9
	je	.LBB1_1648
.LBB1_1644:
	cmpb	$2, 4913(%rsp,%r9)
	jne	.LBB1_1646
	cmpl	$0, 4920(%rsp,%r9)
	jne	.LBB1_1006
.LBB1_1646:
	cmpb	$2, 4953(%rsp,%r9)
	jne	.LBB1_1643
	cmpl	$0, 4960(%rsp,%r9)
	je	.LBB1_1643
	jmp	.LBB1_1006
.LBB1_1648:
	movq	%rbx, 40(%rsp)
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_1649:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_1649
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_1651:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_1651
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB1_1653:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r12d, %r12d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r12b
	addq	%r14, %r12
	addq	%r11, %r12
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r12, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB1_1653
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_1655:
	xorl	%r12d, %r12d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r12b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r13
	adcq	%r12, %r13
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r13, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB1_1655
	movl	$4760, %r12d
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_1657:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r14, %rbp
	adcq	%r13, %rbp
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r14
	addq	$160, %r12
	cmpq	$9880, %r12
	jne	.LBB1_1657
	movl	$2200, %r13d
	xorl	%r12d, %r12d
	.p2align	4
.LBB1_1659:
	xorl	%ebp, %ebp
	cmpl	$0, 160(%rsp,%r13)
	sete	%bpl
	cmpl	$1, 200(%rsp,%r13)
	movq	%r12, %rsi
	adcq	%rbp, %rsi
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%r13)
	sete	%r12b
	cmpl	$1, 280(%rsp,%r13)
	adcq	%rsi, %r12
	addq	$160, %r13
	cmpq	$4760, %r13
	jne	.LBB1_1659
	cmpq	%rax, %r9
	jne	.LBB1_1005
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_1006
	cmpq	%rdx, %r11
	jne	.LBB1_1006
	cmpq	40(%rsp), %rbx
	jne	.LBB1_1006
	cmpq	%rdi, %r14
	jne	.LBB1_1006
	cmpq	%r8, %r12
	movl	$0, %r14d
	jne	.LBB1_1007
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_1006
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	%r15, %rdx
	movl	24(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB1_1006
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$128, 12640(%rsp)
	jne	.LBB1_1006
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	32(%rsp), %r14d
	andb	%al, %r14b
	jmp	.LBB1_1007
.LBB1_1734:
	movq	memcpy@GOTPCREL(%rip), %rbp
	jmp	.LBB1_393
.LBB1_1005:
	movq	memcpy@GOTPCREL(%rip), %rbp
.LBB1_1006:
	xorl	%r14d, %r14d
.LBB1_1007:
	movl	$96, %eax
	.p2align	4
.LBB1_1008:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB1_1008
	xorl	%eax, %eax
	.p2align	4
.LBB1_1010:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_1010
	xorl	%eax, %eax
	.p2align	4
.LBB1_1012:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_1012
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	callq	*%rbp
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%rbp
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%rbp
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%rbp
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	jmp	.LBB1_1015
	.p2align	4
.LBB1_1014:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB1_1082
.LBB1_1015:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB1_1017
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB1_1020
.LBB1_1017:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_1014
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_1014
	incq	%rax
.LBB1_1020:
	movl	$4680, %ecx
	xorl	%esi, %esi
	jmp	.LBB1_1022
	.p2align	4
.LBB1_1021:
	addq	$2, %rsi
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB1_1082
.LBB1_1022:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB1_1024
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB1_1027
.LBB1_1024:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB1_1021
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_1021
	incq	%rsi
.LBB1_1027:
	movq	%rax, %rcx
	shlq	$5, %rcx
	movl	304(%rsp,%rcx), %edx
	movq	$1, 280(%rsp,%rcx)
	movq	$1, 288(%rsp,%rcx)
	movb	$0, 296(%rsp,%rcx)
	movq	%rsi, 80(%rsp)
	leaq	(%rsi,%rsi,4), %rcx
	leaq	280(%rsp), %rsi
	leaq	4608(%rsi,%rcx,8), %rbx
	movq	%rax, 4608(%rsi,%rcx,8)
	movl	%edx, 4616(%rsi,%rcx,8)
	movq	$1, 4624(%rsi,%rcx,8)
	movw	$263, 4632(%rsi,%rcx,8)
	movq	$1, 10032(%rsp)
	movl	4640(%rsi,%rcx,8), %r15d
	xorl	%r12d, %r12d
	leaq	2328(%rsp), %r13
	movl	%r14d, 96(%rsp)
	movl	%r15d, 32(%rsp)
	movq	%rbx, 72(%rsp)
.LBB1_1028:
	cmpl	$64, %r12d
	je	.LBB1_1607
	cmpl	%r15d, 32(%rbx)
	jne	.LBB1_1082
	cmpb	$2, 25(%rbx)
	je	.LBB1_1082
	xorl	%edi, %edi
	cmpq	$1, 16(%rbx)
	jne	.LBB1_1083
	movq	(%rbx), %rax
	cmpq	$63, %rax
	ja	.LBB1_1083
	movl	8(%rbx), %ecx
	movq	%rax, %rdx
	shlq	$5, %rdx
	cmpl	%ecx, 304(%rsp,%rdx)
	jne	.LBB1_1082
	addq	%rsp, %rdx
	addq	$280, %rdx
	xorl	%edi, %edi
	cmpb	$0, 16(%rdx)
	jne	.LBB1_1083
	testb	$1, 24(%rbx)
	je	.LBB1_1083
	incl	%r12d
	movl	$2192, %edx
	xorl	%esi, %esi
	.p2align	4
.LBB1_1037:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%dil
	addq	%rdi, %rsi
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rdx)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rsi, %r8
	xorl	%esi, %esi
	cmpb	$2, 280(%rsp,%rdx)
	setne	%sil
	addq	%r8, %rsi
	addq	$160, %rdx
	cmpq	$4752, %rdx
	jne	.LBB1_1037
	cmpq	10016(%rsp), %rsi
	jae	.LBB1_1082
	movl	$2120, %edx
	xorl	%esi, %esi
	jmp	.LBB1_1041
	.p2align	4
.LBB1_1040:
	addq	$2, %rsi
	addq	$80, %rdx
	cmpq	$4680, %rdx
	je	.LBB1_1082
.LBB1_1041:
	cmpb	$2, 232(%rsp,%rdx)
	jne	.LBB1_1043
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB1_1046
.LBB1_1043:
	cmpb	$2, 272(%rsp,%rdx)
	jne	.LBB1_1040
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB1_1040
	incq	%rsi
.LBB1_1046:
	leaq	(%rsi,%rsi,4), %rdx
	movq	$1, (%r13,%rdx,8)
	movq	%rax, 8(%r13,%rdx,8)
	movl	%ecx, 16(%r13,%rdx,8)
	movb	$0, 24(%r13,%rdx,8)
	movl	32(%r13,%rdx,8), %edx
	leaq	280(%rsp), %rdi
	movq	%rsi, %r13
	movl	%edx, 24(%rsp)
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	xorl	%edi, %edi
	testb	$1, %al
	jne	.LBB1_1083
	testb	$1, %dl
	jne	.LBB1_1083
	movl	$112, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_1049:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r15, %rdx
	xorl	%r15d, %r15d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r15b
	addq	%rdx, %r15
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB1_1049
	movl	$4753, %eax
	xorl	%r14d, %r14d
	movq	%r13, %rsi
	.p2align	4
.LBB1_1051:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB1_1051
	movl	$2192, %eax
	xorl	%ebp, %ebp
	.p2align	4
.LBB1_1053:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbp
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%rbp, %rdx
	xorl	%ebp, %ebp
	cmpb	$2, 280(%rsp,%rax)
	setne	%bpl
	addq	%rdx, %rbp
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB1_1053
	movl	$120, %eax
	movq	10032(%rsp), %rcx
	movq	%rcx, 40(%rsp)
	xorl	%r13d, %r13d
	.p2align	4
.LBB1_1055:
	xorl	%ecx, %ecx
	cmpl	$0, 184(%rsp,%rax)
	sete	%cl
	cmpl	$1, 216(%rsp,%rax)
	movq	%r13, %rdx
	adcq	%rcx, %rdx
	xorl	%r13d, %r13d
	cmpl	$0, 248(%rsp,%rax)
	sete	%r13b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %r13
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB1_1055
	movq	%r12, 56(%rsp)
	movl	$4760, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_1057:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbx, %rdx
	adcq	%rcx, %rdx
	xorl	%ebx, %ebx
	cmpl	$0, 240(%rsp,%rax)
	sete	%bl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %rbx
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB1_1057
	movl	$2200, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB1_1059:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%r12, %rdx
	adcq	%rcx, %rdx
	xorl	%r12d, %r12d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r12b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %r12
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB1_1059
	leaq	280(%rsp), %rdi
	movl	24(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	je	.LBB1_1642
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_1062:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_1062
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_1064:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_1064
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_1066:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_1066
	movl	$120, %r8d
	movq	10032(%rsp), %rsi
	movq	%rsi, 24(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB1_1068:
	xorl	%r9d, %r9d
	cmpl	$0, 184(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 216(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%r8)
	sete	%sil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2168, %r8
	jne	.LBB1_1068
	movl	$4760, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_1070:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$9880, %r9
	jne	.LBB1_1070
	movl	$2200, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_1072:
	xorl	%r11d, %r11d
	cmpl	$0, 160(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 200(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 240(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 280(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$4760, %r10
	jne	.LBB1_1072
	xorl	%edi, %edi
	movq	24(%rsp), %r10
	cmpq	40(%rsp), %r10
	jne	.LBB1_1735
	cmpq	%r15, %rax
	jne	.LBB1_1735
	cmpq	%r14, %rcx
	jne	.LBB1_1735
	cmpq	%rbp, %rdx
	jne	.LBB1_1735
	cmpq	%r13, %rsi
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_1083
	cmpq	%rbx, %r8
	jne	.LBB1_1083
	cmpq	%r12, %r9
	movl	32(%rsp), %r15d
	movq	72(%rsp), %rbx
	movq	56(%rsp), %r12
	leaq	2328(%rsp), %r13
	jne	.LBB1_1083
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	xorl	%edi, %edi
	testb	%al, %al
	jne	.LBB1_1028
	jmp	.LBB1_1083
.LBB1_1607:
	movl	$64, %eax
	.p2align	4
.LBB1_1608:
	addq	$-4, %rax
	jne	.LBB1_1608
	movl	$128, %eax
	.p2align	4
.LBB1_1610:
	addq	$-4, %rax
	jne	.LBB1_1610
	movl	$64, %eax
	.p2align	4
.LBB1_1612:
	addq	$-4, %rax
	jne	.LBB1_1612
	movl	$64, %eax
	.p2align	4
.LBB1_1614:
	addq	$-4, %rax
	jne	.LBB1_1614
	movl	$128, %eax
	.p2align	4
.LBB1_1616:
	addq	$-4, %rax
	jne	.LBB1_1616
	movl	$2200, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_1618:
	xorl	%edx, %edx
	cmpl	$0, 160(%rsp,%rax)
	sete	%dl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rcx, %rsi
	adcq	%rdx, %rsi
	xorl	%ecx, %ecx
	cmpl	$0, 240(%rsp,%rax)
	sete	%cl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %rcx
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB1_1618
	cmpq	$64, %rcx
	jne	.LBB1_1082
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_1621:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_1621
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_1623:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_1623
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_1625:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_1625
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB1_1627:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_1627
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_1629:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_1629
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_1631:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_1631
	cmpl	%r15d, 32(%rbx)
	jne	.LBB1_1675
	cmpb	$2, 25(%rbx)
	je	.LBB1_1675
	movq	(%rbx), %r9
	cmpq	$1, 16(%rbx)
	sete	%r10b
	cmpq	$64, %r9
	setb	%r11b
	andb	%r10b, %r11b
	cmpb	$1, %r11b
	jne	.LBB1_1675
	movl	8(%rbx), %r10d
	shlq	$5, %r9
	cmpl	%r10d, 304(%rsp,%r9)
	jne	.LBB1_1675
	addq	%rsp, %r9
	addq	$280, %r9
	cmpb	$0, 16(%r9)
	jne	.LBB1_1675
	testb	$1, 24(%rbx)
	je	.LBB1_1675
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
.LBB1_1639:
	xorl	%r11d, %r11d
	cmpb	$2, 2352(%rsp,%r9)
	setne	%r11b
	addq	%r11, %r10
	xorl	%r11d, %r11d
	cmpb	$2, 2392(%rsp,%r9)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 2432(%rsp,%r9)
	setne	%bl
	addq	%r11, %rbx
	addq	%r10, %rbx
	xorl	%r10d, %r10d
	cmpb	$2, 2472(%rsp,%r9)
	setne	%r10b
	addq	%rbx, %r10
	addq	$160, %r9
	cmpq	$2560, %r9
	jne	.LBB1_1639
	cmpq	10016(%rsp), %r10
	jae	.LBB1_1675
	xorl	%r9d, %r9d
	jmp	.LBB1_1671
.LBB1_1642:
	xorl	%edi, %edi
	movq	memcpy@GOTPCREL(%rip), %rbp
	jmp	.LBB1_1083
.LBB1_1670:
	addq	$80, %r9
	cmpq	$2560, %r9
	je	.LBB1_1675
.LBB1_1671:
	cmpb	$2, 2352(%rsp,%r9)
	jne	.LBB1_1673
	cmpl	$0, 2360(%rsp,%r9)
	jne	.LBB1_1082
.LBB1_1673:
	cmpb	$2, 2392(%rsp,%r9)
	jne	.LBB1_1670
	cmpl	$0, 2400(%rsp,%r9)
	je	.LBB1_1670
	jmp	.LBB1_1082
.LBB1_1675:
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_1676:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_1676
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_1678:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_1678
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB1_1680:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB1_1680
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_1682:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB1_1682
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_1684:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB1_1684
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_1686:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB1_1686
	cmpq	%rax, %r9
	jne	.LBB1_1081
	cmpq	%rcx, %r10
	movq	memcpy@GOTPCREL(%rip), %rbp
	jne	.LBB1_1082
	cmpq	%rdx, %r11
	jne	.LBB1_1082
	cmpq	%rsi, %rbx
	jne	.LBB1_1082
	cmpq	%rdi, %r14
	jne	.LBB1_1082
	cmpq	%r8, %r15
	movl	$0, %edi
	movl	96(%rsp), %ebx
	movl	32(%rsp), %r14d
	jne	.LBB1_1083
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_1082
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	80(%rsp), %rdx
	movl	%r14d, %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB1_1082
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12624(%rsp)
	jne	.LBB1_1082
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	andb	%al, %bl
	movl	%ebx, %edi
	jmp	.LBB1_1083
.LBB1_1735:
	movq	memcpy@GOTPCREL(%rip), %rbp
	jmp	.LBB1_1083
.LBB1_1736:
	movq	memcpy@GOTPCREL(%rip), %rbp
	jmp	.LBB1_966
.LBB1_1081:
	movq	memcpy@GOTPCREL(%rip), %rbp
.LBB1_1082:
	xorl	%edi, %edi
.LBB1_1083:
	movl	%edi, 164(%rsp)
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5valid
	movb	%al, 71(%rsp)
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9malformed
	movb	%al, 70(%rsp)
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5valid
	movl	%eax, %r12d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9malformed
	movb	%al, 118(%rsp)
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid
	movl	%eax, %r15d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests9malformed
	movl	%eax, %r13d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests6ranges
	movb	%al, 117(%rsp)
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests10boundaries
	movb	%al, 116(%rsp)
	movq	$0, 19768(%rsp)
	movq	19768(%rsp), %rax
	movq	$0, 152(%rsp)
	movl	$0, %edx
	testq	%rax, %rax
	jne	.LBB1_1089
	movq	19768(%rsp), %rax
	.p2align	4
.LBB1_1085:
	cmpq	$-1, %rax
	je	.LBB1_1088
	leaq	1(%rax), %rcx
	lock		cmpxchgq	%rcx, 19768(%rsp)
	jne	.LBB1_1085
	testq	%rax, %rax
	je	.LBB1_1562
.LBB1_1088:
	xorl	%edx, %edx
.LBB1_1089:
	movq	%rdx, 200(%rsp)
	callq	_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8contractNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_
	movb	%al, 115(%rsp)
	callq	_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8lifetimeNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_
	movb	%al, 114(%rsp)
	leaq	17720(%rsp), %rsi
	xorl	%r10d, %r10d
	xorl	%r8d, %r8d
.LBB1_1090:
	leaq	1(%r8), %rax
	movq	%rax, 232(%rsp)
	xorl	%r11d, %r11d
	xorl	%edi, %edi
	movq	%r8, 136(%rsp)
	movq	%r10, 240(%rsp)
.LBB1_1091:
	leaq	1(%rdi), %rax
	movq	%rax, 272(%rsp)
	xorl	%ebx, %ebx
	xorl	%r9d, %r9d
	jmp	.LBB1_1093
	.p2align	4
.LBB1_1092:
	incq	%r9
	decq	%rbx
	cmpq	$4, %r9
	je	.LBB1_1407
.LBB1_1093:
	cmpq	%rdi, %r8
	sete	%al
	cmpq	%r9, %r8
	sete	%cl
	orb	%al, %cl
	cmpq	%r9, %rdi
	sete	%al
	orb	%cl, %al
	jne	.LBB1_1092
	xorl	%r14d, %r14d
.LBB1_1095:
	cmpq	$5, %r14
	movl	$4, %eax
	cmovaeq	%r14, %rax
	decq	%r14
	negq	%rax
	.p2align	4
.LBB1_1096:
	leaq	(%rax,%r14), %rcx
	cmpq	$-1, %rcx
	je	.LBB1_1092
	leaq	(%rbx,%r14), %rcx
	movq	%r14, %rdx
	incq	%r14
	cmpq	$-1, %rcx
	je	.LBB1_1096
	leaq	(%r11,%rdx), %rcx
	cmpq	$-1, %rcx
	je	.LBB1_1096
	leaq	(%r10,%rdx), %rcx
	cmpq	$-1, %rcx
	je	.LBB1_1096
	addq	$2, %rdx
	movq	%rdx, 248(%rsp)
	movl	$96, %eax
	.p2align	4
.LBB1_1101:
	movq	$1, 17648(%rsp,%rax)
	movq	$2, 17640(%rsp,%rax)
	movq	$0, 17632(%rsp,%rax)
	movq	$0, 17624(%rsp,%rax)
	movq	$0, 17656(%rsp,%rax)
	movq	$0, 17664(%rsp,%rax)
	movq	$2, 17672(%rsp,%rax)
	movq	$1, 17680(%rsp,%rax)
	movq	$0, 17688(%rsp,%rax)
	movq	$0, 17696(%rsp,%rax)
	movq	$2, 17704(%rsp,%rax)
	movq	$1, 17712(%rsp,%rax)
	movq	$0, 17720(%rsp,%rax)
	movq	$0, 17728(%rsp,%rax)
	movq	$2, 17736(%rsp,%rax)
	movq	$1, 17744(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB1_1101
	xorl	%eax, %eax
	.p2align	4
.LBB1_1103:
	movq	$1, 12632(%rsp,%rax)
	movq	$512, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$512, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$512, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$512, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_1103
	movq	%rbx, 264(%rsp)
	movq	%r11, 256(%rsp)
	movq	%rdi, 56(%rsp)
	movq	%r9, 88(%rsp)
	movq	%r14, 144(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB1_1105:
	movq	$1, 10072(%rsp,%rax)
	movq	$2, 10064(%rsp,%rax)
	movq	$0, 10056(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10080(%rsp,%rax)
	movq	$0, 10088(%rsp,%rax)
	movq	$0, 10096(%rsp,%rax)
	movq	$2, 10104(%rsp,%rax)
	movq	$1, 10112(%rsp,%rax)
	movq	$0, 10120(%rsp,%rax)
	movq	$0, 10128(%rsp,%rax)
	movq	$0, 10136(%rsp,%rax)
	movq	$2, 10144(%rsp,%rax)
	movq	$1, 10152(%rsp,%rax)
	movq	$0, 10160(%rsp,%rax)
	movq	$0, 10168(%rsp,%rax)
	movq	$0, 10176(%rsp,%rax)
	movq	$2, 10184(%rsp,%rax)
	movq	$1, 10192(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_1105
	movl	$2048, %edx
	leaq	19768(%rsp), %rbx
	movq	%rbx, %rdi
	callq	*%rbp
	movl	$5120, %edx
	leaq	24376(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	callq	*%rbp
	movl	$2560, %edx
	leaq	21816(%rsp), %rdi
	leaq	10040(%rsp), %rsi
	callq	*%rbp
	movl	$9728, %edx
	leaq	280(%rsp), %rdi
	movq	%rbx, %rsi
	callq	*%rbp
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$56, %ecx
	xorl	%eax, %eax
	movq	88(%rsp), %r9
	jmp	.LBB1_1108
	.p2align	4
.LBB1_1107:
	addq	$2, %rax
	addq	$64, %rcx
	cmpq	$2104, %rcx
	je	.LBB1_1699
.LBB1_1108:
	cmpb	$2, 240(%rsp,%rcx)
	jne	.LBB1_1110
	cmpl	$0, 248(%rsp,%rcx)
	jne	.LBB1_1113
.LBB1_1110:
	cmpb	$2, 272(%rsp,%rcx)
	jne	.LBB1_1107
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_1107
	incq	%rax
.LBB1_1113:
	movl	$4680, %ecx
	xorl	%r10d, %r10d
	jmp	.LBB1_1115
	.p2align	4
.LBB1_1114:
	addq	$2, %r10
	addq	$80, %rcx
	cmpq	$9800, %rcx
	je	.LBB1_1699
.LBB1_1115:
	cmpb	$2, 233(%rsp,%rcx)
	jne	.LBB1_1117
	cmpl	$0, 240(%rsp,%rcx)
	jne	.LBB1_1120
.LBB1_1117:
	cmpb	$2, 273(%rsp,%rcx)
	jne	.LBB1_1114
	cmpl	$0, 280(%rsp,%rcx)
	je	.LBB1_1114
	incq	%r10
.LBB1_1120:
	movq	%rax, %rdx
	shlq	$5, %rdx
	movl	304(%rsp,%rdx), %ecx
	movq	$1, 280(%rsp,%rdx)
	movq	$8, 288(%rsp,%rdx)
	movb	$0, 296(%rsp,%rdx)
	leaq	(%r10,%r10,4), %rdx
	leaq	280(%rsp), %rsi
	movq	%rax, 4608(%rsi,%rdx,8)
	movl	%ecx, 4616(%rsi,%rdx,8)
	movq	$1, 4624(%rsi,%rdx,8)
	movw	$263, 4632(%rsi,%rdx,8)
	movq	$8, 10032(%rsp)
	movl	4640(%rsi,%rdx,8), %edx
	movl	%edx, 96(%rsp)
	movl	$2192, %edx
	xorl	%esi, %esi
	.p2align	4
.LBB1_1121:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%dil
	addq	%rdi, %rsi
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rdx)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rsi, %r8
	xorl	%esi, %esi
	cmpb	$2, 280(%rsp,%rdx)
	setne	%sil
	addq	%r8, %rsi
	addq	$160, %rdx
	cmpq	$4752, %rdx
	jne	.LBB1_1121
	cmpq	$63, %rsi
	ja	.LBB1_1699
	movl	$2120, %edx
	xorl	%esi, %esi
	movq	%r10, 80(%rsp)
	jmp	.LBB1_1125
	.p2align	4
.LBB1_1124:
	addq	$2, %rsi
	addq	$80, %rdx
	cmpq	$4680, %rdx
	je	.LBB1_1699
.LBB1_1125:
	cmpb	$2, 232(%rsp,%rdx)
	jne	.LBB1_1127
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB1_1130
.LBB1_1127:
	cmpb	$2, 272(%rsp,%rdx)
	jne	.LBB1_1124
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB1_1124
	movb	%r13b, 53(%rsp)
	movb	%r12b, 54(%rsp)
	movb	%r15b, 55(%rsp)
	incq	%rsi
	jmp	.LBB1_1131
.LBB1_1130:
	movb	%r13b, 53(%rsp)
	movb	%r12b, 54(%rsp)
	movb	%r15b, 55(%rsp)
.LBB1_1131:
	movq	%rsi, 192(%rsp)
	leaq	(%rsi,%rsi,4), %rdx
	leaq	2328(%rsp), %rsi
	leaq	(%rsi,%rdx,8), %rdi
	movq	%rdi, 120(%rsp)
	movq	$1, (%rsi,%rdx,8)
	movq	%rax, 8(%rsi,%rdx,8)
	movl	%ecx, 16(%rsi,%rdx,8)
	movb	$0, 24(%rsi,%rdx,8)
	movl	32(%rsi,%rdx,8), %eax
	movl	%eax, 108(%rsp)
	movq	$0, 12600(%rsp)
	movq	$4, 12608(%rsp)
	movq	136(%rsp), %rax
	movq	%rax, 12616(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 12624(%rsp)
	movq	%r9, 12632(%rsp)
	movq	144(%rsp), %rax
	movq	%rax, 12640(%rsp)
	movb	$1, %al
	movl	%eax, 40(%rsp)
	movl	$8, %eax
	movq	%rax, 32(%rsp)
	movq	$0, 184(%rsp)
	movb	$1, %al
	movl	%eax, 24(%rsp)
	xorl	%eax, %eax
.LBB1_1132:
	movq	%rax, 72(%rsp)
	movq	12616(%rsp,%rax,8), %rax
	cmpq	$3, %rax
	ja	.LBB1_1698
	jmpq	*.LJTI1_0(,%rax,8)
.LBB1_1134:
	movl	$112, %ecx
	xorl	%r13d, %r13d
	.p2align	4
.LBB1_1135:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %r13
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%r13, %rsi
	xorl	%r13d, %r13d
	cmpb	$2, 280(%rsp,%rcx)
	setne	%r13b
	addq	%rsi, %r13
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_1135
	movl	$4753, %ecx
	xorl	%ebx, %ebx
	movq	80(%rsp), %rdx
	.p2align	4
.LBB1_1137:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rcx)
	setne	%sil
	addq	%rsi, %rbx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rcx)
	setne	%dil
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rcx)
	setne	%sil
	addq	%rdi, %rsi
	addq	%rbx, %rsi
	xorl	%ebx, %ebx
	cmpb	$2, 280(%rsp,%rcx)
	setne	%bl
	addq	%rsi, %rbx
	addq	$160, %rcx
	cmpq	$9873, %rcx
	jne	.LBB1_1137
	movl	$2192, %ecx
	xorl	%r12d, %r12d
	.p2align	4
.LBB1_1139:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rcx)
	setne	%sil
	addq	%rsi, %r12
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rcx)
	setne	%dil
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rcx)
	setne	%sil
	addq	%rdi, %rsi
	addq	%r12, %rsi
	xorl	%r12d, %r12d
	cmpb	$2, 280(%rsp,%rcx)
	setne	%r12b
	addq	%rsi, %r12
	addq	$160, %rcx
	cmpq	$4752, %rcx
	jne	.LBB1_1139
	movl	$120, %ecx
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_1141:
	xorl	%edi, %edi
	cmpl	$0, 184(%rsp,%rcx)
	sete	%dil
	cmpl	$1, 216(%rsp,%rcx)
	movq	%r14, %rsi
	adcq	%rdi, %rsi
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%rcx)
	sete	%r14b
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %r14
	subq	$-128, %rcx
	cmpq	$2168, %rcx
	jne	.LBB1_1141
	movl	$4760, %ecx
	xorl	%ebp, %ebp
	.p2align	4
.LBB1_1143:
	xorl	%edi, %edi
	cmpl	$0, 160(%rsp,%rcx)
	sete	%dil
	cmpl	$1, 200(%rsp,%rcx)
	movq	%rbp, %rsi
	adcq	%rdi, %rsi
	xorl	%ebp, %ebp
	cmpl	$0, 240(%rsp,%rcx)
	sete	%bpl
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %rbp
	addq	$160, %rcx
	cmpq	$9880, %rcx
	jne	.LBB1_1143
	movl	$2200, %ecx
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_1145:
	xorl	%edi, %edi
	cmpl	$0, 160(%rsp,%rcx)
	sete	%dil
	cmpl	$1, 200(%rsp,%rcx)
	movq	%r15, %rsi
	adcq	%rdi, %rsi
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%rcx)
	sete	%r15b
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %r15
	addq	$160, %rcx
	cmpq	$4760, %rcx
	jne	.LBB1_1145
	movl	$1, %esi
	leaq	280(%rsp), %rdi
	testq	%rax, %rax
	je	.LBB1_1222
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	jmp	.LBB1_1223
	.p2align	4
.LBB1_1148:
	testb	$1, 40(%rsp)
	je	.LBB1_1322
	movq	120(%rsp), %rax
	movl	108(%rsp), %ecx
	cmpl	%ecx, 32(%rax)
	jne	.LBB1_1698
	movq	120(%rsp), %rax
	cmpb	$2, 24(%rax)
	je	.LBB1_1698
	movq	120(%rsp), %rax
	movq	8(%rax), %rcx
	cmpq	$63, %rcx
	ja	.LBB1_1698
	movq	120(%rsp), %rax
	movl	16(%rax), %eax
	shlq	$5, %rcx
	cmpl	%eax, 304(%rsp,%rcx)
	jne	.LBB1_1698
	addq	%rsp, %rcx
	addq	$280, %rcx
	cmpb	$2, 16(%rcx)
	je	.LBB1_1698
	movq	120(%rsp), %r8
	movzbl	(%r8), %edx
	movzwl	5(%r8), %esi
	movzbl	7(%r8), %edi
	shll	$16, %edi
	orl	%esi, %edi
	movl	1(%r8), %esi
	shlq	$40, %rdi
	shlq	$8, %rsi
	orq	%rdi, %rsi
	orq	%rdx, %rsi
	cmpq	$1, %rsi
	jne	.LBB1_1698
	movq	120(%rsp), %rdx
	movq	$1, (%rdx)
	movb	$1, 24(%rdx)
	cmpl	%eax, 24(%rcx)
	jne	.LBB1_1698
	movb	$1, %al
	movq	%rax, 184(%rsp)
	cmpb	$2, 16(%rcx)
	movb	$1, %al
	movl	%eax, 40(%rsp)
	jne	.LBB1_1359
	jmp	.LBB1_1698
	.p2align	4
.LBB1_1157:
	leaq	280(%rsp), %rdi
	movq	192(%rsp), %rsi
	movl	108(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	jne	.LBB1_1698
	xorb	184(%rsp), %dl
	testb	$1, %dl
	jne	.LBB1_1698
	movl	$112, %eax
	xorl	%r13d, %r13d
	.p2align	4
.LBB1_1160:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r13
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r13, %rdx
	xorl	%r13d, %r13d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r13b
	addq	%rdx, %r13
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB1_1160
	movl	$4753, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_1162:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbx
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	xorl	%ebx, %ebx
	cmpb	$2, 280(%rsp,%rax)
	setne	%bl
	addq	%rdx, %rbx
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB1_1162
	movl	$2192, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB1_1164:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r12
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r12, %rdx
	xorl	%r12d, %r12d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r12b
	addq	%rdx, %r12
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB1_1164
	movl	$120, %eax
	movq	10032(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	xorl	%r14d, %r14d
	movq	192(%rsp), %rsi
	.p2align	4
.LBB1_1166:
	xorl	%ecx, %ecx
	cmpl	$0, 184(%rsp,%rax)
	sete	%cl
	cmpl	$1, 216(%rsp,%rax)
	movq	%r14, %rdx
	adcq	%rcx, %rdx
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%rax)
	sete	%r14b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %r14
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB1_1166
	movl	$4760, %eax
	xorl	%ebp, %ebp
	.p2align	4
.LBB1_1168:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbp, %rdx
	adcq	%rcx, %rdx
	xorl	%ebp, %ebp
	cmpl	$0, 240(%rsp,%rax)
	sete	%bpl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %rbp
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB1_1168
	movl	$2200, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_1170:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%r15, %rdx
	adcq	%rcx, %rdx
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r15b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rdx, %r15
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB1_1170
	leaq	280(%rsp), %rdi
	movl	108(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	je	.LBB1_1698
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_1173:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_1173
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_1175:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_1175
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_1177:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_1177
	movl	$120, %r8d
	movq	10032(%rsp), %rsi
	movq	%rsi, 40(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB1_1179:
	xorl	%r9d, %r9d
	cmpl	$0, 184(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 216(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%r8)
	sete	%sil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2168, %r8
	jne	.LBB1_1179
	movl	$4760, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_1181:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$9880, %r9
	jne	.LBB1_1181
	movl	$2200, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_1183:
	xorl	%r11d, %r11d
	cmpl	$0, 160(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 200(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 240(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 280(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$4760, %r10
	jne	.LBB1_1183
	movq	40(%rsp), %rdi
	cmpq	32(%rsp), %rdi
	jne	.LBB1_1698
	cmpq	%r13, %rax
	jne	.LBB1_1698
	cmpq	%rbx, %rcx
	jne	.LBB1_1698
	cmpq	%r12, %rdx
	jne	.LBB1_1698
	cmpq	%r14, %rsi
	jne	.LBB1_1698
	cmpq	%rbp, %r8
	jne	.LBB1_1698
	cmpq	%r15, %r9
	jne	.LBB1_1698
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_1698
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_1193:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_1193
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_1195:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_1195
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_1197:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_1197
	movl	$120, %edi
	xorl	%esi, %esi
	movq	120(%rsp), %rbx
	.p2align	4
.LBB1_1199:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_1199
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_1201:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_1201
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_1203:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_1203
	movl	108(%rsp), %r9d
	cmpl	%r9d, 32(%rbx)
	jne	.LBB1_1209
	movq	8(%rbx), %r9
	cmpb	$2, 24(%rbx)
	setne	%r10b
	cmpq	$64, %r9
	setb	%r11b
	andb	%r10b, %r11b
	cmpb	$1, %r11b
	jne	.LBB1_1209
	shlq	$5, %r9
	movl	304(%rsp,%r9), %r10d
	cmpl	16(%rbx), %r10d
	jne	.LBB1_1209
	addq	%rsp, %r9
	addq	$280, %r9
	cmpb	$2, 16(%r9)
	je	.LBB1_1209
	movzbl	(%rbx), %r9d
	movzwl	5(%rbx), %r10d
	movzbl	7(%rbx), %r11d
	shll	$16, %r11d
	orl	%r10d, %r11d
	movl	1(%rbx), %r10d
	shlq	$40, %r11
	shlq	$8, %r10
	orq	%r11, %r10
	orq	%r9, %r10
	cmpq	$1, %r10
	je	.LBB1_1697
	.p2align	4
.LBB1_1209:
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_1210:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_1210
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_1212:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_1212
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB1_1214:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB1_1214
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_1216:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB1_1216
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_1218:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB1_1218
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_1220:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB1_1220
	jmp	.LBB1_1351
.LBB1_1222:
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
.LBB1_1223:
	cmpb	$-1, %al
	sete	%al
	xorb	24(%rsp), %al
	testb	$1, %al
	jne	.LBB1_1698
	testb	$1, 24(%rsp)
	jne	.LBB1_1244
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_1226:
	xorl	%edx, %edx
	cmpb	$2, 296(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 328(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 360(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 392(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2048, %rcx
	jne	.LBB1_1226
	xorl	%edx, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_1228:
	xorl	%esi, %esi
	cmpb	$2, 4913(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 4953(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 4993(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 5033(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$5120, %rdx
	jne	.LBB1_1228
	xorl	%esi, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_1230:
	xorl	%edi, %edi
	cmpb	$2, 2352(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 2392(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 2432(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 2472(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$2560, %rsi
	jne	.LBB1_1230
	movq	10032(%rsp), %rsi
	movq	%rsi, 24(%rsp)
	xorl	%r8d, %r8d
	xorl	%esi, %esi
	.p2align	4
.LBB1_1232:
	xorl	%r9d, %r9d
	cmpl	$0, 304(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 336(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 368(%rsp,%r8)
	sete	%sil
	cmpl	$1, 400(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2048, %r8
	jne	.LBB1_1232
	xorl	%r9d, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_1234:
	xorl	%r10d, %r10d
	cmpl	$0, 4920(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 4960(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 5000(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 5040(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$5120, %r9
	jne	.LBB1_1234
	xorl	%r10d, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_1236:
	xorl	%r11d, %r11d
	cmpl	$0, 2360(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 2400(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 2440(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 2480(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$2560, %r10
	jne	.LBB1_1236
	movq	24(%rsp), %rdi
	cmpq	32(%rsp), %rdi
	jne	.LBB1_1698
	cmpq	%r13, %rax
	jne	.LBB1_1698
	cmpq	%rbx, %rcx
	jne	.LBB1_1698
	cmpq	%r12, %rdx
	jne	.LBB1_1698
	cmpq	%r14, %rsi
	jne	.LBB1_1698
	cmpq	%rbp, %r8
	jne	.LBB1_1698
	cmpq	%r15, %r9
	jne	.LBB1_1698
.LBB1_1244:
	movl	$112, %eax
	xorl	%r13d, %r13d
	.p2align	4
.LBB1_1245:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r13
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r13, %rdx
	xorl	%r13d, %r13d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r13b
	addq	%rdx, %r13
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB1_1245
	movl	$4753, %eax
	xorl	%ebx, %ebx
	movq	80(%rsp), %rdx
	.p2align	4
.LBB1_1247:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbx
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rcx, %rsi
	addq	%rbx, %rsi
	xorl	%ebx, %ebx
	cmpb	$2, 280(%rsp,%rax)
	setne	%bl
	addq	%rsi, %rbx
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB1_1247
	movl	$2192, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB1_1249:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r12
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rcx, %rsi
	addq	%r12, %rsi
	xorl	%r12d, %r12d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r12b
	addq	%rsi, %r12
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB1_1249
	movl	$120, %eax
	movq	10032(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_1251:
	xorl	%ecx, %ecx
	cmpl	$0, 184(%rsp,%rax)
	sete	%cl
	cmpl	$1, 216(%rsp,%rax)
	movq	%r14, %rsi
	adcq	%rcx, %rsi
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%rax)
	sete	%r14b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %r14
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB1_1251
	movl	$4760, %eax
	xorl	%ebp, %ebp
	.p2align	4
.LBB1_1253:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbp, %rsi
	adcq	%rcx, %rsi
	xorl	%ebp, %ebp
	cmpl	$0, 240(%rsp,%rax)
	sete	%bpl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %rbp
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB1_1253
	movl	$2200, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_1255:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%r15, %rsi
	adcq	%rcx, %rsi
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r15b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %r15
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB1_1255
	movl	$1, %esi
	leaq	280(%rsp), %rdi
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$-1, %al
	je	.LBB1_1698
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_1258:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_1258
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_1260:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_1260
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_1262:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_1262
	movl	$120, %r8d
	movq	10032(%rsp), %rsi
	movq	%rsi, 24(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB1_1264:
	xorl	%r9d, %r9d
	cmpl	$0, 184(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 216(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%r8)
	sete	%sil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2168, %r8
	jne	.LBB1_1264
	movl	$4760, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_1266:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$9880, %r9
	jne	.LBB1_1266
	movl	$2200, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_1268:
	xorl	%r11d, %r11d
	cmpl	$0, 160(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 200(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 240(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 280(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$4760, %r10
	jne	.LBB1_1268
	movq	24(%rsp), %rdi
	cmpq	32(%rsp), %rdi
	jne	.LBB1_1698
	cmpq	%r13, %rax
	jne	.LBB1_1698
	cmpq	%rbx, %rcx
	jne	.LBB1_1698
	cmpq	%r12, %rdx
	jne	.LBB1_1698
	cmpq	%r14, %rsi
	jne	.LBB1_1698
	cmpq	%rbp, %r8
	jne	.LBB1_1698
	cmpq	%r15, %r9
	jne	.LBB1_1698
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_1698
	movl	$112, %eax
	xorl	%r13d, %r13d
	.p2align	4
.LBB1_1278:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r13
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r13, %rdx
	xorl	%r13d, %r13d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r13b
	addq	%rdx, %r13
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB1_1278
	movl	$4753, %eax
	xorl	%ebx, %ebx
	movq	80(%rsp), %rdx
	.p2align	4
.LBB1_1280:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbx
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rcx, %rsi
	addq	%rbx, %rsi
	xorl	%ebx, %ebx
	cmpb	$2, 280(%rsp,%rax)
	setne	%bl
	addq	%rsi, %rbx
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB1_1280
	movl	$2192, %eax
	xorl	%r12d, %r12d
	.p2align	4
.LBB1_1282:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r12
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rax)
	setne	%sil
	addq	%rcx, %rsi
	addq	%r12, %rsi
	xorl	%r12d, %r12d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r12b
	addq	%rsi, %r12
	addq	$160, %rax
	cmpq	$4752, %rax
	jne	.LBB1_1282
	movl	$120, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_1284:
	xorl	%ecx, %ecx
	cmpl	$0, 184(%rsp,%rax)
	sete	%cl
	cmpl	$1, 216(%rsp,%rax)
	movq	%r14, %rsi
	adcq	%rcx, %rsi
	xorl	%r14d, %r14d
	cmpl	$0, 248(%rsp,%rax)
	sete	%r14b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %r14
	subq	$-128, %rax
	cmpq	$2168, %rax
	jne	.LBB1_1284
	movl	$4760, %eax
	xorl	%ebp, %ebp
	.p2align	4
.LBB1_1286:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%rbp, %rsi
	adcq	%rcx, %rsi
	xorl	%ebp, %ebp
	cmpl	$0, 240(%rsp,%rax)
	sete	%bpl
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %rbp
	addq	$160, %rax
	cmpq	$9880, %rax
	jne	.LBB1_1286
	movl	$2200, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_1288:
	xorl	%ecx, %ecx
	cmpl	$0, 160(%rsp,%rax)
	sete	%cl
	cmpl	$1, 200(%rsp,%rax)
	movq	%r15, %rsi
	adcq	%rcx, %rsi
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%rax)
	sete	%r15b
	cmpl	$1, 280(%rsp,%rax)
	adcq	%rsi, %r15
	addq	$160, %rax
	cmpq	$4760, %rax
	jne	.LBB1_1288
	movl	$1, %esi
	leaq	280(%rsp), %rdi
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	je	.LBB1_1698
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_1291:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_1291
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_1293:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_1293
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_1295:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_1295
	movl	$120, %r8d
	movq	10032(%rsp), %rsi
	movq	%rsi, 24(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB1_1297:
	xorl	%r9d, %r9d
	cmpl	$0, 184(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 216(%rsp,%r8)
	movq	%rsi, %r10
	adcq	%r9, %r10
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%r8)
	sete	%sil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rsi
	subq	$-128, %r8
	cmpq	$2168, %r8
	jne	.LBB1_1297
	movl	$4760, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_1299:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$9880, %r9
	jne	.LBB1_1299
	movl	$2200, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_1301:
	xorl	%r11d, %r11d
	cmpl	$0, 160(%rsp,%r10)
	sete	%r11b
	cmpl	$1, 200(%rsp,%r10)
	movq	%r9, %rdi
	adcq	%r11, %rdi
	xorl	%r9d, %r9d
	cmpl	$0, 240(%rsp,%r10)
	sete	%r9b
	cmpl	$1, 280(%rsp,%r10)
	adcq	%rdi, %r9
	addq	$160, %r10
	cmpq	$4760, %r10
	jne	.LBB1_1301
	movq	24(%rsp), %rdi
	cmpq	32(%rsp), %rdi
	jne	.LBB1_1698
	cmpq	%r13, %rax
	jne	.LBB1_1698
	cmpq	%rbx, %rcx
	jne	.LBB1_1698
	cmpq	%r12, %rdx
	jne	.LBB1_1698
	cmpq	%r14, %rsi
	jne	.LBB1_1698
	cmpq	%rbp, %r8
	jne	.LBB1_1698
	cmpq	%r15, %r9
	jne	.LBB1_1698
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_1698
	xorl	%eax, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_1311:
	xorl	%ecx, %ecx
	cmpb	$2, 296(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbx
	xorl	%ecx, %ecx
	cmpb	$2, 328(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 360(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	xorl	%ebx, %ebx
	cmpb	$2, 392(%rsp,%rax)
	setne	%bl
	addq	%rdx, %rbx
	subq	$-128, %rax
	cmpq	$2048, %rax
	jne	.LBB1_1311
	xorl	%eax, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_1313:
	xorl	%ecx, %ecx
	cmpb	$2, 4913(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 4953(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 4993(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 5033(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_1313
	xorl	%eax, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_1315:
	xorl	%ecx, %ecx
	cmpb	$2, 2352(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 2392(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 2432(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r15, %rdx
	xorl	%r15d, %r15d
	cmpb	$2, 2472(%rsp,%rax)
	setne	%r15b
	addq	%rdx, %r15
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_1315
	movl	$64, %eax
	.p2align	4
.LBB1_1317:
	addq	$-4, %rax
	jne	.LBB1_1317
	movl	$128, %eax
	.p2align	4
.LBB1_1319:
	addq	$-4, %rax
	jne	.LBB1_1319
	movl	$64, %eax
	.p2align	4
.LBB1_1321:
	addq	$-4, %rax
	jne	.LBB1_1321
	jmp	.LBB1_1372
.LBB1_1322:
	movl	$112, %ecx
	xorl	%eax, %eax
	movq	120(%rsp), %rbx
	.p2align	4
.LBB1_1323:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_1323
	movl	$4753, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_1325:
	xorl	%esi, %esi
	cmpb	$2, 160(%rsp,%rdx)
	setne	%sil
	addq	%rsi, %rcx
	xorl	%esi, %esi
	cmpb	$2, 200(%rsp,%rdx)
	setne	%sil
	xorl	%edi, %edi
	cmpb	$2, 240(%rsp,%rdx)
	setne	%dil
	addq	%rsi, %rdi
	addq	%rcx, %rdi
	xorl	%ecx, %ecx
	cmpb	$2, 280(%rsp,%rdx)
	setne	%cl
	addq	%rdi, %rcx
	addq	$160, %rdx
	cmpq	$9873, %rdx
	jne	.LBB1_1325
	movl	$2192, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB1_1327:
	xorl	%edi, %edi
	cmpb	$2, 160(%rsp,%rsi)
	setne	%dil
	addq	%rdi, %rdx
	xorl	%edi, %edi
	cmpb	$2, 200(%rsp,%rsi)
	setne	%dil
	xorl	%r8d, %r8d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r8b
	addq	%rdi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_1327
	movl	$120, %edi
	xorl	%esi, %esi
	.p2align	4
.LBB1_1329:
	xorl	%r8d, %r8d
	cmpl	$0, 184(%rsp,%rdi)
	sete	%r8b
	cmpl	$1, 216(%rsp,%rdi)
	movq	%rsi, %r9
	adcq	%r8, %r9
	xorl	%esi, %esi
	cmpl	$0, 248(%rsp,%rdi)
	sete	%sil
	cmpl	$1, 280(%rsp,%rdi)
	adcq	%r9, %rsi
	subq	$-128, %rdi
	cmpq	$2168, %rdi
	jne	.LBB1_1329
	movl	$4760, %r8d
	xorl	%edi, %edi
	.p2align	4
.LBB1_1331:
	xorl	%r9d, %r9d
	cmpl	$0, 160(%rsp,%r8)
	sete	%r9b
	cmpl	$1, 200(%rsp,%r8)
	movq	%rdi, %r10
	adcq	%r9, %r10
	xorl	%edi, %edi
	cmpl	$0, 240(%rsp,%r8)
	sete	%dil
	cmpl	$1, 280(%rsp,%r8)
	adcq	%r10, %rdi
	addq	$160, %r8
	cmpq	$9880, %r8
	jne	.LBB1_1331
	movl	$2200, %r9d
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_1333:
	xorl	%r10d, %r10d
	cmpl	$0, 160(%rsp,%r9)
	sete	%r10b
	cmpl	$1, 200(%rsp,%r9)
	movq	%r8, %r11
	adcq	%r10, %r11
	xorl	%r8d, %r8d
	cmpl	$0, 240(%rsp,%r9)
	sete	%r8b
	cmpl	$1, 280(%rsp,%r9)
	adcq	%r11, %r8
	addq	$160, %r9
	cmpq	$4760, %r9
	jne	.LBB1_1333
	movl	108(%rsp), %r9d
	cmpl	%r9d, 32(%rbx)
	jne	.LBB1_1339
	movq	8(%rbx), %r9
	cmpb	$2, 24(%rbx)
	setne	%r10b
	cmpq	$64, %r9
	setb	%r11b
	testb	%r11b, %r10b
	je	.LBB1_1339
	shlq	$5, %r9
	movl	304(%rsp,%r9), %r10d
	cmpl	16(%rbx), %r10d
	jne	.LBB1_1339
	addq	%rsp, %r9
	addq	$280, %r9
	cmpb	$2, 16(%r9)
	je	.LBB1_1339
	movzbl	(%rbx), %r9d
	movzwl	5(%rbx), %r10d
	movzbl	7(%rbx), %r11d
	shll	$16, %r11d
	orl	%r10d, %r11d
	movl	1(%rbx), %r10d
	shlq	$40, %r11
	shlq	$8, %r10
	orq	%r11, %r10
	orq	%r9, %r10
	cmpq	$1, %r10
	je	.LBB1_1697
.LBB1_1339:
	movl	$112, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB1_1340:
	xorl	%r11d, %r11d
	cmpb	$2, 184(%rsp,%r10)
	setne	%r11b
	addq	%r11, %r9
	xorl	%r11d, %r11d
	cmpb	$2, 216(%rsp,%r10)
	setne	%r11b
	xorl	%ebx, %ebx
	cmpb	$2, 248(%rsp,%r10)
	setne	%bl
	addq	%r11, %rbx
	addq	%r9, %rbx
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r10)
	setne	%r9b
	addq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2160, %r10
	jne	.LBB1_1340
	movl	$4753, %r11d
	xorl	%r10d, %r10d
	.p2align	4
.LBB1_1342:
	xorl	%ebx, %ebx
	cmpb	$2, 160(%rsp,%r11)
	setne	%bl
	addq	%rbx, %r10
	xorl	%ebx, %ebx
	cmpb	$2, 200(%rsp,%r11)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 240(%rsp,%r11)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r10, %r14
	xorl	%r10d, %r10d
	cmpb	$2, 280(%rsp,%r11)
	setne	%r10b
	addq	%r14, %r10
	addq	$160, %r11
	cmpq	$9873, %r11
	jne	.LBB1_1342
	movl	$2192, %ebx
	xorl	%r11d, %r11d
	.p2align	4
.LBB1_1344:
	xorl	%r14d, %r14d
	cmpb	$2, 160(%rsp,%rbx)
	setne	%r14b
	addq	%r14, %r11
	xorl	%r14d, %r14d
	cmpb	$2, 200(%rsp,%rbx)
	setne	%r14b
	xorl	%r15d, %r15d
	cmpb	$2, 240(%rsp,%rbx)
	setne	%r15b
	addq	%r14, %r15
	addq	%r11, %r15
	xorl	%r11d, %r11d
	cmpb	$2, 280(%rsp,%rbx)
	setne	%r11b
	addq	%r15, %r11
	addq	$160, %rbx
	cmpq	$4752, %rbx
	jne	.LBB1_1344
	movl	$120, %r14d
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_1346:
	xorl	%r15d, %r15d
	cmpl	$0, 184(%rsp,%r14)
	sete	%r15b
	cmpl	$1, 216(%rsp,%r14)
	movq	%rbx, %r12
	adcq	%r15, %r12
	xorl	%ebx, %ebx
	cmpl	$0, 248(%rsp,%r14)
	sete	%bl
	cmpl	$1, 280(%rsp,%r14)
	adcq	%r12, %rbx
	subq	$-128, %r14
	cmpq	$2168, %r14
	jne	.LBB1_1346
	movl	$4760, %r15d
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_1348:
	xorl	%r12d, %r12d
	cmpl	$0, 160(%rsp,%r15)
	sete	%r12b
	cmpl	$1, 200(%rsp,%r15)
	movq	%r14, %r13
	adcq	%r12, %r13
	xorl	%r14d, %r14d
	cmpl	$0, 240(%rsp,%r15)
	sete	%r14b
	cmpl	$1, 280(%rsp,%r15)
	adcq	%r13, %r14
	addq	$160, %r15
	cmpq	$9880, %r15
	jne	.LBB1_1348
	movl	$2200, %r12d
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_1350:
	xorl	%r13d, %r13d
	cmpl	$0, 160(%rsp,%r12)
	sete	%r13b
	cmpl	$1, 200(%rsp,%r12)
	movq	%r15, %rbp
	adcq	%r13, %rbp
	xorl	%r15d, %r15d
	cmpl	$0, 240(%rsp,%r12)
	sete	%r15b
	cmpl	$1, 280(%rsp,%r12)
	adcq	%rbp, %r15
	addq	$160, %r12
	cmpq	$4760, %r12
	jne	.LBB1_1350
.LBB1_1351:
	cmpq	%rax, %r9
	jne	.LBB1_1698
	cmpq	%rcx, %r10
	jne	.LBB1_1698
	cmpq	%rdx, %r11
	jne	.LBB1_1698
	cmpq	%rsi, %rbx
	jne	.LBB1_1698
	cmpq	%rdi, %r14
	jne	.LBB1_1698
	cmpq	%r8, %r15
	jne	.LBB1_1698
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_1698
	movl	$0, 40(%rsp)
.LBB1_1359:
	xorl	%eax, %eax
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_1360:
	xorl	%ecx, %ecx
	cmpb	$2, 296(%rsp,%rax)
	setne	%cl
	addq	%rcx, %rbx
	xorl	%ecx, %ecx
	cmpb	$2, 328(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 360(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	xorl	%ebx, %ebx
	cmpb	$2, 392(%rsp,%rax)
	setne	%bl
	addq	%rdx, %rbx
	subq	$-128, %rax
	cmpq	$2048, %rax
	jne	.LBB1_1360
	xorl	%eax, %eax
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_1362:
	xorl	%ecx, %ecx
	cmpb	$2, 4913(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 4953(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 4993(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 5033(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_1362
	xorl	%eax, %eax
	xorl	%r15d, %r15d
	.p2align	4
.LBB1_1364:
	xorl	%ecx, %ecx
	cmpb	$2, 2352(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r15
	xorl	%ecx, %ecx
	cmpb	$2, 2392(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 2432(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r15, %rdx
	xorl	%r15d, %r15d
	cmpb	$2, 2472(%rsp,%rax)
	setne	%r15b
	addq	%rdx, %r15
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_1364
	movl	$64, %eax
	.p2align	4
.LBB1_1366:
	addq	$-4, %rax
	jne	.LBB1_1366
	movl	$128, %eax
	.p2align	4
.LBB1_1368:
	addq	$-4, %rax
	jne	.LBB1_1368
	movl	$64, %eax
	.p2align	4
.LBB1_1370:
	addq	$-4, %rax
	jne	.LBB1_1370
	movb	$1, %bpl
	testb	$1, 24(%rsp)
	movb	$1, %al
	movl	%eax, 24(%rsp)
	jne	.LBB1_1373
.LBB1_1372:
	movl	$0, 24(%rsp)
	movl	40(%rsp), %eax
	movl	%eax, %ebp
.LBB1_1373:
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_1698
	movzbl	%bpl, %eax
	movl	%eax, %ecx
	andl	$1, %ecx
	cmpq	%rcx, %rbx
	jne	.LBB1_1698
	movzbl	24(%rsp), %ecx
	cmpq	%rcx, %r14
	jne	.LBB1_1698
	movzbl	40(%rsp), %ecx
	cmpq	%rcx, %r15
	jne	.LBB1_1698
	andl	$1, %eax
	shll	$3, %eax
	cmpq	%rax, 32(%rsp)
	jne	.LBB1_1698
	movq	72(%rsp), %rax
	incq	%rax
	cmpq	$4, %rax
	jne	.LBB1_1132
	movl	$112, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB1_1380:
	xorl	%edx, %edx
	cmpb	$2, 184(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 216(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 248(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rax, %rsi
	xorl	%eax, %eax
	cmpb	$2, 280(%rsp,%rcx)
	setne	%al
	addq	%rsi, %rax
	subq	$-128, %rcx
	cmpq	$2160, %rcx
	jne	.LBB1_1380
	movl	$128, %ecx
	movq	memcpy@GOTPCREL(%rip), %rbp
	movq	264(%rsp), %rbx
	.p2align	4
.LBB1_1382:
	addq	$-4, %rcx
	jne	.LBB1_1382
	movl	$64, %ecx
	movzbl	55(%rsp), %r15d
	movzbl	54(%rsp), %r12d
	movzbl	53(%rsp), %r13d
	.p2align	4
.LBB1_1384:
	addq	$-4, %rcx
	jne	.LBB1_1384
	movl	$64, %ecx
	.p2align	4
.LBB1_1386:
	addq	$-4, %rcx
	jne	.LBB1_1386
	movl	$128, %ecx
	.p2align	4
.LBB1_1388:
	addq	$-4, %rcx
	jne	.LBB1_1388
	movl	$64, %ecx
	.p2align	4
.LBB1_1390:
	addq	$-4, %rcx
	jne	.LBB1_1390
	testq	%rax, %rax
	jne	.LBB1_1699
	movl	$64, %eax
	.p2align	4
.LBB1_1393:
	addq	$-4, %rax
	jne	.LBB1_1393
	movl	$128, %eax
	.p2align	4
.LBB1_1395:
	addq	$-4, %rax
	jne	.LBB1_1395
	movl	$64, %eax
	.p2align	4
.LBB1_1397:
	addq	$-4, %rax
	jne	.LBB1_1397
	movl	$64, %eax
	.p2align	4
.LBB1_1399:
	addq	$-4, %rax
	jne	.LBB1_1399
	movl	$128, %eax
	.p2align	4
.LBB1_1401:
	addq	$-4, %rax
	jne	.LBB1_1401
	movl	$64, %eax
	.p2align	4
.LBB1_1403:
	addq	$-4, %rax
	jne	.LBB1_1403
	cmpq	$0, 32(%rsp)
	jne	.LBB1_1699
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movq	88(%rsp), %r9
	testb	%al, %al
	je	.LBB1_1699
	movq	152(%rsp), %rax
	incl	%eax
	movq	%rax, 152(%rsp)
	movq	56(%rsp), %rdi
	movq	136(%rsp), %r8
	leaq	17720(%rsp), %rsi
	movq	240(%rsp), %r10
	movq	256(%rsp), %r11
	movq	248(%rsp), %r14
	jmp	.LBB1_1095
.LBB1_1407:
	decq	%r11
	movq	272(%rsp), %rdi
	cmpq	$4, %rdi
	jne	.LBB1_1091
	decq	%r10
	movq	232(%rsp), %r8
	cmpq	$4, %r8
	jne	.LBB1_1090
	movzbl	70(%rsp), %r10d
	movzbl	71(%rsp), %r9d
	cmpl	$24, 152(%rsp)
	sete	%sil
.LBB1_1410:
	xorl	%edi, %edi
.LBB1_1411:
	cmpq	$15, %rdi
	jne	.LBB1_1417
	movl	$100000, %ecx
.LBB1_1413:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1422
	pause
	decl	%ecx
	jne	.LBB1_1413
	jmp	.LBB1_1415
.LBB1_1417:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.57(%rdi), %ecx
	movl	$100000, %r8d
.LBB1_1418:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1427
	pause
	decl	%r8d
	jne	.LBB1_1418
	jmp	.LBB1_1420
.LBB1_1422:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB1_1423:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1428
	pause
	decl	%ecx
	jne	.LBB1_1423
	jmp	.LBB1_1425
.LBB1_1427:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB1_1429
.LBB1_1428:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB1_1429:
	incq	%rdi
	cmpq	$16, %rdi
	jne	.LBB1_1411
	movq	$0, 280(%rsp)
	movq	$41, 288(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.16, 296(%rsp)
	movq	$13, 304(%rsp)
	movzbl	119(%rsp), %eax
	movb	%al, 312(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.17, 320(%rsp)
	movq	$2, 328(%rsp)
	movl	180(%rsp), %eax
	movb	%al, 336(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.18, 344(%rsp)
	movq	$20, 352(%rsp)
	movl	176(%rsp), %eax
	movb	%al, 360(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.19, 368(%rsp)
	movq	$19, 376(%rsp)
	movl	172(%rsp), %eax
	movb	%al, 384(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.20, 392(%rsp)
	movq	$2, 400(%rsp)
	movq	216(%rsp), %rax
	movb	%al, 408(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.21, 416(%rsp)
	movq	$11, 424(%rsp)
	movq	208(%rsp), %rax
	movb	%al, 432(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.22, 440(%rsp)
	movq	$10, 448(%rsp)
	movq	224(%rsp), %rax
	movb	%al, 456(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.23, 464(%rsp)
	movq	$13, 472(%rsp)
	movb	$1, 480(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.24, 488(%rsp)
	movq	$14, 496(%rsp)
	movl	132(%rsp), %eax
	movb	%al, 504(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.25, 512(%rsp)
	movq	$13, 520(%rsp)
	movl	20(%rsp), %eax
	movb	%al, 528(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.26, 536(%rsp)
	movq	$10, 544(%rsp)
	movl	168(%rsp), %eax
	movb	%al, 552(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.27, 560(%rsp)
	movq	$12, 568(%rsp)
	movl	16(%rsp), %eax
	movb	%al, 576(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.28, 584(%rsp)
	movq	$14, 592(%rsp)
	movl	164(%rsp), %eax
	movb	%al, 600(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.29, 608(%rsp)
	movq	$17, 616(%rsp)
	movb	%r9b, 624(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.30, 632(%rsp)
	movq	$21, 640(%rsp)
	movb	%r10b, 648(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.31, 656(%rsp)
	movq	$18, 664(%rsp)
	movb	%r12b, 672(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.32, 680(%rsp)
	movq	$22, 688(%rsp)
	movzbl	118(%rsp), %eax
	movb	%al, 696(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.33, 704(%rsp)
	movq	$17, 712(%rsp)
	movb	$1, 720(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.34, 728(%rsp)
	movq	$9, 736(%rsp)
	movb	%r15b, 744(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.35, 752(%rsp)
	movq	$13, 760(%rsp)
	movb	%r13b, 768(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.36, 776(%rsp)
	movq	$12, 784(%rsp)
	movzbl	117(%rsp), %eax
	movb	%al, 792(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.37, 800(%rsp)
	movq	$16, 808(%rsp)
	movzbl	116(%rsp), %eax
	movb	%al, 816(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.38, 824(%rsp)
	movq	$14, 832(%rsp)
	movb	$1, 840(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.39, 848(%rsp)
	movq	$11, 856(%rsp)
	movb	$1, 864(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.40, 872(%rsp)
	movq	$11, 880(%rsp)
	movb	$1, 888(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.41, 896(%rsp)
	movq	$14, 904(%rsp)
	movq	200(%rsp), %rax
	movb	%al, 912(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.42, 920(%rsp)
	movq	$14, 928(%rsp)
	movzbl	115(%rsp), %eax
	movb	%al, 936(%rsp)
	leaq	296(%rsp), %rdi
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.43, 944(%rsp)
	movq	$14, 952(%rsp)
	movzbl	114(%rsp), %eax
	movb	%al, 960(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.44, 968(%rsp)
	movq	$13, 976(%rsp)
	movb	$1, 984(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.45, 992(%rsp)
	movq	$15, 1000(%rsp)
	movb	$1, 1008(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.46, 1016(%rsp)
	movq	$13, 1024(%rsp)
	movb	$1, 1032(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.47, 1040(%rsp)
	movq	$11, 1048(%rsp)
	movb	$1, 1056(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.48, 1064(%rsp)
	movq	$14, 1072(%rsp)
	movb	$1, 1080(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.49, 1088(%rsp)
	movq	$14, 1096(%rsp)
	movb	$1, 1104(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.50, 1112(%rsp)
	movq	$16, 1120(%rsp)
	movb	$1, 1128(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.51, 1136(%rsp)
	movq	$14, 1144(%rsp)
	movb	$1, 1152(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.52, 1160(%rsp)
	movq	$16, 1168(%rsp)
	movb	$1, 1176(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.53, 1184(%rsp)
	movq	$15, 1192(%rsp)
	movb	$1, 1200(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54, 1208(%rsp)
	movq	$13, 1216(%rsp)
	movb	$1, 1224(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.55, 1232(%rsp)
	movq	$16, 1240(%rsp)
	movb	$1, 1248(%rsp)
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.56, 1256(%rsp)
	movq	$13, 1264(%rsp)
	movb	%sil, 1272(%rsp)
	movb	$1, %cl
	xorl	%r8d, %r8d
.LBB1_1431:
	leaq	(%r8,%r8,2), %rax
	incq	%r8
	movq	%r8, 280(%rsp)
	movzbl	16(%rdi,%rax,8), %r9d
	cmpb	$2, %r9b
	je	.LBB1_1541
	movq	(%rdi,%rax,8), %r10
	movq	8(%rdi,%rax,8), %r11
	movl	$100000, %esi
	testb	$1, %r9b
	je	.LBB1_1435
.LBB1_1433:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1437
	pause
	decl	%esi
	jne	.LBB1_1433
	jmp	.LBB1_1500
.LBB1_1435:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1440
	pause
	decl	%esi
	jne	.LBB1_1435
	jmp	.LBB1_1505
.LBB1_1437:
	movw	$1016, %dx
	movb	$72, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1438:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1443
	pause
	decl	%esi
	jne	.LBB1_1438
	jmp	.LBB1_1500
.LBB1_1440:
	movw	$1016, %dx
	movb	$72, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1441:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1446
	pause
	decl	%esi
	jne	.LBB1_1441
	jmp	.LBB1_1505
.LBB1_1443:
	movw	$1016, %dx
	movb	$77, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1444:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1449
	pause
	decl	%esi
	jne	.LBB1_1444
	jmp	.LBB1_1500
.LBB1_1446:
	movw	$1016, %dx
	movb	$77, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1447:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1452
	pause
	decl	%esi
	jne	.LBB1_1447
	jmp	.LBB1_1505
.LBB1_1449:
	movw	$1016, %dx
	movb	$84, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1450:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1455
	pause
	decl	%esi
	jne	.LBB1_1450
	jmp	.LBB1_1500
.LBB1_1452:
	movw	$1016, %dx
	movb	$84, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1453:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1458
	pause
	decl	%esi
	jne	.LBB1_1453
	jmp	.LBB1_1505
.LBB1_1455:
	movw	$1016, %dx
	movb	$69, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1456:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1461
	pause
	decl	%esi
	jne	.LBB1_1456
	jmp	.LBB1_1500
.LBB1_1458:
	movw	$1016, %dx
	movb	$69, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1459:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1464
	pause
	decl	%esi
	jne	.LBB1_1459
	jmp	.LBB1_1505
.LBB1_1461:
	movw	$1016, %dx
	movb	$83, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1462:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1467
	pause
	decl	%esi
	jne	.LBB1_1462
	jmp	.LBB1_1500
.LBB1_1464:
	movw	$1016, %dx
	movb	$83, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1465:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1470
	pause
	decl	%esi
	jne	.LBB1_1465
	jmp	.LBB1_1505
.LBB1_1467:
	movw	$1016, %dx
	movb	$84, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1468:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1473
	pause
	decl	%esi
	jne	.LBB1_1468
	jmp	.LBB1_1500
.LBB1_1470:
	movw	$1016, %dx
	movb	$84, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1471:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1476
	pause
	decl	%esi
	jne	.LBB1_1471
	jmp	.LBB1_1505
.LBB1_1473:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1474:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1479
	pause
	decl	%esi
	jne	.LBB1_1474
	jmp	.LBB1_1500
.LBB1_1476:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1477:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1482
	pause
	decl	%esi
	jne	.LBB1_1477
	jmp	.LBB1_1505
.LBB1_1479:
	movw	$1016, %dx
	movb	$80, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1480:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1485
	pause
	decl	%esi
	jne	.LBB1_1480
	jmp	.LBB1_1500
.LBB1_1482:
	movw	$1016, %dx
	movb	$70, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1483:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1488
	pause
	decl	%esi
	jne	.LBB1_1483
	jmp	.LBB1_1505
.LBB1_1485:
	movw	$1016, %dx
	movb	$65, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1486:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1491
	pause
	decl	%esi
	jne	.LBB1_1486
	jmp	.LBB1_1500
.LBB1_1488:
	movw	$1016, %dx
	movb	$65, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1489:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1494
	pause
	decl	%esi
	jne	.LBB1_1489
	jmp	.LBB1_1505
.LBB1_1491:
	movw	$1016, %dx
	movb	$83, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1492:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1497
	pause
	decl	%esi
	jne	.LBB1_1492
	jmp	.LBB1_1500
.LBB1_1494:
	movw	$1016, %dx
	movb	$73, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1495:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1502
	pause
	decl	%esi
	jne	.LBB1_1495
	jmp	.LBB1_1505
.LBB1_1497:
	movw	$1016, %dx
	movb	$83, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1498:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1507
	pause
	decl	%esi
	jne	.LBB1_1498
	jmp	.LBB1_1500
.LBB1_1502:
	movw	$1016, %dx
	movb	$76, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1503:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1508
	pause
	decl	%esi
	jne	.LBB1_1503
	jmp	.LBB1_1505
.LBB1_1507:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB1_1509
.LBB1_1508:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB1_1509:
	testq	%r11, %r11
	je	.LBB1_1530
	addq	%r10, %r11
.LBB1_1511:
	movzbl	(%r10), %esi
	cmpb	$10, %sil
	jne	.LBB1_1517
	movl	$100000, %esi
.LBB1_1513:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1522
	pause
	decl	%esi
	jne	.LBB1_1513
	jmp	.LBB1_1515
.LBB1_1517:
	movl	$100000, %ebx
.LBB1_1518:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1527
	pause
	decl	%ebx
	jne	.LBB1_1518
	jmp	.LBB1_1520
.LBB1_1522:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1523:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1528
	pause
	decl	%esi
	jne	.LBB1_1523
	jmp	.LBB1_1525
.LBB1_1527:
	movw	$1016, %dx
	movl	%esi, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB1_1529
.LBB1_1528:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB1_1529:
	incq	%r10
	cmpq	%r11, %r10
	jne	.LBB1_1511
.LBB1_1530:
	movl	$100000, %esi
.LBB1_1531:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1535
	pause
	decl	%esi
	jne	.LBB1_1531
	jmp	.LBB1_1533
.LBB1_1535:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1536:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1540
	pause
	decl	%esi
	jne	.LBB1_1536
	jmp	.LBB1_1538
.LBB1_1540:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	andb	%r9b, %cl
	cmpq	$41, %r8
	jne	.LBB1_1431
.LBB1_1541:
	xorl	%edi, %edi
.LBB1_1542:
	cmpq	$13, %rdi
	jne	.LBB1_1548
	movl	$100000, %esi
.LBB1_1544:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1553
	pause
	decl	%esi
	jne	.LBB1_1544
	jmp	.LBB1_1546
.LBB1_1548:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.58(%rdi), %esi
	movl	$100000, %r8d
.LBB1_1549:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1558
	pause
	decl	%r8d
	jne	.LBB1_1549
	jmp	.LBB1_1551
.LBB1_1553:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %esi
.LBB1_1554:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1559
	pause
	decl	%esi
	jne	.LBB1_1554
	jmp	.LBB1_1556
.LBB1_1558:
	movw	$1016, %dx
	movl	%esi, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB1_1560
.LBB1_1559:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB1_1560:
	incq	%rdi
	cmpq	$14, %rdi
	jne	.LBB1_1542
	andb	$1, %cl
	movl	%ecx, %eax
	addq	$29496, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB1_1562:
	.cfi_def_cfa_offset 29552
	movq	19768(%rsp), %rax
	.p2align	4
.LBB1_1563:
	cmpq	$-1, %rax
	je	.LBB1_1088
	leaq	1(%rax), %rcx
	lock		cmpxchgq	%rcx, 19768(%rsp)
	jne	.LBB1_1563
	cmpq	$1, %rax
	jne	.LBB1_1088
	movq	19768(%rsp), %rax
	cmpq	$2, %rax
	jne	.LBB1_1088
	movq	$-2, 280(%rsp)
	movq	280(%rsp), %rax
.LBB1_1568:
	cmpq	$-1, %rax
	je	.LBB1_1088
	leaq	1(%rax), %rcx
	lock		cmpxchgq	%rcx, 280(%rsp)
	jne	.LBB1_1568
	cmpq	$-2, %rax
	jb	.LBB1_1088
	movq	280(%rsp), %rax
	cmpq	$-1, %rax
	jne	.LBB1_1088
	movq	280(%rsp), %rax
.LBB1_1573:
	cmpq	$-1, %rax
	je	.LBB1_1731
	leaq	1(%rax), %rcx
	lock		cmpxchgq	%rcx, 280(%rsp)
	jne	.LBB1_1573
	jmp	.LBB1_1088
.LBB1_1697:
	movq	$1, (%rbx)
	movb	$1, 24(%rbx)
.LBB1_1698:
	movzbl	55(%rsp), %r15d
	movzbl	54(%rsp), %r12d
	movzbl	53(%rsp), %r13d
.LBB1_1699:
	xorl	%esi, %esi
	movq	56(%rsp), %r9
.LBB1_1700:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.72(%rsi), %ecx
	incq	%rsi
	movl	$100000, %edi
	.p2align	4
.LBB1_1701:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1705
	pause
	decl	%edi
	jne	.LBB1_1701
	jmp	.LBB1_1703
	.p2align	4
.LBB1_1705:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	cmpq	$25, %rsi
	jne	.LBB1_1700
	movl	$100000, %ecx
	movw	$1021, %dx
	.p2align	4
.LBB1_1707:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1711
	pause
	decl	%ecx
	jne	.LBB1_1707
.LBB1_1709:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB1_1710:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1710
.LBB1_1703:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB1_1704:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1704
.LBB1_1711:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movq	136(%rsp), %rax
	cmpq	$4, %rax
	jae	.LBB1_1972
	shlq	$4, %rax
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.77(%rax), %rsi
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.77+8(%rax), %rdi
	addq	%rsi, %rdi
.LBB1_1713:
	movzbl	(%rsi), %ecx
	cmpb	$10, %cl
	jne	.LBB1_1717
	movl	$100000, %ecx
	.p2align	4
.LBB1_1715:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1722
	pause
	decl	%ecx
	jne	.LBB1_1715
	jmp	.LBB1_1953
.LBB1_1717:
	movl	$100000, %r8d
	.p2align	4
.LBB1_1718:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1725
	pause
	decl	%r8d
	jne	.LBB1_1718
	jmp	.LBB1_1720
.LBB1_1722:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB1_1723:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1726
	pause
	decl	%ecx
	jne	.LBB1_1723
	jmp	.LBB1_1961
.LBB1_1725:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB1_1727
.LBB1_1726:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB1_1727:
	incq	%rsi
	cmpq	%rdi, %rsi
	jne	.LBB1_1713
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB1_1729:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1738
	pause
	decl	%ecx
	jne	.LBB1_1729
	jmp	.LBB1_1709
.LBB1_1731:
	movq	280(%rsp), %rax
.LBB1_1732:
	cmpq	$-1, %rax
	je	.LBB1_1737
	leaq	1(%rax), %rcx
	xorl	%edx, %edx
	lock		cmpxchgq	%rcx, 280(%rsp)
	jne	.LBB1_1732
	jmp	.LBB1_1089
.LBB1_1737:
	movq	280(%rsp), %rax
	cmpq	$-1, %rax
	sete	%dl
	jmp	.LBB1_1089
.LBB1_1738:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	cmpq	$3, %r9
	ja	.LBB1_1971
	shlq	$4, %r9
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.77(%r9), %rsi
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.77+8(%r9), %rdi
	addq	%rsi, %rdi
.LBB1_1740:
	movzbl	(%rsi), %ecx
	cmpb	$10, %cl
	jne	.LBB1_1744
	movl	$100000, %ecx
.LBB1_1742:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1747
	pause
	decl	%ecx
	jne	.LBB1_1742
	jmp	.LBB1_1953
.LBB1_1744:
	movl	$100000, %r8d
.LBB1_1745:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1750
	pause
	decl	%r8d
	jne	.LBB1_1745
	jmp	.LBB1_1720
.LBB1_1747:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB1_1748:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1751
	pause
	decl	%ecx
	jne	.LBB1_1748
	jmp	.LBB1_1961
.LBB1_1750:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB1_1752
.LBB1_1751:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB1_1752:
	incq	%rsi
	cmpq	%rdi, %rsi
	jne	.LBB1_1740
	movl	$100000, %ecx
	movzbl	70(%rsp), %r10d
	movzbl	71(%rsp), %r9d
	movw	$1021, %dx
.LBB1_1754:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1814
	pause
	decl	%ecx
	jne	.LBB1_1754
	jmp	.LBB1_1709
.LBB1_1756:
	movq	$0, 344(%rsp)
	movw	$0, 352(%rsp)
	movl	$1886152040, 280(%rsp)
	movb	$1, %al
	movl	%eax, 132(%rsp)
	jmp	.LBB1_8
.LBB1_1757:
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB1_431
.LBB1_1415:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1416:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1416
.LBB1_1420:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1421:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1421
.LBB1_1758:
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12624(%rsp)
	jne	.LBB1_846
	cmpq	%r14, 12600(%rsp)
	jne	.LBB1_846
	cmpq	%r13, 12608(%rsp)
	jne	.LBB1_846
	cmpq	%r15, 12616(%rsp)
	jne	.LBB1_846
	cmpq	%r12, 12632(%rsp)
	jne	.LBB1_846
	cmpq	%rbp, 12640(%rsp)
	jne	.LBB1_846
	cmpq	%rbx, 12648(%rsp)
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_846
	movl	$96, %eax
.LBB1_1767:
	movq	$1, 9968(%rsp,%rax)
	movq	$2, 9960(%rsp,%rax)
	movq	$0, 9952(%rsp,%rax)
	movq	$0, 9944(%rsp,%rax)
	movq	$0, 9976(%rsp,%rax)
	movq	$0, 9984(%rsp,%rax)
	movq	$2, 9992(%rsp,%rax)
	movq	$1, 10000(%rsp,%rax)
	movq	$0, 10008(%rsp,%rax)
	movq	$0, 10016(%rsp,%rax)
	movq	$2, 10024(%rsp,%rax)
	movq	$1, 10032(%rsp,%rax)
	movq	$0, 10040(%rsp,%rax)
	movq	$0, 10048(%rsp,%rax)
	movq	$2, 10056(%rsp,%rax)
	movq	$1, 10064(%rsp,%rax)
	subq	$-128, %rax
	cmpq	$2144, %rax
	jne	.LBB1_1767
	xorl	%eax, %eax
.LBB1_1769:
	movq	$1, 312(%rsp,%rax)
	movq	$512, 304(%rsp,%rax)
	movq	$0, 296(%rsp,%rax)
	movq	$0, 288(%rsp,%rax)
	movq	$0, 280(%rsp,%rax)
	movq	$0, 320(%rsp,%rax)
	movq	$0, 328(%rsp,%rax)
	movq	$0, 336(%rsp,%rax)
	movq	$512, 344(%rsp,%rax)
	movq	$1, 352(%rsp,%rax)
	movq	$0, 360(%rsp,%rax)
	movq	$0, 368(%rsp,%rax)
	movq	$0, 376(%rsp,%rax)
	movq	$512, 384(%rsp,%rax)
	movq	$1, 392(%rsp,%rax)
	movq	$0, 400(%rsp,%rax)
	movq	$0, 408(%rsp,%rax)
	movq	$0, 416(%rsp,%rax)
	movq	$512, 424(%rsp,%rax)
	movq	$1, 432(%rsp,%rax)
	addq	$160, %rax
	cmpq	$5120, %rax
	jne	.LBB1_1769
	xorl	%eax, %eax
.LBB1_1771:
	movq	$1, 12632(%rsp,%rax)
	movq	$2, 12624(%rsp,%rax)
	movq	$0, 12616(%rsp,%rax)
	movq	$0, 12608(%rsp,%rax)
	movq	$0, 12600(%rsp,%rax)
	movq	$0, 12640(%rsp,%rax)
	movq	$0, 12648(%rsp,%rax)
	movq	$0, 12656(%rsp,%rax)
	movq	$2, 12664(%rsp,%rax)
	movq	$1, 12672(%rsp,%rax)
	movq	$0, 12680(%rsp,%rax)
	movq	$0, 12688(%rsp,%rax)
	movq	$0, 12696(%rsp,%rax)
	movq	$2, 12704(%rsp,%rax)
	movq	$1, 12712(%rsp,%rax)
	movq	$0, 12720(%rsp,%rax)
	movq	$0, 12728(%rsp,%rax)
	movq	$0, 12736(%rsp,%rax)
	movq	$2, 12744(%rsp,%rax)
	movq	$1, 12752(%rsp,%rax)
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB1_1771
	leaq	19768(%rsp), %rbx
	leaq	10040(%rsp), %rsi
	movl	$2048, %edx
	movq	%rbx, %rdi
	movq	memcpy@GOTPCREL(%rip), %r14
	callq	*%r14
	leaq	24376(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$5120, %edx
	callq	*%r14
	leaq	21816(%rsp), %rdi
	leaq	12600(%rsp), %rsi
	movl	$2560, %edx
	callq	*%r14
	leaq	280(%rsp), %rdi
	movl	$9728, %edx
	movq	%rbx, %rsi
	callq	*%r14
	movq	$4096, 10008(%rsp)
	movq	$64, 10016(%rsp)
	movl	$-1, 10024(%rsp)
	movq	$0, 10032(%rsp)
	movl	$112, %eax
	xorl	%r14d, %r14d
.LBB1_1773:
	xorl	%ecx, %ecx
	cmpb	$2, 184(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r14
	xorl	%ecx, %ecx
	cmpb	$2, 216(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 248(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r14, %rdx
	xorl	%r14d, %r14d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r14b
	addq	%rdx, %r14
	subq	$-128, %rax
	cmpq	$2160, %rax
	jne	.LBB1_1773
	movl	$4753, %eax
	xorl	%r12d, %r12d
.LBB1_1775:
	xorl	%ecx, %ecx
	cmpb	$2, 160(%rsp,%rax)
	setne	%cl
	addq	%rcx, %r12
	xorl	%ecx, %ecx
	cmpb	$2, 200(%rsp,%rax)
	setne	%cl
	xorl	%edx, %edx
	cmpb	$2, 240(%rsp,%rax)
	setne	%dl
	addq	%rcx, %rdx
	addq	%r12, %rdx
	xorl	%r12d, %r12d
	cmpb	$2, 280(%rsp,%rax)
	setne	%r12b
	addq	%rdx, %r12
	addq	$160, %rax
	cmpq	$9873, %rax
	jne	.LBB1_1775
	movl	$2192, %ecx
	leaq	2328(%rsp), %rax
	xorl	%ebp, %ebp
.LBB1_1777:
	xorl	%edx, %edx
	cmpb	$2, 160(%rsp,%rcx)
	setne	%dl
	addq	%rdx, %rbp
	xorl	%edx, %edx
	cmpb	$2, 200(%rsp,%rcx)
	setne	%dl
	xorl	%esi, %esi
	cmpb	$2, 240(%rsp,%rcx)
	setne	%sil
	addq	%rdx, %rsi
	addq	%rbp, %rsi
	xorl	%ebp, %ebp
	cmpb	$2, 280(%rsp,%rcx)
	setne	%bpl
	addq	%rsi, %rbp
	addq	$160, %rcx
	cmpq	$4752, %rcx
	jne	.LBB1_1777
	movl	$120, %ecx
	xorl	%r15d, %r15d
.LBB1_1779:
	xorl	%edx, %edx
	cmpl	$0, 184(%rsp,%rcx)
	sete	%dl
	cmpl	$1, 216(%rsp,%rcx)
	movq	%r15, %rsi
	adcq	%rdx, %rsi
	xorl	%r15d, %r15d
	cmpl	$0, 248(%rsp,%rcx)
	sete	%r15b
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %r15
	subq	$-128, %rcx
	cmpq	$2168, %rcx
	jne	.LBB1_1779
	movl	$4760, %ecx
	xorl	%ebx, %ebx
.LBB1_1781:
	xorl	%edx, %edx
	cmpl	$0, 160(%rsp,%rcx)
	sete	%dl
	cmpl	$1, 200(%rsp,%rcx)
	movq	%rbx, %rsi
	adcq	%rdx, %rsi
	xorl	%ebx, %ebx
	cmpl	$0, 240(%rsp,%rcx)
	sete	%bl
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %rbx
	addq	$160, %rcx
	cmpq	$9880, %rcx
	jne	.LBB1_1781
	movl	$2200, %ecx
	xorl	%r13d, %r13d
.LBB1_1783:
	xorl	%edx, %edx
	cmpl	$0, 160(%rsp,%rcx)
	sete	%dl
	cmpl	$1, 200(%rsp,%rcx)
	movq	%r13, %rsi
	adcq	%rdx, %rsi
	xorl	%r13d, %r13d
	cmpl	$0, 240(%rsp,%rcx)
	sete	%r13b
	cmpl	$1, 280(%rsp,%rcx)
	adcq	%rsi, %r13
	addq	$160, %rcx
	cmpq	$4760, %rcx
	jne	.LBB1_1783
	movl	$56, %edx
	xorl	%ecx, %ecx
	jmp	.LBB1_1786
.LBB1_1785:
	addq	$2, %rcx
	addq	$64, %rdx
	cmpq	$2104, %rdx
	je	.LBB1_846
.LBB1_1786:
	cmpb	$2, 240(%rsp,%rdx)
	jne	.LBB1_1788
	cmpl	$0, 248(%rsp,%rdx)
	jne	.LBB1_1791
.LBB1_1788:
	cmpb	$2, 272(%rsp,%rdx)
	jne	.LBB1_1785
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB1_1785
	incq	%rcx
.LBB1_1791:
	movl	$4680, %edx
	movq	$0, 24(%rsp)
	jmp	.LBB1_1793
.LBB1_1792:
	addq	$2, 24(%rsp)
	addq	$80, %rdx
	cmpq	$9800, %rdx
	je	.LBB1_846
.LBB1_1793:
	cmpb	$2, 233(%rsp,%rdx)
	jne	.LBB1_1795
	cmpl	$0, 240(%rsp,%rdx)
	jne	.LBB1_1798
.LBB1_1795:
	cmpb	$2, 273(%rsp,%rdx)
	jne	.LBB1_1792
	cmpl	$0, 280(%rsp,%rdx)
	je	.LBB1_1792
	incq	24(%rsp)
.LBB1_1798:
	movq	%rcx, %rsi
	shlq	$5, %rsi
	movl	304(%rsp,%rsi), %edx
	movq	$1, 280(%rsp,%rsi)
	movq	$32, 288(%rsp,%rsi)
	movb	$0, 296(%rsp,%rsi)
	movq	24(%rsp), %rsi
	leaq	(%rsi,%rsi,4), %rsi
	leaq	280(%rsp), %rdi
	leaq	4608(%rdi,%rsi,8), %r8
	movq	%rcx, 4608(%rdi,%rsi,8)
	movl	%edx, 4616(%rdi,%rsi,8)
	movq	$1, 4624(%rdi,%rsi,8)
	movw	$263, 4632(%rdi,%rsi,8)
	movq	$32, 10032(%rsp)
	movl	4640(%rdi,%rsi,8), %esi
	movl	%esi, 40(%rsp)
	movl	$4680, %esi
	movq	$0, 32(%rsp)
	jmp	.LBB1_1800
.LBB1_1799:
	addq	$2, 32(%rsp)
	addq	$80, %rsi
	cmpq	$9800, %rsi
	je	.LBB1_846
.LBB1_1800:
	cmpb	$2, 233(%rsp,%rsi)
	jne	.LBB1_1802
	cmpl	$0, 240(%rsp,%rsi)
	jne	.LBB1_1805
.LBB1_1802:
	cmpb	$2, 273(%rsp,%rsi)
	jne	.LBB1_1799
	cmpl	$0, 280(%rsp,%rsi)
	je	.LBB1_1799
	incq	32(%rsp)
.LBB1_1805:
	movq	32(%rsp), %rsi
	leaq	(%rsi,%rsi,4), %r9
	leaq	280(%rsp), %rsi
	movq	%rcx, 4608(%rsi,%r9,8)
	movl	%edx, 4616(%rsi,%r9,8)
	movq	$2, 4624(%rsi,%r9,8)
	movw	$1, 4632(%rsi,%r9,8)
	cmpb	$2, 25(%r8)
	je	.LBB1_846
	movq	(%r8), %rsi
	cmpq	$1, 16(%r8)
	sete	%dil
	cmpq	$64, %rsi
	setb	%r10b
	andb	%dil, %r10b
	cmpb	$1, %r10b
	jne	.LBB1_846
	movl	8(%r8), %edi
	movq	%rsi, %r10
	shlq	$5, %r10
	cmpl	%edi, 304(%rsp,%r10)
	jne	.LBB1_846
	addq	%rsp, %r10
	addq	$280, %r10
	movl	$0, 16(%rsp)
	cmpb	$0, 16(%r10)
	jne	.LBB1_847
	movzbl	24(%r8), %r8d
	andb	$2, %r8b
	je	.LBB1_847
	leaq	280(%rsp), %r8
	movl	4640(%r8,%r9,8), %r8d
	movl	%r8d, 96(%rsp)
	movl	$2192, %r8d
	xorl	%r9d, %r9d
.LBB1_1811:
	xorl	%r10d, %r10d
	cmpb	$2, 160(%rsp,%r8)
	setne	%r10b
	addq	%r10, %r9
	xorl	%r10d, %r10d
	cmpb	$2, 200(%rsp,%r8)
	setne	%r10b
	xorl	%r11d, %r11d
	cmpb	$2, 240(%rsp,%r8)
	setne	%r11b
	addq	%r10, %r11
	addq	%r9, %r11
	xorl	%r9d, %r9d
	cmpb	$2, 280(%rsp,%r8)
	setne	%r9b
	addq	%r11, %r9
	addq	$160, %r8
	cmpq	$4752, %r8
	jne	.LBB1_1811
	cmpq	$63, %r9
	ja	.LBB1_846
	movl	$2120, %r8d
	movq	$0, 56(%rsp)
	jmp	.LBB1_1833
.LBB1_1425:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1426:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1426
.LBB1_1814:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	cmpq	$3, 88(%rsp)
	ja	.LBB1_1979
	movq	88(%rsp), %rax
	shlq	$4, %rax
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.77(%rax), %rsi
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.77+8(%rax), %rdi
	addq	%rsi, %rdi
.LBB1_1816:
	movzbl	(%rsi), %ecx
	cmpb	$10, %cl
	jne	.LBB1_1820
	movl	$100000, %ecx
.LBB1_1818:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1823
	pause
	decl	%ecx
	jne	.LBB1_1818
	jmp	.LBB1_1953
.LBB1_1820:
	movl	$100000, %r8d
.LBB1_1821:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1826
	pause
	decl	%r8d
	jne	.LBB1_1821
	jmp	.LBB1_1720
.LBB1_1823:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB1_1824:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1827
	pause
	decl	%ecx
	jne	.LBB1_1824
	jmp	.LBB1_1961
.LBB1_1826:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB1_1828
.LBB1_1827:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB1_1828:
	incq	%rsi
	cmpq	%rdi, %rsi
	jne	.LBB1_1816
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB1_1830:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1947
	pause
	decl	%ecx
	jne	.LBB1_1830
	jmp	.LBB1_1709
.LBB1_1500:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1501:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1501
.LBB1_1505:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1506:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1506
.LBB1_1832:
	addq	$2, 56(%rsp)
	addq	$80, %r8
	movl	$0, 16(%rsp)
	cmpq	$4680, %r8
	je	.LBB1_847
.LBB1_1833:
	cmpb	$2, 232(%rsp,%r8)
	jne	.LBB1_1835
	cmpl	$0, 240(%rsp,%r8)
	jne	.LBB1_1838
.LBB1_1835:
	cmpb	$2, 272(%rsp,%r8)
	jne	.LBB1_1832
	cmpl	$0, 280(%rsp,%r8)
	je	.LBB1_1832
	incq	56(%rsp)
.LBB1_1838:
	movq	56(%rsp), %r8
	leaq	(%r8,%r8,4), %r8
	leaq	(%rax,%r8,8), %r9
	movq	%r9, 80(%rsp)
	movq	$1, (%rax,%r8,8)
	movq	%rsi, 8(%rax,%r8,8)
	movl	%edi, 16(%rax,%r8,8)
	movb	$0, 24(%rax,%r8,8)
	movl	32(%rax,%r8,8), %esi
	movl	%esi, 88(%rsp)
	movl	$2192, %esi
	xorl	%edi, %edi
.LBB1_1839:
	xorl	%r8d, %r8d
	cmpb	$2, 160(%rsp,%rsi)
	setne	%r8b
	addq	%r8, %rdi
	xorl	%r8d, %r8d
	cmpb	$2, 200(%rsp,%rsi)
	setne	%r8b
	xorl	%r9d, %r9d
	cmpb	$2, 240(%rsp,%rsi)
	setne	%r9b
	addq	%r8, %r9
	addq	%rdi, %r9
	xorl	%edi, %edi
	cmpb	$2, 280(%rsp,%rsi)
	setne	%dil
	addq	%r9, %rdi
	addq	$160, %rsi
	cmpq	$4752, %rsi
	jne	.LBB1_1839
	cmpq	$63, %rdi
	ja	.LBB1_846
	movl	$2120, %esi
	movq	$0, 72(%rsp)
	jmp	.LBB1_1844
.LBB1_1842:
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movq	memcpy@GOTPCREL(%rip), %r12
	jmp	.LBB1_432
.LBB1_1843:
	addq	$2, 72(%rsp)
	addq	$80, %rsi
	movl	$0, 16(%rsp)
	cmpq	$4680, %rsi
	je	.LBB1_847
.LBB1_1844:
	cmpb	$2, 232(%rsp,%rsi)
	jne	.LBB1_1846
	cmpl	$0, 240(%rsp,%rsi)
	jne	.LBB1_1849
.LBB1_1846:
	cmpb	$2, 272(%rsp,%rsi)
	jne	.LBB1_1843
	cmpl	$0, 280(%rsp,%rsi)
	je	.LBB1_1843
	incq	72(%rsp)
.LBB1_1849:
	movq	72(%rsp), %rsi
	leaq	(%rsi,%rsi,4), %rsi
	movq	$2, (%rax,%rsi,8)
	movq	%rcx, 8(%rax,%rsi,8)
	movl	%edx, 16(%rax,%rsi,8)
	movb	$0, 24(%rax,%rsi,8)
	movl	32(%rax,%rsi,8), %eax
	movl	%eax, 120(%rsp)
	leaq	280(%rsp), %rdi
	movl	$2, %esi
	movq	32(%rsp), %rdx
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB1_846
	movl	88(%rsp), %eax
	movq	80(%rsp), %rcx
	cmpl	%eax, 32(%rcx)
	jne	.LBB1_846
	movq	80(%rsp), %rcx
	movq	8(%rcx), %rax
	cmpb	$2, 24(%rcx)
	setne	%cl
	cmpq	$64, %rax
	setb	%dl
	andb	%cl, %dl
	cmpb	$1, %dl
	jne	.LBB1_846
	shlq	$5, %rax
	movl	304(%rsp,%rax), %ecx
	movq	80(%rsp), %rdx
	cmpl	16(%rdx), %ecx
	jne	.LBB1_846
	addq	%rsp, %rax
	addq	$280, %rax
	cmpb	$2, 16(%rax)
	je	.LBB1_846
	movq	80(%rsp), %rsi
	movzbl	(%rsi), %eax
	movzwl	5(%rsi), %ecx
	movzbl	7(%rsi), %edx
	shll	$16, %edx
	orl	%ecx, %edx
	movl	1(%rsi), %ecx
	shlq	$40, %rdx
	shlq	$8, %rcx
	orq	%rdx, %rcx
	orq	%rax, %rcx
	cmpq	$1, %rcx
	jne	.LBB1_846
	movq	80(%rsp), %rax
	movq	$1, (%rax)
	movb	$1, 24(%rax)
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	56(%rsp), %rdx
	movl	88(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel
	cmpb	$-1, %al
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	24(%rsp), %rdx
	movl	40(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	cmpb	$-1, %al
	jne	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$32, 12624(%rsp)
	jne	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$1, 12600(%rsp)
	jne	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$0, 12608(%rsp)
	jne	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$2, 12616(%rsp)
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_846
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$2, %esi
	leaq	280(%rsp), %rdi
	movq	32(%rsp), %rdx
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	je	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_846
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_846
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_846
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_846
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_846
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_846
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_846
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	12600(%rsp), %rdi
	movl	$1, %edx
	leaq	280(%rsp), %rsi
	movq	24(%rsp), %rcx
	movl	40(%rsp), %r8d
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$0, 12600(%rsp)
	je	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_846
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_846
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_846
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_846
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_846
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_846
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_846
	leaq	280(%rsp), %rdi
	movq	56(%rsp), %rsi
	movl	88(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	notb	%al
	andb	%dl, %al
	testb	$1, %al
	je	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	cmpq	$32, 12624(%rsp)
	jne	.LBB1_846
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	280(%rsp), %rdi
	movq	56(%rsp), %rsi
	movl	88(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	je	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_846
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_846
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_846
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_846
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_846
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_846
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_846
	leaq	280(%rsp), %rdi
	movq	72(%rsp), %rsi
	movl	120(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	orb	%al, %dl
	testb	$1, %dl
	jne	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$0, 16(%rsp)
	cmpq	$0, 12624(%rsp)
	jne	.LBB1_847
	cmpq	%r14, 12600(%rsp)
	jne	.LBB1_847
	cmpq	%r12, 12608(%rsp)
	jne	.LBB1_847
	cmpq	%rbp, 12616(%rsp)
	jne	.LBB1_847
	cmpq	%r15, 12632(%rsp)
	jne	.LBB1_847
	cmpq	%rbx, 12640(%rsp)
	jne	.LBB1_847
	cmpq	%r13, 12648(%rsp)
	jne	.LBB1_847
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$2, %esi
	leaq	280(%rsp), %rdi
	movq	72(%rsp), %rdx
	movl	120(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel
	cmpb	$-1, %al
	je	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_846
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_846
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_846
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_846
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_846
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_846
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$32, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6create
	cmpb	$1, 12600(%rsp)
	je	.LBB1_846
	movq	12608(%rsp), %rcx
	movl	12616(%rsp), %r8d
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	movl	$1, %edx
	movq	%rcx, 32(%rsp)
	movl	%r8d, 96(%rsp)
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	cmpb	$1, 12600(%rsp)
	je	.LBB1_846
	movq	12608(%rsp), %rax
	movq	%rax, 80(%rsp)
	movl	12616(%rsp), %eax
	movl	%eax, 108(%rsp)
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$1, %esi
	leaq	280(%rsp), %rdi
	movq	24(%rsp), %rdx
	movl	40(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	je	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_846
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_846
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_846
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_846
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_846
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_846
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_846
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	280(%rsp), %rdi
	movq	56(%rsp), %rsi
	movl	88(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	cmpb	$2, %dl
	sete	%cl
	andb	%al, %cl
	cmpb	$1, %cl
	jne	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_846
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_846
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_846
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_846
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_846
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_846
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_846
	leaq	10040(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	leaq	280(%rsp), %rdi
	movq	72(%rsp), %rsi
	movl	120(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	je	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movq	12624(%rsp), %rax
	cmpq	10064(%rsp), %rax
	jne	.LBB1_846
	movq	12600(%rsp), %rax
	cmpq	10040(%rsp), %rax
	jne	.LBB1_846
	movq	12608(%rsp), %rax
	cmpq	10048(%rsp), %rax
	jne	.LBB1_846
	movq	12616(%rsp), %rax
	cmpq	10056(%rsp), %rax
	jne	.LBB1_846
	movq	12632(%rsp), %rax
	cmpq	10072(%rsp), %rax
	jne	.LBB1_846
	movq	12640(%rsp), %rax
	cmpq	10080(%rsp), %rax
	jne	.LBB1_846
	movq	12648(%rsp), %rax
	cmpq	10088(%rsp), %rax
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	testb	%al, %al
	je	.LBB1_846
	leaq	280(%rsp), %rdi
	movq	80(%rsp), %rsi
	movl	108(%rsp), %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	testb	$1, %al
	jne	.LBB1_846
	leaq	280(%rsp), %rdi
	movl	$1, %esi
	movq	32(%rsp), %rdx
	movl	96(%rsp), %ecx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	cmpb	$-1, %al
	jne	.LBB1_846
	leaq	12600(%rsp), %rdi
	leaq	280(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	movl	$0, 16(%rsp)
	cmpq	$0, 12624(%rsp)
	jne	.LBB1_847
	cmpq	%r14, 12600(%rsp)
	jne	.LBB1_847
	cmpq	%r12, 12608(%rsp)
	jne	.LBB1_847
	cmpq	%rbp, 12616(%rsp)
	jne	.LBB1_847
	cmpq	%r15, 12632(%rsp)
	jne	.LBB1_847
	cmpq	%rbx, 12640(%rsp)
	jne	.LBB1_847
	cmpq	%r13, 12648(%rsp)
	jne	.LBB1_847
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	%eax, 16(%rsp)
	jmp	.LBB1_847
.LBB1_1546:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1547:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1547
.LBB1_1551:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1552:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1552
.LBB1_1947:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	cmpq	$3, 144(%rsp)
	ja	.LBB1_1981
	movq	144(%rsp), %rax
	shlq	$4, %rax
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.77(%rax), %rsi
	movq	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.77+8(%rax), %rdi
	addq	%rsi, %rdi
.LBB1_1949:
	movzbl	(%rsi), %ecx
	cmpb	$10, %cl
	jne	.LBB1_1955
	movl	$100000, %ecx
.LBB1_1951:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1958
	pause
	decl	%ecx
	jne	.LBB1_1951
	jmp	.LBB1_1953
.LBB1_1955:
	movl	$100000, %r8d
.LBB1_1956:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1963
	pause
	decl	%r8d
	jne	.LBB1_1956
	jmp	.LBB1_1720
.LBB1_1958:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB1_1959:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1964
	pause
	decl	%ecx
	jne	.LBB1_1959
	jmp	.LBB1_1961
.LBB1_1963:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB1_1965
.LBB1_1964:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB1_1965:
	incq	%rsi
	cmpq	%rdi, %rsi
	jne	.LBB1_1949
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB1_1967:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1973
	pause
	decl	%ecx
	jne	.LBB1_1967
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1970:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1970
.LBB1_1720:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB1_1721:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1721
.LBB1_1953:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB1_1954:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1954
.LBB1_1961:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB1_1962:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1962
.LBB1_1556:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1557:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1557
.LBB1_1971:
	movq	%r9, 136(%rsp)
.LBB1_1972:
	movl	$4, %esi
	movq	136(%rsp), %rdi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.LBB1_1973:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB1_1974:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB1_1978
	pause
	decl	%ecx
	jne	.LBB1_1974
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1977:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1977
.LBB1_1515:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1516:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1516
.LBB1_1520:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1521:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1521
.LBB1_1533:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1534:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1534
.LBB1_1978:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	xorl	%esi, %esi
	jmp	.LBB1_1410
.LBB1_1525:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1526:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1526
.LBB1_1538:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB1_1539:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB1_1539
.LBB1_1979:
	movq	88(%rsp), %rax
	movq	%rax, 136(%rsp)
	movl	$4, %esi
	movq	136(%rsp), %rdi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.LBB1_1980:
	leaq	280(%rsp), %rdi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	movl	%eax, 20(%rsp)
	jmp	.LBB1_212
.LBB1_1981:
	movq	144(%rsp), %rax
	movq	%rax, 136(%rsp)
	movl	$4, %esi
	movq	136(%rsp), %rdi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.Lfunc_end1:
	.size	_RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBE_, .Lfunc_end1-_RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBE_
	.cfi_endproc
	.section	.rodata._RINvCsjFdXuXHMTfk_9hm_kernel9run_testsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBE_,"a",@progbits
	.p2align	3, 0x0
.LJTI1_0:
	.quad	.LBB1_1134
	.quad	.LBB1_1148
	.quad	.LBB1_1157
	.quad	.LBB1_1134

	.section	.text._RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8contractNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_,"ax",@progbits
	.prefalign	4, .Lfunc_end2, nop
	.type	_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8contractNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_,@function
_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8contractNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_:
.Lfunc_begin2:
	.cfi_startproc
	subq	$72, %rsp
	.cfi_def_cfa_offset 80
	movb	$0, 24(%rsp)
	movq	$1, (%rsp)
	movq	$2, 8(%rsp)
	movq	$3, 16(%rsp)
	movb	$0, 40(%rsp)
	movq	$17, 32(%rsp)
	xorl	%ecx, %ecx
	movb	$1, %dl
	xorl	%eax, %eax
	lock		cmpxchgb	%dl, 24(%rsp)
	jne	.LBB2_16
	movq	$29, 8(%rsp)
	xorl	%eax, %eax
	lock		cmpxchgb	%dl, 24(%rsp)
	jne	.LBB2_2
	movb	$0, 24(%rsp)
	jmp	.LBB2_18
.LBB2_2:
	movb	$1, %cl
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 40(%rsp)
	jne	.LBB2_18
	movq	$18, 32(%rsp)
	movq	%rsp, %rdi
	movl	$24, %edx
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.62, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	movb	$0, 40(%rsp)
	testl	%eax, %eax
	jne	.LBB2_18
	movb	$1, %cl
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 24(%rsp)
	movb	$0, 24(%rsp)
	je	.LBB2_18
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 24(%rsp)
	je	.LBB2_9
	movl	$1, %ecx
	movq	$-1, %rdx
	movb	$1, %sil
	.p2align	4
.LBB2_7:
	incq	%rcx
	cmoveq	%rdx, %rcx
	xorl	%eax, %eax
	lock		cmpxchgb	%sil, 24(%rsp)
	jne	.LBB2_7
	cmpq	$1, %rcx
	jne	.LBB2_18
.LBB2_9:
	movq	%rsp, %rdi
	movl	$24, %edx
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.62, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	jne	.LBB2_18
	movq	$41, 16(%rsp)
	movb	$0, 24(%rsp)
	movb	$1, %cl
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 24(%rsp)
	je	.LBB2_14
	movl	$1, %edx
	movq	$-1, %rsi
.LBB2_12:
	incq	%rdx
	cmoveq	%rsi, %rdx
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 24(%rsp)
	jne	.LBB2_12
	cmpq	$1, %rdx
	jne	.LBB2_18
.LBB2_14:
	movq	%rsp, %rdi
	movl	$24, %edx
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.63, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	je	.LBB2_15
.LBB2_18:
	movb	$0, 24(%rsp)
	xorl	%ecx, %ecx
.LBB2_16:
	movl	%ecx, %eax
	addq	$72, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB2_15:
	.cfi_def_cfa_offset 80
	movb	$0, 24(%rsp)
	movq	$53, (%rsp)
	movq	8(%rsp), %rax
	movq	16(%rsp), %rcx
	movq	%rcx, 64(%rsp)
	movq	%rax, 56(%rsp)
	movq	$53, 48(%rsp)
	leaq	48(%rsp), %rdi
	movl	$24, %edx
	movq	$.Lanon.f00a327e9c5915a84331ee2e2076b7b8.64, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	sete	%cl
	movl	%ecx, %eax
	addq	$72, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8contractNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_, .Lfunc_end2-_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8contractNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_
	.cfi_endproc

	.section	.text._RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8lifetimeNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_,"ax",@progbits
	.prefalign	4, .Lfunc_end3, nop
	.type	_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8lifetimeNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_,@function
_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8lifetimeNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_:
.Lfunc_begin3:
	.cfi_startproc
	subq	$80, %rsp
	.cfi_def_cfa_offset 88
	movq	$0, (%rsp)
	movb	$0, 24(%rsp)
	movq	%rsp, %rdx
	movq	%rdx, 8(%rsp)
	movq	$17, 16(%rsp)
	xorl	%ecx, %ecx
	movb	$1, %sil
	xorl	%eax, %eax
	lock		cmpxchgb	%sil, 24(%rsp)
	jne	.LBB3_15
	cmpq	$0, (%rsp)
	je	.LBB3_2
.LBB3_18:
	movb	$0, 24(%rsp)
	xorl	%ecx, %ecx
.LBB3_15:
	movl	%ecx, %eax
	addq	$80, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB3_2:
	.cfi_def_cfa_offset 88
	movq	$18, 16(%rsp)
	movb	$0, 24(%rsp)
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	lock		cmpxchgb	%sil, 24(%rsp)
	jne	.LBB3_15
	cmpq	$0, (%rsp)
	jne	.LBB3_18
	movq	$19, 16(%rsp)
	movb	$0, 24(%rsp)
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	lock		cmpxchgb	%sil, 24(%rsp)
	jne	.LBB3_15
	cmpq	$0, (%rsp)
	jne	.LBB3_18
	movq	$20, 16(%rsp)
	movb	$0, 24(%rsp)
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	lock		cmpxchgb	%sil, 24(%rsp)
	jne	.LBB3_15
	cmpq	$0, (%rsp)
	jne	.LBB3_18
	movq	$21, 16(%rsp)
	movb	$0, 24(%rsp)
	movq	$1, (%rsp)
	movb	$0, 48(%rsp)
	movq	%rdx, 32(%rsp)
	movq	$31, 40(%rsp)
	movb	$1, %cl
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 48(%rsp)
	jne	.LBB3_17
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 48(%rsp)
	jne	.LBB3_10
.LBB3_16:
	movb	$0, 48(%rsp)
	jmp	.LBB3_17
.LBB3_10:
	cmpq	$1, (%rsp)
	jne	.LBB3_17
	movq	$43, 40(%rsp)
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 48(%rsp)
	je	.LBB3_16
	cmpq	$1, (%rsp)
	jne	.LBB3_17
	movq	$2, (%rsp)
	movb	$0, 72(%rsp)
	movq	%rdx, 56(%rsp)
	movq	$59, 64(%rsp)
	xorl	%eax, %eax
	lock		cmpxchgb	%cl, 72(%rsp)
	jne	.LBB3_17
	movb	$0, 72(%rsp)
	cmpq	$2, (%rsp)
	sete	%cl
	movl	%ecx, %eax
	addq	$80, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB3_17:
	.cfi_def_cfa_offset 88
	xorl	%ecx, %ecx
	movl	%ecx, %eax
	addq	$80, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8lifetimeNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_, .Lfunc_end3-_RINvNtCsjFdXuXHMTfk_9hm_kernel11mutex_tests8lifetimeNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_
	.cfi_endproc

	.section	.text._RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch11run_commandNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBY_,"ax",@progbits
	.prefalign	4, .Lfunc_end4, nop
	.type	_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch11run_commandNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBY_,@function
_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch11run_commandNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBY_:
.Lfunc_begin4:
	.cfi_startproc
	testq	%rsi, %rsi
	je	.LBB4_1
	xorl	%eax, %eax
	movabsq	$4294981120, %rcx
	.p2align	4
.LBB4_22:
	cmpq	%rax, %rsi
	je	.LBB4_25
	movzbl	(%rdi,%rax), %edx
	incq	%rax
	cmpq	$32, %rdx
	ja	.LBB4_22
	btq	%rdx, %rcx
	jae	.LBB4_22
.LBB4_1:
	xorl	%esi, %esi
.LBB4_2:
	cmpq	$26, %rsi
	jne	.LBB4_3
	movl	$100000, %ecx
	.p2align	4
.LBB4_10:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB4_14
	pause
	decl	%ecx
	jne	.LBB4_10
	jmp	.LBB4_12
	.p2align	4
.LBB4_3:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.66(%rsi), %ecx
	movl	$100000, %edi
	.p2align	4
.LBB4_4:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB4_8
	pause
	decl	%edi
	jne	.LBB4_4
	jmp	.LBB4_6
	.p2align	4
.LBB4_14:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	.p2align	4
.LBB4_15:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB4_19
	pause
	decl	%ecx
	jne	.LBB4_15
	jmp	.LBB4_17
	.p2align	4
.LBB4_8:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rsi
	cmpq	$27, %rsi
	jne	.LBB4_2
	jmp	.LBB4_45
.LBB4_19:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rsi
	cmpq	$27, %rsi
	jne	.LBB4_2
.LBB4_45:
	retq
.LBB4_6:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB4_7:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB4_7
.LBB4_12:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB4_13:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB4_13
.LBB4_17:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB4_18:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB4_18
.LBB4_25:
	xorl	%esi, %esi
.LBB4_26:
	cmpq	$49, %rsi
	jne	.LBB4_27
	movl	$100000, %ecx
	.p2align	4
.LBB4_34:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB4_38
	pause
	decl	%ecx
	jne	.LBB4_34
	jmp	.LBB4_36
.LBB4_27:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.65(%rsi), %ecx
	movl	$100000, %edi
	.p2align	4
.LBB4_28:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB4_32
	pause
	decl	%edi
	jne	.LBB4_28
	jmp	.LBB4_30
.LBB4_38:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	.p2align	4
.LBB4_39:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB4_43
	pause
	decl	%ecx
	jne	.LBB4_39
	jmp	.LBB4_41
.LBB4_32:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rsi
	cmpq	$50, %rsi
	jne	.LBB4_26
	jmp	.LBB4_45
.LBB4_43:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rsi
	cmpq	$50, %rsi
	jne	.LBB4_26
	jmp	.LBB4_45
.LBB4_36:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB4_37:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB4_37
.LBB4_30:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB4_31:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB4_31
.LBB4_41:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB4_42:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB4_42
.Lfunc_end4:
	.size	_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch11run_commandNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBY_, .Lfunc_end4-_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch11run_commandNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBY_
	.cfi_endproc

	.section	.text._RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch13report_statusNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEB10_,"ax",@progbits
	.prefalign	4, .Lfunc_end5, nop
	.type	_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch13report_statusNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEB10_,@function
_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch13report_statusNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEB10_:
.Lfunc_begin5:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	$100000, %ecx
	movw	$1021, %dx
	.p2align	4
.LBB5_1:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_3
	pause
	decl	%ecx
	jne	.LBB5_1
	jmp	.LBB5_43
.LBB5_3:
	movw	$1016, %dx
	movb	$78, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
	.p2align	4
.LBB5_4:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_5
	pause
	decl	%ecx
	jne	.LBB5_4
	jmp	.LBB5_43
.LBB5_5:
	movw	$1016, %dx
	movb	$97, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
	.p2align	4
.LBB5_6:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_7
	pause
	decl	%ecx
	jne	.LBB5_6
	jmp	.LBB5_43
.LBB5_7:
	movw	$1016, %dx
	movb	$116, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
	.p2align	4
.LBB5_8:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_9
	pause
	decl	%ecx
	jne	.LBB5_8
	jmp	.LBB5_43
.LBB5_9:
	movw	$1016, %dx
	movb	$105, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
	.p2align	4
.LBB5_10:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_11
	pause
	decl	%ecx
	jne	.LBB5_10
	jmp	.LBB5_43
.LBB5_11:
	movw	$1016, %dx
	movb	$118, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
	.p2align	4
.LBB5_12:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_13
	pause
	decl	%ecx
	jne	.LBB5_12
	jmp	.LBB5_43
.LBB5_13:
	movw	$1016, %dx
	movb	$101, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
	.p2align	4
.LBB5_14:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_15
	pause
	decl	%ecx
	jne	.LBB5_14
	jmp	.LBB5_43
.LBB5_15:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_16:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_17
	pause
	decl	%ecx
	jne	.LBB5_16
	jmp	.LBB5_43
.LBB5_17:
	movw	$1016, %dx
	movb	$108, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_18:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_19
	pause
	decl	%ecx
	jne	.LBB5_18
	jmp	.LBB5_43
.LBB5_19:
	movw	$1016, %dx
	movb	$97, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_20:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_21
	pause
	decl	%ecx
	jne	.LBB5_20
	jmp	.LBB5_43
.LBB5_21:
	movw	$1016, %dx
	movb	$117, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_22:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_23
	pause
	decl	%ecx
	jne	.LBB5_22
	jmp	.LBB5_43
.LBB5_23:
	movw	$1016, %dx
	movb	$110, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_24:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_25
	pause
	decl	%ecx
	jne	.LBB5_24
	jmp	.LBB5_43
.LBB5_25:
	movw	$1016, %dx
	movb	$99, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_26:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_27
	pause
	decl	%ecx
	jne	.LBB5_26
	jmp	.LBB5_43
.LBB5_27:
	movw	$1016, %dx
	movb	$104, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_28:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_29
	pause
	decl	%ecx
	jne	.LBB5_28
	jmp	.LBB5_43
.LBB5_29:
	movw	$1016, %dx
	movb	$101, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_30:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_31
	pause
	decl	%ecx
	jne	.LBB5_30
	jmp	.LBB5_43
.LBB5_31:
	movw	$1016, %dx
	movb	$114, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_32:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_33
	pause
	decl	%ecx
	jne	.LBB5_32
	jmp	.LBB5_43
.LBB5_33:
	movw	$1016, %dx
	movb	$58, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_34:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_35
	pause
	decl	%ecx
	jne	.LBB5_34
.LBB5_43:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB5_44:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_44
.LBB5_35:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	xorl	%esi, %esi
.LBB5_36:
	cmpq	$11, %rsi
	jne	.LBB5_37
	movl	$100000, %ecx
.LBB5_47:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_51
	pause
	decl	%ecx
	jne	.LBB5_47
	jmp	.LBB5_49
.LBB5_37:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.68(%rsi), %ecx
	movl	$100000, %edi
.LBB5_38:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_45
	pause
	decl	%edi
	jne	.LBB5_38
	jmp	.LBB5_40
.LBB5_51:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB5_52:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_56
	pause
	decl	%ecx
	jne	.LBB5_52
	jmp	.LBB5_54
.LBB5_45:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB5_57
.LBB5_56:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB5_57:
	incq	%rsi
	cmpq	$12, %rsi
	jne	.LBB5_36
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_59:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_61
	pause
	decl	%ecx
	jne	.LBB5_59
	jmp	.LBB5_99
.LBB5_49:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_50:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_50
.LBB5_40:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_41:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_41
.LBB5_54:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_55:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_55
.LBB5_61:
	movw	$1016, %dx
	movb	$78, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_62:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_63
	pause
	decl	%ecx
	jne	.LBB5_62
	jmp	.LBB5_99
.LBB5_63:
	movw	$1016, %dx
	movb	$97, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_64:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_65
	pause
	decl	%ecx
	jne	.LBB5_64
	jmp	.LBB5_99
.LBB5_65:
	movw	$1016, %dx
	movb	$116, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_66:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_67
	pause
	decl	%ecx
	jne	.LBB5_66
	jmp	.LBB5_99
.LBB5_67:
	movw	$1016, %dx
	movb	$105, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_68:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_69
	pause
	decl	%ecx
	jne	.LBB5_68
	jmp	.LBB5_99
.LBB5_69:
	movw	$1016, %dx
	movb	$118, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_70:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_71
	pause
	decl	%ecx
	jne	.LBB5_70
	jmp	.LBB5_99
.LBB5_71:
	movw	$1016, %dx
	movb	$101, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_72:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_73
	pause
	decl	%ecx
	jne	.LBB5_72
	jmp	.LBB5_99
.LBB5_73:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_74:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_75
	pause
	decl	%ecx
	jne	.LBB5_74
	jmp	.LBB5_99
.LBB5_75:
	movw	$1016, %dx
	movb	$108, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_76:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_77
	pause
	decl	%ecx
	jne	.LBB5_76
	jmp	.LBB5_99
.LBB5_77:
	movw	$1016, %dx
	movb	$97, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_78:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_79
	pause
	decl	%ecx
	jne	.LBB5_78
	jmp	.LBB5_99
.LBB5_79:
	movw	$1016, %dx
	movb	$117, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_80:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_81
	pause
	decl	%ecx
	jne	.LBB5_80
	jmp	.LBB5_99
.LBB5_81:
	movw	$1016, %dx
	movb	$110, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_82:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_83
	pause
	decl	%ecx
	jne	.LBB5_82
	jmp	.LBB5_99
.LBB5_83:
	movw	$1016, %dx
	movb	$99, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_84:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_85
	pause
	decl	%ecx
	jne	.LBB5_84
	jmp	.LBB5_99
.LBB5_85:
	movw	$1016, %dx
	movb	$104, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_86:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_87
	pause
	decl	%ecx
	jne	.LBB5_86
	jmp	.LBB5_99
.LBB5_87:
	movw	$1016, %dx
	movb	$101, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_88:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_89
	pause
	decl	%ecx
	jne	.LBB5_88
	jmp	.LBB5_99
.LBB5_89:
	movw	$1016, %dx
	movb	$115, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_90:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_91
	pause
	decl	%ecx
	jne	.LBB5_90
	jmp	.LBB5_99
.LBB5_91:
	movw	$1016, %dx
	movb	$58, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_92:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_93
	pause
	decl	%ecx
	jne	.LBB5_92
.LBB5_99:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_100:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_100
.LBB5_93:
	movw	$1016, %dx
	movb	$32, %al
	#APP

	outb	%al, %dx

	#NO_APP
	callq	_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch6numberNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_94:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_101
	pause
	decl	%ecx
	jne	.LBB5_94
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_97:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_97
.LBB5_101:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_102:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_106
	pause
	decl	%ecx
	jne	.LBB5_102
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_105:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_105
.LBB5_106:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	xorl	%esi, %esi
.LBB5_107:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.70(%rsi), %ecx
	incq	%rsi
	movl	$100000, %edi
.LBB5_108:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_112
	pause
	decl	%edi
	jne	.LBB5_108
	jmp	.LBB5_110
.LBB5_112:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	cmpq	$26, %rsi
	jne	.LBB5_107
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_114:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_116
	pause
	decl	%ecx
	jne	.LBB5_114
	jmp	.LBB5_125
.LBB5_110:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_111:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_111
.LBB5_116:
	movw	$1016, %dx
	movb	$110, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_117:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_119
	pause
	decl	%ecx
	jne	.LBB5_117
	jmp	.LBB5_125
.LBB5_119:
	movw	$1016, %dx
	movb	$111, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_120:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_122
	pause
	decl	%ecx
	jne	.LBB5_120
	jmp	.LBB5_125
.LBB5_122:
	movw	$1016, %dx
	movb	$110, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_123:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_127
	pause
	decl	%ecx
	jne	.LBB5_123
.LBB5_125:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_126:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_126
.LBB5_127:
	movw	$1016, %dx
	movb	$101, %al
	#APP

	outb	%al, %dx

	#NO_APP
	xorl	%esi, %esi
.LBB5_128:
	testq	%rsi, %rsi
	je	.LBB5_135
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.71(%rsi), %ecx
	movl	$100000, %edi
.LBB5_130:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_134
	pause
	decl	%edi
	jne	.LBB5_130
	jmp	.LBB5_132
.LBB5_135:
	movl	$100000, %ecx
.LBB5_136:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_140
	pause
	decl	%ecx
	jne	.LBB5_136
	jmp	.LBB5_138
.LBB5_134:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	jmp	.LBB5_146
.LBB5_140:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
.LBB5_141:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_145
	pause
	decl	%ecx
	jne	.LBB5_141
	jmp	.LBB5_143
.LBB5_145:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
.LBB5_146:
	incq	%rsi
	cmpq	$14, %rsi
	jne	.LBB5_128
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_148:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_150
	pause
	decl	%ecx
	jne	.LBB5_148
	jmp	.LBB5_180
.LBB5_132:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_133:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_133
.LBB5_138:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_139:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_139
.LBB5_143:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_144:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_144
.LBB5_150:
	movw	$1016, %dx
	movb	$117, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_151:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_153
	pause
	decl	%ecx
	jne	.LBB5_151
	jmp	.LBB5_180
.LBB5_153:
	movw	$1016, %dx
	movb	$110, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_154:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_156
	pause
	decl	%ecx
	jne	.LBB5_154
	jmp	.LBB5_180
.LBB5_156:
	movw	$1016, %dx
	movb	$97, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_157:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_159
	pause
	decl	%ecx
	jne	.LBB5_157
	jmp	.LBB5_180
.LBB5_159:
	movw	$1016, %dx
	movb	$118, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_160:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_162
	pause
	decl	%ecx
	jne	.LBB5_160
	jmp	.LBB5_180
.LBB5_162:
	movw	$1016, %dx
	movb	$97, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_163:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_165
	pause
	decl	%ecx
	jne	.LBB5_163
	jmp	.LBB5_180
.LBB5_165:
	movw	$1016, %dx
	movb	$105, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_166:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_168
	pause
	decl	%ecx
	jne	.LBB5_166
	jmp	.LBB5_180
.LBB5_168:
	movw	$1016, %dx
	movb	$108, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_169:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_171
	pause
	decl	%ecx
	jne	.LBB5_169
	jmp	.LBB5_180
.LBB5_171:
	movw	$1016, %dx
	movb	$97, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_172:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_174
	pause
	decl	%ecx
	jne	.LBB5_172
	jmp	.LBB5_180
.LBB5_174:
	movw	$1016, %dx
	movb	$98, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_175:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_177
	pause
	decl	%ecx
	jne	.LBB5_175
	jmp	.LBB5_180
.LBB5_177:
	movw	$1016, %dx
	movb	$108, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_178:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_182
	pause
	decl	%ecx
	jne	.LBB5_178
.LBB5_180:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_181:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_181
.LBB5_182:
	movw	$1016, %dx
	movb	$101, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_183:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_187
	pause
	decl	%ecx
	jne	.LBB5_183
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_186:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_186
.LBB5_187:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	movw	$1021, %dx
.LBB5_188:
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB5_192
	pause
	decl	%ecx
	jne	.LBB5_188
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
.LBB5_191:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB5_191
.LBB5_192:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end5:
	.size	_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch13report_statusNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEB10_, .Lfunc_end5-_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch13report_statusNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEB10_
	.cfi_endproc

	.section	.text._RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch6numberNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_,"ax",@progbits
	.prefalign	4, .Lfunc_end6, nop
	.type	_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch6numberNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_,@function
_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch6numberNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_:
.Lfunc_begin6:
	.cfi_startproc
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	leaq	27(%rsp), %rsi
	movabsq	$3472328296227680304, %rax
	movq	%rax, 16(%rsp)
	movq	%rax, 8(%rsp)
	movl	$808464432, 24(%rsp)
	leaq	32(%rsp), %rdi
	movl	$1, %edx
	callq	_RNvNtNtCs1R9DcZHJAgT_4core3str8converts9from_utf8
	cmpb	$0, 32(%rsp)
	jne	.LBB6_22
	movq	48(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB6_22
	movq	40(%rsp), %rdi
	addq	%rdi, %rsi
.LBB6_3:
	movzbl	(%rdi), %ecx
	cmpb	$10, %cl
	jne	.LBB6_4
	movl	$100000, %ecx
	.p2align	4
.LBB6_11:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB6_15
	pause
	decl	%ecx
	jne	.LBB6_11
	jmp	.LBB6_13
	.p2align	4
.LBB6_4:
	movl	$100000, %r8d
	.p2align	4
.LBB6_5:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB6_9
	pause
	decl	%r8d
	jne	.LBB6_5
	jmp	.LBB6_7
.LBB6_15:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	.p2align	4
.LBB6_16:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB6_20
	pause
	decl	%ecx
	jne	.LBB6_16
	jmp	.LBB6_18
.LBB6_9:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rdi
	cmpq	%rsi, %rdi
	jne	.LBB6_3
	jmp	.LBB6_22
.LBB6_20:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rdi
	cmpq	%rsi, %rdi
	jne	.LBB6_3
.LBB6_22:
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB6_13:
	.cfi_def_cfa_offset 64
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB6_14:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB6_14
.LBB6_7:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB6_8:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB6_8
.LBB6_18:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB6_19:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB6_19
.Lfunc_end6:
	.size	_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch6numberNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_, .Lfunc_end6-_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch6numberNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBS_
	.cfi_endproc

	.section	.text._RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch9list_appsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBV_,"ax",@progbits
	.prefalign	4, .Lfunc_end7, nop
	.type	_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch9list_appsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBV_,@function
_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch9list_appsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBV_:
.Lfunc_begin7:
	.cfi_startproc
	xorl	%esi, %esi
.LBB7_1:
	cmpq	$49, %rsi
	jne	.LBB7_2
	movl	$100000, %ecx
	.p2align	4
.LBB7_9:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB7_13
	pause
	decl	%ecx
	jne	.LBB7_9
	jmp	.LBB7_11
	.p2align	4
.LBB7_2:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.65(%rsi), %ecx
	movl	$100000, %edi
	.p2align	4
.LBB7_3:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB7_7
	pause
	decl	%edi
	jne	.LBB7_3
	jmp	.LBB7_5
	.p2align	4
.LBB7_13:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	.p2align	4
.LBB7_14:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB7_18
	pause
	decl	%ecx
	jne	.LBB7_14
	jmp	.LBB7_16
	.p2align	4
.LBB7_7:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rsi
	cmpq	$50, %rsi
	jne	.LBB7_1
	jmp	.LBB7_20
.LBB7_18:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rsi
	cmpq	$50, %rsi
	jne	.LBB7_1
.LBB7_20:
	retq
.LBB7_5:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB7_6:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB7_6
.LBB7_11:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB7_12:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB7_12
.LBB7_16:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB7_17:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB7_17
.Lfunc_end7:
	.size	_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch9list_appsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBV_, .Lfunc_end7-_RINvNtCsjFdXuXHMTfk_9hm_kernel13native_launch9list_appsNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBV_
	.cfi_endproc

	.section	.text._RNvCs7n9xbH47f0w_8hematite9boot_main,"ax",@progbits
	.prefalign	4, .Lfunc_end8, nop
	.type	_RNvCs7n9xbH47f0w_8hematite9boot_main,@function
_RNvCs7n9xbH47f0w_8hematite9boot_main:
.Lfunc_begin8:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movw	$1017, %dx
	xorl	%eax, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$1019, %dx
	movb	$-128, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$1016, %dx
	movb	$1, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$1017, %dx
	xorl	%eax, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$1019, %dx
	movb	$3, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$1018, %dx
	movb	$-57, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movw	$1020, %dx
	movb	$3, %al
	#APP

	outb	%al, %dx

	#NO_APP
	callq	_RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform5write
	callq	_RINvCsjFdXuXHMTfk_9hm_kernel11run_monitorNtNtCs7n9xbH47f0w_8hematite4arch12BootPlatformEBH_
.Lfunc_end8:
	.size	_RNvCs7n9xbH47f0w_8hematite9boot_main, .Lfunc_end8-_RNvCs7n9xbH47f0w_8hematite9boot_main
	.cfi_endproc

	.section	.text._RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform5write,"ax",@progbits
	.prefalign	4, .Lfunc_end9, nop
	.type	_RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform5write,@function
_RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform5write:
.Lfunc_begin9:
	.cfi_startproc
	xorl	%esi, %esi
.LBB9_1:
	cmpq	$44, %rsi
	jne	.LBB9_2
	movl	$100000, %ecx
	.p2align	4
.LBB9_9:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB9_13
	pause
	decl	%ecx
	jne	.LBB9_9
	jmp	.LBB9_11
	.p2align	4
.LBB9_2:
	movzbl	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.80(%rsi), %ecx
	movl	$100000, %edi
	.p2align	4
.LBB9_3:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB9_7
	pause
	decl	%edi
	jne	.LBB9_3
	jmp	.LBB9_5
	.p2align	4
.LBB9_13:
	movw	$1016, %dx
	movb	$13, %al
	#APP

	outb	%al, %dx

	#NO_APP
	movl	$100000, %ecx
	.p2align	4
.LBB9_14:
	movw	$1021, %dx
	#APP

	inb	%dx, %al

	#NO_APP
	testb	$32, %al
	jne	.LBB9_18
	pause
	decl	%ecx
	jne	.LBB9_14
	jmp	.LBB9_16
	.p2align	4
.LBB9_7:
	movw	$1016, %dx
	movl	%ecx, %eax
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rsi
	cmpq	$45, %rsi
	jne	.LBB9_1
	jmp	.LBB9_20
.LBB9_18:
	movw	$1016, %dx
	movb	$10, %al
	#APP

	outb	%al, %dx

	#NO_APP
	incq	%rsi
	cmpq	$45, %rsi
	jne	.LBB9_1
.LBB9_20:
	retq
.LBB9_5:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB9_6:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB9_6
.LBB9_11:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB9_12:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB9_12
.LBB9_16:
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.p2align	4
.LBB9_17:
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB9_17
.Lfunc_end9:
	.size	_RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform5write, .Lfunc_end9-_RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform5write
	.cfi_endproc

	.section	.text._RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform6checks,"ax",@progbits
	.prefalign	4, .Lfunc_end10, nop
	.type	_RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform6checks,@function
_RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform6checks:
.Lfunc_begin10:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$16, %rsp
	.cfi_def_cfa_offset 72
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	#APP

	movq	%cr0, %rax

	#NO_APP
	movq	%rax, 8(%rsp)
	#APP

	movq	%cr3, %rsi

	#NO_APP
	#APP

	movq	%cr4, %rdi

	#NO_APP
	movl	$-1073741696, %ecx
	#APP

	rdmsr

	#NO_APP
	movq	$pml4, %rcx
	xorq	%rsi, %rcx
	movq	pml4(%rip), %rdx
	andq	$-97, %rdx
	movq	$pdpt+3, %r9
	xorq	%rdx, %r9
	movq	pdpt(%rip), %rdx
	andq	$-97, %rdx
	movq	$page_directory+3, %r10
	xorq	%rdx, %r10
	orq	%r9, %r10
	orq	%rcx, %r10
	sete	%r10b
	movl	$2, %edx
	movq	$-8, %r9
	.p2align	4
.LBB10_1:
	movq	pml4(%r9,%rdx,8), %rcx
	orq	pdpt(%r9,%rdx,8), %rcx
	sete	%cl
	andb	%r10b, %cl
	cmpq	$512, %rdx
	je	.LBB10_3
	movq	pml4(,%rdx,8), %r10
	orq	pdpt(,%rdx,8), %r10
	sete	%r10b
	andb	%r10b, %cl
	addq	$2, %rdx
	movl	%ecx, %r10d
	jmp	.LBB10_1
.LBB10_3:
	movq	%rsi, (%rsp)
	xorl	%edx, %edx
	xorl	%r9d, %r9d
	.p2align	4
.LBB10_4:
	movq	page_directory+64(,%r9,8), %r10
	movq	page_directory+72(,%r9,8), %r11
	orq	%r10, %r11
	movq	page_directory+80(,%r9,8), %r10
	orq	page_directory+88(,%r9,8), %r10
	movzbl	%cl, %ecx
	orq	%r11, %r10
	cmovnel	%edx, %ecx
	addq	$4, %r9
	cmpq	$504, %r9
	jne	.LBB10_4
	movq	page_directory(%rip), %r14
	movq	page_directory+8(%rip), %r15
	movq	page_directory+16(%rip), %r12
	movq	page_directory+24(%rip), %rbx
	movq	page_directory+32(%rip), %r11
	movq	page_directory+40(%rip), %r10
	movq	page_directory+48(%rip), %rdx
	movq	page_directory+56(%rip), %r13
	andq	$-97, %r13
	movq	$page_tables+28675, %r9
	xorq	%r13, %r9
	andq	$-97, %r14
	movq	$page_tables+3, %r13
	xorq	%r14, %r13
	andq	$-97, %r15
	movq	$page_tables+4099, %r14
	xorq	%r15, %r14
	orq	%r13, %r14
	andq	$-97, %r12
	movq	$page_tables+8195, %r15
	xorq	%r12, %r15
	andq	$-97, %rbx
	movq	$page_tables+12291, %r12
	xorq	%rbx, %r12
	orq	%r15, %r12
	orq	%r14, %r12
	andq	$-97, %r11
	movq	$page_tables+16387, %rbx
	xorq	%r11, %rbx
	andq	$-97, %r10
	movq	$page_tables+20483, %r11
	xorq	%r10, %r11
	orq	%rbx, %r11
	andq	$-97, %rdx
	movq	$page_tables+24579, %r10
	xorq	%rdx, %r10
	orq	%r11, %r10
	orq	page_tables(%rip), %r9
	orq	%r12, %r10
	movzbl	%cl, %ecx
	xorl	%edx, %edx
	orq	%r10, %r9
	cmovnel	%edx, %ecx
	movl	$1, %r9d
	movq	$page_tables+8, %r10
	movl	$4097, %r11d
	movq	$__stack_guard, %rbx
	movl	$3, %r14d
	movabsq	$-9223372036854775808, %r15
	jmp	.LBB10_6
	.p2align	4
.LBB10_13:
	andq	$-97, %r12
	cmpq	%rbp, %r12
.LBB10_14:
	sete	%bpl
	movzbl	%cl, %ecx
	testb	%bpl, %bpl
	cmovel	%edx, %ecx
	addq	$8, %r10
	addq	$4096, %r11
	incq	%r9
	cmpq	$16777217, %r11
	je	.LBB10_15
.LBB10_6:
	movq	%r11, %r13
	subq	%rbx, %r13
	movq	(%r10), %r12
	cmpq	$1, %r13
	jne	.LBB10_11
	testq	%r12, %r12
	jmp	.LBB10_14
	.p2align	4
.LBB10_11:
	leaq	-1(%r11), %r13
	cmpq	$__text_start, %r13
	setae	%r8b
	cmpq	$__text_end, %r13
	setb	%sil
	movq	%r11, %rbp
	testb	%sil, %r8b
	jne	.LBB10_13
	movq	%r9, %rsi
	shlq	$12, %rsi
	xorl	%r8d, %r8d
	cmpq	$__rodata_end, %r13
	setae	%r8b
	cmpq	$__rodata_start, %r13
	leaq	1(%r8,%r8), %rbp
	cmovbq	%r14, %rbp
	orq	%rsi, %rbp
	orq	%r15, %rbp
	jmp	.LBB10_13
.LBB10_15:
	movq	(%rsp), %rsi
	cmpq	$pml4, %rsi
	sete	%r9b
	movq	$__stack_guard, %rdx
	cmpq	$16777216, %rdx
	setb	%r10b
	testb	%r9b, %r10b
	je	.LBB10_16
	shrq	$12, %rdx
	cmpq	$0, page_tables(,%rdx,8)
	sete	%dl
	jmp	.LBB10_9
.LBB10_16:
	xorl	%edx, %edx
	movl	$0, %r9d
	cmpq	$pml4, %rsi
	jne	.LBB10_10
.LBB10_9:
	cmpq	$0, page_tables(%rip)
	sete	%r9b
.LBB10_10:
	movq	8(%rsp), %rsi
	shrl	$16, %esi
	movzbl	%r9b, %r8d
	shlq	$48, %r8
	movzbl	%dl, %edx
	shlq	$40, %rdx
	orq	%r8, %rdx
	movzbl	%cl, %ecx
	shlq	$32, %rcx
	orq	%rdx, %rcx
	movl	%edi, %edx
	andl	$2097152, %edx
	leaq	(%rcx,%rdx,8), %rcx
	shrl	$4, %edi
	andl	$65536, %edi
	orq	%rcx, %rdi
	shrl	$3, %eax
	andl	$256, %eax
	orq	%rdi, %rax
	andl	$1, %esi
	orq	%rax, %rsi
	movq	%rsi, %rax
	addq	$16, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end10:
	.size	_RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform6checks, .Lfunc_end10-_RNvXNtCs7n9xbH47f0w_8hematite4archNtB2_12BootPlatformNtCsjFdXuXHMTfk_9hm_kernel8Platform6checks
	.cfi_endproc

	.section	.text.unlikely._RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt,"ax",@progbits
	.prefalign	4, .Lfunc_end11, nop
	.type	_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt,@function
_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt:
.Lfunc_begin11:
	.cfi_startproc
	.file	1 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/panicking.rs"
	.loc	1 80 14 prologue_end
	movw	$244, %dx
	movl	$17, %eax
	#APP

	outl	%eax, %dx

	#NO_APP
	.loc	1 0 14 is_stmt 0
.Ltmp7:
	.p2align	4
.LBB11_1:
	.loc	1 80 14
	#APP

	cli
	hlt

	#NO_APP
	jmp	.LBB11_1
.Ltmp8:
.Lfunc_end11:
	.size	_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt, .Lfunc_end11-_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt
	.cfi_endproc

	.section	.text._RNvNtNtCs1R9DcZHJAgT_4core3str8converts9from_utf8,"ax",@progbits
	.prefalign	4, .Lfunc_end12, nop
	.type	_RNvNtNtCs1R9DcZHJAgT_4core3str8converts9from_utf8,@function
_RNvNtNtCs1R9DcZHJAgT_4core3str8converts9from_utf8:
.Lfunc_begin12:
	.file	2 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/str/converts.rs"
	.loc	2 89 0 is_stmt 1
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	xorl	%ecx, %ecx
.Ltmp9:
	.file	3 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/str/validations.rs"
	.loc	3 133 25 prologue_end
	movq	%rdx, %rax
	subq	$15, %rax
	cmovaeq	%rax, %rcx
.Ltmp10:
	.loc	3 145 11
	testq	%rdx, %rdx
	je	.LBB12_13
	.loc	3 0 11 is_stmt 0
	leaq	7(%rsi), %r8
	andq	$-8, %r8
	subq	%rsi, %r8
	xorl	%eax, %eax
	movabsq	$-9187201950435737472, %r10
	jmp	.LBB12_4
	.p2align	4
.LBB12_2:
.Ltmp11:
	.loc	3 217 13 is_stmt 1
	incq	%rbx
	movq	%rbx, %rax
.Ltmp12:
.LBB12_3:
	.loc	3 145 11
	cmpq	%rdx, %rax
	jae	.LBB12_13
.LBB12_4:
.Ltmp13:
	.loc	3 164 21
	movzbl	(%rsi,%rax), %r11d
.Ltmp14:
	.loc	3 165 12
	testb	%r11b, %r11b
	js	.LBB12_14
.Ltmp15:
	.file	4 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/num/uint_macros.rs"
	.loc	4 2689 13
	movl	%r8d, %r9d
	subl	%eax, %r9d
.Ltmp16:
	.loc	4 3875 22
	testb	$7, %r9b
.Ltmp17:
	.loc	3 222 39
	je	.LBB12_8
	.loc	3 245 17
	incq	%rax
	jmp	.LBB12_3
	.loc	3 0 17 is_stmt 0
.Ltmp18:
	.p2align	4
.LBB12_7:
.Ltmp19:
	.loc	3 238 21 is_stmt 1
	addq	$16, %rax
.LBB12_8:
	.loc	3 224 23
	cmpq	%rcx, %rax
	jae	.LBB12_10
.Ltmp20:
	.loc	3 233 52
	movq	8(%rsi,%rax), %r9
.Ltmp21:
	.loc	3 234 28
	orq	(%rsi,%rax), %r9
	testq	%r10, %r9
	je	.LBB12_7
.Ltmp22:
.LBB12_10:
	.loc	3 241 23
	cmpq	%rdx, %rax
	jae	.LBB12_3
	.loc	3 0 23 is_stmt 0
.Ltmp23:
	.p2align	4
.LBB12_11:
	.loc	3 241 38
	cmpb	$0, (%rsi,%rax)
	js	.LBB12_3
	.loc	3 242 21 is_stmt 1
	incq	%rax
	.loc	3 241 23
	cmpq	%rax, %rdx
	jne	.LBB12_11
	jmp	.LBB12_13
.Ltmp24:
	.loc	3 0 23 is_stmt 0
.Ltmp25:
	.p2align	4
.LBB12_14:
	.loc	3 279 5 is_stmt 1
	movzbl	.Lanon.5e724348160a06631d781e4ccdca078c.197(%r11), %ebx
	movb	$1, %r9b
	cmpl	$4, %ebx
.Ltmp26:
	.loc	3 185 13
	je	.LBB12_23
	cmpl	$3, %ebx
	je	.LBB12_19
	cmpl	$2, %ebx
	jne	.LBB12_44
	.loc	3 155 17
	leaq	1(%rax), %rbx
	.loc	3 157 20
	cmpq	%rdx, %rbx
	jae	.LBB12_41
	.loc	3 187 24
	cmpb	$-65, (%rsi,%rbx)
	movb	$1, %r11b
	jle	.LBB12_2
	jmp	.LBB12_42
.LBB12_19:
	.loc	3 155 17
	leaq	1(%rax), %rbx
	.loc	3 157 20
	cmpq	%rdx, %rbx
	jae	.LBB12_41
	.loc	3 160 17
	movzbl	(%rsi,%rbx), %ebx
	.loc	3 192 21
	cmpl	$224, %r11d
	je	.LBB12_43
	cmpl	$237, %r11d
	jne	.LBB12_27
	.loc	3 195 34
	cmpb	$-97, %bl
	jle	.LBB12_38
	jmp	.LBB12_44
.LBB12_23:
	.loc	3 155 17
	leaq	1(%rax), %rbx
	.loc	3 157 20
	cmpq	%rdx, %rbx
	jae	.LBB12_41
	.loc	3 160 17
	movzbl	(%rsi,%rbx), %ebx
	.loc	3 204 21
	cmpq	$240, %r11
	je	.LBB12_45
	cmpl	$244, %r11d
	jne	.LBB12_29
	.loc	3 205 83
	cmpb	$-113, %bl
	jle	.LBB12_31
	jmp	.LBB12_44
.LBB12_43:
	.loc	3 193 32
	andb	$-32, %bl
	cmpb	$-96, %bl
	je	.LBB12_38
	jmp	.LBB12_44
.LBB12_45:
	.loc	3 205 32
	addb	$112, %bl
	cmpb	$48, %bl
	jb	.LBB12_31
	jmp	.LBB12_44
.LBB12_27:
	.loc	3 194 28
	leal	31(%r11), %r14d
	cmpb	$12, %r14b
	jb	.LBB12_37
	.loc	3 196 28
	andb	$-2, %r11b
	cmpb	$-18, %r11b
	jne	.LBB12_44
.LBB12_37:
	.loc	3 0 0 is_stmt 0
	cmpb	$-64, %bl
	jge	.LBB12_44
.LBB12_38:
	.loc	3 155 17 is_stmt 1
	leaq	2(%rax), %rbx
	.loc	3 157 20
	cmpq	%rdx, %rbx
	jae	.LBB12_41
	.loc	3 199 24
	cmpb	$-65, (%rsi,%rbx)
	jle	.LBB12_2
	jmp	.LBB12_40
.LBB12_29:
	.loc	3 205 48
	addl	$15, %r11d
	cmpb	$2, %r11b
	ja	.LBB12_44
	cmpb	$-64, %bl
	jge	.LBB12_44
.LBB12_31:
	.loc	3 155 17
	leaq	2(%rax), %r11
	.loc	3 157 20
	cmpq	%rdx, %r11
	jae	.LBB12_41
	.loc	3 208 24
	cmpb	$-65, (%rsi,%r11)
	jg	.LBB12_40
	.loc	3 155 17
	leaq	3(%rax), %rbx
	.loc	3 157 20
	cmpq	%rdx, %rbx
	jae	.LBB12_41
	.loc	3 211 24
	cmpb	$-64, (%rsi,%rbx)
	jl	.LBB12_2
.Ltmp27:
	.loc	3 0 24 is_stmt 0
	movb	$3, %r11b
	jmp	.LBB12_42
.LBB12_13:
	.loc	2 94 13 is_stmt 1
	movq	%rsi, 8(%rdi)
	movq	%rdx, 16(%rdi)
	xorl	%eax, %eax
	.loc	2 0 0 is_stmt 0
	movq	%rax, (%rdi)
	.loc	2 98 2 epilogue_begin is_stmt 1
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB12_41:
	.cfi_def_cfa_offset 24
	.loc	2 0 2 is_stmt 0
	xorl	%r9d, %r9d
	jmp	.LBB12_42
.LBB12_44:
	movb	$1, %r11b
.Ltmp28:
	.loc	3 194 41 is_stmt 1
	jmp	.LBB12_42
.Ltmp29:
.LBB12_40:
	.loc	3 0 41 is_stmt 0
	movb	$2, %r11b
.LBB12_42:
.Ltmp30:
	.loc	2 96 21 is_stmt 1
	movq	%rax, 8(%rdi)
	movb	%r9b, 16(%rdi)
	movb	%r11b, 17(%rdi)
	movl	$1, %eax
.Ltmp31:
	.loc	2 0 0 is_stmt 0
	movq	%rax, (%rdi)
	.loc	2 98 2 epilogue_begin is_stmt 1
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Ltmp32:
.Lfunc_end12:
	.size	_RNvNtNtCs1R9DcZHJAgT_4core3str8converts9from_utf8, .Lfunc_end12-_RNvNtNtCs1R9DcZHJAgT_4core3str8converts9from_utf8
	.cfi_endproc

	.section	.text.unlikely._RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail,"ax",@progbits
	.prefalign	4, .Lfunc_end13, nop
	.type	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail,@function
_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail:
.Lfunc_begin13:
	.file	5 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/slice/index.rs"
	.loc	5 39 0
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
.Ltmp33:
	.file	6 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/panic.rs"
	.loc	6 177 9 prologue_end
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt
.Ltmp34:
.Lfunc_end13:
	.size	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail, .Lfunc_end13-_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
	.cfi_endproc

	.section	.text.unlikely._RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check,"ax",@progbits
	.type	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check,@function
_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check:
.Lfunc_begin14:
	.loc	1 266 0
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
.Ltmp35:
	.loc	1 271 5 prologue_end
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt
.Ltmp36:
.Lfunc_end14:
	.size	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check, .Lfunc_end14-_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
	.cfi_endproc

	.section	.text._RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned,"ax",@progbits
	.prefalign	4, .Lfunc_end15, nop
	.type	_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned,@function
_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned:
.Lfunc_begin15:
	.file	7 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/slice/memchr.rs"
	.loc	7 53 0
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	.file	8 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/ptr/mod.rs"
	.loc	8 2380 31 prologue_end
	leaq	7(%rdi), %rcx
	andq	$-8, %rcx
.Ltmp37:
	.loc	7 73 16
	subq	%rdi, %rcx
	jne	.LBB15_1
	.loc	7 0 16 is_stmt 0
	leaq	-16(%rsi), %rax
	xorl	%ecx, %ecx
.LBB15_5:
	movabsq	$-9187201950435737472, %rdx
	movabsq	$3399988123389603631, %r8
	movabsq	$72340172838076672, %r9
	.p2align	4
.LBB15_6:
.Ltmp38:
	.loc	7 87 29 is_stmt 1
	movq	(%rdi,%rcx), %r10
.Ltmp39:
	.loc	7 91 49
	movq	%r10, %r11
	xorq	%r8, %r11
.Ltmp40:
	.loc	7 19 5
	movq	%r9, %rbx
	subq	%r11, %rbx
	orq	%r10, %rbx
	movq	8(%rdi,%rcx), %r10
.Ltmp41:
	.loc	7 92 49
	xorq	%r8, %r10
.Ltmp42:
	.loc	7 19 5
	movq	%r9, %r11
	subq	%r10, %r11
	orq	%r10, %r11
.Ltmp43:
	.loc	7 93 24
	andq	%rdx, %rbx
	andq	%r11, %rbx
	cmpq	%rdx, %rbx
	jne	.LBB15_7
.Ltmp44:
	.loc	7 97 17
	addq	$16, %rcx
	.loc	7 83 19
	cmpq	%rax, %rcx
	jbe	.LBB15_6
	jmp	.LBB15_7
.Ltmp45:
.LBB15_1:
	.loc	7 0 19 is_stmt 0
	xorl	%edx, %edx
	.p2align	4
.LBB15_2:
.Ltmp46:
	.loc	7 42 12 is_stmt 1
	cmpb	$47, (%rdi,%rdx)
	je	.LBB15_15
	.loc	7 46 9
	incq	%rdx
	.loc	7 41 11
	cmpq	%rdx, %rcx
	jne	.LBB15_2
.Ltmp47:
	.loc	7 0 11 is_stmt 0
	leaq	-16(%rsi), %rax
.Ltmp48:
	.loc	7 83 19 is_stmt 1
	cmpq	%rax, %rcx
	jbe	.LBB15_5
.LBB15_7:
.Ltmp49:
	.loc	7 41 11
	subq	%rcx, %rsi
	jne	.LBB15_10
.Ltmp50:
	.loc	7 0 11 is_stmt 0
	xorl	%eax, %eax
	.loc	7 109 2 epilogue_begin is_stmt 1
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB15_10:
	.cfi_def_cfa_offset 16
	.loc	7 0 2 is_stmt 0
	addq	%rcx, %rdi
	xorl	%eax, %eax
	xorl	%edx, %edx
	.p2align	4
.LBB15_11:
.Ltmp51:
	.loc	7 42 12 is_stmt 1
	cmpb	$47, (%rdi,%rdx)
	je	.LBB15_14
	.loc	7 46 9
	incq	%rdx
	.loc	7 41 11
	cmpq	%rdx, %rsi
	jne	.LBB15_11
.Ltmp52:
	.loc	7 109 2 epilogue_begin
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB15_14:
	.cfi_def_cfa_offset 16
.Ltmp53:
	.loc	7 106 60
	addq	%rcx, %rdx
.Ltmp54:
.LBB15_15:
	.loc	7 0 60 is_stmt 0
	movl	$1, %eax
	.loc	7 109 2 epilogue_begin is_stmt 1
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Ltmp55:
.Lfunc_end15:
	.size	_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned, .Lfunc_end15-_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned
	.cfi_endproc
	.file	9 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/ptr/const_ptr.rs"
	.file	10 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/intrinsics/mod.rs"

	.section	.text.unlikely._RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail,"ax",@progbits
	.prefalign	4, .Lfunc_end16, nop
	.type	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail,@function
_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail:
.Lfunc_begin16:
	.file	11 "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4" "library/core/src/slice/mod.rs"
	.loc	11 5588 0
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
.Ltmp56:
	.loc	6 172 21 prologue_end
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt
.Ltmp57:
.Lfunc_end16:
	.size	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail, .Lfunc_end16-_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
	.cfi_endproc

	.section	.text._RNvMCsjFdXuXHMTfk_9hm_kernelNtB2_9InputLine4feed,"ax",@progbits
	.prefalign	4, .Lfunc_end17, nop
	.type	_RNvMCsjFdXuXHMTfk_9hm_kernelNtB2_9InputLine4feed,@function
_RNvMCsjFdXuXHMTfk_9hm_kernelNtB2_9InputLine4feed:
.Lfunc_begin17:
	.cfi_startproc
	movl	%esi, %edx
	cmpb	$0, 73(%rdi)
	je	.LBB17_1
	movb	$0, 73(%rdi)
	cmpb	$13, %dl
	je	.LBB17_3
	movzbl	%dl, %eax
	cmpl	$10, %eax
	je	.LBB17_6
	jmp	.LBB17_8
.LBB17_1:
	cmpb	$10, %dl
	je	.LBB17_3
	movzbl	%dl, %eax
	cmpl	$13, %eax
	jne	.LBB17_8
.LBB17_3:
	cmpb	$13, %dl
	sete	73(%rdi)
	movb	$3, %al
	retq
.LBB17_8:
	cmpb	$0, 72(%rdi)
	je	.LBB17_9
.LBB17_6:
	xorl	%eax, %eax
	retq
.LBB17_9:
	cmpb	$127, %dl
	je	.LBB17_11
	movzbl	%dl, %eax
	cmpl	$8, %eax
	jne	.LBB17_13
.LBB17_11:
	movq	64(%rdi), %rax
	testq	%rax, %rax
	je	.LBB17_6
	decq	%rax
	movq	%rax, 64(%rdi)
	movb	$2, %al
	retq
.LBB17_13:
	leal	-32(%rdx), %eax
	cmpb	$95, %al
	jae	.LBB17_14
	movq	64(%rdi), %rax
	cmpq	$63, %rax
	jbe	.LBB17_16
.LBB17_14:
	movb	$1, 72(%rdi)
	xorl	%eax, %eax
	retq
.LBB17_16:
	movb	%dl, (%rdi,%rax)
	incq	%rax
	movq	%rax, 64(%rdi)
	movb	$1, %al
	retq
.Lfunc_end17:
	.size	_RNvMCsjFdXuXHMTfk_9hm_kernelNtB2_9InputLine4feed, .Lfunc_end17-_RNvMCsjFdXuXHMTfk_9hm_kernelNtB2_9InputLine4feed
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build,"ax",@progbits
	.prefalign	4, .Lfunc_end18, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build:
.Lfunc_begin18:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$552, %rsp
	.cfi_def_cfa_offset 608
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %rbx
	subq	%rsi, %rbx
	jbe	.LBB18_40
	orl	%esi, %edx
	testl	$4095, %edx
	je	.LBB18_5
	movb	$1, 1(%rdi)
	jmp	.LBB18_3
.LBB18_5:
	cmpq	$16781311, %rbx
	jbe	.LBB18_6
	movb	$2, 1(%rdi)
	jmp	.LBB18_3
.LBB18_6:
	movq	%r8, %r14
	shlq	$4, %r14
	testq	%r8, %r8
	je	.LBB18_13
	leaq	1(%r8), %rax
	xorl	%r10d, %r10d
	movq	%rcx, %r11
	xorl	%r15d, %r15d
.LBB18_10:
	movq	(%r11), %r12
	movq	8(%r11), %r13
	cmpq	%r13, %r12
	jae	.LBB18_11
	cmpq	%rax, %r15
	je	.LBB18_15
	addq	$16, %r11
	incq	%r15
	movq	%r10, %rbp
	movq	%rcx, %rax
	.p2align	4
.LBB18_18:
	testq	%rbp, %rbp
	je	.LBB18_9
	movq	%rax, %rdx
	addq	$16, %rax
	addq	$-16, %rbp
	cmpq	8(%rdx), %r12
	jae	.LBB18_18
	cmpq	%r13, (%rdx)
	jae	.LBB18_18
	jmp	.LBB18_21
.LBB18_9:
	addq	$16, %r10
	leaq	(%rcx,%r14), %rax
	cmpq	%rax, %r11
	leaq	1(%r8), %rax
	jne	.LBB18_10
.LBB18_13:
	movq	608(%rsp), %rax
	movq	%rax, %r15
	shlq	$4, %r15
	testq	%rax, %rax
	je	.LBB18_24
	leaq	(%r9,%r15), %rax
	movq	%r9, %rdx
	.p2align	4
.LBB18_23:
	movq	(%rdx), %r10
	cmpq	8(%rdx), %r10
	jae	.LBB18_40
	addq	$16, %rdx
	cmpq	%rax, %rdx
	jne	.LBB18_23
.LBB18_24:
	movq	%r8, %rbp
	shrq	$12, %rbx
	leaq	16(%rsp), %rax
	movl	$512, %edx
	movq	%rdi, (%rsp)
	movq	%rax, %rdi
	movq	%rsi, %r12
	xorl	%esi, %esi
	movq	%r9, %r13
	movq	%rcx, 8(%rsp)
	callq	*memset@GOTPCREL(%rip)
	movq	8(%rsp), %rax
	movq	(%rsp), %rdi
	movq	%r12, 528(%rsp)
	movq	%rbx, 536(%rsp)
	movq	$0, 544(%rsp)
	testq	%rbx, %rbx
	je	.LBB18_37
	testq	%rbp, %rbp
	je	.LBB18_39
	xorl	%esi, %esi
	jmp	.LBB18_27
.LBB18_21:
	movb	$3, %al
	movb	%al, 1(%rdi)
	jmp	.LBB18_3
.LBB18_41:
	movq	%rcx, %rax
	shrq	$6, %rax
	cmpq	$4095, %rcx
	ja	.LBB18_43
	movl	$1, %r8d
	shlq	%cl, %r8
	orq	%r8, 16(%rsp,%rax,8)
	incq	544(%rsp)
	movq	8(%rsp), %rax
	.p2align	4
.LBB18_36:
	cmpq	%rbx, %rsi
	je	.LBB18_37
.LBB18_27:
	movq	%rsi, %r8
	shlq	$12, %r8
	addq	528(%rsp), %r8
	jb	.LBB18_40
	cmpq	$-4097, %r8
	ja	.LBB18_40
	movq	%rsi, %rcx
	incq	%rsi
	leaq	4096(%r8), %r9
	xorl	%r10d, %r10d
	jmp	.LBB18_30
	.p2align	4
.LBB18_38:
	addq	$16, %r10
	cmpq	%r10, %r14
	je	.LBB18_36
.LBB18_30:
	cmpq	%r8, (%rax,%r10)
	ja	.LBB18_38
	cmpq	8(%rax,%r10), %r9
	ja	.LBB18_38
	movq	%r15, %r10
	movq	%r13, %r11
	.p2align	4
.LBB18_33:
	testq	%r10, %r10
	je	.LBB18_41
	movq	%r11, %rbp
	addq	$16, %r11
	addq	$-16, %r10
	cmpq	8(%rbp), %r8
	jae	.LBB18_33
	cmpq	%r9, (%rbp)
	jae	.LBB18_33
	jmp	.LBB18_36
.LBB18_39:
	xorl	%eax, %eax
	movq	$-4096, %rdx
	subq	%r12, %rdx
	cmovaeq	%rdx, %rax
	addq	$4095, %rax
	shrq	$12, %rax
	decq	%rbx
	cmpq	%rbx, %rax
	jbe	.LBB18_40
.LBB18_37:
	addq	$8, %rdi
	leaq	16(%rsp), %rsi
	movl	$536, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movq	(%rsp), %rdi
	xorl	%eax, %eax
	jmp	.LBB18_4
.LBB18_40:
	movb	$0, 1(%rdi)
.LBB18_3:
	movb	$1, %al
.LBB18_4:
	movb	%al, (%rdi)
	addq	$552, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB18_11:
	.cfi_def_cfa_offset 608
	xorl	%eax, %eax
	movb	%al, 1(%rdi)
	jmp	.LBB18_3
.LBB18_15:
	xorl	%edi, %edi
	movq	%rax, %rsi
	movq	%r8, %rdx
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB18_43:
	movl	$64, %esi
	movq	%rax, %rdi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.Lfunc_end18:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build, .Lfunc_end18-_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit,"ax",@progbits
	.prefalign	4, .Lfunc_end19, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit:
.Lfunc_begin19:
	.cfi_startproc
	movl	9744(%rdi), %edx
	testl	%edx, %edx
	je	.LBB19_3
	movq	9736(%rdi), %rcx
	cmpq	$64, %rcx
	jbe	.LBB19_4
.LBB19_3:
	xorl	%eax, %eax
	retq
.LBB19_4:
	xorl	%esi, %esi
	.p2align	4
.LBB19_5:
	cmpq	$2048, %rsi
	je	.LBB19_13
	movq	%rsi, %rax
	movl	24(%rdi,%rsi), %esi
	cmpl	%edx, %esi
	ja	.LBB19_3
	testl	%esi, %esi
	jne	.LBB19_9
	cmpb	$2, 16(%rdi,%rax)
	jne	.LBB19_3
.LBB19_9:
	movl	56(%rdi,%rax), %r8d
	cmpl	%edx, %r8d
	ja	.LBB19_3
	leaq	64(%rax), %rsi
	testl	%r8d, %r8d
	jne	.LBB19_5
	cmpb	$2, 48(%rdi,%rax)
	je	.LBB19_5
	jmp	.LBB19_3
.LBB19_13:
	xorl	%r8d, %r8d
	.p2align	4
.LBB19_14:
	cmpq	$5120, %r8
	je	.LBB19_25
	movq	%r8, %rsi
	movl	4640(%rdi,%r8), %eax
	cmpl	%edx, %eax
	ja	.LBB19_3
	testl	%eax, %eax
	jne	.LBB19_18
	cmpb	$2, 4633(%rdi,%rsi)
	jne	.LBB19_3
.LBB19_18:
	movl	4680(%rdi,%rsi), %eax
	cmpl	%edx, %eax
	ja	.LBB19_3
	leaq	80(%rsi), %r8
	testl	%eax, %eax
	jne	.LBB19_14
	xorl	%eax, %eax
	cmpb	$2, 4673(%rdi,%rsi)
	je	.LBB19_14
.LBB19_21:
	retq
.LBB19_25:
	xorl	%r8d, %r8d
.LBB19_26:
	cmpq	$2560, %r8
	je	.LBB19_36
	movq	%r8, %rsi
	movl	2080(%rdi,%r8), %eax
	cmpl	%edx, %eax
	ja	.LBB19_3
	testl	%eax, %eax
	jne	.LBB19_30
	cmpb	$2, 2072(%rdi,%rsi)
	jne	.LBB19_3
.LBB19_30:
	movl	2120(%rdi,%rsi), %eax
	cmpl	%edx, %eax
	ja	.LBB19_3
	leaq	80(%rsi), %r8
	testl	%eax, %eax
	jne	.LBB19_26
	xorl	%eax, %eax
	cmpb	$2, 2112(%rdi,%rsi)
	je	.LBB19_26
	jmp	.LBB19_21
.LBB19_36:
	xorl	%eax, %eax
	xorl	%edx, %edx
.LBB19_37:
	xorl	%esi, %esi
	cmpb	$2, 2072(%rdi,%rax)
	setne	%sil
	addq	%rsi, %rdx
	xorl	%esi, %esi
	cmpb	$2, 2112(%rdi,%rax)
	setne	%sil
	xorl	%r8d, %r8d
	cmpb	$2, 2152(%rdi,%rax)
	setne	%r8b
	addq	%rsi, %r8
	addq	%rdx, %r8
	xorl	%edx, %edx
	cmpb	$2, 2192(%rdi,%rax)
	setne	%dl
	addq	%r8, %rdx
	addq	$160, %rax
	cmpq	$2560, %rax
	jne	.LBB19_37
	cmpq	%rcx, %rdx
	ja	.LBB19_3
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	xorl	%edx, %edx
	xorl	%esi, %esi
	xorl	%ecx, %ecx
	jmp	.LBB19_46
.LBB19_44:
	cmpq	$1, %rax
	ja	.LBB19_98
.LBB19_45:
	addq	$32, %rdx
	incq	%rsi
	cmpq	$2048, %rdx
	je	.LBB19_69
.LBB19_46:
	movzbl	16(%rdi,%rdx), %eax
	cmpb	$2, %al
	je	.LBB19_45
	addq	8(%rdi,%rdx), %rcx
	jb	.LBB19_98
	movl	24(%rdi,%rdx), %r8d
	xorl	%r9d, %r9d
	jmp	.LBB19_50
.LBB19_49:
	addq	$80, %r9
	cmpq	$5120, %r9
	je	.LBB19_57
.LBB19_50:
	cmpb	$2, 4633(%rdi,%r9)
	je	.LBB19_53
	cmpl	%r8d, 4616(%rdi,%r9)
	jne	.LBB19_53
	cmpq	%rsi, 4608(%rdi,%r9)
	je	.LBB19_56
.LBB19_53:
	cmpb	$2, 4673(%rdi,%r9)
	je	.LBB19_49
	cmpl	%r8d, 4656(%rdi,%r9)
	jne	.LBB19_49
	cmpq	%rsi, 4648(%rdi,%r9)
	jne	.LBB19_49
.LBB19_56:
	testb	$1, %al
	je	.LBB19_65
	jmp	.LBB19_98
.LBB19_57:
	xorl	%r9d, %r9d
	jmp	.LBB19_59
.LBB19_58:
	addq	$80, %r9
	xorl	%eax, %eax
	cmpq	$2560, %r9
	je	.LBB19_93
.LBB19_59:
	cmpb	$2, 2072(%rdi,%r9)
	je	.LBB19_62
	cmpl	%r8d, 2064(%rdi,%r9)
	jne	.LBB19_62
	cmpq	%rsi, 2056(%rdi,%r9)
	je	.LBB19_65
.LBB19_62:
	cmpb	$2, 2112(%rdi,%r9)
	je	.LBB19_58
	cmpl	%r8d, 2104(%rdi,%r9)
	jne	.LBB19_58
	cmpq	%rsi, 2096(%rdi,%r9)
	jne	.LBB19_58
.LBB19_65:
	xorl	%r9d, %r9d
	xorl	%eax, %eax
	jmp	.LBB19_67
.LBB19_66:
	cmpl	%r8d, 4616(%rdi,%r9)
	sete	%r11b
	cmpq	%rsi, 4608(%rdi,%r9)
	sete	%bl
	andb	%r11b, %bl
	movzbl	%bl, %r11d
	andl	%r11d, %r10d
	addq	%r10, %rax
	addq	$40, %r9
	cmpq	$5120, %r9
	je	.LBB19_44
.LBB19_67:
	movzbl	4633(%rdi,%r9), %r10d
	cmpq	$2, %r10
	jne	.LBB19_66
	xorl	%r10d, %r10d
	addq	%r10, %rax
	addq	$40, %r9
	cmpq	$5120, %r9
	jne	.LBB19_67
	jmp	.LBB19_44
.LBB19_69:
	xorl	%edx, %edx
	jmp	.LBB19_72
.LBB19_70:
	cmpb	$8, %r8b
	jae	.LBB19_98
.LBB19_71:
	addq	$40, %rdx
	cmpq	$5120, %rdx
	je	.LBB19_80
.LBB19_72:
	movzbl	4633(%rdi,%rdx), %eax
	cmpb	$2, %al
	je	.LBB19_71
	movq	4608(%rdi,%rdx), %rsi
	cmpq	$64, %rsi
	jae	.LBB19_98
	shlq	$5, %rsi
	movl	24(%rdi,%rsi), %r8d
	cmpl	4616(%rdi,%rdx), %r8d
	jne	.LBB19_98
	addq	%rdi, %rsi
	cmpb	$0, 16(%rsi)
	jne	.LBB19_98
	movzbl	4632(%rdi,%rdx), %r8d
	testb	$1, %al
	je	.LBB19_70
	xorl	%eax, %eax
	cmpb	$7, %r8b
	ja	.LBB19_93
	movq	(%rsi), %rsi
	cmpq	%rsi, 4624(%rdi,%rdx)
	je	.LBB19_71
	jmp	.LBB19_93
.LBB19_80:
	xorl	%eax, %eax
	jmp	.LBB19_82
.LBB19_81:
	addq	$40, %rax
	cmpq	$2560, %rax
	je	.LBB19_91
.LBB19_82:
	cmpb	$2, 2072(%rdi,%rax)
	je	.LBB19_81
	movq	2056(%rdi,%rax), %rdx
	cmpq	$64, %rdx
	jae	.LBB19_98
	shlq	$5, %rdx
	movl	24(%rdi,%rdx), %esi
	cmpl	2064(%rdi,%rax), %esi
	jne	.LBB19_98
	addq	%rdi, %rdx
	cmpb	$2, 16(%rdx)
	jne	.LBB19_81
	jmp	.LBB19_98
.LBB19_91:
	cmpq	9752(%rdi), %rcx
	jne	.LBB19_98
	cmpq	9728(%rdi), %rcx
	setbe	%al
.LBB19_93:
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	retq
.LBB19_98:
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	retq
.Lfunc_end19:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit, .Lfunc_end19-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5audit
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin,"ax",@progbits
	.prefalign	4, .Lfunc_end20, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin:
.Lfunc_begin20:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movb	$1, %al
	movb	$1, %r10b
	cmpq	$127, %rcx
	ja	.LBB20_7
	leaq	(%rcx,%rcx,4), %rcx
	cmpl	%r8d, 4640(%rsi,%rcx,8)
	jne	.LBB20_7
	leaq	(%rsi,%rcx,8), %r11
	addq	$4608, %r11
	cmpb	$2, 25(%r11)
	je	.LBB20_7
	movb	$3, %r10b
	cmpq	%rdx, 16(%r11)
	jne	.LBB20_7
	movq	(%r11), %rcx
	movb	$11, %r10b
	cmpq	$63, %rcx
	ja	.LBB20_7
	movl	8(%r11), %r8d
	movq	%rcx, %rbx
	shlq	$5, %rbx
	cmpl	%r8d, 24(%rsi,%rbx)
	jne	.LBB20_7
	addq	%rsi, %rbx
	cmpb	$0, 16(%rbx)
	je	.LBB20_8
.LBB20_7:
	movb	%r10b, 1(%rdi)
	movb	%al, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB20_8:
	.cfi_def_cfa_offset 24
	movb	$-2, %r10b
	subb	%r9b, %r10b
	orb	24(%r11), %r10b
	cmpb	$-1, %r10b
	je	.LBB20_10
	movb	$4, 1(%rdi)
	movb	%al, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB20_10:
	.cfi_def_cfa_offset 24
	leaq	2048(%rsi), %r9
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
.LBB20_11:
	xorl	%ebx, %ebx
	cmpb	$2, 2072(%rsi,%r10)
	setne	%bl
	addq	%rbx, %r11
	xorl	%ebx, %ebx
	cmpb	$2, 2112(%rsi,%r10)
	setne	%bl
	xorl	%r14d, %r14d
	cmpb	$2, 2152(%rsi,%r10)
	setne	%r14b
	addq	%rbx, %r14
	addq	%r11, %r14
	xorl	%r11d, %r11d
	cmpb	$2, 2192(%rsi,%r10)
	setne	%r11b
	addq	%r14, %r11
	addq	$160, %r10
	cmpq	$2560, %r10
	jne	.LBB20_11
	cmpq	9736(%rsi), %r11
	jae	.LBB20_23
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	jmp	.LBB20_14
.LBB20_18:
	addq	$2, %r10
	addq	$80, %r11
	cmpq	$2560, %r11
	je	.LBB20_19
.LBB20_14:
	cmpb	$2, 2072(%rsi,%r11)
	jne	.LBB20_16
	cmpl	$0, 2080(%rsi,%r11)
	jne	.LBB20_21
.LBB20_16:
	cmpb	$2, 2112(%rsi,%r11)
	jne	.LBB20_18
	cmpl	$0, 2120(%rsi,%r11)
	je	.LBB20_18
	incq	%r10
.LBB20_21:
	leaq	(%r10,%r10,4), %rax
	movq	%rdx, (%r9,%rax,8)
	movq	%rcx, 8(%r9,%rax,8)
	movl	%r8d, 16(%r9,%rax,8)
	movb	$0, 24(%r9,%rax,8)
	movl	32(%r9,%rax,8), %eax
	movq	%r10, 8(%rdi)
	movl	%eax, 16(%rdi)
	xorl	%eax, %eax
	movb	%al, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB20_23:
	.cfi_def_cfa_offset 24
	movb	$8, 1(%rdi)
	movb	%al, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB20_19:
	.cfi_def_cfa_offset 24
	movb	$9, 1(%rdi)
	movb	%al, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end20:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin, .Lfunc_end20-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5begin
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant,"ax",@progbits
	.prefalign	4, .Lfunc_end21, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant:
.Lfunc_begin21:
	.cfi_startproc
	movb	$1, %al
	movb	$1, %r10b
	cmpq	$127, %rcx
	ja	.LBB21_7
	leaq	(%rcx,%rcx,4), %rcx
	cmpl	%r8d, 4640(%rsi,%rcx,8)
	jne	.LBB21_7
	leaq	(%rsi,%rcx,8), %r11
	addq	$4608, %r11
	cmpb	$2, 25(%r11)
	je	.LBB21_7
	movb	$3, %r10b
	cmpq	%rdx, 16(%r11)
	jne	.LBB21_7
	movq	(%r11), %rcx
	movb	$11, %r10b
	cmpq	$63, %rcx
	ja	.LBB21_7
	movl	8(%r11), %edx
	movq	%rcx, %r8
	shlq	$5, %r8
	cmpl	%edx, 24(%rsi,%r8)
	jne	.LBB21_7
	addq	%rsi, %r8
	cmpb	$0, 16(%r8)
	je	.LBB21_9
.LBB21_7:
	movb	%r10b, 1(%rdi)
	movb	%al, (%rdi)
	retq
.LBB21_9:
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movzbl	16(%rsp), %r8d
	movzbl	24(%r11), %r10d
	movl	%r8d, %r11d
	orb	$4, %r11b
	notb	%r10b
	testb	%r11b, %r10b
	jne	.LBB21_19
	leaq	4608(%rsi), %r10
	xorl	%r11d, %r11d
	xorl	%ebx, %ebx
	jmp	.LBB21_11
.LBB21_15:
	addq	$2, %r11
	addq	$80, %rbx
	cmpq	$5120, %rbx
	je	.LBB21_16
.LBB21_11:
	cmpb	$2, 4633(%rsi,%rbx)
	jne	.LBB21_13
	cmpl	$0, 4640(%rsi,%rbx)
	jne	.LBB21_18
.LBB21_13:
	cmpb	$2, 4673(%rsi,%rbx)
	jne	.LBB21_15
	cmpl	$0, 4680(%rsi,%rbx)
	je	.LBB21_15
	incq	%r11
.LBB21_18:
	leaq	(%r11,%r11,4), %rax
	movq	%rcx, (%r10,%rax,8)
	movl	%edx, 8(%r10,%rax,8)
	movq	%r9, 16(%r10,%rax,8)
	movb	%r8b, 24(%r10,%rax,8)
	movb	$0, 25(%r10,%rax,8)
	movl	32(%r10,%rax,8), %eax
	movq	%r11, 8(%rdi)
	movl	%eax, 16(%rdi)
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	movb	%al, (%rdi)
	retq
.LBB21_19:
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movb	$4, 1(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	movb	%al, (%rdi)
	retq
.LBB21_16:
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movb	$7, 1(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	movb	%al, (%rdi)
	retq
.Lfunc_end21:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant, .Lfunc_end21-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5grant
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats,"ax",@progbits
	.prefalign	4, .Lfunc_end22, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats:
.Lfunc_begin22:
	.cfi_startproc
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB22_1:
	xorl	%edx, %edx
	cmpb	$2, 16(%rsi,%rcx)
	setne	%dl
	addq	%rdx, %rax
	xorl	%edx, %edx
	cmpb	$2, 48(%rsi,%rcx)
	setne	%dl
	xorl	%r8d, %r8d
	cmpb	$2, 80(%rsi,%rcx)
	setne	%r8b
	addq	%rdx, %r8
	addq	%rax, %r8
	xorl	%eax, %eax
	cmpb	$2, 112(%rsi,%rcx)
	setne	%al
	addq	%r8, %rax
	subq	$-128, %rcx
	cmpq	$2048, %rcx
	jne	.LBB22_1
	xorl	%edx, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB22_3:
	xorl	%r8d, %r8d
	cmpb	$2, 4633(%rsi,%rdx)
	setne	%r8b
	addq	%r8, %rcx
	xorl	%r8d, %r8d
	cmpb	$2, 4673(%rsi,%rdx)
	setne	%r8b
	xorl	%r9d, %r9d
	cmpb	$2, 4713(%rsi,%rdx)
	setne	%r9b
	addq	%r8, %r9
	addq	%rcx, %r9
	xorl	%ecx, %ecx
	cmpb	$2, 4753(%rsi,%rdx)
	setne	%cl
	addq	%r9, %rcx
	addq	$160, %rdx
	cmpq	$5120, %rdx
	jne	.LBB22_3
	xorl	%r8d, %r8d
	xorl	%edx, %edx
	.p2align	4
.LBB22_5:
	xorl	%r9d, %r9d
	cmpb	$2, 2072(%rsi,%r8)
	setne	%r9b
	addq	%r9, %rdx
	xorl	%r9d, %r9d
	cmpb	$2, 2112(%rsi,%r8)
	setne	%r9b
	xorl	%r10d, %r10d
	cmpb	$2, 2152(%rsi,%r8)
	setne	%r10b
	addq	%r9, %r10
	addq	%rdx, %r10
	xorl	%edx, %edx
	cmpb	$2, 2192(%rsi,%r8)
	setne	%dl
	addq	%r10, %rdx
	addq	$160, %r8
	cmpq	$2560, %r8
	jne	.LBB22_5
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	9752(%rsi), %r8
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	.p2align	4
.LBB22_7:
	xorl	%r11d, %r11d
	cmpl	$0, 24(%rsi,%r10)
	sete	%r11b
	cmpl	$1, 56(%rsi,%r10)
	movq	%r9, %rbx
	adcq	%r11, %rbx
	xorl	%r9d, %r9d
	cmpl	$0, 88(%rsi,%r10)
	sete	%r9b
	cmpl	$1, 120(%rsi,%r10)
	adcq	%rbx, %r9
	subq	$-128, %r10
	cmpq	$2048, %r10
	jne	.LBB22_7
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	.p2align	4
.LBB22_9:
	xorl	%ebx, %ebx
	cmpl	$0, 4640(%rsi,%r11)
	sete	%bl
	cmpl	$1, 4680(%rsi,%r11)
	movq	%r10, %r14
	adcq	%rbx, %r14
	xorl	%r10d, %r10d
	cmpl	$0, 4720(%rsi,%r11)
	sete	%r10b
	cmpl	$1, 4760(%rsi,%r11)
	adcq	%r14, %r10
	addq	$160, %r11
	cmpq	$5120, %r11
	jne	.LBB22_9
	xorl	%r11d, %r11d
	xorl	%ebx, %ebx
	.p2align	4
.LBB22_11:
	xorl	%r14d, %r14d
	cmpl	$0, 2080(%rsi,%rbx)
	sete	%r14b
	cmpl	$1, 2120(%rsi,%rbx)
	movq	%r11, %r15
	adcq	%r14, %r15
	xorl	%r11d, %r11d
	cmpl	$0, 2160(%rsi,%rbx)
	sete	%r11b
	cmpl	$1, 2200(%rsi,%rbx)
	adcq	%r15, %r11
	addq	$160, %rbx
	cmpq	$2560, %rbx
	jne	.LBB22_11
	movq	%rax, (%rdi)
	movq	%rcx, 8(%rdi)
	movq	%rdx, 16(%rdi)
	movq	%r8, 24(%rdi)
	movq	%r9, 32(%rdi)
	movq	%r10, 40(%rdi)
	movq	%r11, 48(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end22:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats, .Lfunc_end22-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model5stats
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel,"ax",@progbits
	.prefalign	4, .Lfunc_end23, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel:
.Lfunc_begin23:
	.cfi_startproc
	movb	$2, %al
	cmpq	$63, %rdx
	ja	.LBB23_8
	leaq	(%rdx,%rdx,4), %rdx
	cmpl	%ecx, 2080(%rdi,%rdx,8)
	jne	.LBB23_8
	leaq	(%rdi,%rdx,8), %rcx
	addq	$2048, %rcx
	cmpb	$2, 24(%rcx)
	je	.LBB23_8
	movq	8(%rcx), %rdx
	movb	$11, %al
	cmpq	$63, %rdx
	ja	.LBB23_8
	movl	16(%rcx), %r8d
	shlq	$5, %rdx
	cmpl	%r8d, 24(%rdi,%rdx)
	jne	.LBB23_8
	addq	%rdx, %rdi
	cmpb	$2, 16(%rdi)
	je	.LBB23_8
	movzbl	(%rcx), %eax
	movzwl	5(%rcx), %edx
	movzbl	7(%rcx), %edi
	shll	$16, %edi
	orl	%edx, %edi
	movl	1(%rcx), %edx
	shlq	$40, %rdi
	shlq	$8, %rdx
	orq	%rdi, %rdx
	orq	%rax, %rdx
	movb	$3, %al
	cmpq	%rsi, %rdx
	jne	.LBB23_8
	movq	%rsi, (%rcx)
	movb	$1, 24(%rcx)
	movb	$-1, %al
.LBB23_8:
	retq
.Lfunc_end23:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel, .Lfunc_end23-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6cancel
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6create,"ax",@progbits
	.prefalign	4, .Lfunc_end24, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6create,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6create:
.Lfunc_begin24:
	.cfi_startproc
	movq	9752(%rsi), %rax
	addq	%rdx, %rax
	jb	.LBB24_22
	cmpq	9728(%rsi), %rax
	jbe	.LBB24_2
	movb	$5, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.LBB24_2:
	xorl	%ecx, %ecx
	xorl	%r8d, %r8d
	jmp	.LBB24_3
	.p2align	4
.LBB24_7:
	addq	$64, %r8
	addq	$2, %rcx
	cmpq	$2048, %r8
	je	.LBB24_8
.LBB24_3:
	cmpb	$2, 16(%rsi,%r8)
	jne	.LBB24_5
	cmpl	$0, 24(%rsi,%r8)
	jne	.LBB24_11
.LBB24_5:
	cmpb	$2, 48(%rsi,%r8)
	jne	.LBB24_7
	cmpl	$0, 56(%rsi,%r8)
	je	.LBB24_7
	incq	%rcx
.LBB24_11:
	leaq	4608(%rsi), %r8
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	jmp	.LBB24_12
	.p2align	4
.LBB24_16:
	addq	$2, %r9
	addq	$80, %r10
	cmpq	$5120, %r10
	je	.LBB24_17
.LBB24_12:
	cmpb	$2, 4633(%rsi,%r10)
	jne	.LBB24_14
	cmpl	$0, 4640(%rsi,%r10)
	jne	.LBB24_20
.LBB24_14:
	cmpb	$2, 4673(%rsi,%r10)
	jne	.LBB24_16
	cmpl	$0, 4680(%rsi,%r10)
	je	.LBB24_16
	incq	%r9
.LBB24_20:
	movq	%rcx, %r10
	shlq	$5, %r10
	movl	24(%rsi,%r10), %r11d
	movq	$1, (%rsi,%r10)
	movq	%rdx, 8(%rsi,%r10)
	movb	$0, 16(%rsi,%r10)
	leaq	(%r9,%r9,4), %rdx
	movq	%rcx, (%r8,%rdx,8)
	movl	%r11d, 8(%r8,%rdx,8)
	movq	$1, 16(%r8,%rdx,8)
	movw	$263, 24(%r8,%rdx,8)
	movq	%rax, 9752(%rsi)
	movl	32(%r8,%rdx,8), %eax
	movq	%r9, 8(%rdi)
	movl	%eax, 16(%rdi)
	xorl	%eax, %eax
	movb	%al, (%rdi)
	retq
.LBB24_8:
	movb	$6, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.LBB24_17:
	movb	$7, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.LBB24_22:
	movb	$10, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.Lfunc_end24:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6create, .Lfunc_end24-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6create
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke,"ax",@progbits
	.prefalign	4, .Lfunc_end25, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke:
.Lfunc_begin25:
	.cfi_startproc
	movb	$1, %al
	cmpq	$127, %rdx
	ja	.LBB25_29
	leaq	(%rdx,%rdx,4), %rdx
	cmpl	%ecx, 4640(%rdi,%rdx,8)
	jne	.LBB25_29
	leaq	(%rdi,%rdx,8), %rcx
	addq	$4608, %rcx
	movzbl	25(%rcx), %r8d
	cmpb	$2, %r8b
	je	.LBB25_29
	movb	$3, %al
	cmpq	%rsi, 16(%rcx)
	jne	.LBB25_29
	movq	(%rcx), %rdx
	movb	$11, %al
	cmpq	$63, %rdx
	ja	.LBB25_29
	movl	8(%rcx), %esi
	movq	%rdx, %rcx
	shlq	$5, %rcx
	cmpl	%esi, 24(%rdi,%rcx)
	jne	.LBB25_29
	addq	%rdi, %rcx
	cmpb	$0, 16(%rcx)
	jne	.LBB25_29
	movb	$4, %al
	cmpb	$1, %r8b
	jne	.LBB25_29
	xorl	%eax, %eax
	jmp	.LBB25_9
.LBB25_15:
	addq	$80, %rax
	cmpq	$2560, %rax
	je	.LBB25_16
.LBB25_9:
	cmpb	$2, 2072(%rdi,%rax)
	je	.LBB25_12
	cmpl	%esi, 2064(%rdi,%rax)
	jne	.LBB25_12
	cmpq	%rdx, 2056(%rdi,%rax)
	je	.LBB25_30
.LBB25_12:
	cmpb	$2, 2112(%rdi,%rax)
	je	.LBB25_15
	cmpl	%esi, 2104(%rdi,%rax)
	jne	.LBB25_15
	cmpq	%rdx, 2096(%rdi,%rax)
	jne	.LBB25_15
.LBB25_30:
	leaq	9752(%rdi), %rax
	movq	9752(%rdi), %r8
	xorl	%r9d, %r9d
	jmp	.LBB25_18
.LBB25_16:
	movq	9752(%rdi), %r8
	movb	$11, %al
	subq	8(%rcx), %r8
	jb	.LBB25_29
	leaq	9752(%rdi), %rax
	movb	$1, %r9b
.LBB25_18:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset %rbx, -24
	.cfi_offset %rbp, -16
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	jmp	.LBB25_19
.LBB25_23:
	addq	$40, %r11
	cmpq	$5120, %r11
	je	.LBB25_24
.LBB25_19:
	cmpb	$2, 4633(%rdi,%r11)
	je	.LBB25_23
	cmpl	%esi, 4616(%rdi,%r11)
	jne	.LBB25_23
	cmpq	%rdx, 4608(%rdi,%r11)
	jne	.LBB25_23
	movl	4640(%rdi,%r11), %ebx
	leal	1(%rbx), %ebp
	cmpl	9744(%rdi), %ebx
	movb	$2, 4633(%rdi,%r11)
	cmovael	%r10d, %ebp
	movl	%ebp, 4640(%rdi,%r11)
	jmp	.LBB25_23
.LBB25_24:
	cmpb	$2, 16(%rcx)
	je	.LBB25_26
	movb	$1, 16(%rcx)
.LBB25_26:
	testb	%r9b, %r9b
	je	.LBB25_28
	movl	24(%rcx), %edx
	leal	1(%rdx), %esi
	xorl	%r9d, %r9d
	cmpl	9744(%rdi), %edx
	movb	$2, 16(%rcx)
	cmovbl	%esi, %r9d
	movl	%r9d, 24(%rcx)
.LBB25_28:
	movq	%r8, (%rax)
	movb	$-1, %al
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %rbp
.LBB25_29:
	retq
.Lfunc_end25:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke, .Lfunc_end25-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model6revoke
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release,"ax",@progbits
	.prefalign	4, .Lfunc_end26, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release:
.Lfunc_begin26:
	.cfi_startproc
	movb	$1, %al
	cmpq	$127, %rdx
	ja	.LBB26_29
	leaq	(%rdx,%rdx,4), %r8
	cmpl	%ecx, 4640(%rdi,%r8,8)
	jne	.LBB26_29
	leaq	(%rdi,%r8,8), %r8
	addq	$4608, %r8
	cmpb	$2, 25(%r8)
	je	.LBB26_29
	movb	$3, %al
	cmpq	%rsi, 16(%r8)
	jne	.LBB26_29
	movq	(%r8), %r9
	movb	$11, %al
	cmpq	$63, %r9
	ja	.LBB26_29
	movl	8(%r8), %r10d
	movq	%r9, %rsi
	shlq	$5, %rsi
	cmpl	%r10d, 24(%rdi,%rsi)
	jne	.LBB26_29
	addq	%rdi, %rsi
	cmpb	$0, 16(%rsi)
	jne	.LBB26_29
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	xorl	%r11d, %r11d
	movq	%rdx, %rbx
	xorl	%r14d, %r14d
	jmp	.LBB26_8
.LBB26_16:
	addq	$2, %r14
	addq	$-2, %rbx
	addq	$80, %r11
	cmpq	$5120, %r11
	je	.LBB26_17
.LBB26_8:
	testq	%rbx, %rbx
	je	.LBB26_12
	cmpb	$2, 4633(%rdi,%r11)
	je	.LBB26_12
	cmpl	%r10d, 4616(%rdi,%r11)
	jne	.LBB26_12
	cmpq	%r9, 4608(%rdi,%r11)
	je	.LBB26_30
.LBB26_12:
	leaq	1(%r14), %r15
	cmpq	%rdx, %r15
	je	.LBB26_16
	cmpb	$2, 4673(%rdi,%r11)
	je	.LBB26_16
	cmpl	%r10d, 4656(%rdi,%r11)
	jne	.LBB26_16
	cmpq	%r9, 4648(%rdi,%r11)
	jne	.LBB26_16
	jmp	.LBB26_30
.LBB26_17:
	xorl	%edx, %edx
	jmp	.LBB26_18
.LBB26_24:
	addq	$80, %rdx
	cmpq	$2560, %rdx
	je	.LBB26_25
.LBB26_18:
	cmpb	$2, 2072(%rdi,%rdx)
	je	.LBB26_21
	cmpl	%r10d, 2064(%rdi,%rdx)
	jne	.LBB26_21
	cmpq	%r9, 2056(%rdi,%rdx)
	je	.LBB26_30
.LBB26_21:
	cmpb	$2, 2112(%rdi,%rdx)
	je	.LBB26_24
	cmpl	%r10d, 2104(%rdi,%rdx)
	jne	.LBB26_24
	cmpq	%r9, 2096(%rdi,%rdx)
	jne	.LBB26_24
.LBB26_30:
	leaq	9752(%rdi), %rax
	movq	9752(%rdi), %rdx
	leal	1(%rcx), %esi
	xorl	%r9d, %r9d
	cmpl	9744(%rdi), %ecx
	movb	$2, 25(%r8)
	cmovbl	%esi, %r9d
	movl	%r9d, 32(%r8)
.LBB26_27:
	movq	%rdx, (%rax)
	movb	$-1, %al
.LBB26_28:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
.LBB26_29:
	retq
.LBB26_25:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	9752(%rdi), %rdx
	subq	8(%rsi), %rdx
	jb	.LBB26_28
	movl	9744(%rdi), %eax
	addq	$9752, %rdi
	movb	$2, 25(%r8)
	leal	1(%rcx), %r9d
	xorl	%r10d, %r10d
	cmpl	%eax, %ecx
	cmovael	%r10d, %r9d
	movl	%r9d, 32(%r8)
	movb	$2, 16(%rsi)
	movl	24(%rsi), %ecx
	leal	1(%rcx), %r8d
	cmpl	%eax, %ecx
	cmovael	%r10d, %r8d
	movl	%r8d, 24(%rsi)
	movq	%rdi, %rax
	jmp	.LBB26_27
.Lfunc_end26:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release, .Lfunc_end26-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model7release
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete,"ax",@progbits
	.prefalign	4, .Lfunc_end27, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete:
.Lfunc_begin27:
	.cfi_startproc
	movl	%edx, %ecx
	movb	$1, %al
	movb	$2, %dl
	cmpq	$63, %rsi
	ja	.LBB27_28
	leaq	(%rsi,%rsi,4), %r8
	cmpl	%ecx, 2080(%rdi,%r8,8)
	jne	.LBB27_28
	leaq	(%rdi,%r8,8), %r9
	addq	$2048, %r9
	movzbl	24(%r9), %r8d
	cmpb	$2, %r8b
	je	.LBB27_28
	movq	8(%r9), %r11
	movb	$11, %dl
	cmpq	$63, %r11
	ja	.LBB27_28
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movl	16(%r9), %ebx
	movq	%r11, %r10
	shlq	$5, %r10
	cmpl	%ebx, 24(%rdi,%r10)
	jne	.LBB27_27
	addq	%rdi, %r10
	cmpb	$2, 16(%r10)
	je	.LBB27_27
	xorl	%r14d, %r14d
	jmp	.LBB27_7
	.p2align	4
.LBB27_13:
	addq	$80, %r14
	cmpq	$5120, %r14
	je	.LBB27_14
.LBB27_7:
	cmpb	$2, 4633(%rdi,%r14)
	je	.LBB27_10
	cmpl	%ebx, 4616(%rdi,%r14)
	jne	.LBB27_10
	cmpq	%r11, 4608(%rdi,%r14)
	je	.LBB27_29
.LBB27_10:
	cmpb	$2, 4673(%rdi,%r14)
	je	.LBB27_13
	cmpl	%ebx, 4656(%rdi,%r14)
	jne	.LBB27_13
	cmpq	%r11, 4648(%rdi,%r14)
	jne	.LBB27_13
	jmp	.LBB27_29
.LBB27_14:
	xorl	%r14d, %r14d
	movq	%rsi, %r15
	xorl	%r12d, %r12d
	jmp	.LBB27_15
.LBB27_23:
	addq	$2, %r12
	addq	$-2, %r15
	addq	$80, %r14
	cmpq	$2560, %r14
	je	.LBB27_24
.LBB27_15:
	testq	%r15, %r15
	je	.LBB27_19
	cmpb	$2, 2072(%rdi,%r14)
	je	.LBB27_19
	cmpl	%ebx, 2064(%rdi,%r14)
	jne	.LBB27_19
	cmpq	%r11, 2056(%rdi,%r14)
	je	.LBB27_29
.LBB27_19:
	leaq	1(%r12), %r13
	cmpq	%rsi, %r13
	je	.LBB27_23
	cmpb	$2, 2112(%rdi,%r14)
	je	.LBB27_23
	cmpl	%ebx, 2104(%rdi,%r14)
	jne	.LBB27_23
	cmpq	%r11, 2096(%rdi,%r14)
	jne	.LBB27_23
.LBB27_29:
	leaq	9752(%rdi), %rax
	movq	9752(%rdi), %rsi
	leal	1(%rcx), %edx
	xorl	%r10d, %r10d
	cmpl	9744(%rdi), %ecx
	movb	$2, 24(%r9)
	cmovbl	%edx, %r10d
	movl	%r10d, 32(%r9)
.LBB27_26:
	movq	%rsi, (%rax)
	xorl	%eax, %eax
	movl	%r8d, %edx
.LBB27_27:
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r12
	.cfi_restore %r13
	.cfi_restore %r14
	.cfi_restore %r15
.LBB27_28:
	retq
.LBB27_24:
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	9752(%rdi), %rsi
	subq	8(%r10), %rsi
	jb	.LBB27_27
	movl	9744(%rdi), %eax
	addq	$9752, %rdi
	movb	$2, 24(%r9)
	leal	1(%rcx), %edx
	xorl	%r11d, %r11d
	cmpl	%eax, %ecx
	cmovael	%r11d, %edx
	movl	%edx, 32(%r9)
	movb	$2, 16(%r10)
	movl	24(%r10), %ecx
	leal	1(%rcx), %edx
	cmpl	%eax, %ecx
	cmovael	%r11d, %edx
	movl	%edx, 24(%r10)
	movq	%rdi, %rax
	jmp	.LBB27_26
.Lfunc_end27:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete, .Lfunc_end27-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel10capabilityNtB5_5Model8complete
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse,"ax",@progbits
	.prefalign	4, .Lfunc_end28, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse:
.Lfunc_begin28:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$952, %rsp
	.cfi_def_cfa_offset 1008
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	cmpq	$1048576, %rdx
	jbe	.LBB28_2
	movb	$3, (%rdi)
	jmp	.LBB28_23
.LBB28_2:
	cmpq	$64, %rdx
	jae	.LBB28_4
	movb	$2, (%rdi)
	jmp	.LBB28_23
.LBB28_4:
	cmpl	$1179403647, (%rsi)
	jne	.LBB28_22
	cmpb	$2, 4(%rsi)
	jne	.LBB28_21
	cmpb	$1, 5(%rsi)
	jne	.LBB28_21
	cmpb	$1, 6(%rsi)
	jne	.LBB28_21
	cmpb	$0, 7(%rsi)
	jne	.LBB28_21
	cmpb	$0, 8(%rsi)
	jne	.LBB28_21
	cmpb	$0, 9(%rsi)
	jne	.LBB28_21
	cmpb	$0, 10(%rsi)
	jne	.LBB28_21
	cmpb	$0, 11(%rsi)
	jne	.LBB28_21
	cmpb	$0, 12(%rsi)
	jne	.LBB28_21
	cmpb	$0, 13(%rsi)
	jne	.LBB28_21
	cmpb	$0, 14(%rsi)
	jne	.LBB28_21
	cmpb	$0, 15(%rsi)
	jne	.LBB28_21
	movzwl	16(%rsi), %eax
	shll	$16, %eax
	cmpl	$131072, %eax
	jne	.LBB28_21
	movzwl	18(%rsi), %eax
	shll	$16, %eax
	cmpl	$11993088, %eax
	jne	.LBB28_21
	cmpl	$1, 20(%rsi)
	jne	.LBB28_21
	cmpl	$0, 48(%rsi)
	je	.LBB28_25
.LBB28_21:
	movb	$1, (%rdi)
	jmp	.LBB28_23
.LBB28_22:
	movb	$0, (%rdi)
.LBB28_23:
	movb	$-1, 48(%rdi)
.LBB28_24:
	addq	$952, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB28_25:
	.cfi_def_cfa_offset 1008
	movq	%rdi, %rbx
	movzwl	52(%rsi), %eax
	shll	$16, %eax
	cmpl	$4194304, %eax
	jne	.LBB28_29
	movq	%rsi, %r12
	movzwl	54(%rsi), %eax
	shll	$16, %eax
	cmpl	$3670016, %eax
	jne	.LBB28_29
	movzwl	56(%r12), %ebp
	movl	%ebp, %eax
	shll	$16, %eax
	addl	$-1114112, %eax
	cmpl	$-1114112, %eax
	ja	.LBB28_30
	movb	$3, (%rbx)
	movb	$-1, 48(%rbx)
	jmp	.LBB28_24
.LBB28_29:
	movb	$0, (%rbx)
	movb	$-1, 48(%rbx)
	jmp	.LBB28_24
.LBB28_30:
	movq	32(%r12), %r14
	cmpq	$63, %r14
	ja	.LBB28_32
	movb	$4, (%rbx)
	movb	$-1, 48(%rbx)
	jmp	.LBB28_24
.LBB28_32:
	imulq	$56, %rbp, %rax
	addq	%r14, %rax
	jb	.LBB28_34
	movq	%rdx, %r15
	cmpq	%rdx, %rax
	jbe	.LBB28_35
.LBB28_34:
	movb	$2, (%rbx)
	movb	$-1, 48(%rbx)
	jmp	.LBB28_24
.LBB28_35:
	movq	24(%r12), %rax
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 512(%rsp)
	movq	$1, 504(%rsp)
	movq	$1, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$1, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 680(%rsp)
	movq	$1, 672(%rsp)
	movq	$0, 776(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 736(%rsp)
	movq	$1, 728(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 824(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 808(%rsp)
	movq	$0, 800(%rsp)
	movq	$0, 792(%rsp)
	movq	$1, 784(%rsp)
	movq	$0, 888(%rsp)
	movq	$0, 880(%rsp)
	movq	$0, 872(%rsp)
	movq	$0, 864(%rsp)
	movq	$0, 856(%rsp)
	movq	$0, 848(%rsp)
	movq	$1, 840(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 928(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 912(%rsp)
	movq	$0, 904(%rsp)
	movq	$1, 896(%rsp)
	movq	%rax, 480(%rsp)
	leaq	32(%rsp), %rdi
	leaq	504(%rsp), %rsi
	movl	$448, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	addq	$56, %r14
	movq	$0, (%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
.LBB28_36:
	imulq	$56, 16(%rsp), %rax
	addq	%r14, %rax
	movq	%rax, 8(%rsp)
.LBB28_37:
	movq	8(%rsp), %rax
	leaq	-56(%rax), %rdx
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at
	movq	%rax, %r13
	testb	$1, %r13b
	jne	.LBB28_101
	incq	16(%rsp)
	shrq	$32, %r13
	je	.LBB28_93
	movq	8(%rsp), %rax
	leaq	-52(%rax), %rdx
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at
	testb	$1, %al
	jne	.LBB28_102
	movq	8(%rsp), %rdx
	leaq	-48(%rdx), %rcx
	cmpq	$-8, %rcx
	setae	%cl
	addq	$-40, %rdx
	cmpq	%r15, %rdx
	seta	%dl
	orb	%cl, %dl
	movb	$2, %dl
	jne	.LBB28_103
	movq	8(%rsp), %rcx
	addq	$-32, %rcx
	cmpq	%r15, %rcx
	ja	.LBB28_103
	movq	8(%rsp), %rsi
	leaq	-24(%rsi), %rcx
	cmpq	$-8, %rcx
	setae	%cl
	addq	$-16, %rsi
	cmpq	%r15, %rsi
	seta	%sil
	orb	%cl, %sil
	jne	.LBB28_103
	movq	8(%rsp), %rcx
	addq	$-8, %rcx
	cmpq	%r15, %rcx
	ja	.LBB28_103
	cmpq	%r15, 8(%rsp)
	ja	.LBB28_103
	shrq	$32, %rax
	movq	8(%rsp), %r8
	movq	-24(%r12,%r8), %rdi
	movq	-16(%r12,%r8), %rsi
	movq	-8(%r12,%r8), %rcx
	cmpl	$1, %r13d
	jne	.LBB28_95
	cmpq	$8, (%rsp)
	je	.LBB28_140
	testq	%rsi, %rsi
	je	.LBB28_143
	cmpq	%rsi, %rdi
	ja	.LBB28_143
	movq	8(%rsp), %r10
	movq	-48(%r12,%r10), %r9
	movq	-40(%r12,%r10), %r8
	cmpq	$1, %rcx
	jbe	.LBB28_52
	leaq	-1(%rcx), %r10
	testq	%r10, %rcx
	jne	.LBB28_143
	movq	%r8, %rcx
	xorq	%r9, %rcx
	testq	%rcx, %r10
	je	.LBB28_53
	jmp	.LBB28_143
.LBB28_52:
	movq	%r8, %rcx
	xorq	%r9, %rcx
.LBB28_53:
	shlq	$52, %rcx
	jne	.LBB28_143
	addl	$-4, %eax
	cmpl	$2, %eax
	ja	.LBB28_142
	shll	$3, %eax
	movl	$66048, %r10d
	movl	%eax, %ecx
	shrl	%cl, %r10d
	movq	%rdi, %rax
	addq	%r9, %rax
	setb	%cl
	cmpq	%r15, %rax
	seta	%al
	orb	%cl, %al
	jne	.LBB28_103
	movq	%rsi, %rax
	addq	%r8, %rax
	jb	.LBB28_103
	cmpq	$-4096, %rax
	ja	.LBB28_103
	movq	%r8, %rcx
	shrq	$32, %rcx
	je	.LBB28_103
	movabsq	$4296015872, %rcx
	cmpq	%rcx, %rax
	ja	.LBB28_103
	addq	$4095, %rax
	movq	%rax, %rcx
	andq	$-4096, %rcx
	movabsq	$4296015872, %r11
	cmpq	%r11, %rcx
	ja	.LBB28_103
	cmpq	$9, (%rsp)
	jae	.LBB28_156
	movq	%r8, %r11
	andq	$-4096, %r11
	cmpq	$0, (%rsp)
	je	.LBB28_90
	cmpq	%r8, 48(%rsp)
	ja	.LBB28_143
	cmpq	72(%rsp), %r11
	jae	.LBB28_66
	cmpq	%rcx, 64(%rsp)
	jb	.LBB28_143
.LBB28_66:
	cmpq	$1, (%rsp)
	je	.LBB28_90
	cmpq	%r8, 104(%rsp)
	ja	.LBB28_143
	cmpq	128(%rsp), %r11
	jae	.LBB28_70
	cmpq	%rcx, 120(%rsp)
	jb	.LBB28_143
.LBB28_70:
	cmpq	$2, (%rsp)
	je	.LBB28_90
	cmpq	%r8, 160(%rsp)
	ja	.LBB28_143
	cmpq	184(%rsp), %r11
	jae	.LBB28_74
	cmpq	%rcx, 176(%rsp)
	jb	.LBB28_143
.LBB28_74:
	cmpq	$3, (%rsp)
	je	.LBB28_90
	cmpq	%r8, 216(%rsp)
	ja	.LBB28_143
	cmpq	240(%rsp), %r11
	jae	.LBB28_78
	cmpq	%rcx, 232(%rsp)
	jb	.LBB28_143
.LBB28_78:
	cmpq	$4, (%rsp)
	je	.LBB28_90
	cmpq	%r8, 272(%rsp)
	ja	.LBB28_143
	cmpq	296(%rsp), %r11
	jae	.LBB28_82
	cmpq	%rcx, 288(%rsp)
	jb	.LBB28_143
.LBB28_82:
	cmpq	$5, (%rsp)
	je	.LBB28_90
	cmpq	%r8, 328(%rsp)
	ja	.LBB28_143
	cmpq	352(%rsp), %r11
	jae	.LBB28_86
	cmpq	%rcx, 344(%rsp)
	jb	.LBB28_143
.LBB28_86:
	cmpq	$6, (%rsp)
	je	.LBB28_90
	cmpq	%r8, 384(%rsp)
	ja	.LBB28_143
	cmpq	408(%rsp), %r11
	jae	.LBB28_90
	movb	$4, %dl
	cmpq	%rcx, 400(%rsp)
	jb	.LBB28_103
.LBB28_90:
	subq	%r11, %rax
	shrq	$12, %rax
	addq	496(%rsp), %rax
	jb	.LBB28_140
	movq	%rax, 496(%rsp)
	movb	$3, %dl
	cmpq	$256, %rax
	ja	.LBB28_103
	addq	%r12, %r9
	imulq	$56, (%rsp), %rax
	movq	%r9, 32(%rsp,%rax)
	movq	%rdi, 40(%rsp,%rax)
	movq	%r8, 48(%rsp,%rax)
	movq	%rsi, 56(%rsp,%rax)
	movq	%r11, 64(%rsp,%rax)
	movq	%rcx, 72(%rsp,%rax)
	movb	%r10b, 80(%rsp,%rax)
	movq	488(%rsp), %rcx
	incq	%rcx
	movq	%rcx, (%rsp)
	movq	%rcx, 488(%rsp)
	addq	$56, 8(%rsp)
	cmpq	%rbp, 16(%rsp)
	jb	.LBB28_37
	jmp	.LBB28_104
.LBB28_93:
	movq	24(%rsp), %rax
	movl	%eax, %edx
.LBB28_94:
	movl	%edx, %eax
	movq	%rax, 24(%rsp)
	cmpq	%rbp, 16(%rsp)
	jb	.LBB28_36
	jmp	.LBB28_104
.LBB28_95:
	movb	$1, %dl
	cmpl	$1685382481, %r13d
	jne	.LBB28_103
	cmpl	$6, %eax
	jne	.LBB28_103
	movq	24(%rsp), %rax
	xorb	$1, %al
	testb	$1, %al
	je	.LBB28_103
	orq	%rdi, %rsi
	jne	.LBB28_103
	cmpq	$2, %rcx
	jb	.LBB28_94
	leaq	-1(%rcx), %rax
	xorq	%rax, %rcx
	cmpq	%rax, %rcx
	ja	.LBB28_94
	jmp	.LBB28_103
.LBB28_101:
	shrl	$8, %r13d
	movl	%r13d, %edx
	jmp	.LBB28_103
.LBB28_102:
	shrl	$8, %eax
	movl	%eax, %edx
.LBB28_103:
	movb	%dl, (%rbx)
	movb	$-1, 48(%rbx)
	jmp	.LBB28_24
.LBB28_104:
	cmpq	$0, (%rsp)
	je	.LBB28_143
	movq	480(%rsp), %rax
	movb	$6, %dl
	cmpq	$-5, %rax
	ja	.LBB28_103
	testb	$3, %al
	jne	.LBB28_103
	cmpq	$9, (%rsp)
	jae	.LBB28_156
	leaq	4(%rax), %rcx
	cmpb	$2, 80(%rsp)
	jne	.LBB28_111
	movq	48(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB28_111
	addq	40(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB28_139
.LBB28_111:
	cmpq	$1, (%rsp)
	je	.LBB28_103
	cmpb	$2, 136(%rsp)
	jne	.LBB28_115
	movq	104(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB28_115
	addq	96(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB28_139
.LBB28_115:
	cmpq	$2, (%rsp)
	je	.LBB28_103
	cmpb	$2, 192(%rsp)
	jne	.LBB28_119
	movq	160(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB28_119
	addq	152(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB28_139
.LBB28_119:
	cmpq	$3, (%rsp)
	je	.LBB28_103
	cmpb	$2, 248(%rsp)
	jne	.LBB28_123
	movq	216(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB28_123
	addq	208(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB28_139
.LBB28_123:
	cmpq	$4, (%rsp)
	je	.LBB28_103
	cmpb	$2, 304(%rsp)
	jne	.LBB28_127
	movq	272(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB28_127
	addq	264(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB28_139
.LBB28_127:
	cmpq	$5, (%rsp)
	je	.LBB28_103
	cmpb	$2, 360(%rsp)
	jne	.LBB28_131
	movq	328(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB28_131
	addq	320(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB28_139
.LBB28_131:
	cmpq	$6, (%rsp)
	je	.LBB28_103
	cmpb	$2, 416(%rsp)
	jne	.LBB28_135
	movq	384(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB28_135
	addq	376(%rsp), %rsi
	setb	%dil
	cmpq	%rsi, %rcx
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB28_139
.LBB28_135:
	cmpq	$7, (%rsp)
	je	.LBB28_103
	cmpb	$2, 472(%rsp)
	jne	.LBB28_103
	movq	440(%rsp), %rsi
	cmpq	%rsi, %rax
	jb	.LBB28_103
	addq	432(%rsp), %rsi
	setb	%al
	cmpq	%rsi, %rcx
	seta	%cl
	orb	%al, %cl
	jne	.LBB28_103
.LBB28_139:
	leaq	32(%rsp), %rsi
	movl	$472, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	jmp	.LBB28_24
.LBB28_143:
	movb	$4, %dl
	jmp	.LBB28_103
.LBB28_140:
	movb	$3, %dl
	jmp	.LBB28_103
.LBB28_142:
	movb	$5, %dl
	jmp	.LBB28_103
.LBB28_156:
	movl	$8, %edx
	xorl	%edi, %edi
	movq	(%rsp), %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end28:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse, .Lfunc_end28-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at,"ax",@progbits
	.prefalign	4, .Lfunc_end29, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at:
.Lfunc_begin29:
	.cfi_startproc
	movq	%rdx, %rax
	subq	$-4, %rax
	setae	%cl
	cmpq	%rsi, %rax
	seta	%al
	orb	%cl, %al
	je	.LBB29_2
	movb	$2, %dl
	jmp	.LBB29_3
.LBB29_2:
	movl	(%rdi,%rdx), %edx
	movl	%edx, %ecx
	shrl	$8, %ecx
.LBB29_3:
	shll	$8, %ecx
	movzbl	%dl, %edx
	orl	%edx, %ecx
	shlq	$32, %rcx
	xorl	%esi, %esi
	testb	%al, %al
	cmoveq	%rcx, %rsi
	shll	$8, %edx
	movzbl	%al, %eax
	orl	%edx, %eax
	movzwl	%ax, %eax
	orq	%rsi, %rax
	retq
.Lfunc_end29:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at, .Lfunc_end29-_RNvNtCsjFdXuXHMTfk_9hm_kernel3elf6u32_at
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse,"ax",@progbits
	.prefalign	4, .Lfunc_end30, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse:
.Lfunc_begin30:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1656, %rsp
	.cfi_def_cfa_offset 1712
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	cmpq	$40, %rdx
	jb	.LBB30_8
	cmpl	$-302117424, (%rsi)
	jne	.LBB30_8
	movl	4(%rsi), %ebx
	bswapl	%ebx
	leal	-40(%rbx), %eax
	cmpl	$2097113, %eax
	jae	.LBB30_8
	cmpl	$285212672, 20(%rsi)
	jne	.LBB30_8
	cmpl	$268435456, 24(%rsi)
	jne	.LBB30_8
	cmpq	%rbx, %rdx
	jb	.LBB30_6
	movl	8(%rsi), %r14d
	movl	12(%rsi), %r13d
	bswapl	%r14d
	bswapl	%r13d
	movl	36(%rsi), %r12d
	bswapl	%r12d
	leaq	(%r12,%r14), %rax
	cmpq	%r13, %rax
	ja	.LBB30_8
	movl	16(%rsi), %ebp
	bswapl	%ebp
	cmpl	%r14d, %ebp
	jae	.LBB30_8
	cmpl	$40, %ebp
	jb	.LBB30_8
	movl	%ebp, %ecx
	andl	$7, %ecx
	shlq	$32, %rcx
	movl	%r12d, %edx
	orl	%r14d, %edx
	andl	$3, %edx
	shlq	$32, %rdx
	orq	%rcx, %rdx
	jne	.LBB30_8
	cmpq	%rbx, %rax
	ja	.LBB30_6
	movl	32(%rsi), %ecx
	movl	%ecx, %edx
	bswapl	%edx
	leaq	(%rdx,%r13), %rax
	cmpq	%rbx, %rax
	jbe	.LBB30_19
.LBB30_6:
	movw	$257, (%rdi)
	jmp	.LBB30_9
.LBB30_8:
	movw	$1, (%rdi)
.LBB30_9:
	addq	$1656, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB30_19:
	.cfi_def_cfa_offset 1712
	movq	%rdx, 64(%rsp)
	movl	%ecx, 28(%rsp)
	movq	%rsi, 8(%rsp)
	movq	%r14, %r15
	subq	%rbp, %r15
	leaq	856(%rsp), %rax
	movl	$792, %edx
	movq	%rdi, (%rsp)
	movq	%rax, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	(%rsp), %rax
	movq	%rbx, 1648(%rsp)
	cmpq	$16, %r15
	jb	.LBB30_31
	movq	%r15, %rbx
	movq	8(%rsp), %r15
	addq	%r15, %r14
	addq	%r15, %r13
	addq	%r15, %rbp
	movl	$16, %edi
	xorl	%esi, %esi
	xorl	%ecx, %ecx
.LBB30_21:
	movq	(%rbp,%rcx), %rdx
	movq	8(%rbp,%rcx), %r8
	movq	%rdi, %rcx
	bswapq	%rdx
	movq	%r8, %rdi
	bswapq	%rdi
	movq	%rdi, %r9
	orq	%rdx, %r9
	je	.LBB30_33
	testq	%r8, %r8
	je	.LBB30_82
	addq	%rdx, %rdi
	jb	.LBB30_82
	cmpq	$33, %rsi
	jae	.LBB30_86
	movq	%rsi, %r9
	shlq	$4, %r9
	leaq	(%rsp,%r9), %r8
	addq	$856, %r8
	leaq	856(%rsp), %r10
.LBB30_26:
	testq	%r9, %r9
	je	.LBB30_29
	movq	%r10, %r11
	addq	$16, %r10
	addq	$-16, %r9
	cmpq	%rdi, (%r11)
	jae	.LBB30_26
	cmpq	8(%r11), %rdx
	jae	.LBB30_26
	jmp	.LBB30_32
.LBB30_29:
	cmpq	$32, %rsi
	je	.LBB30_85
	movq	%rdx, (%r8)
	movq	%rdi, 8(%r8)
	movq	1632(%rsp), %rsi
	incq	%rsi
	movq	%rsi, 1632(%rsp)
	leaq	16(%rcx), %rdi
	leaq	15(%rcx), %rdx
	cmpq	%rbx, %rdx
	jb	.LBB30_21
.LBB30_31:
	movw	$257, (%rax)
	jmp	.LBB30_9
.LBB30_32:
	movw	$1793, (%rax)
	jmp	.LBB30_9
.LBB30_33:
	movq	%r14, 32(%rsp)
	movq	%r12, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$1024, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$1024, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$1024, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$1024, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$1024, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$1024, 224(%rsp)
	movq	$1024, 248(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$1024, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$1024, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$1024, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$1024, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$1024, 368(%rsp)
	movq	$1024, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 376(%rsp)
	movq	$1024, 416(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$1024, 440(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 424(%rsp)
	movq	$1024, 464(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 448(%rsp)
	movq	$1024, 488(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$1024, 512(%rsp)
	movq	$1024, 536(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 520(%rsp)
	movq	$1024, 560(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	movq	$1024, 584(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 568(%rsp)
	movq	$1024, 608(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 592(%rsp)
	movq	$1024, 632(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 616(%rsp)
	movq	$1024, 656(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 640(%rsp)
	movq	$1024, 680(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 664(%rsp)
	movq	$1024, 704(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 688(%rsp)
	movq	$1024, 728(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 712(%rsp)
	movq	$1024, 752(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 736(%rsp)
	movq	$1024, 776(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 760(%rsp)
	movq	$1024, 800(%rsp)
	movq	$0, 792(%rsp)
	movq	$0, 784(%rsp)
	movq	$1024, 824(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 808(%rsp)
	movq	$1024, 848(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 832(%rsp)
	cmpl	$4, %r12d
	jb	.LBB30_83
	movl	$4, %ebp
	xorl	%ebx, %ebx
	movq	%r12, 8(%rsp)
	xorl	%r15d, %r15d
	movq	$0, 56(%rsp)
	movq	$0, 16(%rsp)
.LBB30_35:
	movq	%rbp, 48(%rsp)
	movl	(%r14,%rbx), %eax
	bswapl	%eax
	decl	%eax
	cmpl	$8, %eax
	ja	.LBB30_92
	jmpq	*.LJTI30_0(,%rax,8)
.LBB30_37:
	leaq	72(%rsp), %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_6Cursor4name
	movq	72(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB30_93
	movq	32(%rsp), %r14
	movq	80(%rsp), %rax
	testq	%r15, %r15
	je	.LBB30_60
	testq	%rax, %rax
	je	.LBB30_92
	cmpq	$33, %r15
	jae	.LBB30_92
	leaq	(%r15,%r15,2), %rcx
	movb	$1, 82(%rsp,%rcx,8)
	movzbl	81(%rsp,%rcx,8), %ecx
	jmpq	*.LJTI30_1(,%rcx,8)
.LBB30_42:
	cmpq	$6, %rax
	je	.LBB30_72
	cmpq	$15, %rax
	jne	.LBB30_73
	movzwl	12(%rsi), %eax
	movzbl	14(%rsi), %ecx
	shll	$16, %ecx
	orl	%eax, %ecx
	shlq	$32, %rcx
	movl	8(%rsi), %eax
	orq	%rcx, %rax
	movabsq	$34184295084289325, %rcx
	xorq	%rcx, %rax
	movq	(%rsi), %rcx
	movabsq	$7234318610140980594, %rdx
	xorq	%rdx, %rcx
	orq	%rax, %rcx
	jne	.LBB30_74
	testb	$1, 56(%rsp)
	jne	.LBB30_97
	movb	$2, %al
	movb	$1, %cl
	movq	%rcx, 56(%rsp)
	cmpq	$32, %r15
	jne	.LBB30_77
	jmp	.LBB30_81
.LBB30_47:
	testq	%r15, %r15
	je	.LBB30_92
	cmpq	$33, %r15
	jae	.LBB30_92
	movq	%r15, %rax
	decq	%rax
	movq	%rax, %r15
	leaq	(%rax,%rax,2), %rax
	leaq	(%rsp,%rax,8), %rdi
	addq	$88, %rdi
	leaq	856(%rsp), %rsi
	callq	_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node6finish
	movq	%rbp, %rbx
	cmpb	$-1, %al
	je	.LBB30_78
	jmp	.LBB30_94
.LBB30_50:
	movq	%rbp, %rbx
	jmp	.LBB30_78
.LBB30_51:
	cmpq	$-5, %rbp
	ja	.LBB30_83
	leaq	4(%rbp), %rax
	cmpq	8(%rsp), %rax
	ja	.LBB30_83
	movq	%rax, 48(%rsp)
	cmpq	$-5, %rax
	ja	.LBB30_83
	leaq	8(%rbp), %rcx
	cmpq	8(%rsp), %rcx
	ja	.LBB30_83
	movl	(%r14,%rax), %edx
	movl	%edx, %eax
	bswapl	%eax
	cmpl	64(%rsp), %eax
	ja	.LBB30_83
	cmpl	28(%rsp), %edx
	je	.LBB30_92
	movl	(%r14,%rbp), %r8d
	bswapl	%r8d
	movl	%eax, %edx
	leaq	(%rdx,%r13), %rsi
	movq	64(%rsp), %rax
	subq	%rdx, %rax
	xorl	%edx, %edx
.LBB30_58:
	cmpb	$0, (%rsi,%rdx)
	je	.LBB30_64
	incq	%rdx
	cmpq	%rdx, %rax
	jne	.LBB30_58
	jmp	.LBB30_92
.LBB30_60:
	testq	%rax, %rax
	jne	.LBB30_92
	testb	$1, 16(%rsp)
	jne	.LBB30_92
	xorl	%eax, %eax
	movb	$1, %cl
	movq	%rcx, 16(%rsp)
	jmp	.LBB30_77
.LBB30_63:
	movb	$3, %al
	cmpq	$32, %r15
	jne	.LBB30_77
	jmp	.LBB30_81
.LBB30_64:
	testq	%rdx, %rdx
	je	.LBB30_92
	movq	%rcx, %rax
	addq	%r8, %rax
	jb	.LBB30_83
	cmpq	8(%rsp), %rax
	ja	.LBB30_83
	movl	%eax, %ebx
	negl	%ebx
	andl	$3, %ebx
	addq	%rax, %rbx
	jb	.LBB30_83
	cmpq	8(%rsp), %rbx
	ja	.LBB30_83
	movq	%rbx, 48(%rsp)
	testq	%r15, %r15
	je	.LBB30_92
	cmpq	$33, %r15
	jae	.LBB30_98
	addq	%r14, %rcx
	leaq	(%r15,%r15,2), %rax
	leaq	(%rsp,%rax,8), %rdi
	addq	$64, %rdi
	callq	_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property
	cmpb	$-1, %al
	je	.LBB30_78
	jmp	.LBB30_94
.LBB30_72:
	movl	(%rsi), %eax
	movzwl	4(%rsi), %ecx
	shlq	$32, %rcx
	orq	%rax, %rcx
	movb	$1, %al
	movabsq	$133532402673005, %rdx
	cmpq	%rdx, %rcx
	jne	.LBB30_75
	jmp	.LBB30_76
.LBB30_73:
	cmpq	$7, %rax
	jb	.LBB30_75
.LBB30_74:
	movl	$7, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.67, %rdi
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	je	.LBB30_80
.LBB30_75:
	movb	$4, %al
.LBB30_76:
	cmpq	$32, %r15
	je	.LBB30_81
.LBB30_77:
	leaq	(%r15,%r15,2), %rcx
	movq	$0, 88(%rsp,%rcx,8)
	movb	$0, 104(%rsp,%rcx,8)
	movb	%al, 105(%rsp,%rcx,8)
	movb	$0, 106(%rsp,%rcx,8)
	incq	%r15
	movq	40(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	48(%rsp), %rbx
.LBB30_78:
	cmpq	$-5, %rbx
	ja	.LBB30_83
	leaq	4(%rbx), %rbp
	cmpq	8(%rsp), %rbp
	ja	.LBB30_83
	jmp	.LBB30_35
.LBB30_80:
	movb	$1, %al
	cmpq	$32, %r15
	jne	.LBB30_77
.LBB30_81:
	movq	(%rsp), %rax
	movb	$5, 1(%rax)
	jmp	.LBB30_84
.LBB30_82:
	movw	$1537, (%rax)
	jmp	.LBB30_9
.LBB30_83:
	movq	(%rsp), %rax
	movb	$1, 1(%rax)
.LBB30_84:
	movb	$1, %cl
	movb	%cl, (%rax)
	jmp	.LBB30_9
.LBB30_85:
	movw	$1281, (%rax)
	jmp	.LBB30_9
.LBB30_86:
	movl	$32, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB30_87:
	testq	%r15, %r15
	jne	.LBB30_92
	testb	$1, 16(%rsp)
	je	.LBB30_92
	cmpq	%r12, %rbp
	jne	.LBB30_92
	cmpq	$0, 1624(%rsp)
	je	.LBB30_96
	movq	(%rsp), %rbx
	leaq	8(%rbx), %rdi
	leaq	856(%rsp), %rsi
	movl	$800, %edx
	callq	*memcpy@GOTPCREL(%rip)
	xorl	%eax, %eax
	movb	%al, (%rbx)
	jmp	.LBB30_9
.LBB30_92:
	movq	(%rsp), %rax
	movb	$2, 1(%rax)
	jmp	.LBB30_84
.LBB30_93:
	movzbl	80(%rsp), %eax
.LBB30_94:
	movq	(%rsp), %rcx
	movb	%al, 1(%rcx)
	movb	$1, %al
	movb	%al, (%rcx)
	jmp	.LBB30_9
.LBB30_95:
	movq	(%rsp), %rax
	movb	$3, 1(%rax)
	jmp	.LBB30_84
.LBB30_96:
	movq	(%rsp), %rax
	movb	$8, 1(%rax)
	jmp	.LBB30_84
.LBB30_97:
	movq	(%rsp), %rax
	movb	$4, 1(%rax)
	jmp	.LBB30_84
.LBB30_98:
	movb	$2, %al
	jmp	.LBB30_94
.Lfunc_end30:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse, .Lfunc_end30-_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse,"a",@progbits
	.p2align	3, 0x0
.LJTI30_0:
	.quad	.LBB30_37
	.quad	.LBB30_47
	.quad	.LBB30_51
	.quad	.LBB30_50
	.quad	.LBB30_92
	.quad	.LBB30_92
	.quad	.LBB30_92
	.quad	.LBB30_92
	.quad	.LBB30_87
.LJTI30_1:
	.quad	.LBB30_42
	.quad	.LBB30_95
	.quad	.LBB30_63
	.quad	.LBB30_95
	.quad	.LBB30_75

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_6Cursor4name,"ax",@progbits
	.prefalign	4, .Lfunc_end31, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_6Cursor4name,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_6Cursor4name:
.Lfunc_begin31:
	.cfi_startproc
	movq	8(%rsi), %rdx
	movq	16(%rsi), %r8
	cmpq	%r8, %rdx
	jae	.LBB31_2
	movb	$1, 8(%rdi)
	movq	$0, (%rdi)
	retq
.LBB31_2:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rcx
	subq	%r8, %rcx
	je	.LBB31_6
	movq	(%rsi), %rax
	leaq	(%rax,%r8), %rbx
	xorl	%r14d, %r14d
	.p2align	4
.LBB31_4:
	cmpb	$0, (%rbx,%r14)
	je	.LBB31_8
	incq	%r14
	cmpq	%r14, %rcx
	jne	.LBB31_4
.LBB31_6:
	movb	$2, 8(%rdi)
.LBB31_7:
	movq	$0, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
	retq
.LBB31_8:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	leaq	(%r8,%r14), %rcx
	incq	%rcx
	cmpq	%r8, %rcx
	setae	%r8b
	cmpq	%rdx, %rcx
	setbe	%r9b
	testb	%r9b, %r8b
	jne	.LBB31_10
	movb	$1, 8(%rdi)
	jmp	.LBB31_7
.LBB31_10:
	movq	%rcx, 16(%rsi)
	movl	%ecx, %r8d
	negl	%r8d
	andl	$3, %r8d
	movq	%r8, %r9
	addq	%rcx, %r9
	setb	%r10b
	cmpq	%rdx, %r9
	seta	%dl
	orb	%r10b, %dl
	movb	$1, %dl
	jne	.LBB31_13
	movq	%r9, 16(%rsi)
	testq	%r8, %r8
	je	.LBB31_15
	movb	$2, %dl
	cmpb	$0, (%rax,%rcx)
	je	.LBB31_14
.LBB31_13:
	movb	%dl, 8(%rdi)
	jmp	.LBB31_7
.LBB31_14:
	cmpl	$1, %r8d
	jne	.LBB31_22
.LBB31_15:
	cmpq	$15, %r14
	ja	.LBB31_20
	testq	%r14, %r14
	je	.LBB31_21
	xorl	%eax, %eax
.LBB31_18:
	cmpb	$47, (%rbx,%rax)
	je	.LBB31_6
	incq	%rax
	cmpq	%rax, %r14
	jne	.LBB31_18
	jmp	.LBB31_21
.LBB31_20:
	movq	%rdi, %r15
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned
	movq	%r15, %rdi
	testb	$1, %al
	jne	.LBB31_6
.LBB31_21:
	movq	%rbx, (%rdi)
	movq	%r14, 8(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
	retq
.LBB31_22:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	cmpb	$0, 1(%rax,%rcx)
	jne	.LBB31_13
	cmpl	$2, %r8d
	je	.LBB31_15
	cmpb	$0, 2(%rax,%rcx)
	jne	.LBB31_13
	jmp	.LBB31_15
.Lfunc_end31:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_6Cursor4name, .Lfunc_end31-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_6Cursor4name
	.cfi_endproc

	.section	.text._RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node6finish,"ax",@progbits
	.prefalign	4, .Lfunc_end32, nop
	.type	_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node6finish,@function
_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node6finish:
.Lfunc_begin32:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movzbl	17(%rdi), %r8d
	leal	(,%r8,8), %ecx
	movabsq	$1099376945148, %rdx
	shrq	%cl, %rdx
	orb	16(%rdi), %dl
	movb	$2, %al
	cmpb	$-1, %dl
	jne	.LBB32_22
	movq	(%rdi), %rdx
	testq	%rdx, %rdx
	je	.LBB32_19
	movq	8(%rdi), %rdi
	andq	$-16, %rdi
	je	.LBB32_19
	addq	%rdx, %rdi
	cmpb	$1, %r8b
	jne	.LBB32_15
	leaq	512(%rsi), %r8
	movb	$6, %al
.LBB32_5:
	movq	8(%rdx), %r9
	testq	%r9, %r9
	je	.LBB32_22
	movq	(%rdx), %r10
	bswapq	%r10
	bswapq	%r9
	movq	%r9, %r11
	addq	%r10, %r11
	jb	.LBB32_22
	movq	768(%rsi), %rcx
	cmpq	$16, %rcx
	ja	.LBB32_24
	addq	$16, %rdx
	movq	%rcx, %r14
	shlq	$4, %r14
	leaq	(%r8,%r14), %rbx
	movq	%r8, %r12
	.p2align	4
.LBB32_9:
	testq	%r14, %r14
	je	.LBB32_12
	movq	%r12, %r15
	addq	$16, %r12
	addq	$-16, %r14
	cmpq	%r11, (%r15)
	jae	.LBB32_9
	cmpq	8(%r15), %r10
	jae	.LBB32_9
	jmp	.LBB32_20
.LBB32_12:
	addq	784(%rsi), %r9
	jb	.LBB32_22
	cmpq	$16, %rcx
	je	.LBB32_21
	movq	%r10, (%rbx)
	movq	%r11, 8(%rbx)
	incq	768(%rsi)
	movq	%r9, 784(%rsi)
	cmpq	%rdi, %rdx
	jne	.LBB32_5
	jmp	.LBB32_19
	.p2align	4
.LBB32_15:
	movq	8(%rdx), %rcx
	movb	$6, %al
	testq	%rcx, %rcx
	je	.LBB32_22
	movq	(%rdx), %r8
	bswapq	%r8
	bswapq	%rcx
	addq	%r8, %rcx
	jb	.LBB32_22
	movq	776(%rsi), %rax
	cmpq	$32, %rax
	jae	.LBB32_21
	shlq	$4, %rax
	movq	%r8, (%rsi,%rax)
	movq	%rcx, 8(%rsi,%rax)
	incq	776(%rsi)
	addq	$16, %rdx
	cmpq	%rdi, %rdx
	jne	.LBB32_15
.LBB32_19:
	movb	$-1, %al
	jmp	.LBB32_22
.LBB32_20:
	movb	$7, %al
	jmp	.LBB32_22
.LBB32_21:
	movb	$5, %al
.LBB32_22:
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB32_24:
	.cfi_def_cfa_offset 48
	movl	$16, %edx
	xorl	%edi, %edi
	movq	%rcx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end32:
	.size	_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node6finish, .Lfunc_end32-_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node6finish
	.cfi_endproc

	.section	.text._RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property,"ax",@progbits
	.prefalign	4, .Lfunc_end33, nop
	.type	_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property,@function
_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property:
.Lfunc_begin33:
	.cfi_startproc
	movb	$2, %al
	cmpb	$0, 18(%rdi)
	je	.LBB33_2
.LBB33_1:
	retq
.LBB33_2:
	cmpq	$11, %rdx
	jne	.LBB33_10
	movzwl	8(%rsi), %eax
	movzbl	10(%rsi), %r9d
	shll	$16, %r9d
	orq	%rax, %r9
	movabsq	$8385532508832687460, %rax
	xorq	(%rsi), %rax
	xorq	$6647929, %r9
	orq	%rax, %r9
	jne	.LBB33_10
	movzbl	16(%rdi), %r9d
	movb	$4, %al
	testb	$16, %r9b
	jne	.LBB33_1
	orb	$16, %r9b
	movb	%r9b, 16(%rdi)
	cmpb	$1, 17(%rdi)
	jne	.LBB33_8
	movb	$3, %al
	cmpq	$7, %r8
	jne	.LBB33_1
	movzwl	4(%rcx), %r9d
	movzbl	6(%rcx), %r10d
	shll	$16, %r10d
	orl	%r9d, %r10d
	shlq	$32, %r10
	movl	(%rcx), %r9d
	orq	%r10, %r9
	movabsq	$133532402673005, %r10
	cmpq	%r10, %r9
	je	.LBB33_10
	jmp	.LBB33_1
.LBB33_8:
	cmpq	$7, %r8
	jne	.LBB33_10
	movzwl	4(%rcx), %eax
	movzbl	6(%rcx), %r9d
	shll	$16, %r9d
	orl	%eax, %r9d
	shlq	$32, %r9
	movl	(%rcx), %r10d
	orq	%r9, %r10
	movb	$3, %al
	movabsq	$133532402673005, %r9
	cmpq	%r9, %r10
	je	.LBB33_1
.LBB33_10:
	movzbl	17(%rdi), %r9d
	movzbl	%r9b, %eax
	jmpq	*.LJTI33_0(,%rax,8)
.LBB33_11:
	cmpq	$6, %rdx
	je	.LBB33_50
	cmpl	$11, %edx
	je	.LBB33_36
	cmpl	$14, %edx
	jne	.LBB33_65
	cmpb	$35, (%rsi)
	jne	.LBB33_65
	cmpb	$97, 1(%rsi)
	jne	.LBB33_65
	cmpb	$100, 2(%rsi)
	jne	.LBB33_65
	cmpb	$100, 3(%rsi)
	jne	.LBB33_65
	cmpb	$114, 4(%rsi)
	jne	.LBB33_65
	cmpb	$101, 5(%rsi)
	jne	.LBB33_65
	cmpb	$115, 6(%rsi)
	jne	.LBB33_65
	cmpb	$115, 7(%rsi)
	jne	.LBB33_65
	cmpb	$45, 8(%rsi)
	jne	.LBB33_65
	cmpb	$99, 9(%rsi)
	jne	.LBB33_65
	cmpb	$101, 10(%rsi)
	jne	.LBB33_65
	cmpb	$108, 11(%rsi)
	jne	.LBB33_65
	cmpb	$108, 12(%rsi)
	jne	.LBB33_65
	cmpb	$115, 13(%rsi)
	jne	.LBB33_65
	movl	8(%rsi), %eax
	movzwl	12(%rsi), %r10d
	shlq	$32, %r10
	orq	%rax, %r10
	movabsq	$8319104478668415267, %rax
	xorq	(%rsi), %rax
	movabsq	$126909512246061, %r11
	xorq	%r10, %r11
	orq	%rax, %r11
	sete	%al
	movb	$2, %r10b
	subb	%al, %r10b
	jmp	.LBB33_47
.LBB33_29:
	cmpq	$3, %rdx
	je	.LBB33_32
	cmpl	$6, %edx
	je	.LBB33_59
	jmp	.LBB33_65
.LBB33_32:
	movzwl	(%rsi), %eax
	movzbl	2(%rsi), %r10d
	shll	$16, %r10d
	orl	%eax, %r10d
	cmpl	$6776178, %r10d
	jne	.LBB33_65
	movzbl	16(%rdi), %r10d
	movb	$4, %al
	testb	$8, %r10b
	jne	.LBB33_1
	orb	$8, %r10b
	movb	%r10b, 16(%rdi)
	testq	%r8, %r8
	sete	%al
	testb	$15, %r8b
	setne	%r10b
	orb	%al, %r10b
	movb	$2, %al
	jne	.LBB33_1
	movq	%rcx, (%rdi)
	movq	%r8, 8(%rdi)
	jmp	.LBB33_65
.LBB33_36:
	cmpb	$35, (%rsi)
	jne	.LBB33_65
	cmpb	$115, 1(%rsi)
	jne	.LBB33_65
	cmpb	$105, 2(%rsi)
	jne	.LBB33_65
	cmpb	$122, 3(%rsi)
	jne	.LBB33_65
	cmpb	$101, 4(%rsi)
	jne	.LBB33_65
	cmpb	$45, 5(%rsi)
	jne	.LBB33_65
	cmpb	$99, 6(%rsi)
	jne	.LBB33_65
	cmpb	$101, 7(%rsi)
	jne	.LBB33_65
	cmpb	$108, 8(%rsi)
	jne	.LBB33_65
	cmpb	$108, 9(%rsi)
	jne	.LBB33_65
	movb	$2, %r10b
	cmpb	$115, 10(%rsi)
	jne	.LBB33_65
.LBB33_47:
	movzbl	16(%rdi), %r11d
	movb	$4, %al
	testb	%r10b, %r11b
	jne	.LBB33_1
	orb	%r10b, %r11b
	movb	%r11b, 16(%rdi)
	movb	$3, %al
	cmpq	$4, %r8
	jne	.LBB33_1
	cmpl	$33554432, (%rcx)
	jne	.LBB33_1
	jmp	.LBB33_65
.LBB33_50:
	cmpb	$114, (%rsi)
	jne	.LBB33_59
	cmpb	$97, 1(%rsi)
	jne	.LBB33_59
	cmpb	$110, 2(%rsi)
	jne	.LBB33_59
	cmpb	$103, 3(%rsi)
	jne	.LBB33_59
	cmpb	$101, 4(%rsi)
	jne	.LBB33_59
	cmpb	$2, %r9b
	jne	.LBB33_59
	cmpb	$115, 5(%rsi)
	jne	.LBB33_59
	movzbl	16(%rdi), %r10d
	movb	$4, %al
	testb	$4, %r10b
	jne	.LBB33_1
	orb	$4, %r10b
	movb	%r10b, 16(%rdi)
	movb	$3, %al
	testq	%r8, %r8
	jne	.LBB33_1
.LBB33_59:
	movl	(%rsi), %eax
	movzwl	4(%rsi), %r10d
	shlq	$32, %r10
	orq	%rax, %r10
	movabsq	$126948300911731, %rax
	cmpq	%rax, %r10
	jne	.LBB33_65
	movzbl	16(%rdi), %r10d
	movb	$4, %al
	testb	$32, %r10b
	jne	.LBB33_1
	orb	$32, %r10b
	movb	%r10b, 16(%rdi)
	movb	$3, %al
	cmpq	$3, %r8
	je	.LBB33_64
	cmpl	$5, %r8d
	jne	.LBB33_1
	movl	(%rcx), %edi
	movzbl	4(%rcx), %ecx
	shlq	$32, %rcx
	orq	%rdi, %rcx
	cmpq	$2036427631, %rcx
	jne	.LBB33_1
	jmp	.LBB33_65
.LBB33_64:
	movzwl	(%rcx), %edi
	movzbl	2(%rcx), %ecx
	shll	$16, %ecx
	orl	%edi, %ecx
	cmpl	$27503, %ecx
	jne	.LBB33_1
.LBB33_65:
	andb	$6, %r9b
	cmpb	$2, %r9b
	jne	.LBB33_31
	addl	$-4, %edx
	cmpl	$8, %edx
	ja	.LBB33_31
	jmpq	*.LJTI33_1(,%rdx,8)
.LBB33_68:
	cmpb	$115, (%rsi)
	jne	.LBB33_31
	cmpb	$105, 1(%rsi)
	jne	.LBB33_31
	cmpb	$122, 2(%rsi)
	movb	$-1, %al
	jne	.LBB33_1
	movb	$101, %al
	movl	$3, %ecx
.LBB33_72:
	cmpb	%al, (%rsi,%rcx)
	setne	%al
	negb	%al
	orb	$3, %al
	retq
.LBB33_74:
	cmpb	$114, (%rsi)
	jne	.LBB33_31
	cmpb	$101, 1(%rsi)
	jne	.LBB33_31
	cmpb	$117, 2(%rsi)
	jne	.LBB33_31
	cmpb	$115, 3(%rsi)
	jne	.LBB33_31
	cmpb	$97, 4(%rsi)
	jne	.LBB33_31
	cmpb	$98, 5(%rsi)
	jne	.LBB33_31
	cmpb	$108, 6(%rsi)
	movb	$-1, %al
	jne	.LBB33_1
	movb	$101, %al
	movl	$7, %ecx
	jmp	.LBB33_72
.LBB33_82:
	cmpb	$110, (%rsi)
	jne	.LBB33_31
	cmpb	$111, 1(%rsi)
	jne	.LBB33_31
	cmpb	$45, 2(%rsi)
	jne	.LBB33_31
	cmpb	$109, 3(%rsi)
	jne	.LBB33_31
	cmpb	$97, 4(%rsi)
	movb	$-1, %al
	jne	.LBB33_1
	movb	$112, %al
	movl	$5, %ecx
	jmp	.LBB33_72
.LBB33_88:
	cmpb	$97, (%rsi)
	jne	.LBB33_31
	cmpb	$108, 1(%rsi)
	jne	.LBB33_31
	cmpb	$105, 2(%rsi)
	jne	.LBB33_31
	cmpb	$103, 3(%rsi)
	jne	.LBB33_31
	cmpb	$110, 4(%rsi)
	jne	.LBB33_31
	cmpb	$109, 5(%rsi)
	jne	.LBB33_31
	cmpb	$101, 6(%rsi)
	jne	.LBB33_31
	cmpb	$110, 7(%rsi)
	movb	$-1, %al
	jne	.LBB33_1
	movb	$116, %al
	movl	$8, %ecx
	jmp	.LBB33_72
.LBB33_97:
	cmpb	$97, (%rsi)
	jne	.LBB33_31
	cmpb	$108, 1(%rsi)
	jne	.LBB33_31
	cmpb	$108, 2(%rsi)
	jne	.LBB33_31
	cmpb	$111, 3(%rsi)
	jne	.LBB33_31
	cmpb	$99, 4(%rsi)
	jne	.LBB33_31
	cmpb	$45, 5(%rsi)
	jne	.LBB33_31
	cmpb	$114, 6(%rsi)
	jne	.LBB33_31
	cmpb	$97, 7(%rsi)
	jne	.LBB33_31
	cmpb	$110, 8(%rsi)
	jne	.LBB33_31
	cmpb	$103, 9(%rsi)
	jne	.LBB33_31
	cmpb	$101, 10(%rsi)
	movb	$-1, %al
	jne	.LBB33_1
	movb	$115, %al
	movl	$11, %ecx
	jmp	.LBB33_72
.LBB33_31:
	movb	$-1, %al
	retq
.Lfunc_end33:
	.size	_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property, .Lfunc_end33-_RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property
	.cfi_endproc
	.section	.rodata._RNvMs1_NtCsjFdXuXHMTfk_9hm_kernel11boot_memoryNtB5_4Node8property,"a",@progbits
	.p2align	3, 0x0
.LJTI33_0:
	.quad	.LBB33_11
	.quad	.LBB33_29
	.quad	.LBB33_11
	.quad	.LBB33_29
	.quad	.LBB33_31
.LJTI33_1:
	.quad	.LBB33_68
	.quad	.LBB33_31
	.quad	.LBB33_82
	.quad	.LBB33_31
	.quad	.LBB33_74
	.quad	.LBB33_88
	.quad	.LBB33_31
	.quad	.LBB33_31
	.quad	.LBB33_97

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse,"ax",@progbits
	.prefalign	4, .Lfunc_end34, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse:
.Lfunc_begin34:
	.cfi_startproc
	cmpq	$40, %rdx
	jb	.LBB34_7
	cmpl	$-302117424, (%rsi)
	jne	.LBB34_7
	movl	4(%rsi), %ecx
	bswapl	%ecx
	leal	-40(%rcx), %eax
	cmpl	$2097113, %eax
	jae	.LBB34_7
	cmpl	$285212672, 20(%rsi)
	jne	.LBB34_7
	cmpl	$268435456, 24(%rsi)
	jne	.LBB34_7
	cmpl	$0, 28(%rsi)
	je	.LBB34_8
	movb	$3, (%rdi)
	movb	$-1, 24(%rdi)
	retq
.LBB34_7:
	movb	$0, (%rdi)
	movb	$-1, 24(%rdi)
	retq
.LBB34_8:
	cmpq	%rcx, %rdx
	jae	.LBB34_10
	movb	$1, (%rdi)
	movb	$-1, 24(%rdi)
	retq
.LBB34_10:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$2264, %rsp
	.cfi_def_cfa_offset 6416
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	8(%rsi), %eax
	bswapl	%eax
	movl	16(%rsi), %edx
	bswapl	%edx
	cmpl	%eax, %edx
	jae	.LBB34_17
	cmpl	$40, %edx
	jb	.LBB34_17
	movl	36(%rsi), %ebp
	bswapl	%ebp
	movl	%edx, %r8d
	andl	$7, %r8d
	shlq	$32, %r8
	movl	%ebp, %r9d
	orl	%eax, %r9d
	andl	$3, %r9d
	shlq	$32, %r9
	orq	%r8, %r9
	jne	.LBB34_17
	movl	12(%rsi), %ebx
	bswapl	%ebx
	leaq	(%rax,%rbp), %r8
	cmpq	%rbx, %r8
	ja	.LBB34_17
	cmpq	%rcx, %r8
	ja	.LBB34_16
	movl	32(%rsi), %r14d
	bswapl	%r14d
	leaq	(%r14,%rbx), %r8
	cmpq	%rcx, %r8
	jbe	.LBB34_20
.LBB34_16:
	movb	$1, (%rdi)
	jmp	.LBB34_18
.LBB34_17:
	movb	$0, (%rdi)
.LBB34_18:
	movb	$-1, 24(%rdi)
.LBB34_19:
	addq	$6360, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r12
	.cfi_restore %r13
	.cfi_restore %r14
	.cfi_restore %r15
	.cfi_restore %rbp
	retq
.LBB34_20:
	.cfi_def_cfa_offset 6416
	.cfi_offset %rbx, -56
	.cfi_offset %rbp, -16
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	leaq	(%rsi,%rax), %r15
	addq	%rsi, %rbx
	subq	%rdx, %rax
	addq	%rdx, %rsi
	movl	$15, %ecx
.LBB34_21:
	cmpq	%rax, %rcx
	jae	.LBB34_16
	movq	-15(%rsi,%rcx), %rdx
	movq	-7(%rsi,%rcx), %r8
	bswapq	%rdx
	bswapq	%r8
	movq	%r8, %r9
	orq	%rdx, %r9
	je	.LBB34_25
	negq	%r8
	addq	$16, %rcx
	cmpq	%r8, %rdx
	jb	.LBB34_21
	movb	$2, (%rdi)
	jmp	.LBB34_18
.LBB34_25:
	movq	%rdi, 16(%rsp)
	movq	%r15, 56(%rsp)
	movq	%rbp, 64(%rsp)
	movq	$0, 72(%rsp)
	leaq	216(%rsp), %rdi
	movq	memcpy@GOTPCREL(%rip), %r12
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	408(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	600(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	792(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	984(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	1176(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	1368(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	1560(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	1752(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	1944(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	2136(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	2328(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	2520(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	2712(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	2904(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	3096(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	3288(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	3480(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	3672(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	3864(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	4056(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	4248(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	4440(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	4632(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	4824(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	5016(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	5208(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	5400(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	5592(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	5784(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	5976(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	leaq	6168(%rsp), %rdi
	movl	$192, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, %rsi
	callq	*%r12
	movw	$0, 28(%rsp)
	movw	$0, 30(%rsp)
	cmpl	$4, %ebp
	jb	.LBB34_105
	movb	$2, 15(%rsp)
	movl	$4, %eax
	xorl	%r13d, %r13d
	movq	%rbp, 32(%rsp)
	xorl	%r12d, %r12d
	movq	$0, 80(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
.LBB34_27:
	movq	%rax, 72(%rsp)
	movl	(%r15,%r13), %ecx
	bswapl	%ecx
	decl	%ecx
	cmpl	$8, %ecx
	ja	.LBB34_115
	jmpq	*.LJTI34_0(,%rcx,8)
.LBB34_29:
	leaq	88(%rsp), %rdi
	leaq	56(%rsp), %rsi
	callq	_RNvMs_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB4_6Cursor4name
	movq	88(%rsp), %r13
	testq	%r13, %r13
	je	.LBB34_116
	movq	56(%rsp), %r15
	movq	96(%rsp), %rdx
	testq	%r12, %r12
	je	.LBB34_59
	testq	%rdx, %rdx
	je	.LBB34_115
	cmpq	$33, %r12
	jae	.LBB34_115
	leaq	(%r12,%r12,2), %rax
	shlq	$6, %rax
	movb	$1, 208(%rsp,%rax)
	movzbl	214(%rsp,%rax), %eax
	jmpq	*.LJTI34_1(,%rax,8)
.LBB34_34:
	cmpq	$4, %rdx
	jne	.LBB34_88
	movl	(%r13), %eax
	cmpl	$1768125296, %eax
	je	.LBB34_103
	cmpl	$1937076323, %eax
	jne	.LBB34_86
	testb	$1, 40(%rsp)
	jne	.LBB34_120
	movb	$1, %al
	movq	%rax, 40(%rsp)
	movb	$1, %al
	jmp	.LBB34_96
.LBB34_39:
	testq	%r12, %r12
	je	.LBB34_115
	cmpq	$33, %r12
	jae	.LBB34_115
	leaq	-1(%r12), %rcx
	leaq	(%rcx,%rcx,2), %rdx
	shlq	$6, %rdx
	leaq	(%rsp,%rdx), %rsi
	addq	$216, %rsi
	movzbl	406(%rsp,%rdx), %edi
	cmpl	$3, %edi
	je	.LBB34_71
	cmpl	$2, %edi
	je	.LBB34_62
	cmpl	$1, %edi
	jne	.LBB34_82
	cmpl	$0, 16(%rsi)
	je	.LBB34_106
	cmpb	$0, 24(%rsi)
	je	.LBB34_106
	cmpl	$0, 28(%rsi)
	movq	%rax, %r13
	movq	%rcx, %r12
	je	.LBB34_99
	jmp	.LBB34_106
.LBB34_47:
	movq	%rax, %r13
	jmp	.LBB34_99
.LBB34_48:
	cmpq	$-5, %rax
	ja	.LBB34_105
	leaq	4(%rax), %rcx
	cmpq	32(%rsp), %rcx
	ja	.LBB34_105
	movq	%rcx, 72(%rsp)
	cmpq	$-5, %rcx
	ja	.LBB34_105
	leaq	8(%rax), %r8
	cmpq	32(%rsp), %r8
	ja	.LBB34_105
	movl	(%r15,%rax), %r9d
	bswapl	%r9d
	movq	%r8, %rax
	addq	%r9, %rax
	jb	.LBB34_105
	cmpq	32(%rsp), %rax
	ja	.LBB34_105
	movl	%eax, %r13d
	negl	%r13d
	andl	$3, %r13d
	addq	%rax, %r13
	jb	.LBB34_105
	cmpq	32(%rsp), %r13
	ja	.LBB34_105
	movl	(%r15,%rcx), %ecx
	movq	%r13, 72(%rsp)
	testq	%r12, %r12
	je	.LBB34_115
	cmpq	$33, %r12
	jae	.LBB34_115
	bswapl	%ecx
	addq	%r15, %r8
	leaq	(%r12,%r12,2), %rax
	shlq	$6, %rax
	leaq	(%rsp,%rax), %rdi
	addq	$24, %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB5_4Node8property
	cmpb	$-1, %al
	je	.LBB34_99
	jmp	.LBB34_117
.LBB34_59:
	testq	%rdx, %rdx
	jne	.LBB34_115
	testb	$1, 48(%rsp)
	jne	.LBB34_115
	movl	$16, %ecx
	leaq	88(%rsp), %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70+32, %rsi
	rep;movsq (%rsi), %es:(%rdi)
	movb	$1, %al
	movq	%rax, 48(%rsp)
	xorl	%edx, %edx
	xorl	%eax, %eax
	jmp	.LBB34_98
.LBB34_62:
	testq	%rcx, %rcx
	je	.LBB34_115
	leaq	(%r12,%r12,2), %rsi
	shlq	$6, %rsi
	cmpl	$1, -152(%rsp,%rsi)
	jne	.LBB34_106
	leaq	(%rsp,%rsi), %rdi
	addq	$216, %rdi
	cmpb	$0, -360(%rdi)
	je	.LBB34_106
	cmpl	$0, -356(%rdi)
	jne	.LBB34_106
	cmpb	$0, 401(%rsp,%rdx)
	je	.LBB34_106
	movq	384(%rsp,%rdx), %rdi
	testq	%rdi, %rdi
	je	.LBB34_115
	movq	392(%rsp,%rdx), %r9
	movl	-148(%rsp,%rsi), %r10d
	leaq	(,%r10,4), %rsi
	cmpq	%rsi, %r9
	jne	.LBB34_115
	movq	216(%rsp,%rdx), %r8
	movq	224(%rsp,%rdx), %rsi
	movzbl	402(%rsp,%rdx), %edx
	cmpl	$1, %r10d
	jne	.LBB34_75
	movl	(%rdi), %edi
	bswapl	%edi
	jmp	.LBB34_77
.LBB34_71:
	movzbl	187(%rsi), %edx
	testb	%dl, 188(%rsi)
	je	.LBB34_106
	movzbl	189(%rsi), %edx
	movb	%dl, 15(%rsp)
	jmp	.LBB34_82
.LBB34_73:
	cmpq	$4, %rdx
	jae	.LBB34_83
	cmpq	$3, %rdx
	jne	.LBB34_95
	jmp	.LBB34_94
.LBB34_75:
	cmpq	$8, %r9
	jb	.LBB34_105
	movq	(%rdi), %rdi
	bswapq	%rdi
.LBB34_77:
	testq	%r8, %r8
	je	.LBB34_106
	cmpq	%rdi, %rsi
	jne	.LBB34_106
	cmpq	$2, %rdi
	jae	.LBB34_106
	cmpb	$1, 28(%rsp,%rsi)
	je	.LBB34_120
	movb	$1, 28(%rsp,%rsi)
	movb	%dl, 30(%rsp,%rsi)
.LBB34_82:
	movq	%rax, %r13
	movq	%rcx, %r12
	jmp	.LBB34_99
.LBB34_83:
	cmpl	$1081438307, (%r13)
	je	.LBB34_101
.LBB34_84:
	cmpq	$4, %rdx
	jne	.LBB34_88
	movl	(%r13), %eax
.LBB34_86:
	cmpl	$1768125296, %eax
	je	.LBB34_106
	cmpl	$1937076323, %eax
	jne	.LBB34_93
	jmp	.LBB34_106
.LBB34_88:
	cmpq	$5, %rdx
	jae	.LBB34_91
	cmpq	$3, %rdx
	je	.LBB34_94
	cmpq	$4, %rdx
	je	.LBB34_93
	jmp	.LBB34_95
.LBB34_91:
	movl	$5, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.71, %rdi
	movq	%r13, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	je	.LBB34_106
	movl	$5, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.72, %rdi
	movq	%r13, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	je	.LBB34_106
.LBB34_93:
	cmpl	$1081438307, (%r13)
	jne	.LBB34_95
	jmp	.LBB34_106
.LBB34_94:
	movzwl	(%r13), %eax
	movzbl	2(%r13), %ecx
	shll	$16, %ecx
	orl	%eax, %ecx
	cmpl	$7696483, %ecx
	je	.LBB34_106
.LBB34_95:
	movb	$4, %al
.LBB34_96:
	xorl	%edx, %edx
.LBB34_97:
	movl	$16, %ecx
	leaq	88(%rsp), %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70+32, %rsi
	rep;movsq (%rsi), %es:(%rdi)
	cmpq	$32, %r12
	je	.LBB34_118
.LBB34_98:
	leaq	(%r12,%r12,2), %r9
	shlq	$6, %r9
	movq	%rdx, 216(%rsp,%r9)
	movq	%r8, 224(%rsp,%r9)
	movl	$0, 232(%rsp,%r9)
	movl	$0, 240(%rsp,%r9)
	leaq	248(%rsp,%r9), %rdi
	movl	$16, %ecx
	leaq	88(%rsp), %rsi
	rep;movsq (%rsi), %es:(%rdi)
	movq	$0, 384(%rsp,%r9)
	movq	$0, 376(%rsp,%r9)
	movl	$0, 400(%rsp,%r9)
	movw	$0, 404(%rsp,%r9)
	movb	%al, 406(%rsp,%r9)
	incq	%r12
	movq	64(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	72(%rsp), %r13
.LBB34_99:
	cmpq	$-5, %r13
	ja	.LBB34_105
	leaq	4(%r13), %rax
	cmpq	32(%rsp), %rax
	ja	.LBB34_105
	jmp	.LBB34_27
.LBB34_101:
	leaq	88(%rsp), %rdi
	movq	%r13, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology12unit_address
	cmpb	$1, 88(%rsp)
	je	.LBB34_125
	movq	96(%rsp), %r8
	movl	$1, %edx
	movb	$2, %al
	jmp	.LBB34_97
.LBB34_103:
	testb	$1, 80(%rsp)
	jne	.LBB34_120
	movb	$3, %al
	movb	$1, %cl
	movq	%rcx, 80(%rsp)
	jmp	.LBB34_96
.LBB34_105:
	movq	16(%rsp), %rax
	movb	$1, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB34_19
.LBB34_106:
	movq	16(%rsp), %rax
	movb	$3, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB34_19
.LBB34_107:
	cmpb	$1, 48(%rsp)
	jne	.LBB34_115
	testq	%r12, %r12
	jne	.LBB34_115
	cmpq	%rbp, %rax
	jne	.LBB34_115
	cmpb	$1, 40(%rsp)
	jne	.LBB34_119
	cmpb	$0, 28(%rsp)
	je	.LBB34_119
	cmpb	$0, 29(%rsp)
	je	.LBB34_121
	cmpb	$2, 15(%rsp)
	je	.LBB34_123
	movl	$2, %eax
	movzwl	30(%rsp), %ecx
	cmpl	$257, %ecx
	je	.LBB34_124
	jmp	.LBB34_123
.LBB34_115:
	movq	16(%rsp), %rax
	movb	$2, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB34_19
.LBB34_116:
	movzbl	96(%rsp), %eax
.LBB34_117:
	movq	16(%rsp), %rcx
	movb	%al, (%rcx)
	movb	$-1, 24(%rcx)
	jmp	.LBB34_19
.LBB34_118:
	movq	16(%rsp), %rax
	movb	$5, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB34_19
.LBB34_119:
	movq	16(%rsp), %rax
	movb	$6, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB34_19
.LBB34_120:
	movq	16(%rsp), %rax
	movb	$4, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB34_19
.LBB34_121:
	movl	$1, %eax
	cmpb	$1, 30(%rsp)
	jne	.LBB34_124
	cmpb	$2, 15(%rsp)
	jne	.LBB34_124
.LBB34_123:
	movq	16(%rsp), %rax
	movb	$7, (%rax)
	movb	$-1, 24(%rax)
	jmp	.LBB34_19
.LBB34_124:
	movq	16(%rsp), %rcx
	movq	$0, (%rcx)
	movq	$1, 8(%rcx)
	movq	%rax, 16(%rcx)
	movzbl	15(%rsp), %eax
	movb	%al, 24(%rcx)
	jmp	.LBB34_19
.LBB34_125:
	movzbl	89(%rsp), %eax
	jmp	.LBB34_117
.Lfunc_end34:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse, .Lfunc_end34-_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse,"a",@progbits
	.p2align	3, 0x0
.LJTI34_0:
	.quad	.LBB34_29
	.quad	.LBB34_39
	.quad	.LBB34_48
	.quad	.LBB34_47
	.quad	.LBB34_115
	.quad	.LBB34_115
	.quad	.LBB34_115
	.quad	.LBB34_115
	.quad	.LBB34_107
.LJTI34_1:
	.quad	.LBB34_34
	.quad	.LBB34_73
	.quad	.LBB34_106
	.quad	.LBB34_106
	.quad	.LBB34_84

	.section	.text._RNvMs_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB4_6Cursor4name,"ax",@progbits
	.prefalign	4, .Lfunc_end35, nop
	.type	_RNvMs_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB4_6Cursor4name,@function
_RNvMs_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB4_6Cursor4name:
.Lfunc_begin35:
	.cfi_startproc
	movq	8(%rsi), %rdx
	movq	16(%rsi), %r8
	cmpq	%r8, %rdx
	jae	.LBB35_2
	movb	$1, 8(%rdi)
	movq	$0, (%rdi)
	retq
.LBB35_2:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rcx
	subq	%r8, %rcx
	je	.LBB35_6
	movq	(%rsi), %rax
	leaq	(%rax,%r8), %rbx
	xorl	%r14d, %r14d
	.p2align	4
.LBB35_4:
	cmpb	$0, (%rbx,%r14)
	je	.LBB35_8
	incq	%r14
	cmpq	%r14, %rcx
	jne	.LBB35_4
.LBB35_6:
	movb	$2, 8(%rdi)
.LBB35_7:
	movq	$0, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
	retq
.LBB35_8:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	leaq	(%r8,%r14), %rcx
	incq	%rcx
	cmpq	%r8, %rcx
	setae	%r8b
	cmpq	%rdx, %rcx
	setbe	%r9b
	testb	%r9b, %r8b
	jne	.LBB35_10
	movb	$1, 8(%rdi)
	jmp	.LBB35_7
.LBB35_10:
	movq	%rcx, 16(%rsi)
	movl	%ecx, %r8d
	negl	%r8d
	andl	$3, %r8d
	movq	%r8, %r9
	addq	%rcx, %r9
	setb	%r10b
	cmpq	%rdx, %r9
	seta	%dl
	orb	%r10b, %dl
	movb	$1, %dl
	jne	.LBB35_13
	movq	%r9, 16(%rsi)
	testq	%r8, %r8
	je	.LBB35_15
	movb	$2, %dl
	cmpb	$0, (%rax,%rcx)
	je	.LBB35_14
.LBB35_13:
	movb	%dl, 8(%rdi)
	jmp	.LBB35_7
.LBB35_14:
	cmpl	$1, %r8d
	jne	.LBB35_22
.LBB35_15:
	cmpq	$15, %r14
	ja	.LBB35_20
	testq	%r14, %r14
	je	.LBB35_21
	xorl	%eax, %eax
.LBB35_18:
	cmpb	$47, (%rbx,%rax)
	je	.LBB35_6
	incq	%rax
	cmpq	%rax, %r14
	jne	.LBB35_18
	jmp	.LBB35_21
.LBB35_20:
	movq	%rdi, %r15
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned
	movq	%r15, %rdi
	testb	$1, %al
	jne	.LBB35_6
.LBB35_21:
	movq	%rbx, (%rdi)
	movq	%r14, 8(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
	retq
.LBB35_22:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	cmpb	$0, 1(%rax,%rcx)
	jne	.LBB35_13
	cmpl	$2, %r8d
	je	.LBB35_15
	cmpb	$0, 2(%rax,%rcx)
	jne	.LBB35_13
	jmp	.LBB35_15
.Lfunc_end35:
	.size	_RNvMs_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB4_6Cursor4name, .Lfunc_end35-_RNvMs_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB4_6Cursor4name
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology12unit_address,"ax",@progbits
	.prefalign	4, .Lfunc_end36, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology12unit_address,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology12unit_address:
.Lfunc_begin36:
	.cfi_startproc
	cmpl	$1081438307, (%rsi)
	je	.LBB36_1
	movb	$3, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.LBB36_1:
	leaq	-21(%rdx), %rax
	cmpq	$-16, %rax
	jae	.LBB36_6
	movb	$2, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.LBB36_6:
	movl	$4, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB36_7:
	movzbl	(%rsi,%rax), %r8d
	leal	-48(%r8), %r9d
	cmpb	$10, %r9b
	jb	.LBB36_12
	leal	-97(%r8), %r9d
	cmpb	$5, %r9b
	ja	.LBB36_9
	addb	$-87, %r8b
	movl	%r8d, %r9d
.LBB36_12:
	movq	%rcx, %r8
	shrq	$60, %r8
	jne	.LBB36_13
	movq	%rcx, %r8
	shlq	$4, %r8
	movzbl	%r9b, %ecx
	addq	%r8, %rcx
	incq	%rax
	cmpq	%rax, %rdx
	jne	.LBB36_7
	movq	%rcx, 8(%rdi)
	xorl	%eax, %eax
	movb	%al, (%rdi)
	retq
.LBB36_9:
	movb	$2, %al
	movb	%al, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.LBB36_13:
	movb	$3, %al
	movb	%al, 1(%rdi)
	movb	$1, %al
	movb	%al, (%rdi)
	retq
.Lfunc_end36:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology12unit_address, .Lfunc_end36-_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology12unit_address
	.cfi_endproc

	.section	.text._RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB5_4Node8property,"ax",@progbits
	.prefalign	4, .Lfunc_end37, nop
	.type	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB5_4Node8property,@function
_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB5_4Node8property:
.Lfunc_begin37:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	cmpb	$0, 184(%rdi)
	je	.LBB37_2
.LBB37_1:
	movb	$2, %al
	jmp	.LBB37_194
.LBB37_2:
	movl	%ecx, %ebx
	movb	$1, %al
	cmpq	%rbx, %rdx
	jae	.LBB37_3
.LBB37_194:
	addq	$72, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB37_3:
	.cfi_def_cfa_offset 128
	movq	%rdx, %r10
	subq	%rbx, %r10
	je	.LBB37_1
	addq	%rsi, %rbx
	xorl	%r14d, %r14d
	.p2align	4
.LBB37_5:
	cmpb	$0, (%rbx,%r14)
	je	.LBB37_7
	incq	%r14
	cmpq	%r14, %r10
	jne	.LBB37_5
	jmp	.LBB37_1
.LBB37_7:
	testq	%r14, %r14
	je	.LBB37_1
	movl	%ecx, 20(%rsp)
	movq	%r9, 8(%rsp)
	movq	%r8, (%rsp)
	movq	160(%rdi), %r15
	cmpq	$33, %r15
	jae	.LBB37_182
	leaq	(%rdi,%r15,4), %r12
	addq	$32, %r12
	testq	%r15, %r15
	je	.LBB37_20
	leaq	32(%rdi), %r13
	movq	memcmp@GOTPCREL(%rip), %rbp
.LBB37_11:
	movl	(%r13), %ecx
	cmpq	%rcx, %rdx
	jb	.LBB37_194
	movq	%rdx, %r8
	subq	%rcx, %r8
	je	.LBB37_1
	addq	$4, %r13
	addq	%rsi, %rcx
	xorl	%r9d, %r9d
	.p2align	4
.LBB37_14:
	cmpb	$0, (%rcx,%r9)
	je	.LBB37_16
	incq	%r9
	cmpq	%r9, %r8
	jne	.LBB37_14
	jmp	.LBB37_1
.LBB37_16:
	cmpq	%r14, %r9
	jne	.LBB37_18
	movq	%rdi, 40(%rsp)
	movq	%rcx, %rdi
	movq	%rsi, 32(%rsp)
	movq	%rbx, %rsi
	movq	%rdx, 24(%rsp)
	movq	%r14, %rdx
	callq	*%rbp
	movq	32(%rsp), %rsi
	movq	24(%rsp), %rdx
	movq	40(%rsp), %rdi
	movl	%eax, %ecx
	movb	$1, %al
	testl	%ecx, %ecx
	je	.LBB37_193
.LBB37_18:
	cmpq	%r12, %r13
	jne	.LBB37_11
	movb	$5, %al
	cmpq	$32, %r15
	je	.LBB37_194
.LBB37_20:
	movl	20(%rsp), %eax
	movl	%eax, (%r12)
	incq	160(%rdi)
	cmpq	$10, %r14
	je	.LBB37_27
	cmpq	$11, %r14
	movq	(%rsp), %rdx
	movq	8(%rsp), %rax
	jne	.LBB37_30
	movzwl	8(%rbx), %ecx
	movzbl	10(%rbx), %esi
	shll	$16, %esi
	orq	%rcx, %rsi
	movabsq	$8385532508832687460, %rcx
	xorq	(%rbx), %rcx
	xorq	$6647929, %rsi
	orq	%rcx, %rsi
	jne	.LBB37_46
	testq	%rax, %rax
	je	.LBB37_1
	xorl	%esi, %esi
.LBB37_25:
	cmpb	$0, (%rdx,%rsi)
	je	.LBB37_39
	incq	%rsi
	cmpq	%rsi, %rax
	jne	.LBB37_25
	jmp	.LBB37_1
.LBB37_27:
	movzwl	8(%rbx), %eax
	movabsq	$7091327050118426467, %rcx
	xorq	(%rbx), %rcx
	xorq	$25964, %rax
	orq	%rcx, %rax
	movq	(%rsp), %rax
	movq	8(%rsp), %rsi
	jne	.LBB37_46
	movq	%rdi, %r15
	movq	%rax, %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology10compatible
	movl	%eax, %ebp
	cmpb	$2, %bpl
	jne	.LBB37_37
	movzwl	%bp, %eax
	shrl	$8, %eax
	jmp	.LBB37_194
.LBB37_30:
	movzbl	190(%rdi), %ecx
.LBB37_31:
	cmpb	$4, %cl
	setne	%sil
	cmpq	$6, %r14
	sete	%r8b
	testb	%sil, %r8b
	je	.LBB37_47
	movl	(%rbx), %esi
	movzwl	4(%rbx), %r8d
	shlq	$32, %r8
	orq	%rsi, %r8
	movl	$6, %r14d
	movabsq	$126948300911731, %rsi
	cmpq	%rsi, %r8
	jne	.LBB37_47
	testq	%rax, %rax
	je	.LBB37_1
	xorl	%esi, %esi
.LBB37_35:
	cmpb	$0, (%rdx,%rsi)
	je	.LBB37_155
	incq	%rsi
	cmpq	%rsi, %rax
	jne	.LBB37_35
	jmp	.LBB37_1
.LBB37_37:
	testb	$1, %bpl
	je	.LBB37_43
	movb	$3, %al
	movq	%r15, %rdi
	cmpb	$3, 190(%r15)
	je	.LBB37_45
	jmp	.LBB37_194
.LBB37_39:
	leaq	1(%rsi), %rcx
	cmpq	%rax, %rcx
	jne	.LBB37_1
	movzbl	190(%rdi), %ecx
	cmpq	$3, %rsi
	jne	.LBB37_177
	cmpb	$2, %cl
	sete	%al
	movzwl	(%rdx), %esi
	movzbl	2(%rdx), %edx
	shll	$16, %edx
	orl	%esi, %edx
	cmpl	$7696483, %edx
	sete	%sil
	xorb	%al, %sil
	movb	$3, %al
	jne	.LBB37_194
	cmpl	$7696483, %edx
	sete	%al
	jmp	.LBB37_179
.LBB37_43:
	movq	(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	8(%rsp), %rax
	movq	%rax, 56(%rsp)
	movb	$0, 64(%rsp)
	leaq	48(%rsp), %rdi
	callq	_RINvYINtNtNtCs1R9DcZHJAgT_4core5slice4iter5SplithNCNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_
	testb	%al, %al
	movq	%r15, %rdi
	je	.LBB37_45
	movb	$3, %al
	cmpb	$3, 190(%rdi)
	jne	.LBB37_194
.LBB37_45:
	movw	%bp, 188(%rdi)
.LBB37_46:
	movzbl	190(%rdi), %ecx
.LBB37_47:
	movb	$-1, %al
	cmpb	$1, %cl
	je	.LBB37_83
	movzbl	%cl, %ecx
	cmpl	$2, %ecx
	je	.LBB37_64
	cmpl	$3, %ecx
	jne	.LBB37_194
	cmpq	$6, %r14
	je	.LBB37_144
	cmpq	$7, %r14
	je	.LBB37_121
	cmpq	$11, %r14
	jne	.LBB37_194
	cmpb	$99, (%rbx)
	jne	.LBB37_194
	cmpb	$112, 1(%rbx)
	jne	.LBB37_194
	cmpb	$117, 2(%rbx)
	jne	.LBB37_194
	cmpb	$95, 3(%rbx)
	jne	.LBB37_187
	cmpb	$115, 4(%rbx)
	jne	.LBB37_187
	cmpb	$117, 5(%rbx)
	jne	.LBB37_187
	cmpb	$115, 6(%rbx)
	jne	.LBB37_187
	cmpb	$112, 7(%rbx)
	jne	.LBB37_187
	cmpb	$101, 8(%rbx)
	jne	.LBB37_187
	cmpb	$110, 9(%rbx)
	jne	.LBB37_187
	movl	$-1006632959, %ecx
	cmpb	$100, 10(%rbx)
	jmp	.LBB37_173
.LBB37_64:
	cmpq	$3, %r14
	je	.LBB37_104
	cmpq	$13, %r14
	jne	.LBB37_194
	cmpb	$101, (%rbx)
	jne	.LBB37_194
	cmpb	$110, 1(%rbx)
	jne	.LBB37_194
	cmpb	$97, 2(%rbx)
	jne	.LBB37_194
	cmpb	$98, 3(%rbx)
	jne	.LBB37_194
	cmpb	$108, 4(%rbx)
	jne	.LBB37_187
	cmpb	$101, 5(%rbx)
	jne	.LBB37_187
	cmpb	$45, 6(%rbx)
	jne	.LBB37_187
	cmpb	$109, 7(%rbx)
	jne	.LBB37_187
	cmpb	$101, 8(%rbx)
	jne	.LBB37_187
	cmpb	$116, 9(%rbx)
	jne	.LBB37_187
	cmpb	$104, 10(%rbx)
	jne	.LBB37_187
	cmpb	$111, 11(%rbx)
	jne	.LBB37_187
	cmpb	$100, 12(%rbx)
	jne	.LBB37_187
	cmpq	$0, 8(%rsp)
	je	.LBB37_1
	xorl	%ecx, %ecx
	movq	(%rsp), %rax
.LBB37_81:
	cmpb	$0, (%rax,%rcx)
	je	.LBB37_188
	incq	%rcx
	cmpq	%rcx, 8(%rsp)
	jne	.LBB37_81
	jmp	.LBB37_1
.LBB37_83:
	cmpq	$11, %r14
	je	.LBB37_129
	cmpq	$13, %r14
	je	.LBB37_108
	cmpq	$14, %r14
	jne	.LBB37_194
	cmpb	$35, (%rbx)
	jne	.LBB37_194
	cmpb	$97, 1(%rbx)
	jne	.LBB37_194
	cmpb	$100, 2(%rbx)
	jne	.LBB37_194
	cmpb	$100, 3(%rbx)
	jne	.LBB37_187
	cmpb	$114, 4(%rbx)
	jne	.LBB37_187
	cmpb	$101, 5(%rbx)
	jne	.LBB37_187
	cmpb	$115, 6(%rbx)
	jne	.LBB37_187
	cmpb	$115, 7(%rbx)
	jne	.LBB37_187
	cmpb	$45, 8(%rbx)
	jne	.LBB37_187
	cmpb	$99, 9(%rbx)
	jne	.LBB37_187
	cmpb	$101, 10(%rbx)
	jne	.LBB37_187
	cmpb	$108, 11(%rbx)
	jne	.LBB37_187
	cmpb	$108, 12(%rbx)
	jne	.LBB37_187
	cmpb	$115, 13(%rbx)
	jne	.LBB37_187
	movb	$2, %al
	cmpq	$4, 8(%rsp)
	jne	.LBB37_194
	movq	(%rsp), %rax
	movl	(%rax), %ecx
	movl	8(%rbx), %eax
	movabsq	$8319104478668415267, %rdx
	xorq	(%rbx), %rdx
	movzwl	12(%rbx), %esi
	shlq	$32, %rsi
	orq	%rax, %rsi
	movabsq	$126909512246061, %rax
	xorq	%rsi, %rax
	orq	%rdx, %rax
	jne	.LBB37_142
	bswapl	%ecx
	leal	-1(%rcx), %edx
	movb	$3, %al
	cmpl	$1, %edx
	ja	.LBB37_194
	movl	$1, 16(%rdi)
	movl	%ecx, 20(%rdi)
	movb	$-1, %al
	jmp	.LBB37_194
.LBB37_104:
	cmpb	$114, (%rbx)
	jne	.LBB37_194
	cmpb	$101, 1(%rbx)
	jne	.LBB37_194
	cmpb	$103, 2(%rbx)
	jne	.LBB37_194
	movq	(%rsp), %rax
	movq	%rax, 168(%rdi)
	movq	8(%rsp), %rax
	movq	%rax, 176(%rdi)
	movb	$-1, %al
	jmp	.LBB37_194
.LBB37_108:
	cmpb	$101, (%rbx)
	jne	.LBB37_194
	cmpb	$110, 1(%rbx)
	jne	.LBB37_194
	cmpb	$97, 2(%rbx)
	jne	.LBB37_194
	cmpb	$98, 3(%rbx)
	jne	.LBB37_187
	cmpb	$108, 4(%rbx)
	jne	.LBB37_187
	cmpb	$101, 5(%rbx)
	jne	.LBB37_187
	cmpb	$45, 6(%rbx)
	jne	.LBB37_187
	cmpb	$109, 7(%rbx)
	jne	.LBB37_187
	cmpb	$101, 8(%rbx)
	jne	.LBB37_187
	cmpb	$116, 9(%rbx)
	jne	.LBB37_187
	cmpb	$104, 10(%rbx)
	jne	.LBB37_187
	cmpb	$111, 11(%rbx)
	movb	$-1, %al
	jne	.LBB37_194
	cmpb	$100, 12(%rbx)
	setne	%al
	jmp	.LBB37_176
.LBB37_121:
	movzbl	(%rbx), %ecx
	cmpl	$109, %ecx
	je	.LBB37_162
	cmpl	$99, %ecx
	jne	.LBB37_194
	cmpb	$112, 1(%rbx)
	jne	.LBB37_194
	cmpb	$117, 2(%rbx)
	jne	.LBB37_194
	cmpb	$95, 3(%rbx)
	jne	.LBB37_187
	cmpb	$111, 4(%rbx)
	jne	.LBB37_187
	cmpb	$102, 5(%rbx)
	jne	.LBB37_187
	movl	$-2080374782, %ecx
	cmpb	$102, 6(%rbx)
	jmp	.LBB37_173
.LBB37_129:
	cmpb	$35, (%rbx)
	jne	.LBB37_194
	cmpb	$115, 1(%rbx)
	jne	.LBB37_194
	cmpb	$105, 2(%rbx)
	jne	.LBB37_194
	cmpb	$122, 3(%rbx)
	jne	.LBB37_187
	cmpb	$101, 4(%rbx)
	jne	.LBB37_187
	cmpb	$45, 5(%rbx)
	jne	.LBB37_187
	cmpb	$99, 6(%rbx)
	jne	.LBB37_187
	cmpb	$101, 7(%rbx)
	jne	.LBB37_187
	cmpb	$108, 8(%rbx)
	jne	.LBB37_187
	cmpb	$108, 9(%rbx)
	jne	.LBB37_187
	cmpb	$115, 10(%rbx)
	jne	.LBB37_187
	movb	$2, %al
	cmpq	$4, 8(%rsp)
	jne	.LBB37_194
	movq	(%rsp), %rax
	movl	(%rax), %ecx
.LBB37_142:
	movb	$3, %al
	testl	%ecx, %ecx
	jne	.LBB37_194
	movq	$1, 24(%rdi)
	movb	$-1, %al
	jmp	.LBB37_194
.LBB37_144:
	movzbl	(%rbx), %ecx
	cmpl	$99, %ecx
	je	.LBB37_168
	cmpl	$109, %ecx
	jne	.LBB37_194
	cmpb	$101, 1(%rbx)
	jne	.LBB37_194
	cmpb	$116, 2(%rbx)
	jne	.LBB37_194
	cmpb	$104, 3(%rbx)
	jne	.LBB37_187
	cmpb	$111, 4(%rbx)
	jne	.LBB37_187
	cmpb	$100, 5(%rbx)
	jne	.LBB37_187
	cmpq	$0, 8(%rsp)
	je	.LBB37_1
	xorl	%ecx, %ecx
	movq	(%rsp), %rax
.LBB37_153:
	cmpb	$0, (%rax,%rcx)
	je	.LBB37_183
	incq	%rcx
	cmpq	%rcx, 8(%rsp)
	jne	.LBB37_153
	jmp	.LBB37_1
.LBB37_155:
	leaq	1(%rsi), %r8
	cmpq	%rax, %r8
	jne	.LBB37_1
	movb	$3, %al
	cmpq	$2, %rsi
	je	.LBB37_180
	cmpq	$4, %rsi
	jne	.LBB37_194
	cmpb	$111, (%rdx)
	jne	.LBB37_192
	movq	(%rsp), %rax
	cmpb	$107, 1(%rax)
	jne	.LBB37_192
	movq	(%rsp), %rax
	cmpb	$97, 2(%rax)
	jne	.LBB37_192
	movq	(%rsp), %rax
	cmpb	$121, 3(%rax)
	movb	$3, %al
	je	.LBB37_47
	jmp	.LBB37_194
.LBB37_193:
	movb	$4, %al
	jmp	.LBB37_194
.LBB37_162:
	cmpb	$105, 1(%rbx)
	jne	.LBB37_194
	cmpb	$103, 2(%rbx)
	jne	.LBB37_194
	cmpb	$114, 3(%rbx)
	jne	.LBB37_187
	cmpb	$97, 4(%rbx)
	jne	.LBB37_187
	cmpb	$116, 5(%rbx)
	jne	.LBB37_187
	movl	$-1006632955, %ecx
	cmpb	$101, 6(%rbx)
	jmp	.LBB37_173
.LBB37_168:
	cmpb	$112, 1(%rbx)
	jne	.LBB37_194
	cmpb	$117, 2(%rbx)
	jne	.LBB37_194
	cmpb	$95, 3(%rbx)
	jne	.LBB37_187
	cmpb	$111, 4(%rbx)
	jne	.LBB37_187
	movl	$-1006632957, %ecx
	cmpb	$110, 5(%rbx)
.LBB37_173:
	movb	$-1, %al
	jne	.LBB37_194
	movb	$2, %al
	cmpq	$4, 8(%rsp)
	jne	.LBB37_194
	movq	(%rsp), %rax
	movl	(%rax), %eax
	bswapl	%eax
	cmpl	%eax, %ecx
	sete	%al
.LBB37_176:
	negb	%al
	orb	$3, %al
	jmp	.LBB37_194
.LBB37_177:
	movb	$3, %al
	cmpb	$2, %cl
	je	.LBB37_194
	xorl	%eax, %eax
.LBB37_179:
	movb	%al, 185(%rdi)
	movq	(%rsp), %rdx
	movq	8(%rsp), %rax
	jmp	.LBB37_31
.LBB37_180:
	cmpb	$111, (%rdx)
	jne	.LBB37_194
	movq	(%rsp), %rdx
	cmpb	$107, 1(%rdx)
	je	.LBB37_47
	jmp	.LBB37_194
.LBB37_182:
	movl	$32, %edx
	xorl	%edi, %edi
	movq	%r15, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB37_183:
	leaq	1(%rcx), %rdx
	movb	$2, %al
	cmpq	8(%rsp), %rdx
	jne	.LBB37_194
	cmpq	$3, %rcx
	jne	.LBB37_192
	movq	(%rsp), %rax
	movzwl	(%rax), %ecx
	movzbl	2(%rax), %eax
	shll	$16, %eax
	orl	%ecx, %eax
	cmpl	$6518376, %eax
	movb	$3, %al
	jne	.LBB37_194
	movb	$1, 187(%rdi)
.LBB37_187:
	movb	$-1, %al
	jmp	.LBB37_194
.LBB37_188:
	leaq	1(%rcx), %rdx
	movb	$2, %al
	cmpq	8(%rsp), %rdx
	jne	.LBB37_194
	cmpq	$4, %rcx
	jne	.LBB37_192
	movq	(%rsp), %rax
	cmpl	$1768125296, (%rax)
	movb	$3, %al
	jne	.LBB37_194
	movb	$1, 186(%rdi)
	movb	$-1, %al
	jmp	.LBB37_194
.LBB37_192:
	movb	$3, %al
	jmp	.LBB37_194
.Lfunc_end37:
	.size	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB5_4Node8property, .Lfunc_end37-_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtB5_4Node8property
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology10compatible,"ax",@progbits
	.prefalign	4, .Lfunc_end38, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology10compatible,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology10compatible:
.Lfunc_begin38:
	.cfi_startproc
	movw	$514, %ax
	testq	%rsi, %rsi
	je	.LBB38_2
	cmpb	$0, -1(%rdi,%rsi)
	je	.LBB38_3
.LBB38_2:
	retq
.LBB38_3:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %rbp, -16
	decq	%rsi
	xorl	%ecx, %ecx
	movabsq	$7594040322295689825, %rdx
	movl	$1, %r8d
	xorl	%r9d, %r9d
	jmp	.LBB38_6
	.p2align	4
.LBB38_4:
	movl	8(%rdi), %ebx
	movq	(%rdi), %rdi
	xorq	%rdx, %rdi
	movq	%rbx, %r14
	xorq	$841887789, %r14
	xorq	$808333613, %rbx
	xorl	%ebp, %ebp
	orq	%rdi, %rbx
	sete	%bpl
	orq	%rdi, %r14
	movl	%ebp, %edi
	cmovel	%r8d, %edi
	orb	%cl, %dil
	orb	%bpl, %r9b
	movl	%edi, %ecx
.LBB38_5:
	movq	%r11, %rdi
	testb	%r10b, %r10b
	jne	.LBB38_14
.LBB38_6:
	testq	%rsi, %rsi
	je	.LBB38_13
	xorl	%ebx, %ebx
	.p2align	4
.LBB38_8:
	movzbl	(%rdi,%rbx), %r10d
	testb	%r10b, %r10b
	je	.LBB38_11
	incq	%rbx
	cmpq	%rbx, %rsi
	jne	.LBB38_8
	movq	%rdi, %r11
	movq	%rsi, %rbx
	cmpq	$12, %rbx
	jne	.LBB38_12
	jmp	.LBB38_4
	.p2align	4
.LBB38_11:
	leaq	1(%rbx), %r11
	subq	%r11, %rsi
	leaq	(%rdi,%rbx), %r11
	incq	%r11
	cmpq	$12, %rbx
	je	.LBB38_4
.LBB38_12:
	testq	%rbx, %rbx
	jne	.LBB38_5
.LBB38_13:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %rbp
	retq
.LBB38_14:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %rbp, -16
	.cfi_offset %r14, -24
	movzbl	%r9b, %edx
	shll	$8, %edx
	movzbl	%cl, %eax
	orl	%edx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %rbp
	retq
.Lfunc_end38:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology10compatible, .Lfunc_end38-_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology10compatible
	.cfi_endproc

	.section	.text._RINvYINtNtNtCs1R9DcZHJAgT_4core5slice4iter5SplithNCNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_,"ax",@progbits
	.prefalign	4, .Lfunc_end39, nop
	.type	_RINvYINtNtNtCs1R9DcZHJAgT_4core5slice4iter5SplithNCNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_,@function
_RINvYINtNtNtCs1R9DcZHJAgT_4core5slice4iter5SplithNCNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_:
.Lfunc_begin39:
	.cfi_startproc
	testb	$1, 16(%rdi)
	jne	.LBB39_1
	movq	(%rdi), %r8
	movq	8(%rdi), %rdx
	movabsq	$7594040322295689825, %rcx
	movb	$1, %sil
.LBB39_4:
	testq	%rdx, %rdx
	je	.LBB39_13
	movq	%r8, %rax
	xorl	%r9d, %r9d
	.p2align	4
.LBB39_6:
	cmpb	$0, (%rax,%r9)
	je	.LBB39_10
	incq	%r9
	cmpq	%r9, %rdx
	jne	.LBB39_6
	jmp	.LBB39_8
	.p2align	4
.LBB39_10:
	leaq	1(%r9), %r8
	subq	%r8, %rdx
	leaq	(%rax,%r9), %r8
	incq	%r8
	movq	%r8, (%rdi)
	movq	%rdx, 8(%rdi)
	cmpq	$8, %r9
	jne	.LBB39_4
	cmpq	%rcx, (%rax)
	sete	%al
	je	.LBB39_2
	testb	%sil, %sil
	jne	.LBB39_4
	jmp	.LBB39_2
.LBB39_8:
	movb	$1, 16(%rdi)
	cmpq	$8, %rdx
	jne	.LBB39_1
	cmpq	%rcx, (%rax)
	sete	%al
	retq
.LBB39_13:
	movb	$1, 16(%rdi)
.LBB39_1:
	xorl	%eax, %eax
.LBB39_2:
	retq
.Lfunc_end39:
	.size	_RINvYINtNtNtCs1R9DcZHJAgT_4core5slice4iter5SplithNCNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_, .Lfunc_end39-_RINvYINtNtNtCs1R9DcZHJAgT_4core5slice4iter5SplithNCNvMs0_NtCsjFdXuXHMTfk_9hm_kernel12cpu_topologyNtBT_4Node8property0ENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB1S_3any5checkRShNCBN_s_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBV_
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests10boundaries,"ax",@progbits
	.prefalign	4, .Lfunc_end40, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests10boundaries,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests10boundaries:
.Lfunc_begin40:
	.cfi_startproc
	subq	$872, %rsp
	.cfi_def_cfa_offset 880
	movq	$0, 40(%rsp)
	movq	$16777216, 48(%rsp)
	movq	$0, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	40(%rsp), %rcx
	movl	$16777216, %edx
	movl	$1, %r8d
	movl	$8, %r9d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 72(%rsp)
	je	.LBB40_1
	cmpq	$4096, 608(%rsp)
	jne	.LBB40_1
	movq	40(%rsp), %rax
	movq	48(%rsp), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rax, 72(%rsp)
	leaq	72(%rsp), %rdx
	movl	$16777216, %esi
	movl	$1, %ecx
	movl	$8, %r8d
	xorl	%edi, %edi
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB40_24
	movq	$9000, 8(%rsp)
	movq	$9000, 16(%rsp)
	movq	$0, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$4096, %edx
	movl	$1, %r8d
	movl	$8, %r9d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 72(%rsp)
	jne	.LBB40_1
	cmpb	$0, 73(%rsp)
	jne	.LBB40_1
	movq	$0, 24(%rsp)
	movq	$4096, 32(%rsp)
	movq	8(%rsp), %rax
	movq	16(%rsp), %rcx
	movq	%rcx, 624(%rsp)
	movq	%rax, 616(%rsp)
	movq	$1, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	24(%rsp), %rcx
	leaq	616(%rsp), %r9
	movl	$4096, %edx
	movl	$1, %r8d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 72(%rsp)
	jne	.LBB40_1
	cmpb	$0, 73(%rsp)
	jne	.LBB40_1
	movq	$-1, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$4096, %edx
	movl	$1, %r8d
	movl	$8, %r9d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 72(%rsp)
	jne	.LBB40_1
	cmpb	$0, 73(%rsp)
	jne	.LBB40_1
	movq	$0, 24(%rsp)
	movq	$4096, 32(%rsp)
	movq	8(%rsp), %rax
	movq	16(%rsp), %rcx
	movq	%rcx, 624(%rsp)
	movq	%rax, 616(%rsp)
	movq	$1, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	24(%rsp), %rcx
	leaq	616(%rsp), %r9
	movl	$4096, %edx
	movl	$1, %r8d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 72(%rsp)
	jne	.LBB40_1
	cmpb	$0, 73(%rsp)
	jne	.LBB40_1
	movq	$0, 616(%rsp)
	movq	$4096, 624(%rsp)
	movq	$4095, 632(%rsp)
	movq	$8192, 640(%rsp)
	movq	$0, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	616(%rsp), %rcx
	movl	$4096, %edx
	movl	$2, %r8d
	movl	$8, %r9d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 72(%rsp)
	jne	.LBB40_1
	cmpb	$3, 73(%rsp)
	movl	$0, %eax
	jne	.LBB40_24
	movq	$0, 616(%rsp)
	movq	$4096, 624(%rsp)
	movq	$4096, 632(%rsp)
	movq	$8192, 640(%rsp)
	movq	$8192, 648(%rsp)
	movq	$12288, 656(%rsp)
	movq	$12288, 664(%rsp)
	movq	$16384, 672(%rsp)
	movq	$16384, 680(%rsp)
	movq	$20480, 688(%rsp)
	movq	$20480, 696(%rsp)
	movq	$24576, 704(%rsp)
	movq	$24576, 712(%rsp)
	movq	$28672, 720(%rsp)
	movq	$28672, 728(%rsp)
	movq	$32768, 736(%rsp)
	movq	$32768, 744(%rsp)
	movq	$36864, 752(%rsp)
	movq	$36864, 760(%rsp)
	movq	$40960, 768(%rsp)
	movq	$40960, 776(%rsp)
	movq	$45056, 784(%rsp)
	movq	$45056, 792(%rsp)
	movq	$49152, 800(%rsp)
	movq	$49152, 808(%rsp)
	movq	$53248, 816(%rsp)
	movq	$53248, 824(%rsp)
	movq	$57344, 832(%rsp)
	movq	$57344, 840(%rsp)
	movq	$61440, 848(%rsp)
	movq	$61440, 856(%rsp)
	movq	$65536, 864(%rsp)
	movq	$268435456, 72(%rsp)
	movq	$268439552, 80(%rsp)
	movq	$268435456, 88(%rsp)
	movq	$268439552, 96(%rsp)
	movq	$268435456, 104(%rsp)
	movq	$268439552, 112(%rsp)
	movq	$268435456, 120(%rsp)
	movq	$268439552, 128(%rsp)
	movq	$268435456, 136(%rsp)
	movq	$268439552, 144(%rsp)
	movq	$268435456, 152(%rsp)
	movq	$268439552, 160(%rsp)
	movq	$268435456, 168(%rsp)
	movq	$268439552, 176(%rsp)
	movq	$268435456, 184(%rsp)
	movq	$268439552, 192(%rsp)
	movq	$268435456, 200(%rsp)
	movq	$268439552, 208(%rsp)
	movq	$268435456, 216(%rsp)
	movq	$268439552, 224(%rsp)
	movq	$268435456, 232(%rsp)
	movq	$268439552, 240(%rsp)
	movq	$268435456, 248(%rsp)
	movq	$268439552, 256(%rsp)
	movq	$268435456, 264(%rsp)
	movq	$268439552, 272(%rsp)
	movq	$268435456, 280(%rsp)
	movq	$268439552, 288(%rsp)
	movq	$268435456, 296(%rsp)
	movq	$268439552, 304(%rsp)
	movq	$268435456, 312(%rsp)
	movq	$268439552, 320(%rsp)
	movq	$268435456, 328(%rsp)
	movq	$268439552, 336(%rsp)
	movq	$268435456, 344(%rsp)
	movq	$268439552, 352(%rsp)
	movq	$268435456, 360(%rsp)
	movq	$268439552, 368(%rsp)
	movq	$268435456, 376(%rsp)
	movq	$268439552, 384(%rsp)
	movq	$268435456, 392(%rsp)
	movq	$268439552, 400(%rsp)
	movq	$268435456, 408(%rsp)
	movq	$268439552, 416(%rsp)
	movq	$268435456, 424(%rsp)
	movq	$268439552, 432(%rsp)
	movq	$268435456, 440(%rsp)
	movq	$268439552, 448(%rsp)
	movq	$268435456, 456(%rsp)
	movq	$268439552, 464(%rsp)
	movq	$268435456, 472(%rsp)
	movq	$268439552, 480(%rsp)
	movq	$268435456, 488(%rsp)
	movq	$268439552, 496(%rsp)
	movq	$268435456, 504(%rsp)
	movq	$268439552, 512(%rsp)
	movq	$268435456, 520(%rsp)
	movq	$268439552, 528(%rsp)
	movq	$268435456, 536(%rsp)
	movq	$268439552, 544(%rsp)
	movq	$268435456, 552(%rsp)
	movq	$268439552, 560(%rsp)
	movq	$268435456, 568(%rsp)
	movq	$268439552, 576(%rsp)
	movq	$268435456, 584(%rsp)
	movq	$268439552, 592(%rsp)
	movq	$268435456, 600(%rsp)
	movq	$268439552, 608(%rsp)
	leaq	616(%rsp), %rdx
	leaq	72(%rsp), %r8
	movl	$16777216, %esi
	movl	$16, %ecx
	movl	$34, %r9d
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	testb	%al, %al
	je	.LBB40_1
	movq	$-8192, 56(%rsp)
	movq	$-1, 64(%rsp)
	movq	$0, (%rsp)
	leaq	72(%rsp), %rdi
	leaq	56(%rsp), %rcx
	movl	$1, %r8d
	movl	$8, %r9d
	movq	$-8192, %rsi
	movq	$-4096, %rdx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$0, 72(%rsp)
	jne	.LBB40_1
	cmpq	$1, 608(%rsp)
	jne	.LBB40_1
	movq	56(%rsp), %rax
	movq	64(%rsp), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rax, 72(%rsp)
	leaq	72(%rsp), %rdx
	movl	$1, %ecx
	movl	$8, %r8d
	movq	$-8192, %rdi
	movq	$-4096, %rsi
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB40_24
	movq	$-8192, 24(%rsp)
	movq	$-4096, 32(%rsp)
	movq	$-4097, 72(%rsp)
	movq	$-1, 80(%rsp)
	leaq	24(%rsp), %rdx
	leaq	72(%rsp), %r8
	movl	$1, %ecx
	movl	$1, %r9d
	movq	$-8192, %rdi
	movq	$-4096, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
.LBB40_24:
	addq	$872, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB40_1:
	.cfi_def_cfa_offset 880
	xorl	%eax, %eax
	addq	$872, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end40:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests10boundaries, .Lfunc_end40-_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests10boundaries
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle,"ax",@progbits
	.prefalign	4, .Lfunc_end41, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle:
.Lfunc_begin41:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1112, %rsp
	.cfi_def_cfa_offset 1168
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %rax
	movq	%rcx, %r13
	movq	%rdx, %rcx
	movq	%rsi, %rbx
	movq	%rdi, %r14
	movq	%r9, 16(%rsp)
	movq	%r9, (%rsp)
	leaq	56(%rsp), %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	movq	%rcx, 40(%rsp)
	movq	%r13, %r8
	movq	%rax, 48(%rsp)
	movq	%rax, %r9
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 56(%rsp)
	jne	.LBB41_1
.LBB41_16:
	xorl	%eax, %eax
	jmp	.LBB41_17
.LBB41_1:
	leaq	64(%rsp), %rsi
	movq	576(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	584(%rsp), %r12
	leaq	600(%rsp), %rdi
	movl	$512, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movq	592(%rsp), %rax
	movq	%rax, 24(%rsp)
	subq	%r14, %rbx
	shrq	$12, %rbx
	je	.LBB41_2
	shlq	$4, %r13
	shlq	$4, 16(%rsp)
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	jmp	.LBB41_5
	.p2align	4
.LBB41_15:
	testb	%r8b, %r8b
	jne	.LBB41_16
.LBB41_14:
	movzbl	%r8b, %eax
	addq	%rax, %rcx
	cmpq	%rbx, %rdx
	je	.LBB41_3
.LBB41_5:
	movq	%rdx, %rsi
	incq	%rdx
	movq	%rsi, %rdi
	shlq	$12, %rdi
	leaq	(%rdi,%r14), %r8
	addq	$4096, %r8
	addq	%r14, %rdi
	movq	%r13, %r11
	movq	40(%rsp), %r10
	.p2align	4
.LBB41_6:
	movq	%r11, %r9
	testq	%r11, %r11
	je	.LBB41_8
	movq	(%r10), %rax
	movq	8(%r10), %r11
	cmpq	%r8, %r11
	cmovaeq	%r8, %r11
	cmpq	%rdi, %rax
	cmovbeq	%rdi, %rax
	subq	%rax, %r11
	movl	$0, %eax
	cmovaeq	%r11, %rax
	addq	$16, %r10
	leaq	-16(%r9), %r11
	cmpq	$4096, %rax
	jne	.LBB41_6
.LBB41_8:
	movq	16(%rsp), %r10
	movq	48(%rsp), %r11
	.p2align	4
.LBB41_9:
	movq	%r10, %rax
	testq	%r10, %r10
	je	.LBB41_11
	movq	(%r11), %rbp
	movq	8(%r11), %r15
	cmpq	%r8, %r15
	cmovaeq	%r8, %r15
	cmpq	%rdi, %rbp
	cmovbeq	%rdi, %rbp
	addq	$16, %r11
	leaq	-16(%rax), %r10
	cmpq	%rbp, %r15
	jbe	.LBB41_9
.LBB41_11:
	testq	%rax, %rax
	sete	%al
	testq	%r9, %r9
	setne	%r8b
	andb	%al, %r8b
	cmpq	%r12, %rsi
	jae	.LBB41_15
	movq	%rsi, %rdi
	shrq	$6, %rdi
	cmpq	$4096, %rsi
	jae	.LBB41_18
	movq	600(%rsp,%rdi,8), %rax
	btq	%rsi, %rax
	movl	%r8d, %eax
	sbbb	$0, %al
	je	.LBB41_14
	jmp	.LBB41_16
.LBB41_2:
	xorl	%ecx, %ecx
.LBB41_3:
	movq	24(%rsp), %rdx
	xorq	%rcx, %rdx
	movq	32(%rsp), %rax
	xorq	%r14, %rax
	xorq	%rbx, %r12
	orq	%rax, %r12
	orq	%rdx, %r12
	sete	%al
.LBB41_17:
	addq	$1112, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB41_18:
	.cfi_def_cfa_offset 1168
	movl	$64, %esi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.Lfunc_end41:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle, .Lfunc_end41-_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests6ranges,"ax",@progbits
	.prefalign	4, .Lfunc_end42, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests6ranges,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests6ranges:
.Lfunc_begin42:
	.cfi_startproc
	subq	$776, %rsp
	.cfi_def_cfa_offset 784
	movq	$0, 24(%rsp)
	movq	$24576, 32(%rsp)
	movq	$28673, 40(%rsp)
	movq	$65537, 48(%rsp)
	movq	$8193, 152(%rsp)
	movq	$8194, 160(%rsp)
	movq	$16383, 168(%rsp)
	movq	$16385, 176(%rsp)
	movq	$16384, 184(%rsp)
	movq	$20480, 192(%rsp)
	movq	$131072, 200(%rsp)
	movq	$196608, 208(%rsp)
	movq	$65536, 216(%rsp)
	movq	$69632, 224(%rsp)
	movq	$5, (%rsp)
	leaq	232(%rsp), %rdi
	leaq	24(%rsp), %rcx
	leaq	152(%rsp), %r9
	movl	$4096, %esi
	movl	$69632, %edx
	movl	$2, %r8d
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 232(%rsp)
	je	.LBB42_19
	cmpq	$10, 768(%rsp)
	jne	.LBB42_19
	leaq	24(%rsp), %rdx
	leaq	152(%rsp), %r8
	movl	$4096, %edi
	movl	$69632, %esi
	movl	$2, %ecx
	movl	$5, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	testb	%al, %al
	je	.LBB42_19
	movq	$1073741824, 8(%rsp)
	movq	$1207959552, 16(%rsp)
	movq	$1073741824, 104(%rsp)
	movq	$1075838976, 112(%rsp)
	movq	$1075838976, 120(%rsp)
	movq	$1076035875, 128(%rsp)
	movq	$1083179009, 136(%rsp)
	movq	$1083179010, 144(%rsp)
	leaq	8(%rsp), %rdx
	leaq	104(%rsp), %r8
	movl	$1073741824, %edi
	movl	$1090519040, %esi
	movl	$1, %ecx
	movl	$3, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	testb	%al, %al
	je	.LBB42_19
	movq	$3, (%rsp)
	leaq	232(%rsp), %rdi
	leaq	8(%rsp), %rcx
	leaq	104(%rsp), %r9
	movl	$1073741824, %esi
	movl	$1090519040, %edx
	movl	$1, %r8d
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$0, 232(%rsp)
	je	.LBB42_6
.LBB42_19:
	xorl	%eax, %eax
	addq	$776, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB42_6:
	.cfi_def_cfa_offset 784
	movq	760(%rsp), %rax
	cmpq	$561, %rax
	jb	.LBB42_19
	cmpq	$3534, 768(%rsp)
	jne	.LBB42_19
	movq	304(%rsp), %rcx
	movq	%rcx, %rdx
	shrq	$48, %rdx
	andl	$1, %edx
	cmpq	$562, %rax
	setb	%al
	orb	%dl, %al
	btq	$49, %rcx
	setae	%cl
	orb	%al, %cl
	jne	.LBB42_19
	movq	$0, 56(%rsp)
	movq	$2048, 64(%rsp)
	movq	$2048, 72(%rsp)
	movq	$8192, 80(%rsp)
	movq	$0, (%rsp)
	leaq	232(%rsp), %rdi
	leaq	56(%rsp), %rcx
	movl	$8192, %edx
	movl	$2, %r8d
	movl	$8, %r9d
	xorl	%esi, %esi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel10frame_planNtB2_4Plan5build
	cmpb	$1, 232(%rsp)
	je	.LBB42_19
	movq	760(%rsp), %rcx
	xorl	%eax, %eax
	testq	%rcx, %rcx
	je	.LBB42_18
	cmpq	$1, 768(%rsp)
	jne	.LBB42_18
	xorl	%eax, %eax
	cmpq	$2, %rcx
	jb	.LBB42_18
	movq	240(%rsp), %rcx
	andl	$3, %ecx
	cmpl	$2, %ecx
	jne	.LBB42_18
	leaq	56(%rsp), %rdx
	movl	$8192, %esi
	movl	$2, %ecx
	movl	$8, %r8d
	xorl	%edi, %edi
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB42_18
	movq	$0, 232(%rsp)
	movq	$4096, 240(%rsp)
	movq	$4096, 248(%rsp)
	movq	$8192, 256(%rsp)
	leaq	232(%rsp), %rdx
	movl	$8192, %esi
	movl	$2, %ecx
	movl	$8, %r8d
	xorl	%edi, %edi
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB42_18
	movl	$8192, %esi
	movl	$8, %edx
	movl	$8, %r8d
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB42_18
	movq	$0, 88(%rsp)
	movq	$8192, 96(%rsp)
	movq	$8192, 240(%rsp)
	movq	$0, 232(%rsp)
	leaq	88(%rsp), %rdx
	leaq	232(%rsp), %r8
	movl	$8192, %esi
	movl	$1, %ecx
	movl	$1, %r9d
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests14matches_oracle
.LBB42_18:
	addq	$776, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end42:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests6ranges, .Lfunc_end42-_RNvNtCsjFdXuXHMTfk_9hm_kernel16frame_plan_tests6ranges
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5valid,"ax",@progbits
	.prefalign	4, .Lfunc_end43, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5valid,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5valid:
.Lfunc_begin43:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$1640, %rsp
	.cfi_def_cfa_offset 9872
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17capacity_boundary
	testb	%al, %al
	je	.LBB43_56
	movabsq	$9007199254740992, %r15
	leaq	808(%rsp), %rbx
	movl	$4096, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$608, 4904(%rsp)
	movq	$0, 4912(%rsp)
	movb	$1, 4920(%rsp)
	movabsq	$4503874505277440, %rax
	movq	%rax, 848(%rsp)
	movq	%r15, 856(%rsp)
	movl	$1, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, 4928(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, 4928(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$5, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.54, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	leaq	17(%rax), %rdi
	addq	$20, %rax
	cmpq	%rdi, %rax
	jb	.LBB43_59
	cmpq	$4097, %rax
	jae	.LBB43_59
	movb	$9, 810(%rsp,%rdi)
	movw	$1023, 808(%rsp,%rdi)
	movq	4904(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB43_6
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_58
	movl	$67108864, 808(%rsp,%rax)
	movq	%rcx, 4904(%rsp)
	jmp	.LBB43_7
.LBB43_6:
	movb	$0, 4920(%rsp)
.LBB43_7:
	movabsq	$4503599627370496, %r12
	leaq	808(%rsp), %rbx
	movl	$3, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.76, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$10, %edx
	movl	$9, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.38, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.94, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$8, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.95, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movq	$0, 4928(%rsp)
	movq	%r12, 4936(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %rcx
	movq	%rcx, %rdx
	addq	$4, %rdx
	movq	$-1, %rax
	cmovaeq	%rdx, %rax
	cmpq	$4096, %rax
	ja	.LBB43_11
	movq	%rax, %rdi
	subq	%rcx, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_58
	movl	$33554432, 808(%rsp,%rcx)
	movq	%rax, 4904(%rsp)
	cmpq	$4093, %rax
	jae	.LBB43_11
	movl	$33554432, 808(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4904(%rsp)
	jmp	.LBB43_12
.LBB43_11:
	movb	$0, 4920(%rsp)
.LBB43_12:
	leaq	808(%rsp), %rbx
	movl	$15, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.25, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$274877906944, %rax
	movq	%rax, 4928(%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 4936(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB43_15
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_58
	movl	$33554432, 808(%rsp,%rax)
	movq	%rcx, 4904(%rsp)
	jmp	.LBB43_16
.LBB43_15:
	movb	$0, 4920(%rsp)
.LBB43_16:
	movl	$2415919104, %r14d
	leaq	808(%rsp), %rbx
	movl	$15, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.96, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.25, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$3, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.55, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$343597383680, %rax
	movq	%rax, 4928(%rsp)
	leaq	1879048192(%r14), %rax
	movq	%rax, 4936(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB43_19
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_58
	movl	$33554432, 808(%rsp,%rax)
	movq	%rcx, 4904(%rsp)
	jmp	.LBB43_20
.LBB43_19:
	movb	$0, 4920(%rsp)
.LBB43_20:
	leaq	808(%rsp), %rbx
	movl	$15, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.66, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, 4928(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, 4928(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$1, %ecx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.83, %rsi
	xorl	%r8d, %r8d
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$15, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.97, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movabsq	$9007474132647936, %rax
	movq	%rax, 4928(%rsp)
	movq	%r15, 4936(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB43_23
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_58
	movl	$33554432, 808(%rsp,%rax)
	movq	%rcx, 4904(%rsp)
	jmp	.LBB43_24
.LBB43_23:
	movb	$0, 4920(%rsp)
.LBB43_24:
	leaq	808(%rsp), %rbx
	movl	$16, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.98, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movabsq	$618475290624, %rax
	movq	%rax, 4928(%rsp)
	movq	%r12, 4936(%rsp)
	leaq	4928(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %r15
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB43_30
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB43_58
	movl	$33554432, 808(%rsp,%r15)
	movq	%rax, 4904(%rsp)
	cmpq	$4092, %rax
	ja	.LBB43_31
	leaq	4(%rax), %r15
	movl	$33554432, 808(%rsp,%rax)
	movq	%r15, 4904(%rsp)
	cmpq	$4088, %rax
	ja	.LBB43_32
	leaq	8(%rax), %r15
	movl	$33554432, 812(%rsp,%rax)
	movq	%r15, 4904(%rsp)
	cmpq	$4085, %rax
	jae	.LBB43_32
	movl	$150994944, 816(%rsp,%rax)
	addq	$12, %rax
	movq	%rax, 4904(%rsp)
	movq	%rax, %r15
	jmp	.LBB43_33
.LBB43_30:
	movb	$0, 4920(%rsp)
	jmp	.LBB43_32
.LBB43_31:
	movq	%rax, %r15
.LBB43_32:
	movb	$0, 4920(%rsp)
.LBB43_33:
	movq	%r15, %rax
	addq	$112, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB43_36
	movq	%rbx, %rdi
	subq	%r15, %rdi
	cmpq	$112, %rdi
	jne	.LBB43_61
	leaq	(%rsp,%r15), %rdi
	addq	$808, %rdi
	movl	$112, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.22, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4904(%rsp)
	jmp	.LBB43_37
.LBB43_36:
	movb	$0, 4920(%rsp)
	movq	%r15, %rbx
.LBB43_37:
	movq	%rbx, 4912(%rsp)
	movl	$-302117424, 808(%rsp)
	movl	%ebx, %eax
	bswapl	%eax
	movl	%eax, 812(%rsp)
	movl	$1610743808, 816(%rsp)
	movl	%r15d, %eax
	bswapl	%eax
	movl	%eax, 820(%rsp)
	movabsq	$1224979099315863552, %rax
	movq	%rax, 824(%rsp)
	movl	$268435456, 832(%rsp)
	movl	$1879048192, 840(%rsp)
	addl	$-608, %r15d
	bswapl	%r15d
	movl	%r15d, 844(%rsp)
	leaq	4928(%rsp), %rdi
	leaq	808(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcpy@GOTPCREL(%rip)
	cmpq	$4097, %rbx
	jae	.LBB43_60
	leaq	9024(%rsp), %rdi
	leaq	808(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	cmpb	$1, 9024(%rsp)
	je	.LBB43_56
	leaq	9032(%rsp), %rsi
	leaq	8(%rsp), %rdi
	movl	$800, %edx
	callq	*memcpy@GOTPCREL(%rip)
	cmpb	$1, 4920(%rsp)
	jne	.LBB43_56
	leaq	808(%rsp), %rdi
	leaq	4928(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	jne	.LBB43_56
	leaq	8(%rsp), %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map
	testb	%al, %al
	je	.LBB43_56
	movq	800(%rsp), %rax
	cmpq	4912(%rsp), %rax
	jne	.LBB43_56
	movq	776(%rsp), %rsi
	cmpq	$17, %rsi
	jae	.LBB43_62
	xorl	%eax, %eax
	cmpq	$2, %rsi
	jne	.LBB43_57
	cmpq	$1073741824, 520(%rsp)
	jne	.LBB43_57
	cmpq	$1207959552, 528(%rsp)
	jne	.LBB43_57
	xorl	%eax, %eax
	cmpq	$1342177280, 536(%rsp)
	jne	.LBB43_57
	cmpq	$1358954496, 544(%rsp)
	jne	.LBB43_57
	movq	784(%rsp), %rsi
	cmpq	$33, %rsi
	jae	.LBB43_63
	xorl	%eax, %eax
	cmpq	$3, %rsi
	jne	.LBB43_57
	cmpq	$1073745920, 8(%rsp)
	jne	.LBB43_57
	cmpq	$1073754112, 16(%rsp)
	jne	.LBB43_57
	xorl	%eax, %eax
	cmpq	$1073750016, 24(%rsp)
	jne	.LBB43_57
	cmpq	$1073758208, 32(%rsp)
	jne	.LBB43_57
	movq	40(%rsp), %rax
	xorq	%r14, %rax
	addq	$4096, %r14
	xorq	48(%rsp), %r14
	orq	%rax, %r14
	sete	%al
	jmp	.LBB43_57
.LBB43_56:
	xorl	%eax, %eax
.LBB43_57:
	addq	$9832, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB43_58:
	.cfi_def_cfa_offset 9872
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB43_59:
	movl	$4096, %edx
	movq	%rax, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB43_60:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB43_61:
	movl	$112, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB43_62:
	movl	$16, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB43_63:
	movl	$32, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end43:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5valid, .Lfunc_end43-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5valid
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17capacity_boundary,"ax",@progbits
	.prefalign	4, .Lfunc_end44, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17capacity_boundary,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17capacity_boundary:
.Lfunc_begin44:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$1896, %rsp
	.cfi_def_cfa_offset 6016
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	leaq	264(%rsp), %rbx
	movl	$4096, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$608, 4360(%rsp)
	movq	$0, 4368(%rsp)
	movb	$1, 4376(%rsp)
	movabsq	$618475290624, %rax
	movq	%rax, 304(%rsp)
	movabsq	$4503599627370496, %r14
	movq	%r14, 312(%rsp)
	movabsq	$4504218102661120, %rax
	movq	%rax, 320(%rsp)
	movq	%r14, 328(%rsp)
	movabsq	$9007817730031616, %rax
	movq	%rax, 336(%rsp)
	movq	%r14, 344(%rsp)
	movabsq	$13511417357402112, %rax
	movq	%rax, 352(%rsp)
	movq	%r14, 360(%rsp)
	movabsq	$18015016984772608, %rax
	movq	%rax, 368(%rsp)
	movq	%r14, 376(%rsp)
	movabsq	$22518616612143104, %rax
	movq	%rax, 384(%rsp)
	movq	%r14, 392(%rsp)
	movabsq	$27022216239513600, %rax
	movq	%rax, 400(%rsp)
	movq	%r14, 408(%rsp)
	movabsq	$31525815866884096, %rax
	movq	%rax, 416(%rsp)
	movq	%r14, 424(%rsp)
	movabsq	$36029415494254592, %rax
	movq	%rax, 432(%rsp)
	movq	%r14, 440(%rsp)
	movabsq	$40533015121625088, %rax
	movq	%rax, 448(%rsp)
	movq	%r14, 456(%rsp)
	movabsq	$45036614748995584, %rax
	movq	%rax, 464(%rsp)
	movq	%r14, 472(%rsp)
	movabsq	$49540214376366080, %rax
	movq	%rax, 480(%rsp)
	movq	%r14, 488(%rsp)
	movabsq	$54043814003736576, %rax
	movq	%rax, 496(%rsp)
	movq	%r14, 504(%rsp)
	movabsq	$58547413631107072, %rax
	movq	%rax, 512(%rsp)
	movq	%r14, 520(%rsp)
	movabsq	$63051013258477568, %rax
	movq	%rax, 528(%rsp)
	movq	%r14, 536(%rsp)
	movabsq	$67554612885848064, %rax
	movq	%rax, 544(%rsp)
	movq	%r14, 552(%rsp)
	movabsq	$1717986918400, %rax
	movq	%rax, 560(%rsp)
	movq	%r14, 568(%rsp)
	movabsq	$4505317614288896, %rax
	movq	%rax, 576(%rsp)
	movq	%r14, 584(%rsp)
	movabsq	$9008917241659392, %rax
	movq	%rax, 592(%rsp)
	movq	%r14, 600(%rsp)
	movabsq	$13512516869029888, %rax
	movq	%rax, 608(%rsp)
	movq	%r14, 616(%rsp)
	movabsq	$18016116496400384, %rax
	movq	%rax, 624(%rsp)
	movq	%r14, 632(%rsp)
	movabsq	$22519716123770880, %rax
	movq	%rax, 640(%rsp)
	movq	%r14, 648(%rsp)
	movabsq	$27023315751141376, %rax
	movq	%rax, 656(%rsp)
	movq	%r14, 664(%rsp)
	movabsq	$31526915378511872, %rax
	movq	%rax, 672(%rsp)
	movq	%r14, 680(%rsp)
	movabsq	$36030515005882368, %rax
	movq	%rax, 688(%rsp)
	movq	%r14, 696(%rsp)
	movabsq	$40534114633252864, %rax
	movq	%rax, 704(%rsp)
	movq	%r14, 712(%rsp)
	movabsq	$45037714260623360, %rax
	movq	%rax, 720(%rsp)
	movq	%r14, 728(%rsp)
	movabsq	$49541313887993856, %rax
	movq	%rax, 736(%rsp)
	movq	%r14, 744(%rsp)
	movabsq	$54044913515364352, %rax
	movq	%rax, 752(%rsp)
	movq	%r14, 760(%rsp)
	movabsq	$58548513142734848, %rax
	movq	%rax, 768(%rsp)
	movq	%r14, 776(%rsp)
	movabsq	$63052112770105344, %rax
	movq	%rax, 784(%rsp)
	movq	%r14, 792(%rsp)
	movabsq	$67555712397475840, %rax
	movq	%rax, 800(%rsp)
	movq	%r14, 808(%rsp)
	movl	$1, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, 4384(%rsp)
	leaq	4384(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, 4384(%rsp)
	leaq	4384(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$15, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.25, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movq	%r14, 16(%rsp)
	movabsq	$4503874505277440, %rax
	movq	%rax, 24(%rsp)
	movq	%r14, 32(%rsp)
	movabsq	$9007474132647936, %rax
	movq	%rax, 40(%rsp)
	movq	%r14, 48(%rsp)
	movabsq	$13511073760018432, %rax
	movq	%rax, 56(%rsp)
	movq	%r14, 64(%rsp)
	movabsq	$18014673387388928, %rax
	movq	%rax, 72(%rsp)
	movq	%r14, 80(%rsp)
	movabsq	$22518273014759424, %rax
	movq	%rax, 88(%rsp)
	movq	%r14, 96(%rsp)
	movabsq	$27021872642129920, %rax
	movq	%rax, 104(%rsp)
	movq	%r14, 112(%rsp)
	movabsq	$31525472269500416, %rax
	movq	%rax, 120(%rsp)
	movq	%r14, 128(%rsp)
	movabsq	$36029071896870912, %rax
	movq	%rax, 136(%rsp)
	movq	%r14, 144(%rsp)
	movabsq	$40532671524241408, %rax
	movq	%rax, 152(%rsp)
	movq	%r14, 160(%rsp)
	movabsq	$45036271151611904, %rax
	movq	%rax, 168(%rsp)
	movq	%r14, 176(%rsp)
	movabsq	$49539870778982400, %rax
	movq	%rax, 184(%rsp)
	movq	%r14, 192(%rsp)
	movabsq	$54043470406352896, %rax
	movq	%rax, 200(%rsp)
	movq	%r14, 208(%rsp)
	movabsq	$58547070033723392, %rax
	movq	%rax, 216(%rsp)
	movq	%r14, 224(%rsp)
	movabsq	$63050669661093888, %rax
	movq	%rax, 232(%rsp)
	movq	%r14, 240(%rsp)
	movabsq	$67554269288464384, %rax
	movq	%rax, 248(%rsp)
	movq	%r14, 256(%rsp)
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$256, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4360(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB44_7
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB44_28
	movl	$33554432, 264(%rsp,%r14)
	movq	%rax, 4360(%rsp)
	cmpq	$4092, %rax
	ja	.LBB44_6
	leaq	4(%rax), %r14
	movl	$33554432, 264(%rsp,%rax)
	movq	%r14, 4360(%rsp)
	cmpq	$4089, %rax
	jae	.LBB44_7
	movl	$150994944, 268(%rsp,%rax)
	addq	$8, %rax
	movq	%rax, 4360(%rsp)
	movq	%rax, %r14
	jmp	.LBB44_8
.LBB44_6:
	movq	%rax, %r14
.LBB44_7:
	movb	$0, 4376(%rsp)
.LBB44_8:
	movq	%r14, %rax
	addq	$112, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB44_11
	movq	%rbx, %rdi
	subq	%r14, %rdi
	cmpq	$112, %rdi
	jne	.LBB44_29
	leaq	(%rsp,%r14), %rdi
	addq	$264, %rdi
	movl	$112, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.22, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4360(%rsp)
	jmp	.LBB44_12
.LBB44_11:
	movb	$0, 4376(%rsp)
	movq	%r14, %rbx
.LBB44_12:
	movq	%rbx, 4368(%rsp)
	movl	$-302117424, 264(%rsp)
	movl	%ebx, %eax
	bswapl	%eax
	movl	%eax, 268(%rsp)
	movl	$1610743808, 272(%rsp)
	movl	%r14d, %eax
	bswapl	%eax
	movl	%eax, 276(%rsp)
	movabsq	$1224979099315863552, %rax
	movq	%rax, 280(%rsp)
	movl	$268435456, 288(%rsp)
	movl	$1879048192, 296(%rsp)
	addl	$-608, %r14d
	bswapl	%r14d
	movl	%r14d, 300(%rsp)
	cmpq	$4097, %rbx
	jae	.LBB44_27
	leaq	4384(%rsp), %rdi
	leaq	264(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	cmpb	$1, 4384(%rsp)
	je	.LBB44_14
	leaq	4392(%rsp), %rsi
	leaq	5192(%rsp), %rdi
	movl	$800, %edx
	callq	*memcpy@GOTPCREL(%rip)
	cmpb	$1, 4376(%rsp)
	jne	.LBB44_14
	leaq	5192(%rsp), %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map
	testb	%al, %al
	je	.LBB44_14
	movq	5960(%rsp), %rsi
	cmpq	$17, %rsi
	jae	.LBB44_30
	cmpq	$16, %rsi
	jne	.LBB44_14
	movq	5968(%rsp), %rsi
	cmpq	$33, %rsi
	jae	.LBB44_31
	cmpq	$32, %rsi
	jne	.LBB44_14
	cmpq	$65536, 5976(%rsp)
	sete	%al
	addq	$5992, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB44_14:
	.cfi_def_cfa_offset 6016
	xorl	%eax, %eax
	addq	$5992, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB44_27:
	.cfi_def_cfa_offset 6016
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB44_28:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB44_29:
	movl	$112, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB44_30:
	movl	$16, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB44_31:
	movl	$32, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end44:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17capacity_boundary, .Lfunc_end44-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17capacity_boundary
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin,"ax",@progbits
	.prefalign	4, .Lfunc_end45, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin:
.Lfunc_begin45:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rdi, %rbx
	movq	4096(%rdi), %rdi
	movq	%rdi, %rax
	addq	$4, %rax
	movq	$-1, %rcx
	cmovaeq	%rax, %rcx
	cmpq	$4097, %rcx
	jae	.LBB45_3
	movq	%rcx, %rax
	subq	%rdi, %rax
	cmpq	$4, %rax
	jne	.LBB45_21
	movl	$16777216, (%rbx,%rdi)
	movq	%rcx, 4096(%rbx)
	movq	%rcx, %rdi
	jmp	.LBB45_4
.LBB45_3:
	movb	$0, 4112(%rbx)
.LBB45_4:
	movq	%rdi, %rax
	addq	%rdx, %rax
	movq	$-1, %r14
	cmovaeq	%rax, %r14
	cmpq	$4097, %r14
	jae	.LBB45_7
	movq	%r14, %rax
	subq	%rdi, %rax
	cmpq	%rdx, %rax
	jne	.LBB45_22
	addq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r14, 4096(%rbx)
	movq	%r14, %rdi
	jmp	.LBB45_8
.LBB45_7:
	movb	$0, 4112(%rbx)
.LBB45_8:
	movq	%rdi, %rax
	incq	%rax
	movq	$-1, %rcx
	cmovneq	%rax, %rcx
	cmpq	$4097, %rcx
	jae	.LBB45_19
	movq	%rcx, %rax
	subq	%rdi, %rax
	cmpq	$1, %rax
	jne	.LBB45_23
	movb	$0, (%rbx,%rdi)
	movq	%rcx, 4096(%rbx)
	testb	$3, %cl
	je	.LBB45_17
	cmpb	$0, 4112(%rbx)
	je	.LBB45_17
	movq	$-1, %rax
	movq	%rcx, %rdx
	.p2align	4
.LBB45_13:
	incq	%rdx
	cmoveq	%rax, %rdx
	cmpq	$4097, %rdx
	jae	.LBB45_19
	movq	%rdx, %rdi
	subq	%rcx, %rdi
	cmpq	$1, %rdi
	jne	.LBB45_20
	movb	$0, (%rbx,%rcx)
	movq	%rdx, 4096(%rbx)
	testb	$3, %dl
	je	.LBB45_17
	cmpb	$0, 4112(%rbx)
	movq	%rdx, %rcx
	jne	.LBB45_13
.LBB45_17:
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB45_19:
	.cfi_def_cfa_offset 32
	movb	$0, 4112(%rbx)
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB45_20:
	.cfi_def_cfa_offset 32
	movl	$1, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB45_21:
	movl	$4, %esi
	movq	%rax, %rdi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB45_22:
	movq	%rax, %rdi
	movq	%rdx, %rsi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB45_23:
	movl	$1, %esi
	movq	%rax, %rdi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end45:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin, .Lfunc_end45-_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property,"ax",@progbits
	.prefalign	4, .Lfunc_end46, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property:
.Lfunc_begin46:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %r14
	movq	%rcx, (%rsp)
	movq	%rdx, %r12
	movq	%rsi, %r13
	movq	%rdi, %rbx
	xorl	%ebp, %ebp
	movq	memcmp@GOTPCREL(%rip), %r15
	jmp	.LBB46_2
	.p2align	4
.LBB46_1:
	leaq	(%r12,%rbp), %rax
	incq	%rax
	incq	%rbp
	cmpq	$112, %rax
	je	.LBB46_9
.LBB46_2:
	leaq	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.22(%rbp), %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	*%r15
	testl	%eax, %eax
	jne	.LBB46_1
	cmpb	$0, .Lanon.2518d136abfec7ebc9d3a69d0b38d406.22(%r12,%rbp)
	jne	.LBB46_1
	movq	4096(%rbx), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	movq	%rax, %rdi
	cmpq	$4096, %rcx
	ja	.LBB46_13
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB46_27
	movl	$50331648, (%rbx,%rax)
	movq	%rcx, 4096(%rbx)
	cmpq	$4092, %rcx
	ja	.LBB46_12
	leaq	4(%rcx), %rdi
	movl	%r14d, %edx
	bswapl	%edx
	movl	%edx, (%rbx,%rcx)
	movq	%rdi, 4096(%rbx)
	cmpq	$4089, %rcx
	jae	.LBB46_13
	bswapl	%ebp
	movl	%ebp, 4(%rbx,%rcx)
	addq	$8, %rcx
	movq	%rcx, 4096(%rbx)
	movq	%rcx, %rdi
	jmp	.LBB46_14
.LBB46_9:
	movb	$0, 4112(%rbx)
	xorl	%eax, %eax
.LBB46_10:
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB46_12:
	.cfi_def_cfa_offset 64
	movq	%rcx, %rdi
.LBB46_13:
	movb	$0, 4112(%rbx)
.LBB46_14:
	movq	%rdi, %rcx
	addq	%r14, %rcx
	movq	$-1, %r12
	cmovaeq	%rcx, %r12
	cmpq	$4097, %r12
	jae	.LBB46_24
	movq	%rax, %r15
	movq	%r12, %rax
	subq	%rdi, %rax
	cmpq	%r14, %rax
	jne	.LBB46_28
	addq	%rbx, %rdi
	movq	(%rsp), %rsi
	movq	%r14, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r12, 4096(%rbx)
	testb	$3, %r12b
	je	.LBB46_25
	cmpb	$0, 4112(%rbx)
	movq	%r15, %rax
	je	.LBB46_10
	movq	$-1, %rcx
	movq	%r12, %rdx
	.p2align	4
.LBB46_19:
	incq	%rdx
	cmoveq	%rcx, %rdx
	cmpq	$4097, %rdx
	jae	.LBB46_24
	movq	%rdx, %rdi
	subq	%r12, %rdi
	cmpq	$1, %rdi
	jne	.LBB46_26
	movb	$0, (%rbx,%r12)
	movq	%rdx, 4096(%rbx)
	testb	$3, %dl
	je	.LBB46_10
	cmpb	$0, 4112(%rbx)
	movq	%rdx, %r12
	jne	.LBB46_19
	jmp	.LBB46_10
.LBB46_24:
	movb	$0, 4112(%rbx)
	jmp	.LBB46_10
.LBB46_25:
	movq	%r15, %rax
	jmp	.LBB46_10
.LBB46_26:
	movl	$1, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB46_27:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB46_28:
	movq	%rax, %rdi
	movq	%r14, %rsi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end46:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property, .Lfunc_end46-_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map,"ax",@progbits
	.prefalign	4, .Lfunc_end47, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map:
.Lfunc_begin47:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	768(%rdi), %rax
	cmpq	$17, %rax
	jae	.LBB47_19
	testq	%rax, %rax
	je	.LBB47_12
	leaq	512(%rdi), %rdx
	movq	%rax, %rcx
	shlq	$4, %rcx
	leaq	(%rdi,%rcx), %rsi
	addq	$512, %rsi
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	xorl	%ecx, %ecx
	jmp	.LBB47_5
	.p2align	4
.LBB47_4:
	addq	$16, %rdx
	incq	%r9
	addq	$16, %r8
	cmpq	%rsi, %rdx
	je	.LBB47_14
.LBB47_5:
	movq	(%rdx), %r10
	movq	8(%rdx), %r11
	movq	%r11, %rbx
	subq	%r10, %rbx
	jbe	.LBB47_12
	addq	%rbx, %rcx
	jb	.LBB47_12
	cmpq	%rax, %r9
	ja	.LBB47_20
	testq	%r9, %r9
	je	.LBB47_4
	xorl	%ebx, %ebx
	jmp	.LBB47_10
	.p2align	4
.LBB47_3:
	addq	$16, %rbx
	cmpq	%rbx, %r8
	je	.LBB47_4
.LBB47_10:
	cmpq	520(%rdi,%rbx), %r10
	jae	.LBB47_3
	cmpq	%r11, 512(%rdi,%rbx)
	jae	.LBB47_3
.LBB47_12:
	xorl	%eax, %eax
.LBB47_13:
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB47_14:
	.cfi_def_cfa_offset 16
	movq	776(%rdi), %rsi
	cmpq	$33, %rsi
	jae	.LBB47_21
	shlq	$4, %rsi
	movq	%rdi, %rdx
	.p2align	4
.LBB47_16:
	testq	%rsi, %rsi
	je	.LBB47_18
	movq	(%rdx), %r8
	addq	$-16, %rsi
	xorl	%eax, %eax
	cmpq	8(%rdx), %r8
	leaq	16(%rdx), %rdx
	jb	.LBB47_16
	jmp	.LBB47_13
.LBB47_18:
	cmpq	%rcx, 784(%rdi)
	sete	%al
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB47_20:
	.cfi_def_cfa_offset 16
	leaq	1(%rax), %rsi
	xorl	%edi, %edi
	movq	%rax, %rdx
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB47_19:
	movl	$16, %edx
	xorl	%edi, %edi
	movq	%rax, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB47_21:
	movl	$32, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end47:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map, .Lfunc_end47-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9malformed,"ax",@progbits
	.prefalign	4, .Lfunc_end48, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9malformed,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9malformed:
.Lfunc_begin48:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests25truncations_and_mutations
	testb	%al, %al
	je	.LBB48_60
	xorl	%edi, %edi
	xorl	%esi, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$4, %edi
	movl	$39, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$4, %edi
	movl	$2097153, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$8, %edi
	movl	$609, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$8, %edi
	movl	$-1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$12, %edi
	movl	$608, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$16, %edi
	movl	$41, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$16, %edi
	movl	$608, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$20, %edi
	movl	$16, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$20, %edi
	movl	$18, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$24, %edi
	movl	$17, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$32, %edi
	movl	$-1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$36, %edi
	movl	$-1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$608, %edi
	movl	$2, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	movl	$628, %edi
	movl	$1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	testb	%al, %al
	je	.LBB48_60
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB48_60
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB48_60
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB48_60
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB48_60
	movl	$4, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB48_60
	movl	$5, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB48_60
	movl	$6, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	testb	%al, %al
	je	.LBB48_60
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$4, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$5, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$6, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$7, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$8, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$9, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$10, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$11, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$12, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$13, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$14, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$15, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$16, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$17, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$18, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	movl	$19, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	testb	%al, %al
	je	.LBB48_60
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$4, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$5, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$6, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$7, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$8, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$9, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$10, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$11, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$12, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	testb	%al, %al
	je	.LBB48_60
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation
	testb	%al, %al
	je	.LBB48_60
	movl	$4, %edi
	popq	%rax
	.cfi_def_cfa_offset 8
	jmp	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation
.LBB48_60:
	.cfi_def_cfa_offset 16
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end48:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9malformed, .Lfunc_end48-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9malformed
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests25truncations_and_mutations,"ax",@progbits
	.prefalign	4, .Lfunc_end49, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests25truncations_and_mutations,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests25truncations_and_mutations:
.Lfunc_begin49:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$1640, %rsp
	.cfi_def_cfa_offset 5792
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	leaq	816(%rsp), %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic
	cmpb	$1, 4928(%rsp)
	jne	.LBB49_6
	movq	4920(%rsp), %rbx
	cmpq	$4097, %rbx
	jae	.LBB49_16
	leaq	8(%rsp), %rdi
	leaq	816(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	cmpb	$0, 8(%rsp)
	je	.LBB49_3
.LBB49_6:
	xorl	%eax, %eax
.LBB49_7:
	addq	$5736, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB49_3:
	.cfi_def_cfa_offset 5792
	movb	$1, %al
	testq	%rbx, %rbx
	je	.LBB49_7
	xorl	%r14d, %r14d
	leaq	8(%rsp), %r15
	leaq	816(%rsp), %r12
	.p2align	4
.LBB49_5:
	movq	%r15, %rdi
	movq	%r12, %rsi
	movq	%r14, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	cmpb	$0, 8(%rsp)
	je	.LBB49_6
	incq	%r14
	cmpq	%r14, %rbx
	jne	.LBB49_5
	xorl	%ebp, %ebp
	leaq	8(%rsp), %r15
	leaq	816(%rsp), %r12
	leaq	4936(%rsp), %r13
	jmp	.LBB49_14
	.p2align	4
.LBB49_9:
	movb	%r14b, 816(%rsp,%rbp)
	incq	%rbp
	cmpq	%rbp, %rbx
	je	.LBB49_10
.LBB49_14:
	movzbl	816(%rsp,%rbp), %r14d
	movl	%r14d, %eax
	notb	%al
	movb	%al, 816(%rsp,%rbp)
	movq	4920(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB49_15
	movq	%r15, %rdi
	movq	%r12, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	cmpb	$1, 8(%rsp)
	je	.LBB49_9
	movl	$800, %edx
	movq	%r13, %rdi
	leaq	16(%rsp), %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r13, %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests9sound_map
	testb	%al, %al
	jne	.LBB49_9
	jmp	.LBB49_6
.LBB49_10:
	movb	$1, %al
	jmp	.LBB49_7
.LBB49_15:
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB49_16:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end49:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests25truncations_and_mutations, .Lfunc_end49-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests25truncations_and_mutations
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header,"ax",@progbits
	.prefalign	4, .Lfunc_end50, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header:
.Lfunc_begin50:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$840, %rsp
	.cfi_def_cfa_offset 4960
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movl	%esi, %ebx
	movq	%rdi, %r14
	leaq	816(%rsp), %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic
	bswapl	%ebx
	movl	%ebx, 816(%rsp,%r14)
	cmpb	$1, 4928(%rsp)
	jne	.LBB50_3
	movq	4920(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB50_5
	leaq	8(%rsp), %rdi
	leaq	816(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	movzbl	8(%rsp), %eax
	addq	$4936, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB50_3:
	.cfi_def_cfa_offset 4960
	xorl	%eax, %eax
	addq	$4936, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB50_5:
	.cfi_def_cfa_offset 4960
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end50:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header, .Lfunc_end50-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests14invalid_header
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure,"ax",@progbits
	.prefalign	4, .Lfunc_end51, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure:
.Lfunc_begin51:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$840, %rsp
	.cfi_def_cfa_offset 4960
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movl	%edi, %ebx
	leaq	816(%rsp), %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic
	testb	%bl, %bl
	je	.LBB51_6
	movzbl	%bl, %eax
	cmpl	$1, %eax
	je	.LBB51_4
	cmpl	$5, %eax
	jne	.LBB51_7
	movl	$-1, 1440(%rsp)
	cmpb	$1, 4928(%rsp)
	je	.LBB51_12
.LBB51_37:
	xorl	%eax, %eax
	addq	$4936, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB51_4:
	.cfi_def_cfa_offset 4960
	movq	4920(%rsp), %rsi
	leaq	-724(%rsi), %rdx
	cmpq	$3485, %rdx
	jae	.LBB51_40
	leaq	1428(%rsp), %rdi
	movl	$120, %esi
	callq	*memset@GOTPCREL(%rip)
	cmpb	$1, 4928(%rsp)
	je	.LBB51_12
	jmp	.LBB51_37
.LBB51_6:
	movb	$1, 1429(%rsp)
	cmpb	$1, 4928(%rsp)
	jne	.LBB51_37
.LBB51_12:
	movq	4920(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB51_39
	leaq	8(%rsp), %rdi
	leaq	816(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	movzbl	8(%rsp), %eax
	addq	$4936, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB51_7:
	.cfi_def_cfa_offset 4960
	cmpb	$5, %bl
	jae	.LBB51_10
	leaq	816(%rsp), %r14
	movl	$4096, %edx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$608, 4912(%rsp)
	movq	$0, 4920(%rsp)
	movl	$1, %esi
	movq	%r14, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	cmpb	$4, %bl
	jne	.LBB51_14
	movq	4912(%rsp), %r14
.LBB51_18:
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB51_21
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB51_41
	movl	$33554432, 816(%rsp,%r14)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r14
	cmpb	$3, %bl
	je	.LBB51_22
	jmp	.LBB51_28
.LBB51_10:
	movq	4920(%rsp), %rdi
	decq	%rdi
	cmpq	$4096, %rdi
	jae	.LBB51_43
	movb	$120, 816(%rsp,%rdi)
	movl	$1694498816, 1440(%rsp)
	cmpb	$1, 4928(%rsp)
	jne	.LBB51_37
	jmp	.LBB51_12
.LBB51_14:
	leaq	816(%rsp), %r14
	movl	$15, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.25, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 16(%rsp)
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4912(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB51_17
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB51_41
	movl	$33554432, 816(%rsp,%r14)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r14
	cmpb	$2, %bl
	jne	.LBB51_18
	jmp	.LBB51_28
.LBB51_21:
	movb	$0, 4928(%rsp)
	cmpb	$3, %bl
	jne	.LBB51_28
.LBB51_22:
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB51_27
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB51_41
	movl	$150994944, 816(%rsp,%r14)
	movq	%rax, 4912(%rsp)
	cmpq	$4093, %rax
	jae	.LBB51_26
	movl	$67108864, 816(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4912(%rsp)
	movq	%rax, %r14
	jmp	.LBB51_28
.LBB51_17:
	movb	$0, 4928(%rsp)
	cmpb	$2, %bl
	je	.LBB51_28
	jmp	.LBB51_18
.LBB51_26:
	movq	%rax, %r14
.LBB51_27:
	movb	$0, 4928(%rsp)
.LBB51_28:
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB51_31
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB51_41
	movl	$150994944, 816(%rsp,%r14)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r14
	jmp	.LBB51_32
.LBB51_31:
	movb	$0, 4928(%rsp)
.LBB51_32:
	movq	%r14, %rax
	addq	$112, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB51_35
	movq	%rbx, %rdi
	subq	%r14, %rdi
	cmpq	$112, %rdi
	jne	.LBB51_42
	leaq	(%rsp,%r14), %rdi
	addq	$816, %rdi
	movl	$112, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.22, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4912(%rsp)
	jmp	.LBB51_36
.LBB51_35:
	movb	$0, 4928(%rsp)
	movq	%r14, %rbx
.LBB51_36:
	movq	%rbx, 4920(%rsp)
	movl	$-302117424, 816(%rsp)
	bswapl	%ebx
	movl	%ebx, 820(%rsp)
	movl	$1610743808, 824(%rsp)
	movl	%r14d, %eax
	bswapl	%eax
	movl	%eax, 828(%rsp)
	movabsq	$1224979099315863552, %rax
	movq	%rax, 832(%rsp)
	movl	$268435456, 840(%rsp)
	movl	$1879048192, 848(%rsp)
	addl	$-608, %r14d
	bswapl	%r14d
	movl	%r14d, 852(%rsp)
	cmpb	$1, 4928(%rsp)
	je	.LBB51_12
	jmp	.LBB51_37
.LBB51_39:
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB51_40:
	addq	$-112, %rsi
	movl	$612, %edi
	movl	$4096, %edx
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB51_41:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB51_42:
	movl	$112, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB51_43:
	movl	$4096, %esi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.Lfunc_end51:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure, .Lfunc_end51-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests17invalid_structure
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree,"ax",@progbits
	.prefalign	4, .Lfunc_end52, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree:
.Lfunc_begin52:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$840, %rsp
	.cfi_def_cfa_offset 4976
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	%edi, %ebx
	leaq	816(%rsp), %r14
	movl	$4096, %edx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$608, 4912(%rsp)
	movq	$0, 4920(%rsp)
	movb	$1, 4928(%rsp)
	movl	$1, %esi
	movq	%r14, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movzbl	%bl, %r14d
	cmpb	$3, %r14b
	ja	.LBB52_9
	jmpq	*.LJTI52_0(,%r14,8)
.LBB52_2:
	movl	$33554432, 8(%rsp)
	leaq	816(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	jmp	.LBB52_8
.LBB52_3:
	movq	4912(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB52_11
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB52_88
	movl	$33554432, 816(%rsp,%rax)
	movq	%rcx, 4912(%rsp)
	jmp	.LBB52_12
.LBB52_6:
	leaq	816(%rsp), %rdi
	movl	$3, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.76, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movb	$1, %bpl
	jmp	.LBB52_14
.LBB52_7:
	leaq	816(%rsp), %rdi
	movl	$6, %edx
	movl	$9, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.74, %rcx
.LBB52_8:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	jmp	.LBB52_13
.LBB52_9:
	leaq	816(%rsp), %rdi
	movl	$15, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	cmpb	$4, %bl
	jne	.LBB52_50
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 16(%rsp)
	leaq	816(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	xorl	%ebp, %ebp
	jmp	.LBB52_25
.LBB52_11:
	movb	$0, 4928(%rsp)
.LBB52_12:
	leaq	816(%rsp), %rdi
	movl	$11, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.75, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
.LBB52_13:
	xorl	%ebp, %ebp
.LBB52_14:
	leaq	816(%rsp), %rdi
	movl	$15, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
.LBB52_15:
	leaq	816(%rsp), %rdi
	movl	$11, %edx
	movl	$7, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.25, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	leal	-5(%r14), %eax
	cmpl	$4, %eax
	ja	.LBB52_47
	jmpq	*.LJTI52_1(,%rax,8)
.LBB52_17:
	movabsq	$-72057594037927937, %rax
	movq	%rax, 8(%rsp)
	movabsq	$288230376151711744, %rax
	movq	%rax, 16(%rsp)
	jmp	.LBB52_22
.LBB52_18:
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movabsq	$4503599627370496, %rax
	movq	%rax, 16(%rsp)
	movabsq	$4503874505277440, %rcx
	movq	%rcx, 24(%rsp)
	movq	%rax, 32(%rsp)
	movabsq	$9007474132647936, %rcx
	movq	%rcx, 40(%rsp)
	movq	%rax, 48(%rsp)
	movabsq	$13511073760018432, %rcx
	movq	%rcx, 56(%rsp)
	movq	%rax, 64(%rsp)
	movabsq	$18014673387388928, %rcx
	movq	%rcx, 72(%rsp)
	movq	%rax, 80(%rsp)
	movabsq	$22518273014759424, %rcx
	movq	%rcx, 88(%rsp)
	movq	%rax, 96(%rsp)
	movabsq	$27021872642129920, %rcx
	movq	%rcx, 104(%rsp)
	movq	%rax, 112(%rsp)
	movabsq	$31525472269500416, %rcx
	movq	%rcx, 120(%rsp)
	movq	%rax, 128(%rsp)
	movabsq	$36029071896870912, %rcx
	movq	%rcx, 136(%rsp)
	movq	%rax, 144(%rsp)
	movabsq	$40532671524241408, %rcx
	movq	%rcx, 152(%rsp)
	movq	%rax, 160(%rsp)
	movabsq	$45036271151611904, %rcx
	movq	%rcx, 168(%rsp)
	movq	%rax, 176(%rsp)
	movabsq	$49539870778982400, %rcx
	movq	%rcx, 184(%rsp)
	movq	%rax, 192(%rsp)
	movabsq	$54043470406352896, %rcx
	movq	%rcx, 200(%rsp)
	movq	%rax, 208(%rsp)
	movabsq	$58547070033723392, %rcx
	movq	%rcx, 216(%rsp)
	movq	%rax, 224(%rsp)
	movabsq	$63050669661093888, %rcx
	movq	%rcx, 232(%rsp)
	movq	%rax, 240(%rsp)
	movabsq	$67554269288464384, %rcx
	movq	%rcx, 248(%rsp)
	movq	%rax, 256(%rsp)
	movabsq	$1374389534720, %rcx
	movq	%rcx, 264(%rsp)
	movq	%rax, 272(%rsp)
	leaq	816(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$272, %r8d
	jmp	.LBB52_23
.LBB52_19:
	leaq	816(%rsp), %rdi
	movl	$3, %edx
	movl	$15, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.77, %rcx
	jmp	.LBB52_24
.LBB52_20:
	leaq	816(%rsp), %rdi
	movl	$3, %edx
	movl	$1, %ecx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	xorl	%r8d, %r8d
	jmp	.LBB52_24
.LBB52_21:
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movq	$0, 16(%rsp)
.LBB52_22:
	leaq	816(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
.LBB52_23:
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
.LBB52_24:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
.LBB52_25:
	movq	4912(%rsp), %r15
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB52_28
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB52_88
	movl	$33554432, 816(%rsp,%r15)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	testb	%bpl, %bpl
	jne	.LBB52_29
.LBB52_32:
	addl	$-15, %r14d
	cmpl	$3, %r14d
	jbe	.LBB52_34
	jmp	.LBB52_66
.LBB52_28:
	movb	$0, 4928(%rsp)
	testb	%bpl, %bpl
	je	.LBB52_32
.LBB52_29:
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB52_33
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB52_88
	movl	$33554432, 816(%rsp,%r15)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	addl	$-15, %r14d
	cmpl	$3, %r14d
	jbe	.LBB52_34
	jmp	.LBB52_66
.LBB52_33:
	movb	$0, 4928(%rsp)
	addl	$-15, %r14d
	cmpl	$3, %r14d
	ja	.LBB52_66
.LBB52_34:
	jmpq	*.LJTI52_3(,%r14,8)
.LBB52_35:
	leaq	816(%rsp), %r14
	movl	$15, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.25, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 16(%rsp)
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4912(%rsp), %r15
.LBB52_36:
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB52_37
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB52_88
	movl	$33554432, 816(%rsp,%r15)
	jmp	.LBB52_65
.LBB52_38:
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB52_37
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB52_88
	movl	$117440512, 816(%rsp,%r15)
.LBB52_65:
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	jmp	.LBB52_66
.LBB52_37:
	movb	$0, 4928(%rsp)
	jmp	.LBB52_66
.LBB52_41:
	leaq	816(%rsp), %r14
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33, %eax
	movq	4912(%rsp), %r15
	movq	$-1, %rcx
	jmp	.LBB52_43
	.p2align	4
.LBB52_42:
	movb	$0, 4928(%rsp)
	decl	%eax
	je	.LBB52_66
.LBB52_43:
	movq	%r15, %rdx
	addq	$4, %rdx
	cmovbq	%rcx, %rdx
	cmpq	$4097, %rdx
	jae	.LBB52_42
	movq	%rdx, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB52_88
	movl	$33554432, 816(%rsp,%r15)
	movq	%rdx, 4912(%rsp)
	movq	%rdx, %r15
	decl	%eax
	jne	.LBB52_43
	jmp	.LBB52_66
.LBB52_46:
	leaq	816(%rsp), %rdi
	movl	$6, %edx
	movl	$5, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.54, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4912(%rsp), %r15
.LBB52_66:
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB52_69
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB52_88
	movl	$33554432, 816(%rsp,%r15)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	cmpb	$19, %bl
	je	.LBB52_70
	jmp	.LBB52_74
.LBB52_69:
	movb	$0, 4928(%rsp)
	cmpb	$19, %bl
	jne	.LBB52_74
.LBB52_70:
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB52_73
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB52_88
	movl	$33554432, 816(%rsp,%r15)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	jmp	.LBB52_74
.LBB52_73:
	movb	$0, 4928(%rsp)
.LBB52_74:
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB52_77
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB52_88
	movl	$150994944, 816(%rsp,%r15)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	jmp	.LBB52_78
.LBB52_77:
	movb	$0, 4928(%rsp)
.LBB52_78:
	movq	%r15, %rax
	addq	$112, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB52_81
	movq	%rbx, %rdi
	subq	%r15, %rdi
	cmpq	$112, %rdi
	jne	.LBB52_90
	leaq	(%rsp,%r15), %rdi
	addq	$816, %rdi
	movl	$112, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.22, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4912(%rsp)
	movzbl	4928(%rsp), %eax
	jmp	.LBB52_82
.LBB52_81:
	movb	$0, 4928(%rsp)
	xorl	%eax, %eax
	movq	%r15, %rbx
.LBB52_82:
	movq	%rbx, 4920(%rsp)
	movl	$-302117424, 816(%rsp)
	movl	%ebx, %ecx
	bswapl	%ecx
	movl	%ecx, 820(%rsp)
	movl	$1610743808, 824(%rsp)
	movl	%r15d, %ecx
	bswapl	%ecx
	movl	%ecx, 828(%rsp)
	movabsq	$1224979099315863552, %rcx
	movq	%rcx, 832(%rsp)
	movl	$268435456, 840(%rsp)
	movl	$1879048192, 848(%rsp)
	addl	$-608, %r15d
	bswapl	%r15d
	movl	%r15d, 852(%rsp)
	testb	%al, %al
	je	.LBB52_85
	cmpq	$4097, %rbx
	jae	.LBB52_89
	leaq	8(%rsp), %rdi
	leaq	816(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	movzbl	8(%rsp), %eax
	jmp	.LBB52_86
.LBB52_85:
	xorl	%eax, %eax
.LBB52_86:
	addq	$4936, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB52_47:
	.cfi_def_cfa_offset 4976
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 16(%rsp)
	leaq	816(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	leal	-10(%r14), %eax
	cmpl	$4, %eax
	ja	.LBB52_25
	jmpq	*.LJTI52_2(,%rax,8)
.LBB52_49:
	movabsq	$343597383680, %rax
	movq	%rax, 8(%rsp)
	movabsq	$4503599627370496, %rax
	movq	%rax, 16(%rsp)
	leaq	816(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	jmp	.LBB52_57
.LBB52_50:
	xorl	%ebp, %ebp
	jmp	.LBB52_15
.LBB52_51:
	leaq	816(%rsp), %rdi
	movl	$11, %edx
	movl	$7, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.25, %rcx
	jmp	.LBB52_57
.LBB52_52:
	leaq	816(%rsp), %rdi
	movl	$6, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.78, %rcx
	jmp	.LBB52_57
.LBB52_53:
	leaq	816(%rsp), %rdi
	movl	$5, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.79, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movq	4912(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB52_87
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB52_88
	movl	$33554432, 816(%rsp,%rax)
	movq	%rcx, 4912(%rsp)
	jmp	.LBB52_58
.LBB52_56:
	leaq	816(%rsp), %rdi
	movl	$6, %edx
	movl	$9, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.74, %rcx
.LBB52_57:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
.LBB52_58:
	movq	4912(%rsp), %r15
	movq	%r15, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB52_61
	movq	%rax, %rdi
	subq	%r15, %rdi
	cmpq	$4, %rdi
	jne	.LBB52_88
	movl	$33554432, 816(%rsp,%r15)
	movq	%rax, 4912(%rsp)
	movq	%rax, %r15
	testb	%bpl, %bpl
	jne	.LBB52_36
	jmp	.LBB52_66
.LBB52_61:
	movb	$0, 4928(%rsp)
	testb	%bpl, %bpl
	jne	.LBB52_36
	jmp	.LBB52_66
.LBB52_87:
	movb	$0, 4928(%rsp)
	jmp	.LBB52_58
.LBB52_88:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB52_89:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB52_90:
	movl	$112, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end52:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree, .Lfunc_end52-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests12invalid_tree,"a",@progbits
	.p2align	3, 0x0
.LJTI52_0:
	.quad	.LBB52_2
	.quad	.LBB52_7
	.quad	.LBB52_3
	.quad	.LBB52_6
.LJTI52_1:
	.quad	.LBB52_17
	.quad	.LBB52_21
	.quad	.LBB52_19
	.quad	.LBB52_20
	.quad	.LBB52_18
.LJTI52_2:
	.quad	.LBB52_49
	.quad	.LBB52_56
	.quad	.LBB52_52
	.quad	.LBB52_53
	.quad	.LBB52_51
.LJTI52_3:
	.quad	.LBB52_35
	.quad	.LBB52_46
	.quad	.LBB52_38
	.quad	.LBB52_41

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation,"ax",@progbits
	.prefalign	4, .Lfunc_end53, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation:
.Lfunc_begin53:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$832, %rsp
	.cfi_def_cfa_offset 4960
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movl	%edi, %ebx
	leaq	808(%rsp), %r14
	movl	$4096, %edx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$608, 4904(%rsp)
	movq	$0, 4912(%rsp)
	movb	$1, 4920(%rsp)
	movl	$1, %esi
	movq	%r14, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$15, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.25, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$274877906944, %rax
	movq	%rax, (%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 8(%rsp)
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB53_1
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB53_53
	movl	$33554432, 808(%rsp,%rax)
	movq	%rcx, 4904(%rsp)
	jmp	.LBB53_4
.LBB53_1:
	movb	$0, 4920(%rsp)
.LBB53_4:
	movabsq	$4503599627370496, %r15
	leaq	808(%rsp), %r14
	movl	$15, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.66, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movzbl	%bl, %r14d
	cmpb	$1, %r14b
	je	.LBB53_10
	leaq	808(%rsp), %rdi
	movl	$6, %edx
	testl	%r14d, %r14d
	jne	.LBB53_7
	movl	$16, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.83, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.84, %rcx
	jmp	.LBB53_9
.LBB53_7:
	movl	$1, %ecx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.83, %rsi
	xorl	%r8d, %r8d
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	leaq	808(%rsp), %rdi
	movl	$6, %edx
	cmpb	$2, %bl
	jne	.LBB53_11
	movl	$9, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.74, %rcx
.LBB53_9:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
.LBB53_10:
	leaq	808(%rsp), %rdi
	movl	$6, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.85, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
.LBB53_12:
	movabsq	$1374389534720, %rax
	movq	%rax, (%rsp)
	movq	%r15, 8(%rsp)
	leaq	808(%rsp), %rdi
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	addl	$-4, %r14d
	cmpl	$7, %r14d
	ja	.LBB53_16
	jmpq	*.LJTI53_0(,%r14,8)
.LBB53_25:
	movq	%r15, (%rsp)
	leaq	808(%rsp), %rdi
	movq	%rsp, %rcx
	movl	$9, %edx
	movl	$8, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.87, %rsi
	jmp	.LBB53_15
.LBB53_11:
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.85, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	cmpb	$3, %bl
	jne	.LBB53_12
.LBB53_14:
	movq	%r15, (%rsp)
	leaq	808(%rsp), %rdi
	movq	%rsp, %rcx
	movl	$4, %edx
	movl	$8, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.86, %rsi
	jmp	.LBB53_15
.LBB53_29:
	leaq	808(%rsp), %rdi
	movl	$8, %edx
	movl	$1, %ecx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.90, %rsi
	xorl	%r8d, %r8d
	jmp	.LBB53_15
.LBB53_26:
	leaq	808(%rsp), %rdi
	movl	$12, %edx
	movl	$16, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.88, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.84, %rcx
	jmp	.LBB53_15
.LBB53_27:
	leaq	808(%rsp), %rdi
	movl	$6, %edx
	movl	$1, %ecx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.89, %rsi
	xorl	%r8d, %r8d
	jmp	.LBB53_15
.LBB53_35:
	movabsq	$2473901162496, %rax
	movq	%rax, (%rsp)
	movq	%r15, 8(%rsp)
	leaq	808(%rsp), %rdi
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	jmp	.LBB53_15
.LBB53_30:
	leaq	808(%rsp), %rdi
	movl	$6, %edx
	movl	$9, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.74, %rcx
.LBB53_15:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
.LBB53_16:
	movq	4904(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB53_20
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB53_53
	movl	$33554432, 808(%rsp,%r14)
	movq	%rax, 4904(%rsp)
	cmpq	$4093, %rax
	jae	.LBB53_19
	movl	$33554432, 808(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4904(%rsp)
	movq	%rax, %r14
	cmpb	$12, %bl
	je	.LBB53_23
	jmp	.LBB53_38
.LBB53_19:
	movq	%rax, %r14
.LBB53_20:
	movb	$0, 4920(%rsp)
	cmpb	$12, %bl
	jne	.LBB53_38
.LBB53_23:
	leaq	808(%rsp), %rbx
	movl	$15, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.66, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$1, %ecx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.83, %rsi
	xorl	%r8d, %r8d
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4904(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB53_24
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB53_53
	movl	$33554432, 808(%rsp,%r14)
	movq	%rax, 4904(%rsp)
	movq	%rax, %r14
	jmp	.LBB53_38
.LBB53_24:
	movb	$0, 4920(%rsp)
.LBB53_38:
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB53_42
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB53_53
	movl	$33554432, 808(%rsp,%r14)
	movq	%rax, 4904(%rsp)
	cmpq	$4093, %rax
	jae	.LBB53_41
	movl	$150994944, 808(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4904(%rsp)
	movq	%rax, %r14
	jmp	.LBB53_44
.LBB53_41:
	movq	%rax, %r14
.LBB53_42:
	movb	$0, 4920(%rsp)
.LBB53_44:
	movq	%r14, %rax
	addq	$112, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB53_45
	movq	%rbx, %rdi
	subq	%r14, %rdi
	cmpq	$112, %rdi
	jne	.LBB53_54
	leaq	(%rsp,%r14), %rdi
	addq	$808, %rdi
	movl	$112, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.22, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4904(%rsp)
	movzbl	4920(%rsp), %eax
	jmp	.LBB53_48
.LBB53_45:
	movb	$0, 4920(%rsp)
	xorl	%eax, %eax
	movq	%r14, %rbx
.LBB53_48:
	movq	%rbx, 4912(%rsp)
	movl	$-302117424, 808(%rsp)
	movl	%ebx, %ecx
	bswapl	%ecx
	movl	%ecx, 812(%rsp)
	movl	$1610743808, 816(%rsp)
	movl	%r14d, %ecx
	bswapl	%ecx
	movl	%ecx, 820(%rsp)
	movabsq	$1224979099315863552, %rcx
	movq	%rcx, 824(%rsp)
	movl	$268435456, 832(%rsp)
	movl	$1879048192, 840(%rsp)
	addl	$-608, %r14d
	bswapl	%r14d
	movl	%r14d, 844(%rsp)
	testb	%al, %al
	je	.LBB53_49
	cmpq	$4097, %rbx
	jae	.LBB53_55
	movq	%rsp, %rdi
	leaq	808(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	movzbl	(%rsp), %eax
	jmp	.LBB53_52
.LBB53_49:
	xorl	%eax, %eax
.LBB53_52:
	addq	$4928, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB53_31:
	.cfi_def_cfa_offset 4960
	leaq	808(%rsp), %rdi
	movl	$5, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.79, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movq	4904(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB53_32
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB53_53
	movl	$33554432, 808(%rsp,%rax)
	movq	%rcx, 4904(%rsp)
	jmp	.LBB53_16
.LBB53_32:
	movb	$0, 4920(%rsp)
	jmp	.LBB53_16
.LBB53_53:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB53_55:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB53_54:
	movl	$112, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end53:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation, .Lfunc_end53-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests19invalid_reservation,"a",@progbits
	.p2align	3, 0x0
.LJTI53_0:
	.quad	.LBB53_14
	.quad	.LBB53_25
	.quad	.LBB53_26
	.quad	.LBB53_27
	.quad	.LBB53_29
	.quad	.LBB53_30
	.quad	.LBB53_31
	.quad	.LBB53_35

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation,"ax",@progbits
	.prefalign	4, .Lfunc_end54, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation:
.Lfunc_begin54:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$832, %rsp
	.cfi_def_cfa_offset 4944
	.cfi_offset %rbx, -16
	movl	%edi, %ebx
	movq	%rsp, %rdi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic
	cmpb	$3, %bl
	ja	.LBB54_4
	movzbl	%bl, %eax
	jmpq	*.LJTI54_0(,%rax,8)
.LBB54_5:
	movabsq	$4503599627370496, %rax
	movabsq	$274877906944, %rsi
	leaq	592(%rsp), %rcx
	movl	$1342308352, 16(%rsp)
	movl	$600, %edx
	jmp	.LBB54_7
.LBB54_2:
	movabsq	$72057594037927936, %rax
	movl	$40, %edx
	movq	%rax, (%rsp,%rdx)
	cmpb	$1, 4112(%rsp)
	je	.LBB54_10
.LBB54_9:
	xorl	%eax, %eax
	addq	$4928, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB54_6:
	.cfi_def_cfa_offset 4944
	movabsq	$4503599627370496, %rax
	leaq	56(%rsp), %rcx
	movabsq	$274877906944, %rdx
	movq	%rdx, 40(%rsp)
	movq	%rax, 48(%rsp)
	movl	$64, %edx
	movabsq	$72057868915834880, %rsi
	jmp	.LBB54_7
.LBB54_3:
	leaq	40(%rsp), %rcx
	movabsq	$144115188075855872, %rax
	movl	$48, %edx
	movq	$-1, %rsi
	jmp	.LBB54_7
.LBB54_4:
	movabsq	$4503599627370496, %rax
	leaq	552(%rsp), %rcx
	movabsq	$274877906944, %rdx
	movq	%rdx, 40(%rsp)
	movq	%rax, 48(%rsp)
	movabsq	$4503874505277440, %rdx
	movq	%rdx, 56(%rsp)
	movq	%rax, 64(%rsp)
	movabsq	$9007474132647936, %rdx
	movq	%rdx, 72(%rsp)
	movq	%rax, 80(%rsp)
	movabsq	$13511073760018432, %rdx
	movq	%rdx, 88(%rsp)
	movq	%rax, 96(%rsp)
	movabsq	$18014673387388928, %rdx
	movq	%rdx, 104(%rsp)
	movq	%rax, 112(%rsp)
	movabsq	$22518273014759424, %rdx
	movq	%rdx, 120(%rsp)
	movq	%rax, 128(%rsp)
	movabsq	$27021872642129920, %rdx
	movq	%rdx, 136(%rsp)
	movq	%rax, 144(%rsp)
	movabsq	$31525472269500416, %rdx
	movq	%rdx, 152(%rsp)
	movq	%rax, 160(%rsp)
	movabsq	$36029071896870912, %rdx
	movq	%rdx, 168(%rsp)
	movq	%rax, 176(%rsp)
	movabsq	$40532671524241408, %rdx
	movq	%rdx, 184(%rsp)
	movq	%rax, 192(%rsp)
	movabsq	$45036271151611904, %rdx
	movq	%rdx, 200(%rsp)
	movq	%rax, 208(%rsp)
	movabsq	$49539870778982400, %rdx
	movq	%rdx, 216(%rsp)
	movq	%rax, 224(%rsp)
	movabsq	$54043470406352896, %rdx
	movq	%rdx, 232(%rsp)
	movq	%rax, 240(%rsp)
	movabsq	$58547070033723392, %rdx
	movq	%rdx, 248(%rsp)
	movq	%rax, 256(%rsp)
	movabsq	$63050669661093888, %rdx
	movq	%rdx, 264(%rsp)
	movq	%rax, 272(%rsp)
	movabsq	$67554269288464384, %rdx
	movq	%rdx, 280(%rsp)
	movq	%rax, 288(%rsp)
	movabsq	$1374389534720, %rdx
	movq	%rdx, 296(%rsp)
	movq	%rax, 304(%rsp)
	movabsq	$4504974016905216, %rdx
	movq	%rdx, 312(%rsp)
	movq	%rax, 320(%rsp)
	movabsq	$9008573644275712, %rdx
	movq	%rdx, 328(%rsp)
	movq	%rax, 336(%rsp)
	movabsq	$13512173271646208, %rdx
	movq	%rdx, 344(%rsp)
	movq	%rax, 352(%rsp)
	movabsq	$18015772899016704, %rdx
	movq	%rdx, 360(%rsp)
	movq	%rax, 368(%rsp)
	movabsq	$22519372526387200, %rdx
	movq	%rdx, 376(%rsp)
	movq	%rax, 384(%rsp)
	movabsq	$27022972153757696, %rdx
	movq	%rdx, 392(%rsp)
	movq	%rax, 400(%rsp)
	movabsq	$31526571781128192, %rdx
	movq	%rdx, 408(%rsp)
	movq	%rax, 416(%rsp)
	movabsq	$36030171408498688, %rdx
	movq	%rdx, 424(%rsp)
	movq	%rax, 432(%rsp)
	movabsq	$40533771035869184, %rdx
	movq	%rdx, 440(%rsp)
	movq	%rax, 448(%rsp)
	movabsq	$45037370663239680, %rdx
	movq	%rdx, 456(%rsp)
	movq	%rax, 464(%rsp)
	movabsq	$49540970290610176, %rdx
	movq	%rdx, 472(%rsp)
	movq	%rax, 480(%rsp)
	movabsq	$54044569917980672, %rdx
	movq	%rdx, 488(%rsp)
	movq	%rax, 496(%rsp)
	movabsq	$58548169545351168, %rdx
	movq	%rdx, 504(%rsp)
	movq	%rax, 512(%rsp)
	movabsq	$63051769172721664, %rdx
	movq	%rdx, 520(%rsp)
	movq	%rax, 528(%rsp)
	movabsq	$67555368800092160, %rdx
	movq	%rdx, 536(%rsp)
	movq	%rax, 544(%rsp)
	movl	$560, %edx
	movabsq	$2473901162496, %rsi
.LBB54_7:
	movq	%rsi, (%rcx)
	movq	%rax, (%rsp,%rdx)
	cmpb	$1, 4112(%rsp)
	jne	.LBB54_9
.LBB54_10:
	movq	4104(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB54_13
	leaq	4120(%rsp), %rdi
	movq	%rsp, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel11boot_memory5parse
	movzbl	4120(%rsp), %eax
	addq	$4928, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB54_13:
	.cfi_def_cfa_offset 4944
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end54:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation, .Lfunc_end54-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests26invalid_header_reservation,"a",@progbits
	.p2align	3, 0x0
.LJTI54_0:
	.quad	.LBB54_5
	.quad	.LBB54_3
	.quad	.LBB54_2
	.quad	.LBB54_6

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic,"ax",@progbits
	.prefalign	4, .Lfunc_end55, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic:
.Lfunc_begin55:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$48, %rsp
	.cfi_def_cfa_offset 4176
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rbx
	leaq	24(%rsp), %r14
	movl	$4096, %edx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$608, 4120(%rsp)
	movq	$0, 4128(%rsp)
	movb	$1, 4136(%rsp)
	movl	$1, %esi
	movq	%r14, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movl	$15, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.23, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$7, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.25, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movabsq	$274877906944, %rax
	movq	%rax, 8(%rsp)
	movabsq	$34359738368, %rax
	movq	%rax, 16(%rsp)
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$16, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_testsNtB2_4Blob8property
	movq	4120(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB55_7
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB55_13
	movl	$33554432, 24(%rsp,%r14)
	movq	%rax, 4120(%rsp)
	cmpq	$4092, %rax
	ja	.LBB55_6
	leaq	4(%rax), %r14
	movl	$33554432, 24(%rsp,%rax)
	movq	%r14, 4120(%rsp)
	cmpq	$4089, %rax
	jae	.LBB55_7
	movl	$150994944, 28(%rsp,%rax)
	addq	$8, %rax
	movq	%rax, 4120(%rsp)
	movq	%rax, %r14
	jmp	.LBB55_8
.LBB55_6:
	movq	%rax, %r14
.LBB55_7:
	movb	$0, 4136(%rsp)
.LBB55_8:
	movq	%r14, %rax
	addq	$112, %rax
	movq	$-1, %r15
	cmovaeq	%rax, %r15
	cmpq	$4097, %r15
	jae	.LBB55_11
	movq	%r15, %rdi
	subq	%r14, %rdi
	cmpq	$112, %rdi
	jne	.LBB55_14
	leaq	(%rsp,%r14), %rdi
	addq	$24, %rdi
	movl	$112, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.22, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r15, 4120(%rsp)
	jmp	.LBB55_12
.LBB55_11:
	movb	$0, 4136(%rsp)
	movq	%r14, %r15
.LBB55_12:
	movq	%r15, 4128(%rsp)
	movl	$-302117424, 24(%rsp)
	bswapl	%r15d
	movl	%r15d, 28(%rsp)
	movl	$1610743808, 32(%rsp)
	movl	%r14d, %eax
	bswapl	%eax
	movl	%eax, 36(%rsp)
	movabsq	$1224979099315863552, %rax
	movq	%rax, 40(%rsp)
	movl	$268435456, 48(%rsp)
	movl	$1879048192, 56(%rsp)
	addl	$-608, %r14d
	bswapl	%r14d
	movl	%r14d, 60(%rsp)
	leaq	24(%rsp), %rsi
	movl	$4120, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	addq	$4144, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB55_13:
	.cfi_def_cfa_offset 4176
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB55_14:
	movl	$112, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end55:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic, .Lfunc_end55-_RNvNtCsjFdXuXHMTfk_9hm_kernel17boot_memory_tests5basic
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5valid,"ax",@progbits
	.prefalign	4, .Lfunc_end56, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5valid,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5valid:
.Lfunc_begin56:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$56, %rsp
	.cfi_def_cfa_offset 8272
	.cfi_offset %rbx, -24
	.cfi_offset %rbp, -16
	leaq	32(%rsp), %rbx
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.111, %rsi
	movl	$1, %ecx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	leaq	4152(%rsp), %rdi
	movl	$4096, %edx
	movq	%rbx, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	4136(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB56_34
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ebp
	cmpb	$-1, %bpl
	je	.LBB56_48
	cmpb	$1, 4144(%rsp)
	jne	.LBB56_48
	movq	16(%rsp), %rbx
	cmpq	$3, %rbx
	jae	.LBB56_45
	movq	(%rsp), %rax
	cmpq	$2, %rbx
	je	.LBB56_7
	cmpq	$1, %rbx
	jne	.LBB56_48
	testq	%rax, %rax
	jne	.LBB56_48
	jmp	.LBB56_8
.LBB56_7:
	movq	8(%rsp), %rcx
	xorq	$1, %rcx
	orq	%rcx, %rax
	setne	%al
	cmpb	$2, %bpl
	sete	%cl
	orb	%al, %cl
	jne	.LBB56_48
.LBB56_8:
	leaq	32(%rsp), %rdi
	leaq	4152(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	setne	%al
	cmpq	$1, %rbx
	setne	%cl
	cmpb	$2, %bpl
	setne	%dl
	orb	%cl, %dl
	orb	%al, %dl
	jne	.LBB56_48
	leaq	32(%rsp), %rbx
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.111, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	leaq	4152(%rsp), %rdi
	movl	$4096, %edx
	movq	%rbx, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB56_34
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ebp
	cmpb	$-1, %bpl
	je	.LBB56_48
	cmpb	$1, 4144(%rsp)
	jne	.LBB56_48
	movq	16(%rsp), %rbx
	cmpq	$2, %rbx
	ja	.LBB56_45
	movq	(%rsp), %rax
	cmpq	$1, %rbx
	je	.LBB56_16
	cmpq	$2, %rbx
	jne	.LBB56_48
	movq	8(%rsp), %rcx
	xorq	$1, %rcx
	orq	%rcx, %rax
	sete	%al
	cmpb	$2, %bpl
	setne	%cl
	testb	%al, %cl
	jne	.LBB56_17
	jmp	.LBB56_48
.LBB56_16:
	testq	%rax, %rax
	jne	.LBB56_48
.LBB56_17:
	leaq	32(%rsp), %rdi
	leaq	4152(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	setne	%al
	cmpq	$1, %rbx
	setne	%cl
	testb	$-3, %bpl
	sete	%dl
	orb	%cl, %dl
	orb	%al, %dl
	jne	.LBB56_48
	leaq	32(%rsp), %rbx
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.111, %rsi
	movl	$2, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	leaq	4152(%rsp), %rdi
	movl	$4096, %edx
	movq	%rbx, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB56_34
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ebp
	cmpb	$-1, %bpl
	je	.LBB56_48
	cmpb	$1, 4144(%rsp)
	jne	.LBB56_48
	movq	16(%rsp), %rbx
	cmpq	$2, %rbx
	ja	.LBB56_45
	movq	(%rsp), %rax
	cmpq	$1, %rbx
	je	.LBB56_25
	cmpq	$2, %rbx
	jne	.LBB56_48
	movq	8(%rsp), %rcx
	xorq	$1, %rcx
	orq	%rcx, %rax
	sete	%al
	cmpb	$2, %bpl
	setne	%cl
	testb	%al, %cl
	jne	.LBB56_26
	jmp	.LBB56_48
.LBB56_25:
	testq	%rax, %rax
	jne	.LBB56_48
.LBB56_26:
	leaq	32(%rsp), %rdi
	leaq	4152(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	setne	%al
	cmpq	$1, %rbx
	setne	%cl
	testb	$-3, %bpl
	sete	%dl
	orb	%cl, %dl
	orb	%al, %dl
	jne	.LBB56_48
	leaq	32(%rsp), %rbx
	movl	$2, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.62, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	leaq	4152(%rsp), %rdi
	movl	$4096, %edx
	movq	%rbx, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB56_34
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ebp
	cmpb	$-1, %bpl
	je	.LBB56_48
	cmpb	$1, 4144(%rsp)
	jne	.LBB56_48
	movq	16(%rsp), %rbx
	cmpq	$2, %rbx
	ja	.LBB56_45
	movq	(%rsp), %rax
	cmpq	$1, %rbx
	je	.LBB56_36
	cmpq	$2, %rbx
	jne	.LBB56_48
	movq	8(%rsp), %rcx
	xorq	$1, %rcx
	orq	%rcx, %rax
	sete	%al
	cmpb	$2, %bpl
	setne	%cl
	testb	%al, %cl
	jne	.LBB56_37
	jmp	.LBB56_48
.LBB56_34:
	movq	%rdx, %rax
.LBB56_35:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rax, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB56_36:
	testq	%rax, %rax
	jne	.LBB56_48
.LBB56_37:
	leaq	32(%rsp), %rdi
	leaq	4152(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	setne	%al
	cmpq	$2, %rbx
	setne	%cl
	testb	$-3, %bpl
	sete	%dl
	orb	%cl, %dl
	orb	%al, %dl
	jne	.LBB56_48
	leaq	32(%rsp), %rbx
	movl	$2, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.120, %rsi
	movl	$2, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	leaq	4152(%rsp), %rdi
	movl	$4096, %edx
	movq	%rbx, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	4136(%rsp), %rcx
	movq	%rcx, %rax
	cmpq	$4096, %rcx
	ja	.LBB56_35
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	movq	%rax, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ebp
	cmpb	$-1, %bpl
	je	.LBB56_48
	cmpb	$1, 4144(%rsp)
	jne	.LBB56_48
	movq	16(%rsp), %rbx
	cmpq	$2, %rbx
	ja	.LBB56_45
	movq	(%rsp), %rax
	cmpq	$1, %rbx
	je	.LBB56_46
	cmpq	$2, %rbx
	jne	.LBB56_48
	movq	8(%rsp), %rcx
	xorq	$1, %rcx
	orq	%rcx, %rax
	sete	%al
	cmpb	$2, %bpl
	setne	%cl
	testb	%al, %cl
	jne	.LBB56_47
	jmp	.LBB56_48
.LBB56_45:
	movl	$2, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB56_46:
	testq	%rax, %rax
	jne	.LBB56_48
.LBB56_47:
	leaq	32(%rsp), %rdi
	leaq	4152(%rsp), %rsi
	movl	$4096, %edx
	callq	*memcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	sete	%al
	cmpq	$2, %rbx
	sete	%cl
	andb	%al, %cl
	testb	$-3, %bpl
	setne	%al
	testb	%al, %cl
	jne	.LBB56_50
.LBB56_48:
	xorl	%eax, %eax
	addq	$8248, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB56_50:
	.cfi_def_cfa_offset 8272
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11extra_valid
	addq	$8248, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end56:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5valid, .Lfunc_end56-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5valid
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic,"ax",@progbits
	.prefalign	4, .Lfunc_end57, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic:
.Lfunc_begin57:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$40, %rsp
	.cfi_def_cfa_offset 4192
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	%r9d, %r13d
	movl	%r8d, 4(%rsp)
	movl	%ecx, %r14d
	movq	%rdx, %r15
	movq	%rsi, %r12
	movq	%rdi, 8(%rsp)
	leaq	16(%rsp), %rbx
	movl	$4096, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$80, 4112(%rsp)
	movq	$0, 4120(%rsp)
	movb	$1, 4128(%rsp)
	movl	$1, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$4, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.35, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	%r14d, %eax
	shll	$24, %eax
	movl	%eax, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	testq	%r15, %r15
	je	.LBB57_3
	shlq	$3, %r15
	xorl	%ebp, %ebp
	movzbl	%r13b, %ebx
	leaq	16(%rsp), %r13
	.p2align	4
.LBB57_2:
	movq	(%r12,%rbp), %rsi
	movq	%r13, %rdi
	movl	%r14d, %edx
	movl	%ebx, %ecx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu
	addq	$8, %rbp
	cmpq	%rbp, %r15
	jne	.LBB57_2
.LBB57_3:
	movq	4112(%rsp), %rbx
	movq	%rbx, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB57_4
	movq	%rax, %rdi
	subq	%rbx, %rdi
	cmpq	$4, %rdi
	jne	.LBB57_20
	movl	$33554432, 16(%rsp,%rbx)
	movq	%rax, 4112(%rsp)
	movq	%rax, %rbx
	movl	4(%rsp), %eax
	testb	%al, %al
	jne	.LBB57_19
	jmp	.LBB57_8
.LBB57_4:
	movb	$0, 4128(%rsp)
	movl	4(%rsp), %eax
	testb	%al, %al
	je	.LBB57_8
.LBB57_19:
	leaq	16(%rsp), %rdi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci
	movq	4112(%rsp), %rbx
.LBB57_8:
	movq	%rbx, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB57_12
	movq	%rax, %rdi
	subq	%rbx, %rdi
	cmpq	$4, %rdi
	jne	.LBB57_20
	movl	$33554432, 16(%rsp,%rbx)
	movq	%rax, 4112(%rsp)
	cmpq	$4093, %rax
	jae	.LBB57_11
	movl	$150994944, 16(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4112(%rsp)
	movq	%rax, %rbx
	jmp	.LBB57_14
.LBB57_11:
	movq	%rax, %rbx
.LBB57_12:
	movb	$0, 4128(%rsp)
.LBB57_14:
	movq	%rbx, %rax
	addq	$117, %rax
	movq	$-1, %r14
	cmovaeq	%rax, %r14
	cmpq	$4097, %r14
	jae	.LBB57_15
	movq	%r14, %rdi
	subq	%rbx, %rdi
	cmpq	$117, %rdi
	jne	.LBB57_21
	leaq	(%rsp,%rbx), %rdi
	addq	$16, %rdi
	movl	$117, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.46, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r14, 4112(%rsp)
	jmp	.LBB57_18
.LBB57_15:
	movb	$0, 4128(%rsp)
	movq	%rbx, %r14
.LBB57_18:
	movq	%r14, 4120(%rsp)
	movl	$-302117424, 16(%rsp)
	bswapl	%r14d
	movl	%r14d, 20(%rsp)
	movl	$1342177280, 24(%rsp)
	movl	%ebx, %eax
	bswapl	%eax
	movl	%eax, 28(%rsp)
	movabsq	$1224979099315863552, %rax
	movq	%rax, 32(%rsp)
	movq	$268435456, 40(%rsp)
	movl	$1962934272, 48(%rsp)
	addl	$-80, %ebx
	bswapl	%ebx
	movl	%ebx, 52(%rsp)
	leaq	16(%rsp), %rsi
	movl	$4120, %edx
	movq	8(%rsp), %rdi
	callq	*memcpy@GOTPCREL(%rip)
	addq	$4136, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB57_20:
	.cfi_def_cfa_offset 4192
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB57_21:
	movl	$117, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end57:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic, .Lfunc_end57-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11extra_valid,"ax",@progbits
	.prefalign	4, .Lfunc_end58, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11extra_valid,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11extra_valid:
.Lfunc_begin58:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$56, %rsp
	.cfi_def_cfa_offset 4176
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	leaq	32(%rsp), %rbx
	movl	$4096, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$80, 4128(%rsp)
	movq	$0, 4136(%rsp)
	movb	$1, 4144(%rsp)
	movl	$4194304, 76(%rsp)
	movl	$1048576, 84(%rsp)
	movl	$1, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB58_3
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB58_48
	movl	$67108864, 32(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	jmp	.LBB58_4
.LBB58_3:
	movb	$0, 4144(%rsp)
.LBB58_4:
	leaq	32(%rsp), %rbx
	movl	$4, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.35, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$16777216, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$5, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.28, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.31, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$5, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.54, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	leaq	17(%rax), %rdi
	addq	$20, %rax
	cmpq	%rdi, %rax
	jb	.LBB58_49
	cmpq	$4097, %rax
	jae	.LBB58_49
	movb	$9, 34(%rsp,%rdi)
	movw	$1023, 32(%rsp,%rdi)
	leaq	32(%rsp), %rdi
	movl	$13, %edx
	movl	$5, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.32, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.33, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB58_9
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB58_48
	movl	$33554432, 32(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	jmp	.LBB58_10
.LBB58_9:
	movb	$0, 4144(%rsp)
.LBB58_10:
	leaq	32(%rsp), %rbx
	movl	$5, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.29, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.31, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$16777216, (%rsp)
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$3, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.55, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$13, %edx
	movl	$5, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.32, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.33, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB58_13
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB58_48
	movl	$33554432, 32(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	jmp	.LBB58_14
.LBB58_13:
	movb	$0, 4144(%rsp)
.LBB58_14:
	leaq	32(%rsp), %rbx
	movl	$7, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.103, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$8, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.104, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$5, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.105, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movq	4128(%rsp), %rcx
	movq	%rcx, %rdx
	addq	$4, %rdx
	movq	$-1, %rax
	cmovaeq	%rdx, %rax
	cmpq	$4096, %rax
	ja	.LBB58_20
	movq	%rax, %rdi
	subq	%rcx, %rdi
	cmpq	$4, %rdi
	jne	.LBB58_48
	movl	$33554432, 32(%rsp,%rcx)
	movq	%rax, 4128(%rsp)
	cmpq	$4092, %rax
	ja	.LBB58_20
	leaq	4(%rax), %rcx
	movl	$33554432, 32(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	cmpq	$4088, %rax
	ja	.LBB58_20
	leaq	8(%rax), %rcx
	movl	$33554432, 36(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	cmpq	$4085, %rax
	jae	.LBB58_20
	movl	$33554432, 40(%rsp,%rax)
	addq	$12, %rax
	movq	%rax, 4128(%rsp)
	jmp	.LBB58_21
.LBB58_20:
	movb	$0, 4144(%rsp)
.LBB58_21:
	leaq	32(%rsp), %rbx
	movl	$4, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.37, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$10, %edx
	movl	$13, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.38, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.106, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.40, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.41, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$5, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.54, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB58_24
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB58_48
	movl	$33554432, 32(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	jmp	.LBB58_25
.LBB58_24:
	movb	$0, 4144(%rsp)
.LBB58_25:
	leaq	32(%rsp), %rbx
	movl	$9, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.107, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$10, %edx
	movl	$12, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.38, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.108, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB58_32
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB58_48
	movl	$33554432, 32(%rsp,%r14)
	movq	%rax, 4128(%rsp)
	cmpq	$4092, %rax
	ja	.LBB58_31
	leaq	4(%rax), %r14
	movl	$33554432, 32(%rsp,%rax)
	movq	%r14, 4128(%rsp)
	cmpq	$4089, %rax
	jae	.LBB58_32
	movl	$150994944, 36(%rsp,%rax)
	addq	$8, %rax
	movq	%rax, 4128(%rsp)
	movq	%rax, %r14
	jmp	.LBB58_33
.LBB58_31:
	movq	%rax, %r14
.LBB58_32:
	movb	$0, 4144(%rsp)
.LBB58_33:
	movq	%r14, %rax
	addq	$117, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB58_36
	movq	%rbx, %rdi
	subq	%r14, %rdi
	cmpq	$117, %rdi
	jne	.LBB58_52
	leaq	(%rsp,%r14), %rdi
	addq	$32, %rdi
	movl	$117, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.46, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4128(%rsp)
	movzbl	4144(%rsp), %eax
	jmp	.LBB58_37
.LBB58_36:
	movb	$0, 4144(%rsp)
	xorl	%eax, %eax
	movq	%r14, %rbx
.LBB58_37:
	movq	%rbx, 4136(%rsp)
	movl	$-302117424, 32(%rsp)
	movl	%ebx, %ecx
	bswapl	%ecx
	movl	%ecx, 36(%rsp)
	movl	$1342177280, 40(%rsp)
	movl	%r14d, %ecx
	bswapl	%ecx
	movl	%ecx, 44(%rsp)
	movabsq	$1224979099315863552, %rcx
	movq	%rcx, 48(%rsp)
	movq	$268435456, 56(%rsp)
	movl	$1962934272, 64(%rsp)
	addl	$-80, %r14d
	bswapl	%r14d
	movl	%r14d, 68(%rsp)
	testb	%al, %al
	je	.LBB58_46
	cmpq	$4097, %rbx
	jae	.LBB58_50
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ecx
	cmpb	$-1, %cl
	je	.LBB58_46
	movq	16(%rsp), %rsi
	cmpq	$3, %rsi
	jae	.LBB58_51
	xorl	%eax, %eax
	cmpq	$2, %rsi
	jne	.LBB58_47
	cmpb	$2, %cl
	je	.LBB58_47
	movq	8(%rsp), %rdx
	xorq	$1, %rdx
	orq	(%rsp), %rdx
	jne	.LBB58_47
	xorb	$1, %cl
	movl	%ecx, %eax
	jmp	.LBB58_47
.LBB58_46:
	xorl	%eax, %eax
.LBB58_47:
	andb	$1, %al
	addq	$4152, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB58_48:
	.cfi_def_cfa_offset 4176
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB58_49:
	movl	$4096, %edx
	movq	%rax, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB58_50:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB58_51:
	movl	$2, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB58_52:
	movl	$117, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end58:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11extra_valid, .Lfunc_end58-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11extra_valid
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin,"ax",@progbits
	.prefalign	4, .Lfunc_end59, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin:
.Lfunc_begin59:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rdi, %rbx
	movq	4096(%rdi), %rdi
	movq	%rdi, %rax
	addq	$4, %rax
	movq	$-1, %rcx
	cmovaeq	%rax, %rcx
	cmpq	$4097, %rcx
	jae	.LBB59_1
	movq	%rcx, %rax
	subq	%rdi, %rax
	cmpq	$4, %rax
	jne	.LBB59_26
	movl	$16777216, (%rbx,%rdi)
	movq	%rcx, 4096(%rbx)
	movq	%rcx, %rdi
	jmp	.LBB59_4
.LBB59_1:
	movb	$0, 4112(%rbx)
.LBB59_4:
	movq	%rdi, %rax
	addq	%rdx, %rax
	movq	$-1, %r14
	cmovaeq	%rax, %r14
	cmpq	$4097, %r14
	jae	.LBB59_5
	movq	%r14, %rax
	subq	%rdi, %rax
	cmpq	%rdx, %rax
	jne	.LBB59_27
	addq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r14, 4096(%rbx)
	movq	%r14, %rdi
	jmp	.LBB59_8
.LBB59_5:
	movb	$0, 4112(%rbx)
.LBB59_8:
	movq	%rdi, %rax
	incq	%rax
	movq	$-1, %rcx
	cmovneq	%rax, %rcx
	cmpq	$4097, %rcx
	jae	.LBB59_9
	movq	%rcx, %rax
	subq	%rdi, %rax
	cmpq	$1, %rax
	jne	.LBB59_28
	movb	$0, (%rbx,%rdi)
	movq	%rcx, 4096(%rbx)
	testb	$3, %cl
	je	.LBB59_25
	cmpb	$0, 4112(%rbx)
	je	.LBB59_25
	cmpq	$4096, %rcx
	jne	.LBB59_15
.LBB59_14:
	movb	$0, 4112(%rbx)
.LBB59_25:
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB59_9:
	.cfi_def_cfa_offset 32
	movb	$0, 4112(%rbx)
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB59_15:
	.cfi_def_cfa_offset 32
	leaq	1(%rcx), %rax
	movb	$0, (%rbx,%rcx)
	movq	%rax, 4096(%rbx)
	cmpb	$1, 4112(%rbx)
	jne	.LBB59_25
	movl	%eax, %edx
	andl	$3, %edx
	je	.LBB59_25
	cmpq	$4096, %rax
	je	.LBB59_14
	leaq	2(%rcx), %rdx
	movb	$0, (%rbx,%rax)
	movq	%rdx, 4096(%rbx)
	cmpb	$1, 4112(%rbx)
	jne	.LBB59_25
	movl	%edx, %eax
	andl	$3, %eax
	je	.LBB59_25
	cmpq	$4096, %rdx
	je	.LBB59_14
	leaq	3(%rcx), %rax
	movb	$0, (%rbx,%rdx)
	movq	%rax, 4096(%rbx)
	cmpb	$1, 4112(%rbx)
	jne	.LBB59_25
	movl	%eax, %edx
	andl	$3, %edx
	je	.LBB59_25
	cmpq	$4096, %rax
	je	.LBB59_14
	movb	$0, 3(%rbx,%rcx)
	addq	$4, %rcx
	movq	%rcx, 4096(%rbx)
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB59_26:
	.cfi_def_cfa_offset 32
	movl	$4, %esi
	movq	%rax, %rdi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB59_27:
	movq	%rax, %rdi
	movq	%rdx, %rsi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB59_28:
	movl	$1, %esi
	movq	%rax, %rdi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end59:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin, .Lfunc_end59-_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property,"ax",@progbits
	.prefalign	4, .Lfunc_end60, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property:
.Lfunc_begin60:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %r14
	movq	%rcx, (%rsp)
	movq	%rdx, %r12
	movq	%rsi, %r13
	movq	%rdi, %rbx
	xorl	%ebp, %ebp
	movq	memcmp@GOTPCREL(%rip), %r15
	jmp	.LBB60_2
	.p2align	4
.LBB60_1:
	leaq	(%r12,%rbp), %rax
	incq	%rax
	incq	%rbp
	cmpq	$117, %rax
	je	.LBB60_9
.LBB60_2:
	leaq	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.46(%rbp), %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	*%r15
	testl	%eax, %eax
	jne	.LBB60_1
	cmpb	$0, .Lanon.2518d136abfec7ebc9d3a69d0b38d406.46(%r12,%rbp)
	jne	.LBB60_1
	movq	4096(%rbx), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	movq	%rax, %rdi
	cmpq	$4096, %rcx
	ja	.LBB60_13
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB60_32
	movl	$50331648, (%rbx,%rax)
	movq	%rcx, 4096(%rbx)
	cmpq	$4092, %rcx
	ja	.LBB60_12
	leaq	4(%rcx), %rdi
	movl	%r14d, %edx
	shll	$24, %edx
	movl	%edx, (%rbx,%rcx)
	movq	%rdi, 4096(%rbx)
	cmpq	$4089, %rcx
	jae	.LBB60_13
	bswapl	%ebp
	movl	%ebp, 4(%rbx,%rcx)
	addq	$8, %rcx
	movq	%rcx, 4096(%rbx)
	movq	%rcx, %rdi
	jmp	.LBB60_14
.LBB60_9:
	movb	$0, 4112(%rbx)
	xorl	%eax, %eax
	jmp	.LBB60_10
.LBB60_12:
	movq	%rcx, %rdi
.LBB60_13:
	movb	$0, 4112(%rbx)
.LBB60_14:
	movq	%rdi, %rcx
	addq	%r14, %rcx
	movq	$-1, %r12
	cmovaeq	%rcx, %r12
	cmpq	$4097, %r12
	jae	.LBB60_20
	movq	%rax, %r15
	movq	%r12, %rax
	subq	%rdi, %rax
	cmpq	%r14, %rax
	jne	.LBB60_33
	addq	%rbx, %rdi
	movq	(%rsp), %rsi
	movq	%r14, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r12, 4096(%rbx)
	testb	$3, %r12b
	je	.LBB60_21
	cmpb	$0, 4112(%rbx)
	movq	%r15, %rax
	je	.LBB60_10
	cmpq	$4096, %r12
	jne	.LBB60_22
.LBB60_20:
	movb	$0, 4112(%rbx)
.LBB60_10:
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB60_21:
	.cfi_def_cfa_offset 64
	movq	%r15, %rax
	jmp	.LBB60_10
.LBB60_22:
	leaq	1(%r12), %rcx
	movb	$0, (%rbx,%r12)
	movq	%rcx, 4096(%rbx)
	cmpb	$1, 4112(%rbx)
	jne	.LBB60_10
	movl	%ecx, %edx
	andl	$3, %edx
	je	.LBB60_10
	cmpq	$4096, %rcx
	je	.LBB60_20
	leaq	2(%r12), %rdx
	movb	$0, (%rbx,%rcx)
	movq	%rdx, 4096(%rbx)
	cmpb	$1, 4112(%rbx)
	jne	.LBB60_10
	movl	%edx, %ecx
	andl	$3, %ecx
	je	.LBB60_10
	cmpq	$4096, %rdx
	je	.LBB60_20
	leaq	3(%r12), %rcx
	movb	$0, (%rbx,%rdx)
	movq	%rcx, 4096(%rbx)
	cmpb	$1, 4112(%rbx)
	jne	.LBB60_10
	movl	%ecx, %edx
	andl	$3, %edx
	je	.LBB60_10
	cmpq	$4096, %rcx
	je	.LBB60_20
	movb	$0, 3(%rbx,%r12)
	addq	$4, %r12
	movq	%r12, 4096(%rbx)
	jmp	.LBB60_10
.LBB60_32:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB60_33:
	movq	%rax, %rdi
	movq	%r14, %rsi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end60:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property, .Lfunc_end60-_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu,"ax",@progbits
	.prefalign	4, .Lfunc_end61, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu:
.Lfunc_begin61:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	%ecx, %ebp
	movl	%edx, %r15d
	movq	%rsi, %r14
	movq	%rdi, %rbx
	cmpq	$1, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.29, %rax
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.30, %rcx
	cmoveq	%rax, %rcx
	testq	%rsi, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.28, %rsi
	cmovneq	%rcx, %rsi
	movl	$5, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.31, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	cmpl	$2, %r15d
	jne	.LBB61_2
	bswapq	%r14
	movq	%r14, 16(%rsp)
	leaq	16(%rsp), %rcx
	movl	$3, %edx
	movl	$8, %r8d
	jmp	.LBB61_3
.LBB61_2:
	bswapl	%r14d
	movl	%r14d, 12(%rsp)
	leaq	12(%rsp), %rcx
	movl	$3, %edx
	movl	$4, %r8d
.LBB61_3:
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	testb	%bpl, %bpl
	je	.LBB61_4
	movl	$13, %edx
	movl	$5, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.32, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.33, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB61_4:
	movq	4096(%rbx), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB61_5
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB61_10
	movl	$33554432, (%rbx,%rax)
	movq	%rcx, 4096(%rbx)
	jmp	.LBB61_8
.LBB61_5:
	movb	$0, 4112(%rbx)
.LBB61_8:
	addq	$24, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB61_10:
	.cfi_def_cfa_offset 64
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end61:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu, .Lfunc_end61-_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu
	.cfi_endproc

	.section	.text._RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci,"ax",@progbits
	.prefalign	4, .Lfunc_end62, nop
	.type	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci,@function
_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci:
.Lfunc_begin62:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movl	$4, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.37, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$10, %edx
	movl	$35, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.38, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.39, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.40, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.41, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$50331844, 12(%rsp)
	leaq	12(%rsp), %rcx
	movl	$6, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.42, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554564, 12(%rsp)
	leaq	12(%rsp), %rcx
	movl	$7, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.43, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$16777412, 12(%rsp)
	leaq	12(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.44, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$83886276, 12(%rsp)
	leaq	12(%rsp), %rcx
	movl	$7, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.45, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4096(%rbx), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB62_1
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB62_5
	movl	$33554432, (%rbx,%rax)
	movq	%rcx, 4096(%rbx)
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB62_1:
	.cfi_def_cfa_offset 32
	movb	$0, 4112(%rbx)
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB62_5:
	.cfi_def_cfa_offset 32
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end62:
	.size	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci, .Lfunc_end62-_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9malformed,"ax",@progbits
	.prefalign	4, .Lfunc_end63, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9malformed,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9malformed:
.Lfunc_begin63:
	.cfi_startproc
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$56, %rsp
	.cfi_def_cfa_offset 4160
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9mutations
	testb	%al, %al
	je	.LBB63_1
	leaq	32(%rsp), %rdi
	movl	$8, %esi
	xorl	%edx, %edx
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB63_1
	movq	4136(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB63_5
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB63_1
	leaq	32(%rsp), %rdi
	movl	$1, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.121, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB63_1
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB63_5
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB63_1
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.84, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB63_1
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB63_5
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB63_1
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.63, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB63_1
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB63_5
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB63_1
	leaq	32(%rsp), %rdi
	movl	$3, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.122, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB63_1
	movq	4136(%rsp), %rdx
	cmpq	$4096, %rdx
	ja	.LBB63_5
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB63_1
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.62, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	xorl	%r9d, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB63_1
	movq	4136(%rsp), %rcx
	movq	%rcx, %rax
	cmpq	$4096, %rcx
	ja	.LBB63_6
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	movq	%rax, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB63_1
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.62, %rsi
	movl	$1, %ecx
	xorl	%r8d, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB63_1
	movq	4136(%rsp), %rcx
	movq	%rcx, %rax
	cmpq	$4096, %rcx
	ja	.LBB63_6
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	movq	%rax, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	je	.LBB63_7
.LBB63_1:
	xorl	%eax, %eax
.LBB63_2:
	addq	$4152, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB63_5:
	.cfi_def_cfa_offset 4160
	movq	%rdx, %rax
.LBB63_6:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rax, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB63_7:
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB63_2
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$4, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$5, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$6, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$7, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$8, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$9, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$10, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$11, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$12, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$13, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$14, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$15, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$16, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$17, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$18, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	movl	$19, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	testb	%al, %al
	je	.LBB63_1
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB63_2
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$4, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$5, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$6, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$7, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$8, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$9, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$10, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$11, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$12, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$13, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$14, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$15, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$16, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	movl	$17, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	testb	%al, %al
	je	.LBB63_1
	xorl	%edi, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	movl	%eax, %ecx
	xorl	%eax, %eax
	testb	%cl, %cl
	je	.LBB63_2
	movl	$1, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB63_1
	movl	$2, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB63_1
	movl	$3, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB63_1
	movl	$4, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB63_1
	movl	$5, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB63_1
	movl	$6, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB63_1
	movl	$7, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB63_1
	movl	$8, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB63_1
	movl	$9, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB63_1
	movl	$10, %edi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	testb	%al, %al
	je	.LBB63_1
	xorl	%edi, %edi
	xorl	%esi, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$4, %edi
	movl	$39, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$4, %edi
	movl	$2097153, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$8, %edi
	movl	$65, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$8, %edi
	movl	$-1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$12, %edi
	movl	$80, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$16, %edi
	movl	$41, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$16, %edi
	movl	$80, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$20, %edi
	movl	$16, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$20, %edi
	movl	$18, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$24, %edi
	movl	$17, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$28, %edi
	movl	$1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$32, %edi
	movl	$-1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	testb	%al, %al
	je	.LBB63_1
	movl	$36, %edi
	movl	$-1, %esi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	movl	%eax, %ecx
	movb	$1, %al
	testb	%cl, %cl
	je	.LBB63_1
	jmp	.LBB63_2
.Lfunc_end63:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9malformed, .Lfunc_end63-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9malformed
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9mutations,"ax",@progbits
	.prefalign	4, .Lfunc_end64, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9mutations,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9mutations:
.Lfunc_begin64:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$56, %rsp
	.cfi_def_cfa_offset 4208
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.62, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$1, 4144(%rsp)
	jne	.LBB64_6
	movq	4136(%rsp), %rbx
	cmpq	$4097, %rbx
	jae	.LBB64_20
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	je	.LBB64_6
	movb	$1, %bpl
	testq	%rbx, %rbx
	je	.LBB64_7
	xorl	%r14d, %r14d
	movq	%rsp, %r15
	leaq	32(%rsp), %r12
	.p2align	4
.LBB64_5:
	movq	%r15, %rdi
	movq	%r12, %rsi
	movq	%r14, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	jne	.LBB64_6
	incq	%r14
	cmpq	%r14, %rbx
	jne	.LBB64_5
	xorl	%r12d, %r12d
	movq	%rsp, %r14
	leaq	32(%rsp), %r15
	jmp	.LBB64_18
	.p2align	4
.LBB64_9:
	movb	%r13b, 32(%rsp,%r12)
	incq	%r12
	cmpq	%r12, %rbx
	je	.LBB64_7
.LBB64_18:
	movzbl	32(%rsp,%r12), %r13d
	movl	%r13d, %eax
	notb	%al
	movb	%al, 32(%rsp,%r12)
	movq	4136(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB64_19
	movq	%r14, %rdi
	movq	%r15, %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	movzbl	24(%rsp), %ecx
	cmpb	$-1, %cl
	je	.LBB64_9
	movq	16(%rsp), %rsi
	cmpq	$3, %rsi
	jae	.LBB64_21
	movq	(%rsp), %rax
	cmpq	$2, %rsi
	je	.LBB64_14
	cmpq	$1, %rsi
	jne	.LBB64_6
	testq	%rax, %rax
	je	.LBB64_9
	jmp	.LBB64_6
	.p2align	4
.LBB64_14:
	cmpb	$2, %cl
	je	.LBB64_6
	movq	8(%rsp), %rcx
	xorq	$1, %rcx
	orq	%rcx, %rax
	je	.LBB64_9
.LBB64_6:
	xorl	%ebp, %ebp
.LBB64_7:
	movl	%ebp, %eax
	addq	$4152, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB64_19:
	.cfi_def_cfa_offset 4208
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB64_21:
	movl	$2, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB64_20:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end64:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9mutations, .Lfunc_end64-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests9mutations
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu,"ax",@progbits
	.prefalign	4, .Lfunc_end65, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu:
.Lfunc_begin65:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$64, %rsp
	.cfi_def_cfa_offset 4192
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movl	%edi, %ebx
	leaq	40(%rsp), %r14
	movl	$4096, %edx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$80, 4136(%rsp)
	movq	$0, 4144(%rsp)
	movb	$1, 4152(%rsp)
	movl	$1, %esi
	movq	%r14, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movzbl	%bl, %r15d
	cmpb	$17, %bl
	jne	.LBB65_2
	leaq	40(%rsp), %r14
	movl	$3, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.76, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$4, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.35, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$16777216, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	jmp	.LBB65_5
.LBB65_2:
	leaq	40(%rsp), %rdi
	movl	$4, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.35, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	testb	%bl, %bl
	je	.LBB65_6
	cmpl	$1, %r15d
	jne	.LBB65_15
	movl	$50331648, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
.LBB65_5:
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB65_6:
	movl	$0, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB65_7:
	leaq	40(%rsp), %rdi
	movl	$5, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.28, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	cmpb	$7, %bl
	je	.LBB65_11
	cmpl	$8, %r15d
	jne	.LBB65_17
	leaq	40(%rsp), %rdi
	movl	$11, %edx
	movl	$7, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.110, %rcx
.LBB65_10:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB65_11:
	movl	$0, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB65_12:
	leaq	40(%rsp), %rdi
	movl	$13, %edx
	movl	$5, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.32, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.33, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	leal	-13(%r15), %eax
	cmpl	$3, %eax
	ja	.LBB65_29
	jmpq	*.LJTI65_0(,%rax,8)
.LBB65_14:
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$9, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.74, %rcx
	jmp	.LBB65_28
.LBB65_15:
	movl	$16777216, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	cmpb	$2, %bl
	jne	.LBB65_60
.LBB65_16:
	leaq	40(%rsp), %rdi
	movl	$5, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.28, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
.LBB65_17:
	leaq	40(%rsp), %rdi
	movl	$11, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.31, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	cmpb	$9, %bl
	je	.LBB65_27
	cmpl	$10, %r15d
	je	.LBB65_25
	cmpl	$11, %r15d
	jne	.LBB65_58
	movl	$16777216, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	jmp	.LBB65_26
.LBB65_21:
	leaq	40(%rsp), %rdi
	movl	$5, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.79, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movq	4136(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB65_64
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB65_67
	movl	$33554432, 40(%rsp,%rax)
	movq	%rcx, 4136(%rsp)
	jmp	.LBB65_29
.LBB65_24:
	movl	$0, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	jmp	.LBB65_28
.LBB65_25:
	leaq	40(%rsp), %rdi
	movl	$3, %edx
	movl	$8, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.111, %rcx
.LBB65_26:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB65_27:
	leaq	40(%rsp), %rdi
	movl	$13, %edx
	movl	$5, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.32, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.33, %rcx
.LBB65_28:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB65_29:
	movq	4136(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4096, %rcx
	ja	.LBB65_35
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB65_67
	movl	$33554432, 40(%rsp,%rax)
	movq	%rcx, 4136(%rsp)
	cmpq	$4093, %rcx
	jae	.LBB65_34
	movl	$33554432, 40(%rsp,%rcx)
	addq	$4, %rcx
	movq	%rcx, 4136(%rsp)
	movq	%rcx, %rax
	cmpb	$19, %bl
	jne	.LBB65_36
.LBB65_33:
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$5, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.54, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	jmp	.LBB65_43
.LBB65_34:
	movq	%rcx, %rax
.LBB65_35:
	movb	$0, 4152(%rsp)
	cmpb	$19, %bl
	je	.LBB65_33
.LBB65_36:
	cmpl	$18, %r15d
	je	.LBB65_40
	cmpl	$17, %r15d
	jne	.LBB65_43
	jmp	.LBB65_38
.LBB65_40:
	leaq	40(%rsp), %rbx
	movl	$4, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.35, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$16777216, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	%rbx, %rdi
	xorl	%esi, %esi
	movl	$1, %edx
	movl	$1, %ecx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu
	movq	4136(%rsp), %rax
.LBB65_38:
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB65_39
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB65_67
	movl	$33554432, 40(%rsp,%rax)
	movq	%rcx, 4136(%rsp)
	jmp	.LBB65_43
.LBB65_39:
	movb	$0, 4152(%rsp)
.LBB65_43:
	leaq	40(%rsp), %rdi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci
	movq	4136(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB65_48
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB65_67
	movl	$33554432, 40(%rsp,%r14)
	movq	%rax, 4136(%rsp)
	cmpq	$4093, %rax
	jae	.LBB65_47
	movl	$150994944, 40(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4136(%rsp)
	movq	%rax, %r14
	jmp	.LBB65_49
.LBB65_47:
	movq	%rax, %r14
.LBB65_48:
	movb	$0, 4152(%rsp)
.LBB65_49:
	movq	%r14, %rax
	addq	$117, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB65_52
	movq	%rbx, %rdi
	subq	%r14, %rdi
	cmpq	$117, %rdi
	jne	.LBB65_69
	leaq	(%rsp,%r14), %rdi
	addq	$40, %rdi
	movl	$117, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.46, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4136(%rsp)
	movzbl	4152(%rsp), %eax
	jmp	.LBB65_53
.LBB65_52:
	movb	$0, 4152(%rsp)
	xorl	%eax, %eax
	movq	%r14, %rbx
.LBB65_53:
	movq	%rbx, 4144(%rsp)
	movl	$-302117424, 40(%rsp)
	movl	%ebx, %ecx
	bswapl	%ecx
	movl	%ecx, 44(%rsp)
	movl	$1342177280, 48(%rsp)
	movl	%r14d, %ecx
	bswapl	%ecx
	movl	%ecx, 52(%rsp)
	movabsq	$1224979099315863552, %rcx
	movq	%rcx, 56(%rsp)
	movq	$268435456, 64(%rsp)
	movl	$1962934272, 72(%rsp)
	addl	$-80, %r14d
	bswapl	%r14d
	movl	%r14d, 76(%rsp)
	testb	%al, %al
	je	.LBB65_56
	cmpq	$4097, %rbx
	jae	.LBB65_68
	leaq	8(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 32(%rsp)
	sete	%al
	jmp	.LBB65_57
.LBB65_56:
	xorl	%eax, %eax
.LBB65_57:
	addq	$4160, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB65_58:
	.cfi_def_cfa_offset 4192
	movl	$0, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	cmpb	$12, %bl
	jne	.LBB65_12
	leaq	40(%rsp), %rdi
	movl	$13, %edx
	movl	$11, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.32, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.112, %rcx
	jmp	.LBB65_28
.LBB65_60:
	xorl	%eax, %eax
	cmpb	$3, %bl
	sete	%al
	shll	$24, %eax
	movl	%eax, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	cmpb	$6, %bl
	je	.LBB65_66
	cmpl	$5, %r15d
	je	.LBB65_65
	cmpl	$4, %r15d
	jne	.LBB65_7
	movl	$16777216, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	jmp	.LBB65_16
.LBB65_64:
	movb	$0, 4152(%rsp)
	jmp	.LBB65_29
.LBB65_65:
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$9, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.74, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	jmp	.LBB65_16
.LBB65_66:
	leaq	40(%rsp), %r14
	movl	$3, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.47, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.31, %rcx
	jmp	.LBB65_10
.LBB65_67:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB65_68:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB65_69:
	movl	$117, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end65:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu, .Lfunc_end65-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests11invalid_cpu,"a",@progbits
	.p2align	3, 0x0
.LJTI65_0:
	.quad	.LBB65_14
	.quad	.LBB65_24
	.quad	.LBB65_27
	.quad	.LBB65_21

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci,"ax",@progbits
	.prefalign	4, .Lfunc_end66, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci:
.Lfunc_begin66:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$64, %rsp
	.cfi_def_cfa_offset 4192
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movl	%edi, %ebx
	leaq	40(%rsp), %r14
	movl	$4096, %edx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$80, 4136(%rsp)
	movq	$0, 4144(%rsp)
	movb	$1, 4152(%rsp)
	movl	$1, %esi
	movq	%r14, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554432, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$4, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.35, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$16777216, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, 8(%rsp)
	leaq	8(%rsp), %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	%r14, %rdi
	xorl	%esi, %esi
	movl	$1, %edx
	movl	$1, %ecx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu
	movl	$1, %esi
	movq	%r14, %rdi
	movl	$1, %edx
	movl	$1, %ecx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob3cpu
	movq	4136(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB66_10
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB66_63
	movl	$33554432, 40(%rsp,%r14)
	movq	%rax, 4136(%rsp)
	movq	%rax, %r14
	movzbl	%bl, %r15d
	cmpb	$13, %r15b
	jne	.LBB66_11
.LBB66_3:
	leaq	40(%rsp), %r14
	movl	$3, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.76, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$4, %edx
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.37, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$10, %edx
	movl	$13, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.38, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.106, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB66_4:
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.40, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.41, %rcx
.LBB66_5:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB66_6:
	movq	4136(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB66_15
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB66_63
	movl	$33554432, 40(%rsp,%r14)
	movq	%rax, 4136(%rsp)
	movq	%rax, %r14
	cmpb	$14, %bl
	jne	.LBB66_16
.LBB66_9:
	leaq	40(%rsp), %rdi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob4psci
	movq	4136(%rsp), %r14
	jmp	.LBB66_47
.LBB66_10:
	movb	$0, 4152(%rsp)
	movzbl	%bl, %r15d
	cmpb	$13, %r15b
	je	.LBB66_3
.LBB66_11:
	testl	%r15d, %r15d
	je	.LBB66_47
	leaq	40(%rsp), %rdi
	movl	$4, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.37, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	leal	-1(%r15), %eax
	cmpl	$4, %eax
	ja	.LBB66_31
	jmpq	*.LJTI66_0(,%rax,8)
.LBB66_14:
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.113, %rcx
	movl	$9, %r8d
	jmp	.LBB66_27
.LBB66_15:
	movb	$0, 4152(%rsp)
	cmpb	$14, %bl
	je	.LBB66_9
.LBB66_16:
	cmpl	$13, %r15d
	jne	.LBB66_20
.LBB66_17:
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB66_46
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB66_63
	movl	$33554432, 40(%rsp,%r14)
	movq	%rax, 4136(%rsp)
	movq	%rax, %r14
	jmp	.LBB66_47
.LBB66_20:
	cmpb	$15, %bl
	jb	.LBB66_47
	cmpb	$16, %bl
	je	.LBB66_39
	cmpl	$17, %r15d
	jne	.LBB66_40
	leaq	40(%rsp), %rdi
	movl	$4, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.37, %rsi
	jmp	.LBB66_41
.LBB66_46:
	movb	$0, 4152(%rsp)
.LBB66_47:
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB66_52
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB66_63
	movl	$33554432, 40(%rsp,%r14)
	movq	%rax, 4136(%rsp)
	cmpq	$4093, %rax
	jae	.LBB66_51
	movl	$150994944, 40(%rsp,%rax)
	addq	$4, %rax
	movq	%rax, 4136(%rsp)
	movq	%rax, %r14
	jmp	.LBB66_53
.LBB66_51:
	movq	%rax, %r14
.LBB66_52:
	movb	$0, 4152(%rsp)
.LBB66_53:
	movq	%r14, %rax
	addq	$117, %rax
	movq	$-1, %rbx
	cmovaeq	%rax, %rbx
	cmpq	$4097, %rbx
	jae	.LBB66_56
	movq	%rbx, %rdi
	subq	%r14, %rdi
	cmpq	$117, %rdi
	jne	.LBB66_65
	leaq	(%rsp,%r14), %rdi
	addq	$40, %rdi
	movl	$117, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.46, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, 4136(%rsp)
	movzbl	4152(%rsp), %eax
	jmp	.LBB66_57
.LBB66_56:
	movb	$0, 4152(%rsp)
	xorl	%eax, %eax
	movq	%r14, %rbx
.LBB66_57:
	movq	%rbx, 4144(%rsp)
	movl	$-302117424, 40(%rsp)
	movl	%ebx, %ecx
	bswapl	%ecx
	movl	%ecx, 44(%rsp)
	movl	$1342177280, 48(%rsp)
	movl	%r14d, %ecx
	bswapl	%ecx
	movl	%ecx, 52(%rsp)
	movabsq	$1224979099315863552, %rcx
	movq	%rcx, 56(%rsp)
	movq	$268435456, 64(%rsp)
	movl	$1962934272, 72(%rsp)
	addl	$-80, %r14d
	bswapl	%r14d
	movl	%r14d, 76(%rsp)
	testb	%al, %al
	je	.LBB66_60
	cmpq	$4097, %rbx
	jae	.LBB66_64
	leaq	8(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 32(%rsp)
	sete	%al
	jmp	.LBB66_61
.LBB66_60:
	xorl	%eax, %eax
.LBB66_61:
	addq	$4160, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB66_24:
	.cfi_def_cfa_offset 4192
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.115, %rcx
	movl	$15, %r8d
	jmp	.LBB66_27
.LBB66_25:
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.68, %rcx
	movl	$12, %r8d
	jmp	.LBB66_27
.LBB66_26:
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.114, %rcx
	movl	$14, %r8d
.LBB66_27:
	leaq	40(%rsp), %rdi
	movl	$10, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.38, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
.LBB66_28:
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.40, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.41, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	leal	-8(%r15), %eax
	cmpl	$4, %eax
	ja	.LBB66_6
	jmpq	*.LJTI66_1(,%rax,8)
.LBB66_30:
	leaq	40(%rsp), %rdi
	movl	$10, %edx
	movl	$13, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.38, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.117, %rcx
	jmp	.LBB66_5
.LBB66_31:
	leaq	40(%rsp), %rdi
	movl	$10, %edx
	movl	$13, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.38, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.106, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	cmpb	$6, %bl
	je	.LBB66_6
	cmpl	$7, %r15d
	jne	.LBB66_28
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.40, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.116, %rcx
	jmp	.LBB66_5
.LBB66_34:
	leaq	40(%rsp), %rdi
	movl	$5, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.79, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movq	4136(%rsp), %rax
	movq	%rax, %rdx
	addq	$4, %rdx
	movq	$-1, %rcx
	cmovaeq	%rdx, %rcx
	cmpq	$4097, %rcx
	jae	.LBB66_62
	movq	%rcx, %rdi
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB66_63
	movl	$33554432, 40(%rsp,%rax)
	movq	%rcx, 4136(%rsp)
	jmp	.LBB66_6
.LBB66_37:
	movl	$50331780, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movl	$6, %edx
	movl	$4, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.42, %rsi
	jmp	.LBB66_5
.LBB66_38:
	leaq	40(%rsp), %rdi
	movl	$6, %edx
	movl	$9, %r8d
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.74, %rcx
	jmp	.LBB66_5
.LBB66_39:
	leaq	40(%rsp), %rdi
	movl	$3, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.76, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
.LBB66_40:
	leaq	40(%rsp), %rdi
	movl	$15, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.118, %rsi
.LBB66_41:
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	leaq	40(%rsp), %r14
	movl	$10, %edx
	movl	$9, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.38, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.113, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$6, %edx
	movl	$4, %r8d
	movq	%r14, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.40, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.41, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4136(%rsp), %r14
	movq	%r14, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB66_44
	movq	%rax, %rdi
	subq	%r14, %rdi
	cmpq	$4, %rdi
	jne	.LBB66_63
	movl	$33554432, 40(%rsp,%r14)
	movq	%rax, 4136(%rsp)
	movq	%rax, %r14
	cmpb	$16, %bl
	je	.LBB66_17
	jmp	.LBB66_47
.LBB66_44:
	movb	$0, 4152(%rsp)
	cmpb	$16, %bl
	je	.LBB66_17
	jmp	.LBB66_47
.LBB66_62:
	movb	$0, 4152(%rsp)
	jmp	.LBB66_6
.LBB66_63:
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB66_64:
	movl	$4096, %edx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB66_65:
	movl	$117, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end66:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci, .Lfunc_end66-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests12invalid_psci,"a",@progbits
	.p2align	3, 0x0
.LJTI66_0:
	.quad	.LBB66_4
	.quad	.LBB66_14
	.quad	.LBB66_25
	.quad	.LBB66_26
	.quad	.LBB66_24
.LJTI66_1:
	.quad	.LBB66_4
	.quad	.LBB66_30
	.quad	.LBB66_37
	.quad	.LBB66_38
	.quad	.LBB66_34

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure,"ax",@progbits
	.prefalign	4, .Lfunc_end67, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure:
.Lfunc_begin67:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$56, %rsp
	.cfi_def_cfa_offset 4176
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movl	%edi, %ebx
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.62, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	cmpb	$9, %bl
	ja	.LBB67_25
	movzbl	%bl, %eax
	jmpq	*.LJTI67_0(,%rax,8)
.LBB67_2:
	movb	$1, 117(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB67_40
	jmp	.LBB67_51
.LBB67_3:
	movl	$1207959552, 48(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB67_40
	jmp	.LBB67_51
.LBB67_4:
	movq	4136(%rsp), %rax
	addq	$-121, %rax
	movq	%rax, %rcx
	addq	$4, %rcx
	movq	$-1, %rdi
	cmovaeq	%rcx, %rdi
	cmpq	$4097, %rdi
	jae	.LBB67_39
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB67_32
	movl	$33554432, 32(%rsp,%rax)
	cmpb	$1, 4144(%rsp)
	jne	.LBB67_40
	jmp	.LBB67_51
.LBB67_7:
	movl	$-1, 128(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB67_40
	jmp	.LBB67_51
.LBB67_8:
	movl	$-1, 124(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB67_40
	jmp	.LBB67_51
.LBB67_9:
	movq	4136(%rsp), %rax
	addq	$-121, %rax
	movq	%rax, %rcx
	addq	$4, %rcx
	movq	$-1, %rdi
	cmovaeq	%rcx, %rdi
	cmpq	$4097, %rdi
	jae	.LBB67_39
	subq	%rax, %rdi
	cmpq	$4, %rdi
	je	.LBB67_11
	jmp	.LBB67_32
.LBB67_12:
	movl	$117440512, 112(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB67_40
	jmp	.LBB67_51
.LBB67_13:
	movq	$-1, 72(%rsp)
	movl	$16777216, 84(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB67_40
	jmp	.LBB67_51
.LBB67_14:
	leaq	32(%rsp), %rbx
	movl	$4096, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$80, 4128(%rsp)
	movq	$0, 4136(%rsp)
	movb	$1, 4144(%rsp)
	movl	$1, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$1, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33, %eax
	movq	4128(%rsp), %rdx
	movq	$-1, %rcx
	jmp	.LBB67_16
	.p2align	4
.LBB67_15:
	movb	$0, 4144(%rsp)
	decl	%eax
	je	.LBB67_19
.LBB67_16:
	movq	%rdx, %rsi
	addq	$4, %rsi
	cmovbq	%rcx, %rsi
	cmpq	$4097, %rsi
	jae	.LBB67_15
	movq	%rsi, %rdi
	subq	%rdx, %rdi
	cmpq	$4, %rdi
	jne	.LBB67_32
	movl	$33554432, 32(%rsp,%rdx)
	movq	%rsi, 4128(%rsp)
	movq	%rsi, %rdx
	decl	%eax
	jne	.LBB67_16
.LBB67_19:
	leaq	32(%rsp), %rbx
	movl	$4, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.35, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$16777216, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$5, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.28, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.31, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %rbx
	movq	%rbx, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4097, %rax
	jae	.LBB67_42
	movq	%rax, %rdi
	subq	%rbx, %rdi
	cmpq	$4, %rdi
	jne	.LBB67_32
	movl	$33554432, 32(%rsp,%rbx)
	movq	%rax, 4128(%rsp)
	cmpq	$4092, %rax
	ja	.LBB67_44
	leaq	4(%rax), %rbx
	movl	$33554432, 32(%rsp,%rax)
	movq	%rbx, 4128(%rsp)
	cmpq	$4088, %rax
	ja	.LBB67_45
	leaq	8(%rax), %rbx
	movl	$33554432, 36(%rsp,%rax)
	movq	%rbx, 4128(%rsp)
	cmpq	$4085, %rax
	jae	.LBB67_45
	movl	$150994944, 40(%rsp,%rax)
	addq	$12, %rax
	jmp	.LBB67_38
.LBB67_25:
	leaq	32(%rsp), %rbx
	movl	$4096, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$80, 4128(%rsp)
	movq	$0, 4136(%rsp)
	movb	$1, 4144(%rsp)
	movl	$1, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$33554432, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$4, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.35, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$16777216, (%rsp)
	movq	%rsp, %rcx
	movl	$14, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$5, %edx
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.28, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movl	$11, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, %rsi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.31, %rcx
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movl	$0, (%rsp)
	movq	%rsp, %rcx
	movl	$3, %edx
	movl	$4, %r8d
	movq	%rbx, %rdi
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob8property
	movq	4128(%rsp), %rcx
	movq	%rcx, %rdx
	addq	$4, %rdx
	movq	$-1, %rax
	cmovaeq	%rdx, %rax
	cmpq	$4096, %rax
	ja	.LBB67_33
	movq	%rax, %rdi
	subq	%rcx, %rdi
	cmpq	$4, %rdi
	jne	.LBB67_32
	movl	$33554432, 32(%rsp,%rcx)
	movq	%rax, 4128(%rsp)
	cmpq	$4092, %rax
	ja	.LBB67_33
	leaq	4(%rax), %rcx
	movl	$33554432, 32(%rsp,%rax)
	movq	%rcx, 4128(%rsp)
	cmpq	$4089, %rax
	jae	.LBB67_33
	movl	$33554432, 36(%rsp,%rax)
	addq	$8, %rax
	movq	%rax, 4128(%rsp)
	jmp	.LBB67_34
.LBB67_30:
	movq	4136(%rsp), %rax
	addq	$-125, %rax
	movq	%rax, %rcx
	addq	$4, %rcx
	movq	$-1, %rdi
	cmovaeq	%rcx, %rdi
	cmpq	$4097, %rdi
	jae	.LBB67_39
	subq	%rax, %rdi
	cmpq	$4, %rdi
	jne	.LBB67_32
.LBB67_11:
	movl	$67108864, 32(%rsp,%rax)
	cmpb	$1, 4144(%rsp)
	jne	.LBB67_40
	jmp	.LBB67_51
.LBB67_39:
	movb	$0, 4144(%rsp)
	cmpb	$1, 4144(%rsp)
	je	.LBB67_51
.LBB67_40:
	xorl	%eax, %eax
	addq	$4152, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB67_33:
	.cfi_def_cfa_offset 4176
	movb	$0, 4144(%rsp)
.LBB67_34:
	leaq	32(%rsp), %rdi
	movl	$12, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.119, %rsi
	callq	_RNvMNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_testsNtB2_4Blob5begin
	movq	4128(%rsp), %rbx
	movq	%rbx, %rcx
	addq	$4, %rcx
	movq	$-1, %rax
	cmovaeq	%rcx, %rax
	cmpq	$4096, %rax
	ja	.LBB67_45
	movq	%rax, %rdi
	subq	%rbx, %rdi
	cmpq	$4, %rdi
	jne	.LBB67_32
	movl	$33554432, 32(%rsp,%rbx)
	movq	%rax, 4128(%rsp)
	cmpq	$4093, %rax
	jae	.LBB67_44
	movl	$150994944, 32(%rsp,%rax)
	addq	$4, %rax
.LBB67_38:
	movq	%rax, 4128(%rsp)
	movq	%rax, %rbx
	jmp	.LBB67_46
.LBB67_44:
	movq	%rax, %rbx
	jmp	.LBB67_45
.LBB67_42:
	movb	$0, 4144(%rsp)
.LBB67_45:
	movb	$0, 4144(%rsp)
.LBB67_46:
	movq	%rbx, %rax
	addq	$117, %rax
	movq	$-1, %r14
	cmovaeq	%rax, %r14
	cmpq	$4097, %r14
	jae	.LBB67_49
	movq	%r14, %rdi
	subq	%rbx, %rdi
	cmpq	$117, %rdi
	jne	.LBB67_54
	leaq	(%rsp,%rbx), %rdi
	addq	$32, %rdi
	movl	$117, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.46, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r14, 4128(%rsp)
	jmp	.LBB67_50
.LBB67_49:
	movb	$0, 4144(%rsp)
	movq	%rbx, %r14
.LBB67_50:
	movq	%r14, 4136(%rsp)
	movl	$-302117424, 32(%rsp)
	bswapl	%r14d
	movl	%r14d, 36(%rsp)
	movl	$1342177280, 40(%rsp)
	movl	%ebx, %eax
	bswapl	%eax
	movl	%eax, 44(%rsp)
	movabsq	$1224979099315863552, %rax
	movq	%rax, 48(%rsp)
	movq	$268435456, 56(%rsp)
	movl	$1962934272, 64(%rsp)
	addl	$-80, %ebx
	bswapl	%ebx
	movl	%ebx, 68(%rsp)
	cmpb	$1, 4144(%rsp)
	jne	.LBB67_40
.LBB67_51:
	movq	4136(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB67_53
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	sete	%al
	addq	$4152, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB67_32:
	.cfi_def_cfa_offset 4176
	movl	$4, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.LBB67_53:
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB67_54:
	movl	$117, %esi
	callq	_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail
.Lfunc_end67:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure, .Lfunc_end67-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure
	.cfi_endproc
	.section	.rodata._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests17invalid_structure,"a",@progbits
	.p2align	3, 0x0
.LJTI67_0:
	.quad	.LBB67_2
	.quad	.LBB67_12
	.quad	.LBB67_7
	.quad	.LBB67_8
	.quad	.LBB67_3
	.quad	.LBB67_13
	.quad	.LBB67_14
	.quad	.LBB67_9
	.quad	.LBB67_30
	.quad	.LBB67_4

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header,"ax",@progbits
	.prefalign	4, .Lfunc_end68, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header:
.Lfunc_begin68:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$56, %rsp
	.cfi_def_cfa_offset 4176
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movl	%esi, %ebx
	movq	%rdi, %r14
	leaq	32(%rsp), %rdi
	movl	$2, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.62, %rsi
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$1, %r9d
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests5basic
	bswapl	%ebx
	movl	%ebx, 32(%rsp,%r14)
	cmpb	$1, 4144(%rsp)
	jne	.LBB68_3
	movq	4136(%rsp), %rdx
	cmpq	$4097, %rdx
	jae	.LBB68_5
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvNtCsjFdXuXHMTfk_9hm_kernel12cpu_topology5parse
	cmpb	$-1, 24(%rsp)
	sete	%al
	addq	$4152, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB68_3:
	.cfi_def_cfa_offset 4176
	xorl	%eax, %eax
	addq	$4152, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB68_5:
	.cfi_def_cfa_offset 4176
	movq	%rdx, %rsi
	movl	$4096, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end68:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header, .Lfunc_end68-_RNvNtCsjFdXuXHMTfk_9hm_kernel18cpu_topology_tests14invalid_header
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid,"ax",@progbits
	.prefalign	4, .Lfunc_end69, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid:
.Lfunc_begin69:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$520, %rsp
	.cfi_def_cfa_offset 4672
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movabsq	$4294967552, %r15
	movq	$0, 2688(%rsp)
	movl	$0, 2696(%rsp)
	movl	$0, 2706(%rsp)
	movw	$0, 2710(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1136(%rsp)
	movq	$0, 1144(%rsp)
	movq	$0, 1152(%rsp)
	movq	$0, 3152(%rsp)
	movq	$0, 3144(%rsp)
	movq	$0, 3136(%rsp)
	movq	$0, 3128(%rsp)
	movq	$0, 3120(%rsp)
	movq	$0, 3112(%rsp)
	movq	$0, 3104(%rsp)
	movq	$0, 3096(%rsp)
	movq	$0, 3088(%rsp)
	movq	$0, 3080(%rsp)
	movq	$0, 3072(%rsp)
	movq	$0, 3064(%rsp)
	movq	$0, 3056(%rsp)
	movq	$0, 3048(%rsp)
	movq	$0, 1631(%rsp)
	movb	$0, 1639(%rsp)
	movl	$1179403647, 1624(%rsp)
	movl	$16843334, 1627(%rsp)
	movabsq	$-6510615555426900571, %rbx
	movq	%rbx, 144(%rsp)
	movq	%rbx, 136(%rsp)
	movq	%rbx, 128(%rsp)
	movq	%rbx, 120(%rsp)
	movabsq	$6510615555426900570, %rax
	movq	%rax, 1168(%rsp)
	movq	%rax, 1160(%rsp)
	movq	1632(%rsp), %rax
	movq	%rax, 2656(%rsp)
	movq	1624(%rsp), %rax
	movq	%rax, 2648(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 2664(%rsp)
	movq	%r15, 2672(%rsp)
	movq	$64, 2680(%rsp)
	movl	$3670080, 2700(%rsp)
	movw	$2, 2704(%rsp)
	movabsq	$21474836481, %rax
	movq	%rax, 2712(%rsp)
	movq	$256, 2720(%rsp)
	movq	%r15, 2728(%rsp)
	movq	$-1, 2736(%rsp)
	movq	$32, 2744(%rsp)
	movq	$32, 2752(%rsp)
	movq	$4096, 2760(%rsp)
	movabsq	$25769803777, %rax
	movq	%rax, 2768(%rsp)
	movq	$384, 2776(%rsp)
	leaq	8320(%r15), %rax
	movq	%rax, 2784(%rsp)
	movq	$-1, 2792(%rsp)
	movq	$16, 2800(%rsp)
	movq	$4097, 2808(%rsp)
	movq	$4096, 2816(%rsp)
	leaq	2824(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %r14
	movl	$112, %edx
	callq	*%r14
	leaq	2936(%rsp), %rdi
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	callq	*%r14
	leaq	40(%rsp), %rdi
	leaq	2648(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	movzbl	88(%rsp), %r13d
	xorl	%eax, %eax
	cmpb	$-1, %r13b
	je	.LBB69_31
	cmpq	%r15, 488(%rsp)
	jne	.LBB69_31
	cmpq	$3, 504(%rsp)
	jne	.LBB69_31
	movq	496(%rsp), %rsi
	cmpq	$9, %rsi
	jae	.LBB69_43
	cmpq	$2, %rsi
	jne	.LBB69_30
	cmpq	$32, 48(%rsp)
	jne	.LBB69_30
	movq	40(%rsp), %rdi
	movq	56(%rsp), %rax
	movq	%rax, 1608(%rsp)
	movq	64(%rsp), %rax
	movq	%rax, 1616(%rsp)
	movq	72(%rsp), %r12
	movq	80(%rsp), %rbp
	movq	96(%rsp), %rax
	movq	%rax, 1576(%rsp)
	movq	104(%rsp), %r14
	movq	120(%rsp), %rax
	movq	%rax, 1584(%rsp)
	movq	128(%rsp), %rax
	movq	%rax, 1592(%rsp)
	movq	136(%rsp), %rax
	movq	%rax, 1600(%rsp)
	movzbl	144(%rsp), %eax
	movb	%al, 7(%rsp)
	movl	$32, %edx
	movq	$.Lanon.2518d136abfec7ebc9d3a69d0b38d406.127, %rsi
	callq	*memcmp@GOTPCREL(%rip)
	movl	%eax, %ecx
	xorl	%eax, %eax
	cmpq	$16, %r14
	jne	.LBB69_31
	leaq	3840(%r15), %rdx
	cmpq	%rdx, %rbp
	jne	.LBB69_31
	movabsq	$4294967296, %rdx
	cmpq	%rdx, %r12
	jne	.LBB69_31
	cmpq	$32, 1616(%rsp)
	jne	.LBB69_31
	cmpq	%r15, 1608(%rsp)
	jne	.LBB69_31
	cmpb	$2, %r13b
	jne	.LBB69_31
	testl	%ecx, %ecx
	movabsq	$21474836481, %r14
	movabsq	$4306960386, %r12
	movabsq	$6510615555426900570, %rsi
	jne	.LBB69_31
	leaq	16128(%r15), %rcx
	xorl	%eax, %eax
	cmpq	%rcx, 1600(%rsp)
	jne	.LBB69_31
	leaq	7936(%r15), %rcx
	cmpq	%rcx, 1592(%rsp)
	jne	.LBB69_31
	cmpq	$4097, 1584(%rsp)
	jne	.LBB69_31
	cmpb	$1, 7(%rsp)
	jne	.LBB69_31
	movq	1576(%rsp), %rdx
	movq	(%rdx), %rcx
	xorq	%rsi, %rcx
	movq	8(%rdx), %rdx
	xorq	%rsi, %rdx
	orq	%rcx, %rdx
	jne	.LBB69_31
	leaq	216(%rsp), %rdi
	leaq	328(%rsp), %r13
	movq	$0, 80(%rsp)
	movl	$0, 88(%rsp)
	movl	$0, 98(%rsp)
	movw	$0, 102(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1136(%rsp)
	movq	$0, 1624(%rsp)
	movq	$0, 1632(%rsp)
	movq	$0, 1640(%rsp)
	movq	$0, 1648(%rsp)
	movq	$0, 1656(%rsp)
	movq	$0, 1664(%rsp)
	movq	$0, 1672(%rsp)
	movq	$0, 1680(%rsp)
	movq	$0, 1688(%rsp)
	movq	$0, 1696(%rsp)
	movq	$0, 1704(%rsp)
	movq	$0, 1712(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 2143(%rsp)
	movb	$0, 2151(%rsp)
	movl	$1179403647, 2136(%rsp)
	movl	$16843334, 2139(%rsp)
	movq	%rbx, 1168(%rsp)
	movq	%rbx, 1160(%rsp)
	movq	%rbx, 1152(%rsp)
	movq	%rbx, 1144(%rsp)
	movq	%rsi, 1728(%rsp)
	movq	%rsi, 1720(%rsp)
	movq	2144(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	2136(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	%r12, 56(%rsp)
	movq	%r15, 64(%rsp)
	movq	$64, 72(%rsp)
	movl	$3670080, 92(%rsp)
	movw	$2, 96(%rsp)
	movq	%r14, 104(%rsp)
	movq	$256, 112(%rsp)
	movq	%r15, 120(%rsp)
	movq	$-1, 128(%rsp)
	movq	$32, 136(%rsp)
	movq	$32, 144(%rsp)
	movabsq	$25769803777, %r14
	movq	%r14, 160(%rsp)
	movq	$384, 168(%rsp)
	leaq	8320(%r15), %rbp
	movq	%rbp, 176(%rsp)
	movq	$-1, 184(%rsp)
	movq	$16, 192(%rsp)
	movq	$4097, 200(%rsp)
	movq	%rsi, %r12
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	callq	*memcpy@GOTPCREL(%rip)
	leaq	1624(%rsp), %rsi
	movl	$112, %edx
	movq	%r13, %rdi
	movq	memcpy@GOTPCREL(%rip), %r14
	callq	*%r14
	movq	$0, 152(%rsp)
	movq	$0, 208(%rsp)
	leaq	1064(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1112(%rsp)
	je	.LBB69_30
	leaq	80(%rsp), %rax
	movl	$0, 8(%rax)
	movq	$0, (%rax)
	movw	$0, 22(%rax)
	movl	$0, 18(%rax)
	movq	$0, 1136(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1624(%rsp)
	movq	$0, 1632(%rsp)
	movq	$0, 1640(%rsp)
	movq	$0, 1648(%rsp)
	movq	$0, 1656(%rsp)
	movq	$0, 1664(%rsp)
	movq	$0, 1672(%rsp)
	movq	$0, 1680(%rsp)
	movq	$0, 1688(%rsp)
	movq	$0, 1696(%rsp)
	movq	$0, 1704(%rsp)
	movq	$0, 1712(%rsp)
	movq	$0, 464(%rax)
	movq	$0, 456(%rax)
	movq	$0, 448(%rax)
	movq	$0, 440(%rax)
	movq	$0, 432(%rax)
	movq	$0, 424(%rax)
	movq	$0, 416(%rax)
	movq	$0, 408(%rax)
	movq	$0, 400(%rax)
	movq	$0, 392(%rax)
	movq	$0, 384(%rax)
	movq	$0, 376(%rax)
	movq	$0, 368(%rax)
	movq	%rax, %r13
	movq	$0, 360(%rax)
	movq	$0, 2143(%rsp)
	movb	$0, 2151(%rsp)
	movl	$1179403647, 2136(%rsp)
	movl	$16843334, 2139(%rsp)
	movq	%rbx, 1144(%rsp)
	movq	%rbx, 1152(%rsp)
	movq	%rbx, 1160(%rsp)
	movq	%rbx, 1168(%rsp)
	movq	%r12, 1720(%rsp)
	movq	%r12, 1728(%rsp)
	movq	2136(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	2144(%rsp), %rax
	movq	%rax, 48(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 56(%rsp)
	movq	%r15, 64(%rsp)
	movq	$64, 72(%rsp)
	movl	$3670080, 92(%rsp)
	movw	$2, 96(%rsp)
	movabsq	$21474836481, %rax
	movq	%rax, 104(%rsp)
	movq	$256, 112(%rsp)
	movq	%r15, 120(%rsp)
	movq	$-1, 128(%rsp)
	movq	$32, 136(%rsp)
	movq	$32, 144(%rsp)
	movabsq	$25769803777, %rax
	movq	%rax, 160(%rsp)
	movq	$384, 168(%rsp)
	movq	%rbp, 176(%rsp)
	movq	$-1, 184(%rsp)
	movq	$16, 192(%rsp)
	movq	$4097, 200(%rsp)
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	leaq	216(%rsp), %rdi
	callq	*%r14
	leaq	1624(%rsp), %rsi
	movl	$112, %edx
	leaq	328(%rsp), %rdi
	callq	*%r14
	movq	$1, 152(%rsp)
	movq	$1, 208(%rsp)
	leaq	1064(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1112(%rsp)
	je	.LBB69_30
	movl	$0, 8(%r13)
	movq	$0, (%r13)
	movw	$0, 22(%r13)
	movl	$0, 18(%r13)
	movq	$0, 1136(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1624(%rsp)
	movq	$0, 1632(%rsp)
	movq	$0, 1640(%rsp)
	movq	$0, 1648(%rsp)
	movq	$0, 1656(%rsp)
	movq	$0, 1664(%rsp)
	movq	$0, 1672(%rsp)
	movq	$0, 1680(%rsp)
	movq	$0, 1688(%rsp)
	movq	$0, 1696(%rsp)
	movq	$0, 1704(%rsp)
	movq	$0, 1712(%rsp)
	movq	$0, 464(%r13)
	movq	$0, 456(%r13)
	movq	$0, 448(%r13)
	movq	$0, 440(%r13)
	movq	$0, 432(%r13)
	movq	$0, 424(%r13)
	movq	$0, 416(%r13)
	movq	$0, 408(%r13)
	movq	$0, 400(%r13)
	movq	$0, 392(%r13)
	movq	$0, 384(%r13)
	movq	$0, 376(%r13)
	movq	$0, 368(%r13)
	movq	$0, 360(%r13)
	movq	$0, 2143(%rsp)
	movb	$0, 2151(%rsp)
	movl	$1179403647, 2136(%rsp)
	movl	$16843334, 2139(%rsp)
	movq	%rbx, 1144(%rsp)
	movq	%rbx, 1152(%rsp)
	movq	%rbx, 1160(%rsp)
	movq	%rbx, 1168(%rsp)
	movq	%r12, 1720(%rsp)
	movq	%r12, 1728(%rsp)
	movq	2136(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	2144(%rsp), %rax
	movq	%rax, 48(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 56(%rsp)
	movq	%r15, 64(%rsp)
	movq	$64, 72(%rsp)
	movl	$3670080, 92(%rsp)
	movw	$2, 96(%rsp)
	movabsq	$21474836481, %rax
	movq	%rax, 104(%rsp)
	movq	$256, 112(%rsp)
	movq	%r15, 120(%rsp)
	movq	$-1, 128(%rsp)
	movq	$32, 136(%rsp)
	movq	$32, 144(%rsp)
	movabsq	$25769803777, %rax
	movq	%rax, 160(%rsp)
	movq	$384, 168(%rsp)
	movq	%rbp, 176(%rsp)
	movq	$-1, 184(%rsp)
	movq	$16, 192(%rsp)
	movq	$4097, 200(%rsp)
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	leaq	216(%rsp), %rdi
	callq	*%r14
	leaq	1624(%rsp), %rsi
	movl	$112, %edx
	leaq	328(%rsp), %rdi
	callq	*%r14
	movq	$4096, 152(%rsp)
	movq	$4096, 208(%rsp)
	leaq	1064(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1112(%rsp)
	je	.LBB69_30
	movl	$0, 8(%r13)
	movq	$0, (%r13)
	movw	$0, 22(%r13)
	movl	$0, 18(%r13)
	movq	$0, 1136(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1624(%rsp)
	movq	$0, 1632(%rsp)
	movq	$0, 1640(%rsp)
	movq	$0, 1648(%rsp)
	movq	$0, 1656(%rsp)
	movq	$0, 1664(%rsp)
	movq	$0, 1672(%rsp)
	movq	$0, 1680(%rsp)
	movq	$0, 1688(%rsp)
	movq	$0, 1696(%rsp)
	movq	$0, 1704(%rsp)
	movq	$0, 1712(%rsp)
	movq	$0, 464(%r13)
	movq	$0, 456(%r13)
	movq	$0, 448(%r13)
	movq	$0, 440(%r13)
	movq	$0, 432(%r13)
	movq	$0, 424(%r13)
	movq	$0, 416(%r13)
	movq	$0, 408(%r13)
	movq	$0, 400(%r13)
	movq	$0, 392(%r13)
	movq	$0, 384(%r13)
	movq	$0, 376(%r13)
	movq	$0, 368(%r13)
	movq	$0, 360(%r13)
	movq	$0, 2143(%rsp)
	movb	$0, 2151(%rsp)
	movl	$1179403647, 2136(%rsp)
	movl	$16843334, 2139(%rsp)
	movq	%rbx, 1144(%rsp)
	movq	%rbx, 1152(%rsp)
	movq	%rbx, 1160(%rsp)
	movq	%rbx, 1168(%rsp)
	movq	%r12, 1720(%rsp)
	movq	%r12, 1728(%rsp)
	movq	2136(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	2144(%rsp), %rax
	movq	%rax, 48(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 56(%rsp)
	movq	%r15, 64(%rsp)
	movq	$64, 72(%rsp)
	movl	$3670080, 92(%rsp)
	movw	$2, 96(%rsp)
	movabsq	$21474836481, %rax
	movq	%rax, 104(%rsp)
	movq	$256, 112(%rsp)
	movq	%r15, 120(%rsp)
	movq	$-1, 128(%rsp)
	movq	$32, 136(%rsp)
	movq	$32, 144(%rsp)
	movabsq	$25769803777, %rax
	movq	%rax, 160(%rsp)
	movq	$384, 168(%rsp)
	movq	%rbp, 176(%rsp)
	movq	$-1, 184(%rsp)
	movq	$16, 192(%rsp)
	movq	$4097, 200(%rsp)
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	leaq	216(%rsp), %rdi
	callq	*%r14
	leaq	1624(%rsp), %rsi
	movl	$112, %edx
	leaq	328(%rsp), %rdi
	callq	*%r14
	movq	$8192, 152(%rsp)
	movq	$8192, 208(%rsp)
	leaq	1064(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1112(%rsp)
	je	.LBB69_30
	movq	$0, 3200(%rsp)
	movl	$0, 3208(%rsp)
	movl	$0, 3218(%rsp)
	movw	$0, 3222(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1136(%rsp)
	movq	$0, 1144(%rsp)
	movq	$0, 1152(%rsp)
	movq	$0, 3664(%rsp)
	movq	$0, 3656(%rsp)
	movq	$0, 3648(%rsp)
	movq	$0, 3640(%rsp)
	movq	$0, 3632(%rsp)
	movq	$0, 3624(%rsp)
	movq	$0, 3616(%rsp)
	movq	$0, 3608(%rsp)
	movq	$0, 3600(%rsp)
	movq	$0, 3592(%rsp)
	movq	$0, 3584(%rsp)
	movq	$0, 3576(%rsp)
	movq	$0, 3568(%rsp)
	movq	$0, 3560(%rsp)
	movq	$0, 1631(%rsp)
	movb	$0, 1639(%rsp)
	movl	$1179403647, 1624(%rsp)
	movl	$16843334, 1627(%rsp)
	movq	%rbx, 144(%rsp)
	movq	%rbx, 136(%rsp)
	movq	%rbx, 128(%rsp)
	movq	%rbx, 120(%rsp)
	movq	%r12, 1168(%rsp)
	movq	%r12, 1160(%rsp)
	movq	1632(%rsp), %rax
	movq	%rax, 3168(%rsp)
	movq	1624(%rsp), %rax
	movq	%rax, 3160(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 3176(%rsp)
	movq	%r15, 3184(%rsp)
	movq	$64, 3192(%rsp)
	movl	$3670080, 3212(%rsp)
	movw	$2, 3216(%rsp)
	movabsq	$21474836481, %rax
	movq	%rax, 3224(%rsp)
	movq	$256, 3232(%rsp)
	movq	%r15, 3240(%rsp)
	movq	$-1, 3248(%rsp)
	movq	$32, 3256(%rsp)
	movq	$32, 3264(%rsp)
	movq	$4096, 3272(%rsp)
	movabsq	$25769803777, %rax
	movq	%rax, 3280(%rsp)
	movq	$384, 3288(%rsp)
	movq	%rbp, 3296(%rsp)
	movq	$-1, 3304(%rsp)
	movq	$4097, 3320(%rsp)
	movq	$4096, 3328(%rsp)
	leaq	3336(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$112, %edx
	callq	*%r14
	leaq	3448(%rsp), %rdi
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	callq	*%r14
	movq	$0, 3312(%rsp)
	leaq	4144(%rsp), %rdi
	leaq	3160(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 4192(%rsp)
	je	.LBB69_30
	movq	%r14, %r13
	leaq	4144(%rsp), %rdi
	callq	_RNCNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid0B5_
	testb	%al, %al
	je	.LBB69_30
	movq	$0, 2176(%rsp)
	movl	$0, 2184(%rsp)
	movl	$0, 2194(%rsp)
	movw	$0, 2198(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1136(%rsp)
	movq	$0, 1144(%rsp)
	movq	$0, 1152(%rsp)
	movq	$0, 2640(%rsp)
	movq	$0, 2632(%rsp)
	movq	$0, 2624(%rsp)
	movq	$0, 2616(%rsp)
	movq	$0, 2608(%rsp)
	movq	$0, 2600(%rsp)
	movq	$0, 2592(%rsp)
	movq	$0, 2584(%rsp)
	movq	$0, 2576(%rsp)
	movq	$0, 2568(%rsp)
	movq	$0, 2560(%rsp)
	movq	$0, 2552(%rsp)
	movq	$0, 2544(%rsp)
	movq	$0, 2536(%rsp)
	movq	$0, 1631(%rsp)
	movb	$0, 1639(%rsp)
	movl	$1179403647, 1624(%rsp)
	movl	$16843334, 1627(%rsp)
	movq	%rbx, 144(%rsp)
	movq	%rbx, 136(%rsp)
	movq	%rbx, 128(%rsp)
	movq	%rbx, 120(%rsp)
	movabsq	$6510615555426900570, %rax
	movq	%rax, 1168(%rsp)
	movq	%rax, 1160(%rsp)
	movq	1632(%rsp), %rax
	movq	%rax, 2144(%rsp)
	movq	1624(%rsp), %rax
	movq	%rax, 2136(%rsp)
	movabsq	$4306960386, %r12
	movq	%r12, 2152(%rsp)
	movq	%r15, 2160(%rsp)
	movq	$64, 2168(%rsp)
	movl	$3670080, 2188(%rsp)
	movw	$2, 2192(%rsp)
	movabsq	$21474836481, %r14
	movq	%r14, 2200(%rsp)
	movq	$256, 2208(%rsp)
	movq	%r15, 2216(%rsp)
	movq	$-1, 2224(%rsp)
	movq	$32, 2232(%rsp)
	movq	$32, 2240(%rsp)
	movq	$4096, 2248(%rsp)
	movl	$1, 2256(%rsp)
	movq	$384, 2264(%rsp)
	movq	%rbp, 2272(%rsp)
	movq	$-1, 2280(%rsp)
	movq	$16, 2288(%rsp)
	movq	$4097, 2296(%rsp)
	movq	$4096, 2304(%rsp)
	leaq	2312(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$112, %edx
	callq	*%r13
	leaq	2424(%rsp), %rdi
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	callq	*%r13
	movl	$4, 2260(%rsp)
	leaq	40(%rsp), %rdi
	leaq	2136(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 88(%rsp)
	je	.LBB69_30
	movq	496(%rsp), %rsi
	cmpq	$9, %rsi
	jae	.LBB69_43
	cmpq	$2, %rsi
	jb	.LBB69_44
	cmpb	$0, 144(%rsp)
	je	.LBB69_32
.LBB69_30:
	xorl	%eax, %eax
.LBB69_31:
	addq	$4616, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB69_32:
	.cfi_def_cfa_offset 4672
	movl	$0, 1672(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1136(%rsp)
	movq	$0, 1144(%rsp)
	movq	$0, 1152(%rsp)
	movq	$0, 2128(%rsp)
	movq	$0, 2120(%rsp)
	movq	$0, 2112(%rsp)
	movq	$0, 2104(%rsp)
	movq	$0, 2096(%rsp)
	movq	$0, 2088(%rsp)
	movq	$0, 2080(%rsp)
	movq	$0, 2072(%rsp)
	movq	$0, 2064(%rsp)
	movq	$0, 2056(%rsp)
	movq	$0, 2048(%rsp)
	movq	$0, 2040(%rsp)
	movq	$0, 2032(%rsp)
	movq	$0, 2024(%rsp)
	movq	$0, 3679(%rsp)
	movb	$0, 3687(%rsp)
	movl	$1179403647, 3672(%rsp)
	movl	$16843334, 3675(%rsp)
	movq	%rbx, 144(%rsp)
	movq	%rbx, 136(%rsp)
	movq	%rbx, 128(%rsp)
	movq	%rbx, 120(%rsp)
	movabsq	$6510615555426900570, %rbp
	movq	%rbp, 1168(%rsp)
	movq	%rbp, 1160(%rsp)
	movq	3680(%rsp), %rax
	movq	%rax, 1632(%rsp)
	movq	3672(%rsp), %rax
	movq	%rax, 1624(%rsp)
	movq	%r12, 1640(%rsp)
	movq	%r15, 1648(%rsp)
	movq	$64, 1656(%rsp)
	movl	$3670080, 1676(%rsp)
	movw	$2, 1680(%rsp)
	movq	%r14, 1688(%rsp)
	movq	$256, 1696(%rsp)
	movq	%r15, 1704(%rsp)
	movq	$-1, 1712(%rsp)
	movq	$32, 1720(%rsp)
	movq	$32, 1728(%rsp)
	movq	$4096, 1736(%rsp)
	movabsq	$25769803777, %r12
	movq	%r12, 1744(%rsp)
	movq	$384, 1752(%rsp)
	leaq	8320(%r15), %r14
	movq	%r14, 1760(%rsp)
	movq	$-1, 1768(%rsp)
	movq	$16, 1776(%rsp)
	movq	$4097, 1784(%rsp)
	movq	$4096, 1792(%rsp)
	leaq	1800(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$112, %edx
	callq	*%r13
	leaq	1912(%rsp), %rdi
	leaq	1064(%rsp), %rsi
	movl	$112, %edx
	callq	*%r13
	movq	$-1, 1664(%rsp)
	movl	$-1, 1682(%rsp)
	movw	$-1, 1686(%rsp)
	leaq	40(%rsp), %rdi
	leaq	1624(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 88(%rsp)
	je	.LBB69_30
	movq	$0, 1104(%rsp)
	movl	$0, 1112(%rsp)
	movl	$0, 1122(%rsp)
	movw	$0, 1126(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 3672(%rsp)
	movq	$0, 3680(%rsp)
	movq	$0, 3688(%rsp)
	movq	$0, 3696(%rsp)
	movq	$0, 3704(%rsp)
	movq	$0, 3712(%rsp)
	movq	$0, 3720(%rsp)
	movq	$0, 3728(%rsp)
	movq	$0, 3736(%rsp)
	movq	$0, 3744(%rsp)
	movq	$0, 3752(%rsp)
	movq	$0, 3760(%rsp)
	movq	$0, 1568(%rsp)
	movq	$0, 1560(%rsp)
	movq	$0, 1552(%rsp)
	movq	$0, 1544(%rsp)
	movq	$0, 1536(%rsp)
	movq	$0, 1528(%rsp)
	movq	$0, 1520(%rsp)
	movq	$0, 1512(%rsp)
	movq	$0, 1504(%rsp)
	movq	$0, 1496(%rsp)
	movq	$0, 1488(%rsp)
	movq	$0, 1480(%rsp)
	movq	$0, 1472(%rsp)
	movq	$0, 1464(%rsp)
	movq	$0, 15(%rsp)
	movb	$0, 23(%rsp)
	movl	$1179403647, 8(%rsp)
	movl	$16843334, 11(%rsp)
	movq	%rbx, 144(%rsp)
	movq	%rbx, 136(%rsp)
	movq	%rbx, 128(%rsp)
	movq	%rbx, 120(%rsp)
	movq	%rbp, 3776(%rsp)
	movq	%rbp, 3768(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 1072(%rsp)
	movq	8(%rsp), %rax
	movq	%rax, 1064(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 1080(%rsp)
	movq	%r15, 1088(%rsp)
	movq	$64, 1096(%rsp)
	movl	$3670080, 1116(%rsp)
	movabsq	$21474836481, %rax
	movq	%rax, 1128(%rsp)
	movq	$256, 1136(%rsp)
	movq	%r15, 1144(%rsp)
	movq	$-1, 1152(%rsp)
	movq	$32, 1160(%rsp)
	movq	$4096, 1176(%rsp)
	movq	%r12, 1184(%rsp)
	movq	$384, 1192(%rsp)
	movq	%r14, 1200(%rsp)
	movq	$-1, 1208(%rsp)
	movq	$16, 1216(%rsp)
	movq	$4097, 1224(%rsp)
	movq	$4096, 1232(%rsp)
	leaq	1240(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$112, %edx
	callq	*%r13
	leaq	1352(%rsp), %rdi
	leaq	3672(%rsp), %rsi
	movl	$112, %edx
	callq	*%r13
	movw	$1, 1120(%rsp)
	movq	$1048320, 1168(%rsp)
	leaq	40(%rsp), %rdi
	leaq	1064(%rsp), %rsi
	movl	$512, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 88(%rsp)
	je	.LBB69_30
	cmpq	$256, 504(%rsp)
	jne	.LBB69_30
	movq	496(%rsp), %rsi
	cmpq	$9, %rsi
	jae	.LBB69_43
	testq	%rsi, %rsi
	je	.LBB69_45
	leaq	1048320(%r15), %rax
	cmpq	%rax, 80(%rsp)
	movabsq	$21474836481, %rcx
	movabsq	$4306960386, %rdx
	jne	.LBB69_30
	movq	$0, 31(%rsp)
	movb	$0, 39(%rsp)
	movl	$1179403647, 24(%rsp)
	movl	$16843334, 27(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
	movq	$0, 960(%rsp)
	movq	$0, 968(%rsp)
	movq	$0, 976(%rsp)
	movq	$0, 984(%rsp)
	movq	$0, 992(%rsp)
	movq	$0, 1000(%rsp)
	movq	$0, 1008(%rsp)
	movq	$0, 1016(%rsp)
	movq	$0, 1024(%rsp)
	movq	$0, 1032(%rsp)
	movq	$0, 1040(%rsp)
	movq	$0, 1048(%rsp)
	movq	$0, 1056(%rsp)
	movq	24(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	32(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	%rdx, 56(%rsp)
	movq	$64, 72(%rsp)
	movabsq	$15762873573703680, %rax
	movq	%rax, 88(%rsp)
	movq	$0, 80(%rsp)
	movl	$0, 98(%rsp)
	movw	$0, 102(%rsp)
	movw	$16, 96(%rsp)
	leaq	704(%r15), %rax
	movq	%rax, 64(%rsp)
	movq	%rcx, 104(%rsp)
	movq	$960, 112(%rsp)
	movq	%rax, 120(%rsp)
	movq	$-1, 128(%rsp)
	movq	$16, 136(%rsp)
	movq	$16, 144(%rsp)
	movq	$4096, 152(%rsp)
	movabsq	$17179869185, %rax
	movq	%rax, 160(%rsp)
	movq	$0, 168(%rsp)
	leaq	7936(%r15), %rcx
	movq	%rcx, 176(%rsp)
	movq	$-1, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$4096, 200(%rsp)
	movq	$4096, 208(%rsp)
	movq	%rax, 216(%rsp)
	movq	$0, 224(%rsp)
	leaq	16128(%r15), %rcx
	movq	%rcx, 232(%rsp)
	movq	$-1, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$4096, 256(%rsp)
	movq	$4096, 264(%rsp)
	movq	%rax, 272(%rsp)
	movq	$0, 280(%rsp)
	leaq	24320(%r15), %rcx
	movq	%rcx, 288(%rsp)
	movq	$-1, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$4096, 312(%rsp)
	movq	$4096, 320(%rsp)
	movq	%rax, 328(%rsp)
	movq	$0, 336(%rsp)
	leaq	32512(%r15), %rcx
	movq	%rcx, 344(%rsp)
	movq	$-1, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$4096, 368(%rsp)
	movq	$4096, 376(%rsp)
	movq	%rax, 384(%rsp)
	movq	$0, 392(%rsp)
	leaq	40704(%r15), %rcx
	movq	%rcx, 400(%rsp)
	movq	$-1, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$4096, 424(%rsp)
	movq	$4096, 432(%rsp)
	movq	%rax, 440(%rsp)
	movq	$0, 448(%rsp)
	leaq	48896(%r15), %rcx
	movq	%rcx, 456(%rsp)
	movq	$-1, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$4096, 480(%rsp)
	movq	$4096, 488(%rsp)
	movq	%rax, 496(%rsp)
	movq	$0, 504(%rsp)
	addq	$57088, %r15
	movq	%r15, 512(%rsp)
	movq	$-1, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$4096, 536(%rsp)
	movq	$4096, 544(%rsp)
	movl	$4294967295, %eax
	movq	%rax, 604(%rsp)
	movq	$-1, 596(%rsp)
	movq	$-1, 588(%rsp)
	movq	$-1, 580(%rsp)
	movq	$-1, 572(%rsp)
	movq	$-1, 564(%rsp)
	movq	$-1, 556(%rsp)
	movl	$0, 552(%rsp)
	movq	$-1, 612(%rsp)
	movq	$-1, 620(%rsp)
	movq	$-1, 628(%rsp)
	movq	$-1, 636(%rsp)
	movq	$-1, 644(%rsp)
	movq	$-1, 652(%rsp)
	movl	$-1, 660(%rsp)
	movq	$-1, 668(%rsp)
	movq	$-1, 676(%rsp)
	movq	$-1, 684(%rsp)
	movq	$-1, 692(%rsp)
	movq	$-1, 700(%rsp)
	movq	$-1, 708(%rsp)
	movl	$-1, 716(%rsp)
	movl	$0, 664(%rsp)
	movq	%rax, 772(%rsp)
	movq	$-1, 764(%rsp)
	movq	$-1, 756(%rsp)
	movq	$-1, 748(%rsp)
	movq	$-1, 740(%rsp)
	movq	$-1, 732(%rsp)
	movq	$-1, 724(%rsp)
	movl	$0, 720(%rsp)
	movl	$-1, 828(%rsp)
	movq	$-1, 820(%rsp)
	movq	$-1, 812(%rsp)
	movq	$-1, 804(%rsp)
	movq	$-1, 796(%rsp)
	movq	$-1, 788(%rsp)
	movq	$-1, 780(%rsp)
	movl	$-1, 884(%rsp)
	movq	$-1, 876(%rsp)
	movq	$-1, 868(%rsp)
	movq	$-1, 860(%rsp)
	movq	$-1, 852(%rsp)
	movq	$-1, 844(%rsp)
	movq	$-1, 836(%rsp)
	movl	$0, 832(%rsp)
	movl	$-1, 940(%rsp)
	movq	$-1, 932(%rsp)
	movq	$-1, 924(%rsp)
	movq	$-1, 916(%rsp)
	movq	$-1, 908(%rsp)
	movq	$-1, 900(%rsp)
	movq	$-1, 892(%rsp)
	movl	$0, 888(%rsp)
	movl	$-1, 996(%rsp)
	movq	$-1, 988(%rsp)
	movq	$-1, 980(%rsp)
	movq	$-1, 972(%rsp)
	movq	$-1, 964(%rsp)
	movq	$-1, 956(%rsp)
	movq	$-1, 948(%rsp)
	movl	$0, 944(%rsp)
	leaq	3672(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$1024, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3720(%rsp)
	je	.LBB69_30
	movq	4128(%rsp), %rsi
	cmpq	$9, %rsi
	jae	.LBB69_43
	cmpq	$8, %rsi
	jne	.LBB69_30
	cmpq	$8, 4136(%rsp)
	jne	.LBB69_30
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movabsq	$27455186257, %rax
	movq	%rax, 552(%rsp)
	movq	$16, 600(%rsp)
	leaq	3672(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$1024, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3720(%rsp)
	setne	%al
	jmp	.LBB69_31
.LBB69_43:
	movl	$8, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB69_44:
	movl	$1, %edi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.LBB69_45:
	xorl	%edi, %edi
	xorl	%esi, %esi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.Lfunc_end69:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid, .Lfunc_end69-_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid
	.cfi_endproc

	.section	.text._RNCNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid0B5_,"ax",@progbits
	.prefalign	4, .Lfunc_end70, nop
	.type	_RNCNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid0B5_,@function
_RNCNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid0B5_:
.Lfunc_begin70:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	456(%rdi), %rsi
	cmpq	$9, %rsi
	jae	.LBB70_3
	cmpq	$2, %rsi
	jb	.LBB70_2
	movq	80(%rdi), %rax
	xorq	$4097, %rax
	orq	64(%rdi), %rax
	sete	%al
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB70_3:
	.cfi_def_cfa_offset 16
	movl	$8, %edx
	xorl	%edi, %edi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.LBB70_2:
	movl	$1, %edi
	callq	_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check
.Lfunc_end70:
	.size	_RNCNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid0B5_, .Lfunc_end70-_RNCNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests5valid0B5_
	.cfi_endproc

	.section	.text._RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests9malformed,"ax",@progbits
	.prefalign	4, .Lfunc_end71, nop
	.type	_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests9malformed,@function
_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests9malformed:
.Lfunc_begin71:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$984, %rsp
	.cfi_def_cfa_offset 5136
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movabsq	$4294967552, %r13
	movq	$0, 552(%rsp)
	movl	$0, 560(%rsp)
	movl	$0, 570(%rsp)
	movw	$0, 574(%rsp)
	movq	$0, 1024(%rsp)
	movq	$0, 1032(%rsp)
	movq	$0, 1040(%rsp)
	movq	$0, 1048(%rsp)
	movq	$0, 1056(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 1016(%rsp)
	movq	$0, 1008(%rsp)
	movq	$0, 1000(%rsp)
	movq	$0, 992(%rsp)
	movq	$0, 984(%rsp)
	movq	$0, 976(%rsp)
	movq	$0, 968(%rsp)
	movq	$0, 960(%rsp)
	movq	$0, 952(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 928(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 912(%rsp)
	movq	$0, 2055(%rsp)
	movb	$0, 2063(%rsp)
	movl	$16843334, 2051(%rsp)
	movl	$1179403647, 2048(%rsp)
	movabsq	$-6510615555426900571, %rax
	movq	%rax, 1128(%rsp)
	movq	%rax, 1120(%rsp)
	movq	%rax, 1112(%rsp)
	movq	%rax, 1104(%rsp)
	movabsq	$6510615555426900570, %rax
	movq	%rax, 104(%rsp)
	movq	%rax, 96(%rsp)
	movq	2056(%rsp), %rax
	movq	%rax, 520(%rsp)
	movq	2048(%rsp), %rax
	movq	%rax, 512(%rsp)
	movabsq	$4306960386, %rax
	movq	%rax, 528(%rsp)
	movq	%r13, 536(%rsp)
	movq	$64, 544(%rsp)
	movl	$3670080, 564(%rsp)
	movw	$2, 568(%rsp)
	movabsq	$21474836481, %rbp
	movq	%rbp, 576(%rsp)
	movq	$256, 584(%rsp)
	movq	%r13, 592(%rsp)
	movq	$-1, 600(%rsp)
	movq	$32, 608(%rsp)
	movq	$32, 616(%rsp)
	movq	$4096, 624(%rsp)
	movabsq	$25769803777, %rax
	movq	%rax, 632(%rsp)
	movq	$384, 640(%rsp)
	leaq	8320(%r13), %rax
	movq	%rax, 648(%rsp)
	movq	$-1, 656(%rsp)
	movq	$16, 664(%rsp)
	movq	$4097, 672(%rsp)
	movq	$4096, 680(%rsp)
	leaq	688(%rsp), %rdi
	leaq	1024(%rsp), %rbx
	movq	memcpy@GOTPCREL(%rip), %r12
	movl	$112, %edx
	movq	%rbx, %rsi
	callq	*%r12
	leaq	800(%rsp), %rdi
	movq	%rsp, %rsi
	movl	$112, %edx
	callq	*%r12
	xorl	%r14d, %r14d
	leaq	512(%rsp), %r15
	.p2align	4
.LBB71_1:
	movq	%rbx, %rdi
	movq	%r15, %rsi
	movq	%r14, %rdx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1072(%rsp)
	jne	.LBB71_11
	incq	%r14
	cmpq	$400, %r14
	jne	.LBB71_1
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$0, 1024(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$1, 1028(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$2, 1029(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$0, 1030(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$3, 1031(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$1, 1032(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$1, 1033(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$1, 1039(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$3, 1040(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$62, 1042(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$63, 1076(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$55, 1078(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$0, 1080(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$17, 1080(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$-1, 1080(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$0, 1044(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$1, 1072(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$2, 1088(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$3, 1088(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$6, 1088(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$7, 1088(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$-1, 1088(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$0, 1092(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$1, 1092(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$2, 1092(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$3, 1092(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$7, 1092(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	leaq	1024(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$-2147483643, 1092(%rsp)
	movq	%rsp, %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	je	.LBB71_35
.LBB71_11:
	xorl	%eax, %eax
.LBB71_12:
	addq	$5080, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB71_35:
	.cfi_def_cfa_offset 5136
	movq	$0, 2048(%rsp)
	movq	$21, 2056(%rsp)
	movq	$32, 2064(%rsp)
	movq	$0, 2072(%rsp)
	movq	$32, 2080(%rsp)
	movq	$63, 2088(%rsp)
	movq	$32, 2096(%rsp)
	movq	$-1, 2104(%rsp)
	movq	$72, 2112(%rsp)
	movq	$-1, 2120(%rsp)
	movq	$72, 2128(%rsp)
	movq	$257, 2136(%rsp)
	movq	$96, 2144(%rsp)
	movq	$33, 2152(%rsp)
	movq	$96, 2160(%rsp)
	movq	$-1, 2168(%rsp)
	movq	$104, 2176(%rsp)
	movq	$0, 2184(%rsp)
	movq	$104, 2192(%rsp)
	movq	$-1, 2200(%rsp)
	movq	$80, 2208(%rsp)
	movq	$256, 2216(%rsp)
	movq	$80, 2224(%rsp)
	leaq	1048576(%r13), %rax
	movq	%rax, 2232(%rsp)
	movq	$80, 2240(%rsp)
	movq	$-256, 2248(%rsp)
	movq	$112, 2256(%rsp)
	movq	$3, 2264(%rsp)
	movq	$112, 2272(%rsp)
	movabsq	$8589934592, %rax
	movq	%rax, 2280(%rsp)
	movq	$136, 2288(%rsp)
	leaq	128(%r13), %rax
	movq	%rax, 2296(%rsp)
	movq	$152, 2304(%rsp)
	movq	$-1, 2312(%rsp)
	movq	$160, 2320(%rsp)
	movq	$-1, 2328(%rsp)
	movq	$24, 2336(%rsp)
	leaq	1(%r13), %rax
	movq	%rax, 2344(%rsp)
	movq	$24, 2352(%rsp)
	leaq	32(%r13), %rax
	movq	%rax, 2360(%rsp)
	movq	$24, 2368(%rsp)
	leaq	8320(%r13), %rax
	movq	%rax, 2376(%rsp)
	movq	$24, 2384(%rsp)
	movq	$-4, 2392(%rsp)
	xorl	%r15d, %r15d
.LBB71_36:
	movq	2064(%rsp,%r15), %r14
	movq	2072(%rsp,%r15), %rbx
	movl	$512, %edx
	leaq	1024(%rsp), %rdi
	leaq	512(%rsp), %rsi
	callq	*%r12
	cmpq	$505, %r14
	jae	.LBB71_50
	movq	%rbx, 1024(%rsp,%r14)
	movl	$512, %edx
	movq	%rsp, %rdi
	leaq	1024(%rsp), %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	addq	$16, %r15
	cmpq	$336, %r15
	jne	.LBB71_36
	leaq	3544(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	$-1, 3640(%rsp)
	movq	$-1, 3648(%rsp)
	leaq	1024(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1072(%rsp)
	jne	.LBB71_11
	leaq	4056(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	$31, 4152(%rsp)
	leaq	28(%r13), %rax
	movq	%rax, 4080(%rsp)
	leaq	1024(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1072(%rsp)
	jne	.LBB71_11
	leaq	2560(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	leaq	576(%rsp), %rdx
	movq	(%rdx), %rax
	movq	8(%rdx), %rcx
	movq	%rax, 2680(%rsp)
	movq	%rcx, 2688(%rsp)
	movq	16(%rdx), %rax
	movq	%rax, 2696(%rsp)
	movq	24(%rdx), %rax
	movq	%rax, 2704(%rsp)
	movq	32(%rdx), %rax
	movq	%rax, 2712(%rsp)
	movq	40(%rdx), %rax
	movq	%rax, 2720(%rsp)
	movq	48(%rdx), %rax
	movq	%rax, 2728(%rsp)
	movq	56(%rdx), %rax
	movq	64(%rdx), %rcx
	movq	%rax, 2624(%rsp)
	movq	%rcx, 2632(%rsp)
	movq	72(%rdx), %rax
	movq	%rax, 2640(%rsp)
	movq	80(%rdx), %rax
	movq	%rax, 2648(%rsp)
	movq	88(%rdx), %rax
	movq	%rax, 2656(%rsp)
	movq	96(%rdx), %rax
	movq	%rax, 2664(%rsp)
	movq	104(%rdx), %rax
	movq	%rax, 2672(%rsp)
	leaq	1024(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1072(%rsp)
	jne	.LBB71_11
	leaq	4568(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$0, 4632(%rsp)
	movl	$0, 4688(%rsp)
	leaq	1024(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1072(%rsp)
	jne	.LBB71_11
	leaq	2048(%rsp), %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	$64, 2152(%rsp)
	leaq	32(%r13), %rax
	movq	%rax, 2072(%rsp)
	leaq	1024(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 1072(%rsp)
	jne	.LBB71_11
	leaq	1592(%rsp), %rdi
	movl	$456, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	568(%rsp), %rax
	movq	%rax, 1080(%rsp)
	movq	512(%rsp), %rax
	movq	520(%rsp), %rcx
	movq	%rax, 1024(%rsp)
	movq	%rcx, 1032(%rsp)
	movq	528(%rsp), %rax
	movq	%rax, 1040(%rsp)
	movq	544(%rsp), %rax
	movq	%rax, 1056(%rsp)
	movq	552(%rsp), %rax
	movq	%rax, 1064(%rsp)
	movq	560(%rsp), %rax
	movq	%rax, 1072(%rsp)
	movw	$9, 1080(%rsp)
	leaq	704(%r13), %rax
	movq	%rax, 1048(%rsp)
	movq	%rbp, 1088(%rsp)
	movq	$960, 1096(%rsp)
	movq	%rax, 1104(%rsp)
	movq	$-1, 1112(%rsp)
	movq	$16, 1120(%rsp)
	movq	$16, 1128(%rsp)
	movq	$4096, 1136(%rsp)
	movabsq	$17179869185, %rax
	movq	%rax, 1144(%rsp)
	movq	$0, 1152(%rsp)
	leaq	7936(%r13), %rcx
	movq	%rcx, 1160(%rsp)
	movq	$-1, 1168(%rsp)
	movq	$0, 1176(%rsp)
	movq	$4096, 1184(%rsp)
	movq	$4096, 1192(%rsp)
	movq	%rax, 1200(%rsp)
	movq	$0, 1208(%rsp)
	leaq	16128(%r13), %rcx
	movq	%rcx, 1216(%rsp)
	movq	$-1, 1224(%rsp)
	movq	$0, 1232(%rsp)
	movq	$4096, 1240(%rsp)
	movq	$4096, 1248(%rsp)
	movq	%rax, 1256(%rsp)
	movq	$0, 1264(%rsp)
	leaq	24320(%r13), %rcx
	movq	%rcx, 1272(%rsp)
	movq	$-1, 1280(%rsp)
	movq	$0, 1288(%rsp)
	movq	$4096, 1296(%rsp)
	movq	$4096, 1304(%rsp)
	movq	%rax, 1312(%rsp)
	movq	$0, 1320(%rsp)
	leaq	32512(%r13), %rcx
	movq	%rcx, 1328(%rsp)
	movq	$-1, 1336(%rsp)
	movq	$0, 1344(%rsp)
	movq	$4096, 1352(%rsp)
	movq	$4096, 1360(%rsp)
	movq	%rax, 1368(%rsp)
	movq	$0, 1376(%rsp)
	leaq	40704(%r13), %rcx
	movq	%rcx, 1384(%rsp)
	movq	$-1, 1392(%rsp)
	movq	$0, 1400(%rsp)
	movq	$4096, 1408(%rsp)
	movq	$4096, 1416(%rsp)
	movq	%rax, 1424(%rsp)
	movq	$0, 1432(%rsp)
	leaq	48896(%r13), %rcx
	movq	%rcx, 1440(%rsp)
	movq	$-1, 1448(%rsp)
	movq	$0, 1456(%rsp)
	movq	$4096, 1464(%rsp)
	movq	$4096, 1472(%rsp)
	movq	%rax, 1480(%rsp)
	movq	$0, 1488(%rsp)
	leaq	57088(%r13), %rcx
	movq	%rcx, 1496(%rsp)
	movq	$-1, 1504(%rsp)
	movq	$0, 1512(%rsp)
	movq	$4096, 1520(%rsp)
	movq	$4096, 1528(%rsp)
	movq	%rax, 1536(%rsp)
	movq	$0, 1544(%rsp)
	addq	$65280, %r13
	movq	%r13, 1552(%rsp)
	movq	$-1, 1560(%rsp)
	movq	$0, 1568(%rsp)
	movq	$4096, 1576(%rsp)
	movq	$4096, 1584(%rsp)
	movq	%rsp, %rdi
	leaq	1024(%rsp), %rsi
	movl	$1024, %edx
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 48(%rsp)
	jne	.LBB71_11
	movq	%rsp, %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$3, 56(%rsp)
	movabsq	$31750153553, %rax
	movq	%rax, 176(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$16, 224(%rsp)
	leaq	3072(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3120(%rsp)
	jne	.LBB71_11
	movq	%rsp, %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$3, 56(%rsp)
	movabsq	$27455186257, %r14
	movq	%r14, 176(%rsp)
	movq	$1, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$16, 224(%rsp)
	leaq	3072(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3120(%rsp)
	jne	.LBB71_11
	movq	%rsp, %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$3, 56(%rsp)
	movq	%r14, 176(%rsp)
	movq	$0, 208(%rsp)
	movq	$1, 216(%rsp)
	movq	$16, 224(%rsp)
	leaq	3072(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3120(%rsp)
	jne	.LBB71_11
	leaq	208(%rsp), %r15
	movq	%rsp, %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$3, 56(%rsp)
	movq	%r14, 176(%rsp)
	movq	$0, (%r15)
	movq	$0, 8(%r15)
	movq	$3, 224(%rsp)
	leaq	3072(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3120(%rsp)
	jne	.LBB71_11
	movq	%rsp, %rbx
	leaq	512(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movw	$4, 56(%rsp)
	movq	%r14, 176(%rsp)
	movq	%r14, 232(%rsp)
	leaq	3072(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCsjFdXuXHMTfk_9hm_kernel3elfNtB5_5Image5parse
	cmpb	$-1, 3120(%rsp)
	sete	%al
	jmp	.LBB71_12
.LBB71_50:
	leaq	8(%r14), %rsi
	movl	$512, %edx
	movq	%r14, %rdi
	callq	_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail
.Lfunc_end71:
	.size	_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests9malformed, .Lfunc_end71-_RNvNtCsjFdXuXHMTfk_9hm_kernel9elf_tests9malformed
	.cfi_endproc

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.0,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.0,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.0:
	.ascii	"Hematite bootstrap monitor (local working name)\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.0, 48

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.1,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.1,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.1:
	.ascii	"Commands: help, status, test, apps, run <path>. This is not a Linux shell.\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.1, 75

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.2,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.2,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.2:
	.ascii	"Rejected: use at most 64 printable ASCII bytes.\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.2, 48

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.3,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.3,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.3:
	.ascii	"help   - show commands\nstatus - inspect boot protections\ntest   - run bootstrap tests\napps   - list native programs\nrun <path> - launch a native program\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.3, 153

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.4,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.4,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.4:
	.ascii	"Bootstrap tests FAILED.\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.4, 24

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.5,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.5,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.5:
	.ascii	"Bootstrap tests passed.\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.5, 24

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.6,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.6,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.6:
	.ascii	"Unknown command; type help.\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.6, 28

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.7,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.7:
	.ascii	"write protection"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.7, 16

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.8,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.8,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.8:
	.ascii	"NX"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.8, 2

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.9,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9:
	.ascii	"user execution protection"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.9, 25

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.10,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.10,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.10:
	.ascii	"user access protection"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.10, 22

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.11,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.11,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.11:
	.ascii	"W^X mappings"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.11, 12

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.12,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.12,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.12:
	.ascii	"stack guard"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.12, 11

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.13,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.13,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.13:
	.ascii	"null guard"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.13, 10

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.14,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.14,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.14:
	.ascii	"No storage or networking.\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.14, 26

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.15,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.15,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.15:
	.ascii	": FAILED\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.15, 9

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.16,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.16,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.16:
	.ascii	"write_protect"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.16, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.17,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.17,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.17:
	.ascii	"nx"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.17, 2

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.18,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.18,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.18:
	.ascii	"user_execute_protect"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.18, 20

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.19,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.19,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.19:
	.ascii	"user_access_protect"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.19, 19

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.20,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.20,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.20:
	.ascii	"wx"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.20, 2

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.21,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.21,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.21:
	.ascii	"stack_guard"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.21, 11

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.22,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.22,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.22:
	.ascii	"null_guard"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.22, 10

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.23,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.23,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.23:
	.ascii	"checked_range"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.23, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.24,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.24,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.24:
	.ascii	"monitor_bounds"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.24, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.25,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.25,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.25:
	.ascii	"cap_authority"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.25, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.26,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.26,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.26:
	.ascii	"cap_limits"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.26, 10

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.27,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.27,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.27:
	.ascii	"cap_lifetime"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.27, 12

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.28,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.28,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.28:
	.ascii	"cap_generation"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.28, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.29,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.29,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.29:
	.ascii	"boot_memory_valid"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.29, 17

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.30,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.30,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.30:
	.ascii	"boot_memory_malformed"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.30, 21

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.31,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.31,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.31:
	.ascii	"cpu_topology_valid"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.31, 18

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.32,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.32,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.32:
	.ascii	"cpu_topology_malformed"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.32, 22

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.33,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.33,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.33:
	.ascii	"cpu_topology_live"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.33, 17

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.34,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.34,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.34:
	.ascii	"elf_valid"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.34, 9

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.35,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.35,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.35:
	.ascii	"elf_malformed"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.35, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.36,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.36,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.36:
	.ascii	"frame_ranges"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.36, 12

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.37,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.37:
	.ascii	"frame_boundaries"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.37, 16

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.38,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.38,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.38:
	.ascii	"frame_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.38, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.39,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.39,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.39:
	.ascii	"heap_blocks"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.39, 11

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.40,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.40,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.40:
	.ascii	"heap_values"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.40, 11

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.41,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.41,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.41:
	.ascii	"event_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.41, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.42,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.42,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.42:
	.ascii	"mutex_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.42, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.43,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.43,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.43:
	.ascii	"mutex_lifetime"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.43, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.44,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.44,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.44:
	.ascii	"mutex_workers"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.44, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.45,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.45,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.45:
	.ascii	"thread_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.45, 15

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.46,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.46,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.46:
	.ascii	"thread_limits"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.46, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.47,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.47,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.47:
	.ascii	"thread_core"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.47, 11

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.48,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.48,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.48:
	.ascii	"timer_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.48, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.49,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.49,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.49:
	.ascii	"fault_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.49, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.50,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.50:
	.ascii	"mapping_contract"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.50, 16

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.51,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.51,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.51:
	.ascii	"mapping_limits"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.51, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.52,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.52:
	.ascii	"mapping_hardware"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.52, 16

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.53,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.53,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.53:
	.ascii	"cpu_local_state"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.53, 15

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.54,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54:
	.ascii	"gic_ownership"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.54, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.55,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.55:
	.ascii	"secondary_memory"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.55, 16

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.56,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.56,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.56:
	.ascii	"cap_orderings"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.56, 13

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.57,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.57:
	.ascii	"HMTEST BEGIN 41\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.57, 16

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.58,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.58,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.58:
	.ascii	"HMTEST END 41\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.58, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.62,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.62,"a",@progbits
	.p2align	3, 0x0
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.62:
	.asciz	"\001\000\000\000\000\000\000\000\035\000\000\000\000\000\000\000\003\000\000\000\000\000\000"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.62, 24

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.63,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.63,"a",@progbits
	.p2align	3, 0x0
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.63:
	.asciz	"\001\000\000\000\000\000\000\000\035\000\000\000\000\000\000\000)\000\000\000\000\000\000"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.63, 24

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.64,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.64,"a",@progbits
	.p2align	3, 0x0
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.64:
	.asciz	"5\000\000\000\000\000\000\000\035\000\000\000\000\000\000\000)\000\000\000\000\000\000"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.64, 24

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.65,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.65,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.65:
	.ascii	"Native launching is unsupported on this platform.\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.65, 50

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.66,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.66,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.66:
	.ascii	"Usage: run <archive-path>.\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.66, 27

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.68,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.68,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.68:
	.ascii	"unsupported\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.68, 12

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.70,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.70,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.70:
	.ascii	"Last prepared generation: "
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.70, 26

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.71,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.71,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.71:
	.ascii	"\nFree frames: "
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.71, 14

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.72,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.72,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.72:
	.ascii	"CAPMODEL failed ordering:"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.72, 25

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.73,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.73,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.73:
	.ascii	"revoke"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.73, 6

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.74,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.74,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.74:
	.ascii	"cancel"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.74, 6

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.75,@object
	.section	.rodata.cst8,"aM",@progbits,8
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.75:
	.ascii	"complete"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.75, 8

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.76,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.76,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.76:
	.ascii	"release"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.76, 7

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.77,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.77,"a",@progbits
	.p2align	3, 0x0
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.77:
	.quad	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.73
	.asciz	"\006\000\000\000\000\000\000"
	.quad	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.74
	.asciz	"\006\000\000\000\000\000\000"
	.quad	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.75
	.asciz	"\b\000\000\000\000\000\000"
	.quad	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.76
	.asciz	"\007\000\000\000\000\000\000"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.77, 64

	.type	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.80,@object
	.section	.rodata..Lanon.f00a327e9c5915a84331ee2e2076b7b8.80,"a",@progbits
.Lanon.f00a327e9c5915a84331ee2e2076b7b8.80:
	.ascii	"hematite: x86_64 Rust kernel entered via PVH\n"
	.size	.Lanon.f00a327e9c5915a84331ee2e2076b7b8.80, 45

	.type	.Lanon.5e724348160a06631d781e4ccdca078c.197,@object
	.section	.rodata..Lanon.5e724348160a06631d781e4ccdca078c.197,"a",@progbits
.Lanon.5e724348160a06631d781e4ccdca078c.197:
	.asciz	"\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\002\003\003\003\003\003\003\003\003\003\003\003\003\003\003\003\003\004\004\004\004\004\000\000\000\000\000\000\000\000\000\000"
	.size	.Lanon.5e724348160a06631d781e4ccdca078c.197, 256

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.0,@object
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.0:
	.zero	16
	.byte	2
	.zero	7
	.asciz	"\001\000\000"
	.zero	4
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.0, 32

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.1,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.1,"a",@progbits
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.1:
	.zero	25
	.byte	2
	.zero	6
	.asciz	"\001\000\000"
	.zero	4
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.1, 40

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.2,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.2,"a",@progbits
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.2:
	.zero	24
	.byte	2
	.zero	7
	.asciz	"\001\000\000"
	.zero	4
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.2, 40

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.20,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20:
	.ascii	"#address-cells"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.20, 14

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.21,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21:
	.ascii	"#size-cells"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.21, 11

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.22,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.22,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.22:
	.asciz	"#address-cells\000#size-cells\000device_type\000reg\000status\000ranges\000size\000alignment\000alloc-ranges\000no-map\000reusable\000compatible"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.22, 112

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.23,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.23,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.23:
	.ascii	"memory@40000000"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.23, 15

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.24,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24:
	.ascii	"device_type"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.24, 11

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.25,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.25:
	.asciz	"memory"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.25, 7

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.26,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26:
	.ascii	"reg"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.26, 3

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.28,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.28,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.28:
	.ascii	"cpu@0"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.28, 5

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.29,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.29,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.29:
	.ascii	"cpu@1"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.29, 5

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.30,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.30,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.30:
	.ascii	"cpu@2"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.30, 5

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.31,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.31:
	.asciz	"cpu"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.31, 4

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.32,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.32,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.32:
	.ascii	"enable-method"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.32, 13

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.33,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.33:
	.asciz	"psci"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.33, 5

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.35,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.35:
	.ascii	"cpus"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.35, 4

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.37,@object
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.37:
	.ascii	"psci"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.37, 4

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.38,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.38,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.38:
	.ascii	"compatible"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.38, 10

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.39,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.39,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.39:
	.asciz	"arm,psci-1.0\000arm,psci-0.2\000arm,psci"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.39, 35

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.40,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.40,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.40:
	.ascii	"method"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.40, 6

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.41,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.41:
	.asciz	"hvc"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.41, 4

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.42,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.42,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.42:
	.ascii	"cpu_on"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.42, 6

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.43,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.43,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.43:
	.ascii	"cpu_off"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.43, 7

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.44,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.44,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.44:
	.ascii	"cpu_suspend"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.44, 11

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.45,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.45,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.45:
	.ascii	"migrate"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.45, 7

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.46,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.46,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.46:
	.asciz	"#address-cells\000#size-cells\000device_type\000reg\000status\000enable-method\000compatible\000method\000cpu_on\000cpu_off\000cpu_suspend\000migrate"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.46, 117

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.47,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.47,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.47:
	.ascii	"cpu"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.47, 3

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.48,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48:
	.ascii	"status"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.48, 6

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.51,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.51,"a",@progbits
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.51:
	.quad	1
	.zero	41
	.zero	7
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.51, 56

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.54,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.54:
	.asciz	"okay"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.54, 5

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.55,@object
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.55:
	.asciz	"ok"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.55, 3

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.62,@object
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.62:
	.asciz	"\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.62, 16

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.63,@object
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.63:
	.asciz	"\000\000\000\000\000\000\000\000\002\000\000\000\000\000\000"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.63, 16

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.65,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.65,"a",@progbits
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.65:
	.zero	8
	.zero	8
	.asciz	"\000\004"
	.zero	5
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.65, 24

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.66,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.66,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.66:
	.ascii	"reserved-memory"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.66, 15

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.67,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.67,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.67:
	.ascii	"memory@"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.67, 7

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.68,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.68,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.68:
	.ascii	"arm,psci-0.2"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.68, 12

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.69,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.69:
	.ascii	"cpu@"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.69, 4

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.70,"a",@progbits
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70:
	.zero	8
	.zero	8
	.zero	4
	.zero	4
	.zero	4
	.zero	4
	.zero	144
	.zero	8
	.ascii	"\000\000\000\000\000\000\004"
	.zero	1
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.70, 192

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.71,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.71,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.71:
	.ascii	"cpus@"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.71, 5

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.72,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.72,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.72:
	.ascii	"psci@"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.72, 5

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.74,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.74:
	.asciz	"disabled"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.74, 9

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.75,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.75,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.75:
	.ascii	"second-root"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.75, 11

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.76,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.76,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.76:
	.ascii	"bus"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.76, 3

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.77,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.77,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.77:
	.zero	15
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.77, 15

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.78,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.78:
	.ascii	"okay"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.78, 4

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.79,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.79,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.79:
	.ascii	"child"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.79, 5

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.80,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80:
	.byte	97
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.80, 1

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.83,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.83,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.83:
	.ascii	"ranges"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.83, 6

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.84,@object
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.84:
	.zero	16
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.84, 16

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.85,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.85,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.85:
	.ascii	"buffer"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.85, 6

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.86,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.86:
	.ascii	"size"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.86, 4

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.87,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.87,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.87:
	.ascii	"alignment"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.87, 9

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.88,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.88,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.88:
	.ascii	"alloc-ranges"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.88, 12

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.89,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.89,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.89:
	.ascii	"no-map"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.89, 6

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.90,@object
	.section	.rodata.cst8,"aM",@progbits,8
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.90:
	.ascii	"reusable"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.90, 8

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.93,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.93,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.93:
	.ascii	"\377\003\t"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.93, 3

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.94,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.94:
	.asciz	"test,bus"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.94, 9

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.95,@object
	.section	.rodata.cst8,"aM",@progbits,8
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.95:
	.ascii	"device@0"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.95, 8

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.96,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.96,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.96:
	.ascii	"memory@50000000"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.96, 15

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.97,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.97,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.97:
	.ascii	"buffer@40002000"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.97, 15

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.98,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.98:
	.ascii	"outside@90000000"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.98, 16

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.103,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.103,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.103:
	.ascii	"cpu-map"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.103, 7

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.104,@object
	.section	.rodata.cst8,"aM",@progbits,8
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.104:
	.ascii	"cluster0"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.104, 8

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.105,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.105,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.105:
	.ascii	"core0"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.105, 5

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.106,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.106:
	.asciz	"arm,psci-0.2"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.106, 13

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.107,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.107,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.107:
	.ascii	"unrelated"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.107, 9

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.108,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.108:
	.asciz	"test,device"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.108, 12

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.110,@object
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.110:
	.asciz	"device"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.110, 7

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.111,@object
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.111:
	.zero	8
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.111, 8

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.112,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.112:
	.asciz	"spin-table"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.112, 11

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.113,@object
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.113:
	.asciz	"arm,psci"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.113, 9

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.114,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.114,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.114:
	.asciz	"arm,psci-0.2\000"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.114, 14

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.115,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.115:
	.asciz	"vendor,unknown"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.115, 15

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.116,@object
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.116:
	.asciz	"smc"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.116, 4

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.117,@object
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.117:
	.asciz	"arm,psci-1.0"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.117, 13

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.118,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.118,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.118:
	.ascii	"legacy-firmware"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.118, 15

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.119,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.119,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.119:
	.ascii	"another-root"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.119, 12

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.120,@object
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.120:
	.asciz	"\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.120, 16

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.121,@object
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.121:
	.asciz	"\001\000\000\000\000\000\000"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.121, 8

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.122,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.122,"a",@progbits
	.p2align	3, 0x0
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.122:
	.asciz	"\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\002\000\000\000\000\000\000"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.122, 24

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.127,@object
	.section	.rodata.cst32,"aM",@progbits,32
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.127:
	.zero	32,165
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.127, 32

	.type	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.130,@object
	.section	.rodata..Lanon.2518d136abfec7ebc9d3a69d0b38d406.130,"a",@progbits
.Lanon.2518d136abfec7ebc9d3a69d0b38d406.130:
	.ascii	"\177ELF\002\001\001"
	.size	.Lanon.2518d136abfec7ebc9d3a69d0b38d406.130, 7

	.section	.debug_abbrev,"",@progbits
	.byte	1
	.byte	17
	.byte	1
	.byte	37
	.byte	14
	.byte	19
	.byte	5
	.byte	3
	.byte	14
	.byte	16
	.byte	23
	.byte	27
	.byte	14
	.byte	17
	.byte	1
	.byte	85
	.byte	23
	.byte	0
	.byte	0
	.byte	2
	.byte	57
	.byte	1
	.byte	3
	.byte	14
	.byte	0
	.byte	0
	.byte	3
	.byte	46
	.byte	0
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	54
	.byte	11
	.byte	63
	.byte	25
	.ascii	"\207\001"
	.byte	25
	.byte	0
	.byte	0
	.byte	4
	.byte	46
	.byte	0
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	54
	.byte	11
	.byte	63
	.byte	25
	.ascii	"\207\001"
	.byte	25
	.byte	0
	.byte	0
	.byte	5
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	6
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	7
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	63
	.byte	25
	.byte	0
	.byte	0
	.byte	8
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	9
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	10
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	54
	.byte	11
	.byte	63
	.byte	25
	.byte	0
	.byte	0
	.byte	11
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	12
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	13
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	14
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	15
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.ascii	"\207\001"
	.byte	25
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	16
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.ascii	"\207\001"
	.byte	25
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	17
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	54
	.byte	11
	.byte	63
	.byte	25
	.ascii	"\207\001"
	.byte	25
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.long	.Ldebug_info_end0-.Ldebug_info_start0
.Ldebug_info_start0:
	.short	4
	.long	.debug_abbrev
	.byte	8
	.byte	1
	.long	.Linfo_string0
	.short	28
	.long	.Linfo_string1
	.long	.Lline_table_start0
	.long	.Linfo_string2
	.quad	0
	.long	.Ldebug_ranges3
	.byte	2
	.long	.Linfo_string3
	.byte	2
	.long	.Linfo_string4
	.byte	3
	.quad	.Lfunc_begin11
	.long	.Lfunc_end11-.Lfunc_begin11
	.byte	1
	.byte	87
	.long	.Linfo_string39
	.long	.Linfo_string40
	.byte	1
	.byte	60
	.byte	3


	.byte	4
	.quad	.Lfunc_begin14
	.long	.Lfunc_end14-.Lfunc_begin14
	.byte	1
	.byte	86
	.long	.Linfo_string45
	.long	.Linfo_string46
	.byte	1
	.short	266
	.byte	3


	.byte	0
	.byte	2
	.long	.Linfo_string5
	.byte	2
	.long	.Linfo_string6
	.byte	5
	.long	.Linfo_string7
	.long	.Linfo_string8
	.byte	3
	.byte	126
	.byte	1
	.byte	6
	.long	.Linfo_string15
	.long	.Linfo_string16
	.byte	3
	.short	278
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string17
	.byte	7
	.quad	.Lfunc_begin12
	.long	.Lfunc_end12-.Lfunc_begin12
	.byte	1
	.byte	87
	.long	.Linfo_string41
	.long	.Linfo_string42
	.byte	2
	.byte	89

	.byte	8
	.long	116
	.long	.Ldebug_ranges0
	.byte	2
	.byte	91
	.byte	11
	.byte	9
	.long	258
	.quad	.Ltmp15
	.long	.Ltmp16-.Ltmp15
	.byte	3
	.byte	222
	.byte	45
	.byte	9
	.long	271
	.quad	.Ltmp16
	.long	.Ltmp17-.Ltmp16
	.byte	3
	.byte	222
	.byte	65
	.byte	9
	.long	128
	.quad	.Ltmp24
	.long	.Ltmp26-.Ltmp24
	.byte	3
	.byte	166
	.byte	21
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string9
	.byte	2
	.long	.Linfo_string10
	.byte	6
	.long	.Linfo_string11
	.long	.Linfo_string12
	.byte	4
	.short	2688
	.byte	1
	.byte	6
	.long	.Linfo_string13
	.long	.Linfo_string14
	.byte	4
	.short	3872
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string18
	.byte	2
	.long	.Linfo_string19
	.byte	3
	.quad	.Lfunc_begin13
	.long	.Lfunc_end13-.Lfunc_begin13
	.byte	1
	.byte	86
	.long	.Linfo_string43
	.long	.Linfo_string44
	.byte	5
	.byte	39
	.byte	3


	.byte	0
	.byte	2
	.long	.Linfo_string26
	.byte	2
	.long	.Linfo_string27
	.byte	6
	.long	.Linfo_string28
	.long	.Linfo_string29
	.byte	10
	.short	2623
	.byte	1
	.byte	0
	.byte	5
	.long	.Linfo_string30
	.long	.Linfo_string31
	.byte	7
	.byte	18
	.byte	1
	.byte	5
	.long	.Linfo_string32
	.long	.Linfo_string33
	.byte	7
	.byte	37
	.byte	1
	.byte	10
	.quad	.Lfunc_begin15
	.long	.Lfunc_end15-.Lfunc_begin15
	.byte	1
	.byte	87
	.long	.Linfo_string47
	.long	.Linfo_string27
	.byte	7
	.byte	53
	.byte	3

	.byte	11
	.long	333
	.long	.Ldebug_ranges1
	.byte	10
	.short	2636
	.byte	9
	.byte	12
	.long	669
	.quad	.Lfunc_begin15
	.long	.Ltmp37-.Lfunc_begin15
	.byte	7
	.byte	71
	.byte	34
	.byte	13
	.long	646
	.quad	.Lfunc_begin15
	.long	.Ltmp37-.Lfunc_begin15
	.byte	9
	.short	1286
	.byte	28
	.byte	0
	.byte	9
	.long	347
	.quad	.Ltmp40
	.long	.Ltmp41-.Ltmp40
	.byte	7
	.byte	91
	.byte	30
	.byte	9
	.long	347
	.quad	.Ltmp42
	.long	.Ltmp43-.Ltmp42
	.byte	7
	.byte	92
	.byte	30
	.byte	14
	.long	359
	.long	.Ldebug_ranges2
	.byte	7
	.byte	106
	.byte	30
	.byte	9
	.long	359
	.quad	.Ltmp46
	.long	.Ltmp47-.Ltmp46
	.byte	7
	.byte	76
	.byte	38
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string34
	.byte	2
	.long	.Linfo_string35
	.byte	2
	.long	.Linfo_string36
	.byte	15
	.long	.Linfo_string37
	.long	.Linfo_string29
	.byte	10
	.short	2623

	.byte	1
	.byte	0
	.byte	16
	.long	.Linfo_string38
	.long	.Linfo_string36
	.byte	6
	.byte	166

	.byte	1
	.byte	0
	.byte	17
	.quad	.Lfunc_begin16
	.long	.Lfunc_end16-.Lfunc_begin16
	.byte	1
	.byte	86
	.long	.Linfo_string48
	.long	.Linfo_string35
	.byte	11
	.short	5588
	.byte	3


	.byte	12
	.long	556
	.quad	.Ltmp56
	.long	.Ltmp57-.Ltmp56
	.byte	6
	.byte	177
	.byte	9
	.byte	13
	.long	542
	.quad	.Ltmp56
	.long	.Ltmp57-.Ltmp56
	.byte	10
	.short	2636
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string20
	.byte	6
	.long	.Linfo_string21
	.long	.Linfo_string22
	.byte	8
	.short	2288
	.byte	1
	.byte	2
	.long	.Linfo_string23
	.byte	2
	.long	.Linfo_string24
	.byte	6
	.long	.Linfo_string25
	.long	.Linfo_string22
	.byte	9
	.short	1277
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
.Ldebug_info_end0:
	.section	.text.unlikely._RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt,"ax",@progbits
.Lsec_end0:
	.section	.text._RNvNtNtCs1R9DcZHJAgT_4core3str8converts9from_utf8,"ax",@progbits
.Lsec_end1:
	.section	.text.unlikely._RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail,"ax",@progbits
.Lsec_end2:
	.section	.text.unlikely._RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check,"ax",@progbits
.Lsec_end3:
	.section	.text._RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned,"ax",@progbits
.Lsec_end4:
	.section	.text.unlikely._RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail,"ax",@progbits
.Lsec_end5:
	.section	.debug_aranges,"",@progbits
	.long	124
	.short	2
	.long	.Lcu_begin0
	.byte	8
	.byte	0
	.zero	4,255
	.quad	.Lfunc_begin11
	.quad	.Lsec_end0-.Lfunc_begin11
	.quad	.Lfunc_begin12
	.quad	.Lsec_end1-.Lfunc_begin12
	.quad	.Lfunc_begin13
	.quad	.Lsec_end2-.Lfunc_begin13
	.quad	.Lfunc_begin14
	.quad	.Lsec_end3-.Lfunc_begin14
	.quad	.Lfunc_begin15
	.quad	.Lsec_end4-.Lfunc_begin15
	.quad	.Lfunc_begin16
	.quad	.Lsec_end5-.Lfunc_begin16
	.quad	0
	.quad	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.quad	.Ltmp9
	.quad	.Ltmp27
	.quad	.Ltmp28
	.quad	.Ltmp29
	.quad	0
	.quad	0
.Ldebug_ranges1:
	.quad	.Lfunc_begin15
	.quad	.Ltmp50
	.quad	.Ltmp51
	.quad	.Ltmp52
	.quad	.Ltmp53
	.quad	.Ltmp54
	.quad	0
	.quad	0
.Ldebug_ranges2:
	.quad	.Ltmp49
	.quad	.Ltmp50
	.quad	.Ltmp51
	.quad	.Ltmp52
	.quad	0
	.quad	0
.Ldebug_ranges3:
	.quad	.Lfunc_begin11
	.quad	.Lfunc_end11
	.quad	.Lfunc_begin12
	.quad	.Lfunc_end12
	.quad	.Lfunc_begin13
	.quad	.Lfunc_end13
	.quad	.Lfunc_begin14
	.quad	.Lfunc_end14
	.quad	.Lfunc_begin15
	.quad	.Lfunc_end15
	.quad	.Lfunc_begin16
	.quad	.Lfunc_end16
	.quad	0
	.quad	0
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"clang LLVM (rustc version 1.99.0 (b940084d7 2026-09-28))"
.Linfo_string1:
	.asciz	"/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4/library/core/src/lib.rs/@/core.15a23645e69e4fd1-cgu.0"
.Linfo_string2:
	.asciz	"/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4"
.Linfo_string3:
	.asciz	"core"
.Linfo_string4:
	.asciz	"panicking"
.Linfo_string5:
	.asciz	"str"
.Linfo_string6:
	.asciz	"validations"
.Linfo_string7:
	.asciz	"_RNvNtNtCs1R9DcZHJAgT_4core3str11validations19run_utf8_validation"
.Linfo_string8:
	.asciz	"run_utf8_validation"
.Linfo_string9:
	.asciz	"num"
.Linfo_string10:
	.asciz	"{impl#11}"
.Linfo_string11:
	.asciz	"_RNvMs9_NtCs1R9DcZHJAgT_4core3numj12wrapping_sub"
.Linfo_string12:
	.asciz	"wrapping_sub"
.Linfo_string13:
	.asciz	"_RNvMs9_NtCs1R9DcZHJAgT_4core3numj14is_multiple_of"
.Linfo_string14:
	.asciz	"is_multiple_of"
.Linfo_string15:
	.asciz	"_RNvNtNtCs1R9DcZHJAgT_4core3str11validations15utf8_char_width"
.Linfo_string16:
	.asciz	"utf8_char_width"
.Linfo_string17:
	.asciz	"converts"
.Linfo_string18:
	.asciz	"slice"
.Linfo_string19:
	.asciz	"index"
.Linfo_string20:
	.asciz	"ptr"
.Linfo_string21:
	.asciz	"_RINvNtCs1R9DcZHJAgT_4core3ptr12align_offsethEB4_"
.Linfo_string22:
	.asciz	"align_offset<u8>"
.Linfo_string23:
	.asciz	"const_ptr"
.Linfo_string24:
	.asciz	"{impl#0}"
.Linfo_string25:
	.asciz	"_RNvMNtNtCs1R9DcZHJAgT_4core3ptr9const_ptrPh12align_offsetB6_"
.Linfo_string26:
	.asciz	"memchr"
.Linfo_string27:
	.asciz	"memchr_aligned"
.Linfo_string28:
	.asciz	"_RNvNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned7runtime"
.Linfo_string29:
	.asciz	"runtime"
.Linfo_string30:
	.asciz	"_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr18contains_zero_byte"
.Linfo_string31:
	.asciz	"contains_zero_byte"
.Linfo_string32:
	.asciz	"_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr12memchr_naive"
.Linfo_string33:
	.asciz	"memchr_naive"
.Linfo_string34:
	.asciz	"copy_from_slice_impl"
.Linfo_string35:
	.asciz	"len_mismatch_fail"
.Linfo_string36:
	.asciz	"do_panic"
.Linfo_string37:
	.asciz	"_RNvNvNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail8do_panic7runtime"
.Linfo_string38:
	.asciz	"_RNvNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail8do_panic"
.Linfo_string39:
	.asciz	"_RNvNtCs1R9DcZHJAgT_4core9panicking9panic_fmt"
.Linfo_string40:
	.asciz	"panic_fmt"
.Linfo_string41:
	.asciz	"_RNvNtNtCs1R9DcZHJAgT_4core3str8converts9from_utf8"
.Linfo_string42:
	.asciz	"from_utf8"
.Linfo_string43:
	.asciz	"_RNvNtNtCs1R9DcZHJAgT_4core5slice5index16slice_index_fail"
.Linfo_string44:
	.asciz	"slice_index_fail"
.Linfo_string45:
	.asciz	"_RNvNtCs1R9DcZHJAgT_4core9panicking18panic_bounds_check"
.Linfo_string46:
	.asciz	"panic_bounds_check"
.Linfo_string47:
	.asciz	"_RNvNtNtCs1R9DcZHJAgT_4core5slice6memchr14memchr_aligned"
.Linfo_string48:
	.asciz	"_RNvNvNtCs1R9DcZHJAgT_4core5slice20copy_from_slice_impl17len_mismatch_fail"
	.ident	"rustc version 1.99.0 (b940084d7 2026-09-28)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
