// Generated from the independently compiled layout witness; do not edit.
pub const PROCESS_BYTES: usize = 9832;
pub const PROCESS_PAGES: usize = 3;
pub const IMAGE_BYTES: usize = 472;
pub const IMAGE_PAGES: usize = 1;
pub const AUTHORITY_BYTES: usize = 928;
pub const AUTHORITY_PAGES: usize = 1;
pub const METADATA_PAGES: usize = 3;
