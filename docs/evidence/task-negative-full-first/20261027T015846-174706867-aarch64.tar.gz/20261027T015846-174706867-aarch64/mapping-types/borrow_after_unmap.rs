#![no_std]
#![forbid(unsafe_code)]
use hm_mappings::{Mapper, MappedPage, Frame, Pool};
use hm_kernel::frame_api::OwnedFrame;
use hm_kernel::mapping_api::OwnedMapping;
pub fn client(p: MappedPage<'_, '_>) -> u8 {
        let bytes = p.bytes(); let _f = p.unmap(); bytes[0]
    }
